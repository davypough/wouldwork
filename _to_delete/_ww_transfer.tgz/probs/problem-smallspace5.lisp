;;; Filename: problem-smallspace5.lisp


;;; Removes $occluder from beam-segment relation


(in-package :ww)  ;required

(ww-set *problem-name* smallspace5)

(ww-set *problem-type* planning)

(ww-set *solution-type* min-length)

(ww-set *tree-or-graph* graph)

(ww-set *depth-cutoff* 17)


(define-types
  agent       (agent1)
  gate        (gate1 gate2 gate3 gate4)
  connector   (connector1 connector2 connector3)
  transmitter (transmitter1 transmitter2)
  receiver    (receiver1 receiver2 receiver3 receiver4)
  hue         (blue red)  ;the color of a transmitter, receiver, or connector
  area        (area1 area2 area3 area4 area5)
  cargo       (either connector)  ;what an agent can pickup & carry
  beam        ()  ;the list of initial beams
  source      (either transmitter connector)  ;beam source
  target      (either connector receiver)  ;beam target
  occluder    (either cargo agent gate)  ;objects that can occlude a beam
  terminus    (either transmitter receiver connector)  ;what a connector can connect to
  fixture     (either transmitter receiver)
  zone        (either gate area))


(define-dynamic-relations  ;relations with fluents can be bound in rules--eg (bind (holds agent1 $any-cargo))
  (holds agent $cargo)  ;fluent because we need to sometimes lookup what is currently being held
  (loc (either agent cargo) $area)
  (paired terminus terminus)  ;potential beam between two terminus
  (active receiver)
  (open gate)
  (color connector $hue)
  (beam-segment> beam $source $target $rational $rational)  ;endpoint-x endpoint-y
  (current-beams $list))


(define-static-relations
  (coords> (either area fixture) $fixnum $fixnum)
  (controls receiver gate)
  (chroma fixture $hue)
  (gate-segment> gate $fixnum $fixnum $fixnum $fixnum)
  ;potential clear los from an area to a fixture
  (los0 area fixture)  
  (los1 area zone fixture)  ;los can be blocked either by a closed gate or object in an area
  ;potential visibility from an area to another area
  (visible0 area area)  
  (visible1 area zone area)
  ;potential accesibility to move from an area to another area
  (accessible0 area area)
  (accessible1 area gate area))


;;;; QUERY FUNCTIONS ;;;;


(define-query heuristic? ()
  ;; Estimates distance to goal based on agent's area and gate status
  ;; Lower values indicate states closer to goal or with more open gates
  (do (bind (loc agent1 $area))
      ;; Base distance: how many areas away from area5
      (assign $base-distance
        (cond ((eql $area 'area5) 0)    ; At goal
              ((eql $area 'area4) 1)    ; One area away
              ((eql $area 'area3) 2)    ; Two areas away
              ((eql $area 'area2) 3)    ; Three areas away
              ((eql $area 'area1) 4)    ; Four areas away
              (t 10)))                   ; Should not occur
      ;; Penalty for closed gates on the path forward
      (assign $penalty 0)
      ;; From area1, all gates ahead matter
      (if (or (eql $area 'area1) (eql $area 'area2) 
              (eql $area 'area3) (eql $area 'area4))
        (if (not (open gate1))
          (assign $penalty (+ $penalty 0.5))))
      ;; From area2 forward, gate2-4 matter
      (if (or (eql $area 'area2) (eql $area 'area3) (eql $area 'area4))
        (if (not (open gate2))
          (assign $penalty (+ $penalty 0.5))))
      ;; From area3 forward, gate3-4 matter
      (if (or (eql $area 'area3) (eql $area 'area4))
        (if (not (open gate3))
          (assign $penalty (+ $penalty 0.5))))
      ;; From area4, only gate4 matters
      (if (eql $area 'area4)
        (if (not (open gate4))
          (assign $penalty (+ $penalty 0.5))))
      ;; Return total heuristic value
      (+ $base-distance $penalty)))


(define-query get-current-beams ()
  (do (bind (current-beams $beams))
      (remove nil $beams)))  ; Filter out placeholders


(define-query beam-exists-p (?source ?target)
  ; Returns t if a beam already exists from ?source to ?target
  (exists (?b (get-current-beams))
    (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
         (eql $src ?source)
         (eql $tgt ?target))))


(define-query get-hue-if-source (?terminus)
  ;gets the hue of ?terminus if it is a source, else nil
  (or (and (transmitter ?terminus)
           (bind (chroma ?terminus $hue))
           $hue)
      (and (connector ?terminus)
           (bind (color ?terminus $hue))
           $hue)))


(define-query get-fixed-coordinates (?area/fixture)
  ;; Efficiently get coordinates for fixed objects
  (do (bind (coords> ?area/fixture $x $y))
      (values $x $y)))


(define-query get-coordinates (?object)
  ;; Finds coordinates for any arbitrary object
  (cond 
    ((or (area ?object) (fixture ?object))
     (bind (coords> ?object $x $y))
     (values $x $y))
    ((or (agent ?object) (and (cargo ?object) (not (holds agent1 ?object))))
     (bind (loc ?object $area))
     (bind (coords> $area $x $y))
     (values $x $y))
    (t (error "~%No coordinates found for ~A~%" ?object))))


(define-query beam-reaches-target (?source ?target)
  ; Returns t if a beam from ?source to ?target reaches ?target's coordinates
  (do (mv-assign ($target-x $target-y) (get-coordinates ?target))
      (exists (?b (get-current-beams))
        (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
             (eql $src ?source)
             (eql $tgt ?target)
             (= $end-x $target-x)
             (= $end-y $target-y)))))


(define-query los (?area ?fixture)
  (or (los0 ?area ?fixture)
      (exists (?zone zone)
        (and (los1 ?area ?zone ?fixture)
             (or (and (gate ?zone)
                      (open ?zone))
                 (and (area ?zone)
                      (not (exists (?obj (either agent cargo))
                             (loc ?obj ?zone)))))))))


(define-query visible (?area1 ?area2)
  (or (visible0 ?area1 ?area2)
      (exists (?zone zone)
        (and (visible1 ?area1 ?zone ?area2)
             (or (and (gate ?zone)
                      (open ?zone))
                 (and (area ?zone)
                      (not (exists (?obj (either agent cargo))
                             (loc ?obj ?zone)))))))))


(define-query accessible (?area1 ?area2)
  (or (accessible0 ?area1 ?area2)
      (exists (?g gate)  ;note that an area may be accessible through more than one gate
        (and (accessible1 ?area1 ?g ?area2)
             (open ?g)))))


(define-query vacant (?area)
  (not (exists (?cargo cargo)
         (loc ?cargo ?area))))


(define-query resolve-consensus-hue (?hue-list)
  ; Returns consensus hue from list of available hues, nil if no consensus
  (do (assign $unique-hues (remove-duplicates (remove nil ?hue-list)))
      (if (= (length $unique-hues) 1)
        (first $unique-hues)  ; Single unique hue (consensus achieved)
        nil)))               ; Multiple different hues or no hues (no consensus)


(define-query beam-segment-interference
    (?source-x ?source-y ?end-x ?end-y ?cross-x1 ?cross-y1 ?cross-x2 ?cross-y2)
  ; Determines if a cross segment (beam, gate, etc) interferes with the main beam-segment
  ; Returns the interference endpoint, or nil
  ; Step 1: Calculate direction vectors and displacement
  (do (assign $dx1 (- ?end-x ?source-x))    ; Beam direction x
      (assign $dy1 (- ?end-y ?source-y))    ; Beam direction y
      (assign $dx2 (- ?cross-x2 ?cross-x1)) ; Obstacle direction x
      (assign $dy2 (- ?cross-y2 ?cross-y1)) ; Obstacle direction y
      (assign $dx3 (- ?cross-x1 ?source-x)) ; Displacement x
      (assign $dy3 (- ?cross-y1 ?source-y)) ; Displacement y
      ;; Step 2: Calculate determinant for parallel line detection
      (assign $det (- (* $dy1 $dx2) (* $dx1 $dy2)))
      ;; Step 3: Handle parallel lines case
      (if (< (abs $det) 1e-10)
        (values nil nil nil)
        ;; Step 4: Solve for intersection parameters using Cramer's rule
        (do (assign $t (/ (- (* $dy3 $dx2) (* $dx3 $dy2)) $det))
            (assign $s (/ (- (* $dx1 $dy3) (* $dy1 $dx3)) $det))
            ;; Treat hits within 2% of either endpoint as "at the endpoint" => no interference
            (assign $eps 2e-2)  ; parameter-space epsilon (2%)
            ;; Step 5: Validate intersection lies well inside both segments
            (if (and (> $t $eps) (< $t (- 1.0 $eps))      ; main beam interior only
                     (> $s $eps) (< $s (- 1.0 $eps)))     ; cross segment interior only
              ;; Step 6: Calculate and return intersection coordinates
              (do (assign $int-x (+ ?source-x (* $t $dx1)))
                  (assign $int-y (+ ?source-y (* $t $dy1)))
                  (values $t $int-x $int-y))
              ;; No valid intersection within (epsilon-trimmed) interiors
              (values nil nil nil))))))


(define-query beam-segment-occlusion (?source-x ?source-y ?end-x ?end-y ?px ?py)
  ; Determines if an object in an area at (?px,?py) occludes a beam-segment with tolerance < 1.0
  ; Step 1: Calculate beam direction and length
  (do (assign $dx (- ?end-x ?source-x))
      (assign $dy (- ?end-y ?source-y))
      (assign $length-squared (+ (* $dx $dx) (* $dy $dy)))
      ;; Step 2: Handle degenerate case (zero-length beam)
      (if (< $length-squared 1e-10)
        ;; Check if point coincides with source/target
        (if (and (< (abs (- ?px ?source-x)) 1e-6)
                 (< (abs (- ?py ?source-y)) 1e-6))
          (values 0.0 ?source-x ?source-y)      ; Point at source
          (values nil nil nil))     ; Point not at degenerate beam
        ;; Step 3: Calculate projection parameter
        (do (assign $vx (- ?px ?source-x))   ; Vector from source to point
            (assign $vy (- ?py ?source-y))
            (assign $dot-product (+ (* $vx $dx) (* $vy $dy)))
            (assign $t (/ $dot-product $length-squared))
            ;; Step 4: Validate parameter within segment bounds
            (if (and (> $t 0.0) (< $t 1.0))
              ;; Step 5: Calculate closest point on beam to given point
              (do (assign $closest-x (+ ?source-x (* $t $dx)))
                  (assign $closest-y (+ ?source-y (* $t $dy)))
                  ;; Step 6: Calculate distance from point to beam
                  (assign $dist-x (- ?px $closest-x))
                  (assign $dist-y (- ?py $closest-y))
                  (assign $distance (sqrt (+ (* $dist-x $dist-x) 
                                          (* $dist-y $dist-y))))
                  ;; Step 7: Check if point is within intersection tolerance
                  (if (< $distance (+ 0.25d0 1d-6))  ; Tolerance for blocking the beam with epsilon
                    (values $t $closest-x $closest-y)  ; Point blocks beam
                    (values nil nil nil)))             ; Point too far from beam
              ;; Projection falls outside segment bounds
              (values nil nil nil))))))


(define-query find-first-obstacle-intersection (?source-x ?source-y ?target-x ?target-y)
  ; Establishes each beam's intended full path by finding intersections with static obstacles only
  ; Returns the endpoint coordinates where the beam terminates and what blocks it
  (do
    ;; Initialize closest intersection tracking
    (assign $closest-t 1.0)  ; Default to target if no intersections
    (assign $result-x ?target-x)   
    (assign $result-y ?target-y)
    ;; Check static obstacles only - exclude beams
    (doall (?obj occluder)
      (if (and ;; Type-specific coordinate binding and conditions
               (or (and (gate ?obj) 
                        (not (open ?obj))  ; Block UNLESS explicitly open
                        (bind (gate-segment> ?obj $x1 $y1 $x2 $y2)))
                   (and (or (cargo ?obj) (agent ?obj))
                        (bind (loc ?obj $area))
                        (bind (coords> $area $x1 $y1))
                        (assign $x2 $x1) (assign $y2 $y1)))
               ;; Endpoint exclusion logic for all obstacle types
               (not (or (and (= $x1 ?source-x) (= $y1 ?source-y))
                        (and (= $x2 ?source-x) (= $y2 ?source-y))
                        (and (= $x1 ?target-x) (= $y1 ?target-y))
                        (and (= $x2 ?target-x) (= $y2 ?target-y)))))
        ;; Calculate intersection with obstacle
        (do (mv-assign ($int-t $int-x $int-y)
              (if (and (= $x1 $x2) (= $y1 $y2))
                ;; Point occlusion (cargo)
                (beam-segment-occlusion ?source-x ?source-y ?target-x ?target-y $x1 $y1)
                ;; Line segment interference (gates)
                (beam-segment-interference ?source-x ?source-y ?target-x ?target-y $x1 $y1 $x2 $y2)))
            (if (and $int-t (< $int-t $closest-t))
              (do (assign $closest-t $int-t)
                  (assign $result-x $int-x)
                  (assign $result-y $int-y))))))
    ;; Return closest intersection coordinates
    (values $result-x $result-y)))


(define-query collect-all-beam-intersections ()
  ; Use current endpoints (actual segments), not intended targets
  ; Returns list of intersection records: ((beam1 beam2 intersection-x intersection-y t1 t2) ...)
  (do 
      ;; Build coordinate cache for all beam sources
      (assign $coord-cache (make-hash-table :test 'eq))
      (doall (?b (get-current-beams))
        (do (bind (beam-segment> ?b $src $tgt $end-x $end-y))
            ;; Cache source coordinates if not already cached
            (if (not (gethash $src $coord-cache))
              (do (mv-assign ($x $y) (get-coordinates $src))
                  (setf (gethash $src $coord-cache) (list $x $y))))))
      ;; Detect intersections using cached coordinates
      (doall (?b1 (get-current-beams))
        (doall (?b2 (get-current-beams))
          (if (and (different ?b1 ?b2)
                   (string< (symbol-name ?b1) (symbol-name ?b2))) ; Avoid duplicate pairs
            (do (bind (beam-segment> ?b1 $src1 $tgt1 $end1-x $end1-y))
                (bind (beam-segment> ?b2 $src2 $tgt2 $end2-x $end2-y))
                (assign $src1-coords (gethash $src1 $coord-cache))
                (assign $src1-x (first $src1-coords))
                (assign $src1-y (second $src1-coords))
                (assign $tgt1-x $end1-x)
                (assign $tgt1-y $end1-y)
                (assign $src2-coords (gethash $src2 $coord-cache))
                (assign $src2-x (first $src2-coords))
                (assign $src2-y (second $src2-coords))
                (assign $tgt2-x $end2-x)
                (assign $tgt2-y $end2-y)
                ;; Check intersection between current segments (not intended paths)
                (mv-assign ($t1 $int-x $int-y)
                  (beam-segment-interference
                    $src1-x $src1-y $tgt1-x $tgt1-y
                    $src2-x $src2-y $tgt2-x $tgt2-y))
                (if $t1
                  (do
                    ;; Get t2 parameter by checking beam2 vs beam1
                    (mv-assign ($t2 $int-x2 $int-y2)
                      (beam-segment-interference
                        $src2-x $src2-y $tgt2-x $tgt2-y
                        $src1-x $src1-y $tgt1-x $tgt1-y))
                    ;; Only push if both intersections valid
                    (if $t2
                      (push (list ?b1 ?b2 $int-x $int-y $t1 $t2) $intersections))))))))
      $intersections))


(define-query connectable (?area ?terminus)
  (or
    ;; Case 1: Transmitters and receivers (fixtures) use static line-of-sight
    (and (fixture ?terminus)
         (los ?area ?terminus)
         ;; Additional validation: verify geometric beam path is clear
         (mv-assign ($source-x $source-y) (get-fixed-coordinates ?area))
         (mv-assign ($target-x $target-y) (get-coordinates ?terminus))
         (mv-assign ($end-x $end-y)
           (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
         ;; Verify beam reaches fixture
         (= $end-x $target-x)
         (= $end-y $target-y))
    ;; Case 2: Connectors require geometric beam path validation
    ;; Must verify actual beam reaches target through dynamic obstacles
    (and (connector ?terminus)
         (exists (?target-area area)
           (and (loc ?terminus ?target-area)
                ;; Verify areas are gate-visible
                (visible ?area ?target-area)
                ;; Get source coordinates
                (mv-assign ($source-x $source-y) (get-fixed-coordinates ?area))
                ;; Get target connector coordinates
                (mv-assign ($target-x $target-y) (get-coordinates ?terminus))
                ;; Calculate where beam actually terminates
                (mv-assign ($end-x $end-y)
                  (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
                ;; Verify beam reaches target
                (= $end-x $target-x)
                (= $end-y $target-y))))))


(define-query receiver-beam-reaches (?receiver)
  ; Returns t if a color-matching beam reaches the receiver
  (do
    (mv-assign ($r-x $r-y) (get-fixed-coordinates ?receiver))
    (bind (chroma ?receiver $required-hue))
    (exists (?b (get-current-beams))
      (and (bind (beam-segment> ?b $source $target $end-x $end-y))
           (= $end-x $r-x)
           (= $end-y $r-y)
           ;; Get hue from source
           (or (bind (chroma $source $source-hue))
               (bind (color $source $source-hue)))
           (eql $source-hue $required-hue)))))


(define-query connector-has-beam-power (?connector ?hue)
  ; Returns t if a beam with matching hue reaches the connector at its current coordinates
  (do
    (mv-assign ($c-x $c-y) (get-coordinates ?connector))
    (exists (?b (get-current-beams))
      (and (bind (beam-segment> ?b $source $target $end-x $end-y))
           (eql $target ?connector)  ; Beam must target this connector
           (= $end-x $c-x)            ; Beam must reach connector coordinates
           (= $end-y $c-y)
           ;; Verify source has matching hue
           (or (bind (chroma $source $source-hue))
               (bind (color $source $source-hue)))
           (eql $source-hue ?hue)))))


(define-query connector-is-powered-by (?connector ?potential-source)
  ;; Returns t if ?connector is currently receiving power from ?potential-source
  ;; This prevents creating reciprocal beams back to the power source
  (and (connector ?connector)
       (bind (color ?connector $conn-hue))  ; Connector must be active
       ;; Check if a beam exists from ?potential-source to ?connector
       (exists (?b (get-current-beams))
         (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
              (eql $src ?potential-source)
              (eql $tgt ?connector)
              ;; Verify beam actually reaches connector's coordinates
              (mv-assign ($conn-x $conn-y) (get-coordinates ?connector))
              (= $end-x $conn-x)
              (= $end-y $conn-y)
              ;; Verify source has matching hue (confirming power flow)
              (or (bind (chroma $src $src-hue))     ; Transmitter
                  (bind (color $src $src-hue)))     ; Active connector
              (eql $src-hue $conn-hue)))))


;;;; UPDATE FUNCTIONS ;;;;


(define-update deactivate-receiver! (?receiver)
  (do (not (active ?receiver))
      (doall (?g gate)
        (if (controls ?receiver ?g)
          (not (open ?g))))))


(define-update activate-reachable-connectors! ()
  ;; Returns t if any connector was activated, nil otherwise
  ;; Now uses consensus logic: connector only activates if ALL reaching beams have same hue
  (do
    (assign $activated-any nil)
    (doall (?c connector)
      (if (not (bind (color ?c $existing-hue)))
        (do
          ;; Collect all hues from beams that reach this connector
          (assign $reaching-hues nil)
          ;; Check all paired termini that could be sources
          (doall (?src terminus)
            (if (or (paired ?c ?src) (paired ?src ?c))  ; Pairing exists (bidirectional)
              (do
                ;; Get source hue if it's an active source (transmitter or powered connector)
                (assign $src-hue (get-hue-if-source ?src))
                ;; If source has hue AND beam reaches connector, collect hue
                (if (and $src-hue
                         (beam-reaches-target ?src ?c))
                  (push $src-hue $reaching-hues)))))
          ;; Check for consensus among all reaching hues
          (assign $consensus-hue (resolve-consensus-hue $reaching-hues))
          ;; Only activate if consensus achieved (all hues identical)
          (if $consensus-hue
            (do (color ?c $consensus-hue)
                (assign $activated-any t))))))
    $activated-any))


(define-update deactivate-unreachable-connectors! ()
  ;; Returns t if any connector was deactivated, nil otherwise
  ;; Beam removal now handled by Phase 0 Part B in next iteration
  (do
    (assign $deactivated-any nil)
    (doall (?c connector)
      (if (bind (color ?c $c-hue))
        ;; Connector is currently active - verify it still has power
        (if (not (connector-has-beam-power ?c $c-hue))
          ;; Lost power - deactivate (beams removed by Phase 0 next iteration)
          (do
            (not (color ?c $c-hue))
            (assign $deactivated-any t)))))
    $deactivated-any))


(define-update recalculate-all-beams! ()
  (do (doall (?b (get-current-beams))
        (do (bind (beam-segment> ?b $source $target $old-end-x $old-end-y))
            ;; Get source coordinates
            (mv-assign ($source-x $source-y) (get-coordinates $source))
            ;; Get target coordinates  
            (mv-assign ($target-x $target-y) (get-coordinates $target))
            ;; Recalculate endpoint using current gate/beam states
            (mv-assign ($new-end-x $new-end-y)
                    (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
            ;; Update beam segment if endpoint changed
            (if (or (/= $new-end-x $old-end-x)
                    (/= $new-end-y $old-end-y))
              (beam-segment> ?b $source $target $new-end-x $new-end-y))))
      nil))  ;must return nil


(define-update update-beams-if-interference! ()
  ;; Simultaneously resolves all beam-beam intersections by truncating interfering beams
  ;; at their intersection points, eliminating sequential processing dependencies
  (do
    ;; Phase 1: For each beam, determine its closest intersection point
    (doall (?b (get-current-beams))
      (do (bind (beam-segment> ?b $src $tgt $old-end-x $old-end-y))
          (mv-assign ($src-x $src-y) (get-coordinates $src))
          (mv-assign ($tgt-x $tgt-y) (get-coordinates $tgt))
          ;; Calculate t-parameter for current endpoint position
          (assign $dx (- $tgt-x $src-x))
          (assign $dy (- $tgt-y $src-y))
          (assign $length-sq (+ (* $dx $dx) (* $dy $dy)))
          (assign $curr-dx (- $old-end-x $src-x))
          (assign $curr-dy (- $old-end-y $src-y))
          (assign $dot (+ (* $curr-dx $dx) (* $curr-dy $dy)))
          (assign $closest-t (/ $dot $length-sq))
          (assign $new-end-x $old-end-x)
          (assign $new-end-y $old-end-y)
          ;; Check all intersections involving this beam
          (ww-loop for $intersection in (collect-all-beam-intersections) do
                (assign $beam1 (first $intersection))
                (assign $beam2 (second $intersection))
                (assign $int-x (third $intersection))
                (assign $int-y (fourth $intersection))
                (assign $t1 (fifth $intersection))
                (assign $t2 (sixth $intersection))
                ;; Determine which t-parameter applies to this beam and identify blocking beam
                (if (eql ?b $beam1)
                  (do (assign $t-param $t1)
                      (assign $blocking-beam $beam2))
                  (if (eql ?b $beam2)
                    (do (assign $t-param $t2)
                        (assign $blocking-beam $beam1))
                    (assign $t-param nil)))
                ;; Update closest intersection if this one is closer
                (if (and $t-param (< $t-param $closest-t))
                  (do (assign $closest-t $t-param)
                      (assign $new-end-x $int-x)
                      (assign $new-end-y $int-y))))
          ;; Phase 2: Atomically update beam segment if endpoint changed
          (if (or (/= $new-end-x $old-end-x) 
                  (/= $new-end-y $old-end-y))
            (beam-segment> ?b $src $tgt $new-end-x $new-end-y))))
    nil))  ;must return nil


(define-update create-missing-beams! ()
  ;; Creates beams for active sources paired with targets where no beam exists yet
  ;; Returns t if any beams were created, nil otherwise
  (do
    (assign $created-any nil)
    (doall (?src terminus)
      (doall (?tgt terminus)
        (if (and (different ?src ?tgt)
                 (or (paired ?src ?tgt) (paired ?tgt ?src)))  ; Pairing exists (bidirectional)
          ;; Have a pairing - check if source can emit and beam should exist
          (do (assign $source-hue (get-hue-if-source ?src))
              (if (and $source-hue                              ; Source is active
                       (target ?tgt)
                       (not (beam-exists-p ?src ?tgt))          ; Beam doesn't exist yet
                       (not (connector-is-powered-by ?src ?tgt))) ; ?tgt is not powering ?src
                ;; Create beam: source is transmitter (always active) or powered connector
                (do (create-beam-segment-p! ?src ?tgt)
                    (assign $created-any t)))))))
    $created-any))


(define-update remove-orphaned-beams! ()
  ;; Removes beams whose pairing no longer exists or whose source lost power
  ;; Returns t if any beams were removed, nil otherwise
  (do
    (assign $removed-any nil)
    (doall (?b (get-current-beams))
      (do (bind (beam-segment> ?b $src $tgt $end-x $end-y))
          ;; Determine if beam should be removed
          (assign $should-remove nil)
          ;; Reason 1: Pairing no longer exists (check bidirectional)
          (if (not (or (paired $src $tgt) (paired $tgt $src)))
            (assign $should-remove t))
          ;; Reason 2: Source is connector that lost power (no color binding)
          (if (and (connector $src)
                   (not (bind (color $src $hue))))
            (assign $should-remove t))
          ;; Execute removal if needed
          (if $should-remove
            (do (remove-beam-segment-p! ?b)
                (assign $removed-any t)))))
    $removed-any))


(define-update deactivate-receivers-that-lost-power! ()
  ;; Returns t if any receiver was deactivated, nil otherwise
  (do
    (doall (?r receiver)
      (if (and (active ?r)
               (not (receiver-beam-reaches ?r)))
        (do (deactivate-receiver! ?r)
            (assign $any-deactivated t))))
    $any-deactivated))


(define-update activate-receivers-that-gained-power! ()
  ;; Returns t if any receiver was activated, nil otherwise
  (do
    (doall (?r receiver)
      (if (and (not (active ?r))
               (receiver-beam-reaches ?r))
        (do (active ?r)
            (doall (?g gate)
              (if (controls ?r ?g)
                (open ?g)))
            (assign $any-activated t))))
    $any-activated))


(define-update propagate-consequences! ()
  ;; All functions must execute in order; returns t if any change occurred
  (some #'identity
        (mapcar (lambda (fn) (funcall fn state))
                (list #'create-missing-beams!
                      #'remove-orphaned-beams!
                      #'recalculate-all-beams!          ;always returns nil
                      #'update-beams-if-interference!   ;always returns nil
                      #'deactivate-receivers-that-lost-power!
                      #'deactivate-unreachable-connectors!
                      #'activate-receivers-that-gained-power!
                      #'activate-reachable-connectors!))))


(define-update propagate-changes! ()
  (ww-loop for $iteration from 1 to 10
           do (if (not (propagate-consequences!))
                (return))  ;convergence achieved
           finally (inconsistent-state)))  ;no convergence, mark state inconsistent


(define-update create-beam-segment-p! (?source ?target)
  ; Create a beam segment from source, and return the new beam's name.
  (do
    ;; Generate new beam entity with next available index
    (bind (current-beams $current-beams))
    (assign $next-index (1+ (length $current-beams)))
    (assign $new-beam (intern (format nil "BEAM~D" $next-index)))
    (register-dynamic-object $new-beam 'beam)
    ;; Calculate beam path and intersection
    (mv-assign ($source-x $source-y) (get-coordinates ?source))
    (mv-assign ($target-x $target-y) (get-coordinates ?target))
    (mv-assign ($end-x $end-y) (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
    ;; Create beam relations
    (beam-segment> $new-beam ?source ?target $end-x $end-y)
    (current-beams (cons $new-beam $current-beams))
    $new-beam))


(define-update remove-beam-segment-p! (?beam)
  (if (bind (beam-segment> ?beam $source $target $end-x $end-y))
    (do (not (beam-segment> ?beam $source $target $end-x $end-y))
        (bind (current-beams $beams))
        (current-beams (substitute nil ?beam $beams))
        t)
    nil))


;;;; ACTIONS ;;;;


(define-action connect-to-1-terminus
    1
  (?terminus terminus)
  (and (bind (holds agent1 $cargo))
       (connector $cargo)
       (bind (loc agent1 $area))
       (vacant $area)
       (connectable $area ?terminus))
  ($cargo ?terminus $area)
  (assert (not (holds agent1 $cargo))
          (loc $cargo $area)
          (paired ?terminus $cargo)
          (propagate-changes!)))     ; PROPAGATION: handle all consequences


(define-action connect-to-2-terminus
    1
  (combination (?terminus1 ?terminus2) terminus)
  (and (bind (holds agent1 $cargo))
       (connector $cargo)
       (bind (loc agent1 $area))
       (vacant $area)
       (connectable $area ?terminus1)
       (connectable $area ?terminus2))
  ($cargo ?terminus1 ?terminus2 $area)
  (assert (not (holds agent1 $cargo))
          (loc $cargo $area)
          (paired $cargo ?terminus1)
          (paired $cargo ?terminus2)
          (propagate-changes!)))


(define-action connect-to-3-terminus
    1
  (combination (?terminus1 ?terminus2 ?terminus3) terminus)
  (and (bind (holds agent1 $cargo))
       (connector $cargo)
       (bind (loc agent1 $area))
       (vacant $area)
       (connectable $area ?terminus1)
       (connectable $area ?terminus2)
       (connectable $area ?terminus3))
  ($cargo ?terminus1 ?terminus2 ?terminus3 $area)
  (assert (not (holds agent1 $cargo))
          (loc $cargo $area)
          (paired $cargo ?terminus1)
          (paired $cargo ?terminus2)
          (paired $cargo ?terminus3)
          (propagate-changes!))) 


(define-action pickup-connector
    1
  (?connector connector)
  (and (not (bind (holds agent1 $cargo)))
       (bind (loc agent1 $area))
       (loc ?connector $area))
  (?connector $area)
  (assert (holds agent1 ?connector)
          (not (loc ?connector $area))
          ;; Remove pairings before convergence (Phase 0 needs this)
          (doall (?t terminus)
            (if (paired ?connector ?t)
              (not (paired ?connector ?t))))
          ;; Deactivate connector if active
          (if (bind (color ?connector $hue))
            (not (color ?connector $hue)))
          (propagate-changes!)))


(define-action drop
    1
  ()
  (and (bind (holds agent1 $cargo))  ;if not holding anything, then bind statement returns nil
       (bind (loc agent1 $area))  ;agent1 is always located somewhere
       (vacant $area))
  ($cargo $area)
  (assert (not (holds agent1 $cargo))
          (loc $cargo $area)
          (propagate-changes!)))


(define-action move
    1
  (?area2 area)
  (and (bind (loc agent1 $area1))
       (different $area1 ?area2)
       (accessible $area1 ?area2))
  ($area1 ?area2)
  (assert (loc agent1 ?area2)
          (propagate-changes!)))


;;;; INITIALIZATION ;;;;


(define-init
  ;dynamic
  (loc agent1 area1)
  (loc connector1 area1)
  (loc connector2 area2)
  (loc connector3 area3)
  (current-beams ())
  ;static
  (coords> area1 18 10)
  (coords> area2 1 16)
  (coords> area3 17 18)
  (coords> area4 27 11)
  (coords> area5 9 5)
  (accessible1 area1 gate1 area2)
  (accessible1 area2 gate2 area3)
  (accessible1 area3 gate3 area4)
  (accessible1 area4 gate4 area5)
  (chroma transmitter1 blue)
  (chroma transmitter2 red)
  (chroma receiver1 blue)
  (chroma receiver2 red)
  (chroma receiver3 blue)
  (chroma receiver4 red)
  (gate-segment> gate1 8 15 12 15)
  (gate-segment> gate2 15 17 15 22)
  (gate-segment> gate3 30 15 35 15)
  (gate-segment> gate4 30 7 35 7)
  (controls receiver1 gate1)
  (controls receiver2 gate2)
  (controls receiver3 gate3)
  (controls receiver4 gate4)
  (coords> transmitter1 13 7)
  (coords> transmitter2 7 15)
  (coords> receiver1 13 15)
  (coords> receiver2 20 24)
  (coords> receiver3 36 12)
  (coords> receiver4 11 0)
  ;los is from an area to a fixture
  (los0 area1 transmitter1)
  (los0 area1 receiver1)
  (los0 area1 receiver2)
  (los1 area1 area4 receiver3)
  (los0 area2 transmitter2)
  (los0 area2 transmitter1)
  (los1 area2 gate2 receiver2)
  (los0 area3 receiver2)
  (los1 area3 gate2 transmitter2)
  (los0 area4 receiver3)
  (los0 area4 receiver1)
  (los0 area4 transmitter1)
  (los0 area4 receiver4)
  ;visibility is from an area to an area 
  (visible0 area1 area2)
  (visible0 area1 area3)
  (visible0 area1 area4)
  (visible1 area2 gate2 area3)
  (visible0 area3 area4))


;;;; GOAL ;;;;

(define-goal
  (and (loc agent1 area3) (holds agent1 connector3))
)


;;;; EXAMPLE SOLUTION ;;;;
#|
Number of steps in a minimum path length solution = 13

A minimum length solution path from start state to goal state:
(0.0 (START-STATE))
((CURRENT-BEAMS NIL) (LOC AGENT1 AREA1) (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (LOC CONNECTOR3 AREA3))

(1.0 (PICKUP-CONNECTOR CONNECTOR1 AREA1))
((CURRENT-BEAMS NIL) (HOLDS AGENT1 CONNECTOR1) (LOC AGENT1 AREA1) (LOC CONNECTOR2 AREA2) (LOC CONNECTOR3 AREA3))

(2.0 (CONNECT-TO-2-TERMINUS CONNECTOR1 RECEIVER1 TRANSMITTER1 AREA1))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM1 TRANSMITTER1 CONNECTOR1 18 10) (BEAM-SEGMENT BEAM2 CONNECTOR1 RECEIVER1 13 15)
 (COLOR CONNECTOR1 BLUE) (CURRENT-BEAMS (BEAM2 BEAM1)) (LOC AGENT1 AREA1) (LOC CONNECTOR2 AREA2) (LOC CONNECTOR3 AREA3)
 (LOC CONNECTOR1 AREA1) (OPEN GATE1) (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED TRANSMITTER1 CONNECTOR1)
 (PAIRED CONNECTOR1 TRANSMITTER1))

(3.0 (MOVE AREA1 AREA2))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM1 TRANSMITTER1 CONNECTOR1 18 10) (BEAM-SEGMENT BEAM2 CONNECTOR1 RECEIVER1 13 15)
 (COLOR CONNECTOR1 BLUE) (CURRENT-BEAMS (BEAM2 BEAM1)) (LOC AGENT1 AREA2) (LOC CONNECTOR2 AREA2) (LOC CONNECTOR3 AREA3)
 (LOC CONNECTOR1 AREA1) (OPEN GATE1) (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED TRANSMITTER1 CONNECTOR1)
 (PAIRED CONNECTOR1 TRANSMITTER1))

(4.0 (PICKUP-CONNECTOR CONNECTOR2 AREA2))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM1 TRANSMITTER1 CONNECTOR1 18 10) (BEAM-SEGMENT BEAM2 CONNECTOR1 RECEIVER1 13 15)
 (COLOR CONNECTOR1 BLUE) (CURRENT-BEAMS (BEAM2 BEAM1)) (HOLDS AGENT1 CONNECTOR2) (LOC AGENT1 AREA2) (LOC CONNECTOR3 AREA3)
 (LOC CONNECTOR1 AREA1) (OPEN GATE1) (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED TRANSMITTER1 CONNECTOR1)
 (PAIRED CONNECTOR1 TRANSMITTER1))

(5.0 (CONNECT-TO-1-TERMINUS CONNECTOR2 TRANSMITTER1 AREA2))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM1 TRANSMITTER1 CONNECTOR1 18 10) (BEAM-SEGMENT BEAM2 CONNECTOR1 RECEIVER1 13 15)
 (BEAM-SEGMENT BEAM3 TRANSMITTER1 CONNECTOR2 1 16) (COLOR CONNECTOR1 BLUE) (COLOR CONNECTOR2 BLUE) (CURRENT-BEAMS (BEAM3 BEAM2 BEAM1))
 (LOC AGENT1 AREA2) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (OPEN GATE1) (PAIRED RECEIVER1 CONNECTOR1)
 (PAIRED CONNECTOR1 RECEIVER1) (PAIRED TRANSMITTER1 CONNECTOR1) (PAIRED CONNECTOR1 TRANSMITTER1) (PAIRED CONNECTOR2 TRANSMITTER1)
 (PAIRED TRANSMITTER1 CONNECTOR2))

(6.0 (MOVE AREA2 AREA1))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM1 TRANSMITTER1 CONNECTOR1 18 10) (BEAM-SEGMENT BEAM2 CONNECTOR1 RECEIVER1 13 15)
 (BEAM-SEGMENT BEAM3 TRANSMITTER1 CONNECTOR2 1 16) (COLOR CONNECTOR1 BLUE) (COLOR CONNECTOR2 BLUE) (CURRENT-BEAMS (BEAM3 BEAM2 BEAM1))
 (LOC AGENT1 AREA1) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (OPEN GATE1) (PAIRED RECEIVER1 CONNECTOR1)
 (PAIRED CONNECTOR1 RECEIVER1) (PAIRED TRANSMITTER1 CONNECTOR1) (PAIRED CONNECTOR1 TRANSMITTER1) (PAIRED CONNECTOR2 TRANSMITTER1)
 (PAIRED TRANSMITTER1 CONNECTOR2))

(7.0 (PICKUP-CONNECTOR CONNECTOR1 AREA1))
((BEAM-SEGMENT BEAM3 TRANSMITTER1 CONNECTOR2 1 16) (COLOR CONNECTOR2 BLUE) (CURRENT-BEAMS (BEAM3 NIL NIL)) (HOLDS AGENT1 CONNECTOR1)
 (LOC AGENT1 AREA1) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR2 AREA2) (PAIRED CONNECTOR2 TRANSMITTER1) (PAIRED TRANSMITTER1 CONNECTOR2))

(8.0 (CONNECT-TO-3-TERMINUS CONNECTOR1 CONNECTOR2 RECEIVER2 RECEIVER1 AREA1))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM3 TRANSMITTER1 CONNECTOR2 1 16) (BEAM-SEGMENT BEAM4 CONNECTOR2 CONNECTOR1 18 10)
 (BEAM-SEGMENT BEAM5 CONNECTOR1 RECEIVER1 13 15) (BEAM-SEGMENT BEAM6 CONNECTOR1 RECEIVER2 20 24) (COLOR CONNECTOR2 BLUE)
 (COLOR CONNECTOR1 BLUE) (CURRENT-BEAMS (BEAM6 BEAM5 BEAM4 BEAM3 NIL NIL)) (LOC AGENT1 AREA1) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR2 AREA2)
 (LOC CONNECTOR1 AREA1) (OPEN GATE1) (PAIRED CONNECTOR2 TRANSMITTER1) (PAIRED TRANSMITTER1 CONNECTOR2) (PAIRED CONNECTOR2 CONNECTOR1)
 (PAIRED CONNECTOR1 CONNECTOR2) (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2) (PAIRED RECEIVER1 CONNECTOR1)
 (PAIRED CONNECTOR1 RECEIVER1))

(9.0 (MOVE AREA1 AREA2))
((ACTIVE RECEIVER1) (BEAM-SEGMENT BEAM3 TRANSMITTER1 CONNECTOR2 1 16) (BEAM-SEGMENT BEAM4 CONNECTOR2 CONNECTOR1 18 10)
 (BEAM-SEGMENT BEAM5 CONNECTOR1 RECEIVER1 13 15) (BEAM-SEGMENT BEAM6 CONNECTOR1 RECEIVER2 20 24) (COLOR CONNECTOR2 BLUE)
 (COLOR CONNECTOR1 BLUE) (CURRENT-BEAMS (BEAM6 BEAM5 BEAM4 BEAM3 NIL NIL)) (LOC AGENT1 AREA2) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR2 AREA2)
 (LOC CONNECTOR1 AREA1) (OPEN GATE1) (PAIRED CONNECTOR2 TRANSMITTER1) (PAIRED TRANSMITTER1 CONNECTOR2) (PAIRED CONNECTOR2 CONNECTOR1)
 (PAIRED CONNECTOR1 CONNECTOR2) (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2) (PAIRED RECEIVER1 CONNECTOR1)
 (PAIRED CONNECTOR1 RECEIVER1))

(10.0 (PICKUP-CONNECTOR CONNECTOR2 AREA2))
((CURRENT-BEAMS (NIL NIL NIL NIL NIL NIL)) (HOLDS AGENT1 CONNECTOR2) (LOC AGENT1 AREA2) (LOC CONNECTOR3 AREA3) (LOC CONNECTOR1 AREA1)
 (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2) (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1))

(11.0 (CONNECT-TO-2-TERMINUS CONNECTOR2 CONNECTOR1 TRANSMITTER2 AREA2))
((ACTIVE RECEIVER2) (BEAM-SEGMENT BEAM7 TRANSMITTER2 CONNECTOR2 1 16) (BEAM-SEGMENT BEAM8 CONNECTOR2 CONNECTOR1 18 10)
 (BEAM-SEGMENT BEAM9 CONNECTOR1 RECEIVER1 13 15) (BEAM-SEGMENT BEAM10 CONNECTOR1 RECEIVER2 20 24) (COLOR CONNECTOR2 RED)
 (COLOR CONNECTOR1 RED) (CURRENT-BEAMS (BEAM10 BEAM9 BEAM8 BEAM7 NIL NIL NIL NIL NIL NIL)) (LOC AGENT1 AREA2) (LOC CONNECTOR3 AREA3)
 (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (OPEN GATE2) (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2)
 (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED CONNECTOR1 CONNECTOR2) (PAIRED CONNECTOR2 CONNECTOR1)
 (PAIRED TRANSMITTER2 CONNECTOR2) (PAIRED CONNECTOR2 TRANSMITTER2))

(12.0 (MOVE AREA2 AREA3))
((ACTIVE RECEIVER2) (BEAM-SEGMENT BEAM7 TRANSMITTER2 CONNECTOR2 1 16) (BEAM-SEGMENT BEAM8 CONNECTOR2 CONNECTOR1 18 10)
 (BEAM-SEGMENT BEAM9 CONNECTOR1 RECEIVER1 13 15) (BEAM-SEGMENT BEAM10 CONNECTOR1 RECEIVER2 20 24) (COLOR CONNECTOR2 RED)
 (COLOR CONNECTOR1 RED) (CURRENT-BEAMS (BEAM10 BEAM9 BEAM8 BEAM7 NIL NIL NIL NIL NIL NIL)) (LOC AGENT1 AREA3) (LOC CONNECTOR3 AREA3)
 (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (OPEN GATE2) (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2)
 (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED CONNECTOR1 CONNECTOR2) (PAIRED CONNECTOR2 CONNECTOR1)
 (PAIRED TRANSMITTER2 CONNECTOR2) (PAIRED CONNECTOR2 TRANSMITTER2))

(13.0 (PICKUP-CONNECTOR CONNECTOR3 AREA3))
((ACTIVE RECEIVER2) (BEAM-SEGMENT BEAM7 TRANSMITTER2 CONNECTOR2 1 16) (BEAM-SEGMENT BEAM8 CONNECTOR2 CONNECTOR1 18 10)
 (BEAM-SEGMENT BEAM9 CONNECTOR1 RECEIVER1 13 15) (BEAM-SEGMENT BEAM10 CONNECTOR1 RECEIVER2 20 24) (COLOR CONNECTOR2 RED)
 (COLOR CONNECTOR1 RED) (CURRENT-BEAMS (BEAM10 BEAM9 BEAM8 BEAM7 NIL NIL NIL NIL NIL NIL)) (HOLDS AGENT1 CONNECTOR3) (LOC AGENT1 AREA3)
 (LOC CONNECTOR1 AREA1) (LOC CONNECTOR2 AREA2) (OPEN GATE2) (PAIRED RECEIVER2 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER2)
 (PAIRED RECEIVER1 CONNECTOR1) (PAIRED CONNECTOR1 RECEIVER1) (PAIRED CONNECTOR1 CONNECTOR2) (PAIRED CONNECTOR2 CONNECTOR1)
 (PAIRED TRANSMITTER2 CONNECTOR2) (PAIRED CONNECTOR2 TRANSMITTER2))


Evaluation took:
  0.938 seconds of real time
  0.937500 seconds of total run time (0.703125 user, 0.234375 system)
  [ Real times consist of 0.017 seconds GC time, and 0.921 seconds non-GC time. ]
  [ Run times consist of 0.015 seconds GC time, and 0.923 seconds non-GC time. ]
  100.00% CPU
  2,990,670,608 processor cycles
  1,337,954,240 bytes consed
|#
