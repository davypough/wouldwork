;;; Filename: ww-utilities.lisp

;;; Collection of utilities for the Wouldwork Planner.


(in-package :ut)


(set-pprint-dispatch '(array * (* *))
  (lambda (stream array)
    "User friendly printout for a state representation containing a 2D array."
    (declare (type simple-array array))
    (loop for i below (first (array-dimensions array))
      do (format stream "~%    ")
         (loop for j below (second (array-dimensions array))
           do (let ((cell (aref array i j)))
                (format stream "~A" cell))))))


(defmacro if-it (form then &optional else)
  "Binds the variable 'it' to the result of evaluating the form,
   which can then be used subsequently in the then or else clauses."
  `(let ((it ,form))
     (if it ,then ,else)))


(defmacro prt (&rest forms)
  "Print the names & values of given forms (ie,variables or accessors).
   Can wrap around an expression, returning its value."
  `(progn ,@(loop for form in forms
              collect `(format t "~&  ~S => ~S~%" ',form ,form))
          ,@(last `,forms)))


(defmacro prt-if (&rest args)
  "Conditional prt--eg, (ut::prt-if (?x 3) (?y 'abc) (ut::prt 'printing-x&y ?x ?y))"
  (let ((conditions '())
        (body-expr (car (last args))))
    ;; Parse condition pairs from beginning
    (loop for arg in (butlast args)
          do (assert (and (listp arg) (= (length arg) 2)) ()
                     "Each condition must be a 2-element list: ~A" arg)
             (push arg conditions))
    ;; Validate requirements
    (assert (> (length conditions) 0) () "At least one condition required")
    (assert body-expr () "Body expression required")
    ;; Generate conditional execution
    `(when (and ,@(mapcar (lambda (condition)
                           `(eql ,(first condition) ,(second condition)))
                         (reverse conditions)))
       ,body-expr)))


(defmacro mvb (vars values-form &rest body)
  "Abbreviation for multiple-value-bind."
  `(multiple-value-bind ,vars ,values-form ,@body))


(defmacro mvs (vars values-form &rest body)
  "Abbreviation for multiple-value-setq."
  `(multiple-value-setq ,vars ,values-form ,@body))


(define-modify-macro sortf (function &rest sort-key)  ;can include function in &rest
  sort
  "Modifies a referenced sequence by sorting it.")


(defun forget (sym)
  "Removes a symbol from the current package."
  (declare (type symbol sym))
  (makunbound sym)
  (fmakunbound sym)
  (setf (symbol-plist sym) nil))
  

(defun sort-symbols (list-of-symbols)
  "Sorts a list of symbols alphabetically."
  (sort (copy-list list-of-symbols) #'string< :key #'symbol-name))


(defun merge-sort (item items predicate)
  "Adds an item to list of items sorted."
  (declare (type function predicate))
  (merge 'list (list item) (copy-list items) predicate))
  
  
(defun remove-at-indexes (idxs lst)
  "Removes items at given indexes from a list."
  (multiple-value-bind (remaining removed)
      (split-at-indexes idxs lst)
    (declare (ignore removed))
    remaining))


(defun collect-at-indexes (idxs lst)
  "Collect items at given indexes from a list."
  (multiple-value-bind (remaining removed)
      (split-at-indexes idxs lst)
    (declare (ignore remaining))
    removed))


(defun split-at-indexes (idxs lst)
  "Returns two values: elements not at IDXS, and elements at IDXS."
  (let ((sorted-idxs (sort (copy-list idxs) #'<)))
    (loop with next-idxs = sorted-idxs
          with keep = nil
          with pick = nil
          for i from 0
          for elt in lst
          do (if (and next-idxs (= i (first next-idxs)))
                 (progn
                   (push elt pick)
                   (pop next-idxs))
                 (push elt keep))
          finally (return (values (nreverse keep) (nreverse pick))))))


(defun subst-items-at-ascending-indexes (items idxs lst)
  "Substitutes for elements at given indexes in a list.
   Indexes & items must correspond and be in ascending order."
  (loop for i from 0
    for elt in lst
    if (and idxs (= i (first idxs)))
      collect (first items)
      and do (pop idxs)
             (pop items)
      else collect elt))

#|
(defun segregate-plist (plist)
  "Returns two lists, the list of properties and the list of values in plist.
   Ex call: (destructuring-bind (properties values) (segregate-plist plist) ..."
  (loop with properties and values
    for (property value) on plist by #'cddr
    if (listp property)
      do (loop for item in property
           do (push item properties)
              (push value values))
      else do (push property properties)
              (push value values)
    finally (return (list (reverse properties) (reverse values)))))
(declaim (ftype (function (list) list) segregate-plist))
|#

(defun intern-symbol (&rest args)
  "Interns a symbol created by concatenating args.
   Based on symb in Let Over Lambda."
  (flet ((mkstr (&rest args)
           (with-output-to-string (s)
             (dolist (a args) (princ a s)))))
    (values (intern (apply #'mkstr args)))))
(declaim (ftype (function (&rest t) (values symbol &optional)) intern-symbol))


;(defun list-difference (lst sublst)
;  "Returns lst with elements in sublst removed."
;  (assert (and (listp lst) (listp sublst)))
;  (remove-if (lambda (item)
;               (member item sublst))
;    lst))
;(declaim (ftype (function (list list) list) list-difference))


(defun walk-tree (fun tree)
  "Apply fun to each cons and atom in tree."
  (the list (subst-if t (constantly nil) tree :key fun)))
(declaim (ftype (function (function list) list) walk-tree))


(defun map-into-tree-atoms (fn tree)
  "Returns a new tree with all atoms replaced by the value of fn."
  (declare (type function fn))
  (cond ((null tree) nil)
        ((atom tree) (let ((result (funcall fn tree)))
                       (if result result)))
        (t (remove-if #'null
                      (mapcar (lambda (subtree)
                                (map-into-tree-atoms fn subtree))
                              tree)))))


(defun ninsert-list (new-element position lst)
  "Destructively inserts new element in a list at given position.
   For position 0, returns new list with element prepended.
   For position > length, extends list with NILs then inserts."
  (cond
    ;; Position 0: Can't destructively modify head, return new list
    ((zerop position)
     (cons new-element lst))
    ;; Empty list at position > 0: fabricate required NIL padding and append.
    ((null lst)
     (append (make-list position) (list new-element)))
    ;; Normal case: Insert at position > 0
    (t
     ;; Extend list if too short
     (let ((current-length (length lst)))
       (when (< current-length position)
         ;; Extend with NIL elements up to position
         (setf (cdr (last lst)) (make-list (- position current-length)))))
     ;; Now perform the insertion
     (let ((target-cell (nthcdr (1- position) lst)))
       (push new-element (cdr target-cell)))
     lst)))


(defun intersperse (element lst)
  "Returns a list with element inserted at odd indexed locations."
  (loop for item in lst
    append (list item element)))
(declaim (ftype (function (t list) list) intersperse))


(defun interleave+ (lst)
  "Inserts a + sign between list items."
  (format nil "~{~A~^+~}" lst))
(declaim (ftype (function (list) string) interleave+))


(defun transpose (list-of-equi-length-lists)  ;same as regroup-by-index ?
  "Regroups all first elements together, second elements together, etc into a new
   list-of-lists. Changes instantiate-types into arg format for some, every, etc.
   ((a b) (c d) (e f)) -> ((a c e) (b d f))"
  (apply #'mapcar #'list list-of-equi-length-lists))

#|
(defun quote-elements (lst)
  "Quotes the individual elements of a list."
  (or (mapcar (lambda (elem) `',elem) lst)
      '((quote nil))))
(declaim (ftype (function (list) list) quote-elements))


(defun map-product-less-bags (lists)
  "Performs alexandria:map-product but leaves out combination with duplicates."
  (the list (if (car lists)
              (mapcan (lambda (inner-val)
                        (mapcan (lambda (outer-val)
                                  (unless (member outer-val inner-val)
                                (list (cons outer-val inner-val))))
                                (car lists)))
                      (map-product-less-bags (cdr lists)))
              (list nil))))
(declaim (ftype (function (list) list) map-product-less-bags))
|#

(defgeneric show (object &rest rest)
  (:documentation "Displays an object in a user-friendly format."))


(defmethod show ((table hash-table) &key (sort-by 'key))
  "Displays a hash table line-by-line, sorted either by key or val."
  (declare (type hash-table table))
  (when (= (hash-table-count table) 0)
    (format t "~&~A Empty~%" table)
    (return-from show))
  (let (alist)
    (maphash
      (lambda (key val)
        (push (cons (princ-to-string key) (prin1-to-string val))
          alist))
      table)
    (setf alist 
      (sort (copy-list alist) #'string< :key (ecase sort-by (key #'car) (val #'cdr))))
    (loop for (key . val) in alist
      do (format t "~&~A ->~10T ~A~%" key val)))
  t)


(defmethod show ((fn function) &rest rest)
  (declare (ignore rest))
  (format t "~&~A~%" (function-lambda-expression fn))
  t)


(defmethod show ((lst list) &rest rest)
  (declare (ignore rest))
  (format t "~&~A~%" lst))


(defmethod show ((object t) &rest rest)
  "Prints any basic lisp object."
  (declare (ignore rest))
  (format t "~&~S~%" object)
  t)


(defun print-ht (ht) 
  "Prints a hash table line by line."
  (declare (type hash-table ht))
  (format t "~&~A" ht)
  (maphash (lambda (key val) (format t "~&~S ->~10T ~S" key val)) ht)
  (terpri)
  ht)


(defun hash-table-same-keys-p (ht1 ht2)
  "Returns t if two hash tables have the same keys."
  (declare (type hash-table ht1 ht2))
  (when (= (hash-table-count ht1) (hash-table-count ht2))
    (maphash (lambda (ht1-key ht1-value)
               (declare (ignore ht1-value))
               (multiple-value-bind (_ present)
                   (gethash ht1-key ht2)
                 (declare (ignore _))
                 (unless present
                   (return-from hash-table-same-keys-p nil))))
             ht1)
    t))


(defun hash-table-present-p (key ht)
  "Determines if a key is present in ht."
  (declare (type hash-table ht))
  (mvb (* present) (gethash key ht)
    present))


(defun save (object file)
  "Saves an object to a file so it can be read in later."
  (with-open-file (out-stream file :direction :output)
    (let ((*print-readably* t))
      (pprint object out-stream))))


(defun retrieve (file)
  "Retrieves one or more objects from a file."
  (with-open-file (in-stream file :direction :input)
    (loop for object = (read in-stream nil in-stream)
      until (eql object in-stream)
      collect object into objects
      finally (return (if (= (length objects) 1)
                        (first objects)
                        objects)))))


(defun extract-symbols (x.y)
  "Splits a symbol, whose print name contains the delimiter #\., into two symbols."
  (let* ((x.y-string (string x.y))
         (index (position #\. x.y-string :test #'char=)))
    (values (intern (subseq x.y-string 0 index)) (intern (subseq x.y-string (1+ index))))))


(defun merge-sort-list (list &key (pred #'<) (key #'identity))
  (labels ((ms (l)
             (if (null (cdr l))
                 l
                 (let* ((len (length l))
                        (half (floor len 2))
                        (l1 (subseq l 0 half))
                        (l2 (subseq l half)))
                   (merge-list (ms l1) (ms l2)))))
           (merge-list (a b)
             (cond
               ((null a) b)
               ((null b) a)
               ((funcall pred (funcall key (first a))
                         (funcall key (first b)))
                (cons (first a) (merge-list (rest a) b)))
               (t (cons (first b) (merge-list a (rest b)))))))
    (ms list)))


;;;;;;;;;;;;;;;;;;;;;


(defun agent-starred-p (agent)
  "Returns T if AGENT symbol name ends with asterisk."
  (declare (type symbol agent))
  (let ((name (symbol-name agent)))
    (char= (char name (1- (length name))) #\*)))


(defun get-path-action-agent (path-element)
  "Extracts the agent from a path element of form (time (action agent ...))."
  (second (second path-element)))


(defun count-agent-switches (path)
  "Counts transitions between starred and unstarred agents in PATH."
  (loop with prev-starred = nil
        with first-p = t
        for element in path
        for agent = (get-path-action-agent element)
        for starred = (agent-starred-p agent)
        count (and (not first-p) (not (eql starred prev-starred)))
        do (setf prev-starred starred)
           (setf first-p nil)))


(defun print-optimal-solutions (&optional (solutions ww::*solution-paths*))
  "Prints optimal solutions from SOLUTIONS list.
   Optimal solutions: (1) begin with unstarred agent, (2) minimize agent switches.
   Requires all solutions to have the same depth."
  ;; Check for empty input
  (when (null solutions)
    (format t "~&No solutions to analyze.~%")
    (return-from print-optimal-solutions nil))
  ;; Verify uniform depth
  (let ((depths (mapcar #'ww::solution.depth solutions)))
    (unless (apply #'= depths)
      (error "Solutions have varying depths: ~A" (remove-duplicates depths))))
  ;; Filter: first action must be by unstarred agent
  (let ((filtered (remove-if 
                    (lambda (sol)
                      (agent-starred-p 
                        (get-path-action-agent 
                          (first (ww::solution.path sol)))))
                    solutions)))
    (when (null filtered)
      (format t "~&No solutions begin with unstarred agent.~%")
      (return-from print-optimal-solutions nil))
    ;; Score and find minimum switches
    (let* ((scored (mapcar (lambda (sol)
                             (cons (count-agent-switches (ww::solution.path sol))
                                   sol))
                           filtered))
           (min-switches (reduce #'min scored :key #'car))
           (optimal (remove-if-not (lambda (pair) (= (car pair) min-switches))
                                   scored)))
      ;; Print results
      (format t "~&~%=== OPTIMAL SOLUTIONS ===~%")
      (format t "Found ~D optimal solution~:P with ~D agent switch~[es~;~:;es~].~%"
              (length optimal) min-switches min-switches)
      (format t "Solution depth: ~D~%~%" (ww::solution.depth (cdar optimal)))
      (loop for (_switches . sol) in optimal                        ; <-- CHANGED
            for i from 1
            do (format t "~&--- Solution ~D ---~%" i)
               (loop for (time action) in (ww::solution.path sol)
                     do (format t "  ~A ~A~%" time action))
               (terpri))
      ;; Return count and switch value
      (values (length optimal) min-switches))))


;;;;;;;;;; Check-parens utility ;;;;;;;;;;;;;;;;;


(defun check-parens-file (filepath)
  "Scans file for parenthesis balance, reports line of first mismatch.
   Properly handles comments, strings, and character literals."
  (with-open-file (stream filepath :direction :input)
    (loop with depth = 0
          with line-num = 1
          with open-positions = nil  ; stack of line numbers where '(' occurred
          with in-string = nil
          with in-line-comment = nil
          with in-block-comment = 0  ; depth counter for nested #|...|#
          with prev-char = nil
          with backslash-run = 0
          for char = (read-char stream nil nil)
          while char
          do (cond
               ;; Track newlines and exit line comments
               ((char= char #\Newline)
                (incf line-num)
                (setf in-line-comment nil))
               
               ;; Inside line comment - skip everything
               (in-line-comment
                nil)
               
               ;; Check for block comment start: #|
               ((and (char= char #\|) (eql prev-char #\#) (not in-string))
                (incf in-block-comment))
               
               ;; Check for block comment end: |#
               ((and (char= char #\#) (eql prev-char #\|) (plusp in-block-comment))
                (decf in-block-comment))
               
               ;; Inside block comment - skip everything else
               ((plusp in-block-comment)
                nil)
               
               ;; Check for line comment start
               ((and (char= char #\;) (not in-string))
                (setf in-line-comment t))
               
               ;; Handle string delimiters (not escaped)
               ((and (char= char #\") (evenp backslash-run))
                (setf in-string (not in-string)))
               
               ;; Inside string - skip parens
               (in-string
                nil)
               
               ;; Character literal #\( or #\) - skip
               ((and (eql prev-char #\\)
                     (or (char= char #\() (char= char #\))))
                nil)
               
               ;; Open paren
               ((char= char #\()
                (push line-num open-positions)
                (incf depth))
               
               ;; Close paren
               ((char= char #\))
                (if (zerop depth)
                    (return (format nil "Extra ')' at line ~D" line-num))
                    (progn (decf depth) (pop open-positions)))))
             
             (setf prev-char char)
             (if (char= char #\\)
                 (incf backslash-run)
                 (setf backslash-run 0))
          
          finally (return (if (zerop depth)
                              "Parentheses balanced."
                              (format nil "Unclosed '(' at line ~D (depth ~D remaining)"
                                      (car open-positions) depth))))))


(defun check-parens (filename)
  ;Check parenthesis balance in a file anywhere under the wouldwork project.
  ;Usage: (ut::check-parens "ww-searcher.lisp")
  (let* ((root (asdf:system-relative-pathname :wouldwork ""))
         (pattern (merge-pathnames
                   (make-pathname :directory '(:relative :wild-inferiors)
                                  :name :wild :type :wild)
                   root))
         (matches (remove-if-not
                   (lambda (path)
                     (string-equal filename (file-namestring path)))
                   (directory pattern))))
    (cond
      ((null matches)
       (format nil "File ~S not found under ~A" filename root))
      ((= (length matches) 1)
       (check-parens-file (first matches)))
      (t
       (format nil "Ambiguous: ~D files named ~S found:~%~{  ~A~%~}"
               (length matches) filename matches)))))
