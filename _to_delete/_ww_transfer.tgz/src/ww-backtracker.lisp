;;; Filename: ww-backtracker.lisp

;;; Backtracking search infrastructure for wouldwork


(in-package :ww)


;; Basic data structures for backtracking


(defstruct (choice (:conc-name choice.))
  "Represents a choice point in backtracking search"
  act             ; (action-name arg1 arg2 ...)
  forward-update  ; The update structure that applies this choice
  inverse-update  ; The update structure that undoes this choice
  forward-sig     ; Order-insensitive signature of forward-update
  inverse-sig     ; Order-insensitive signature of inverse-update
  level           ; Depth in the search tree
  pre-applied-p)  ; T when effect already applied to *backtrack-state*


(defparameter *backtrack-state* nil
  "The single working state for backtracking search")


(defparameter *choice-stack* nil
  "Stack of choices made during backtracking search; path back to start state.")


(defun cycle-check-enabled-bt ()
  "Enable immediate inverse-cycle detection only for planning problems."
  (not (eql *problem-type* 'csp)))


(defun update-set-signature (ops)
  "Build an order-insensitive signature for OPS, ignoring duplicates.
   Used as a cheap prefilter before exact set-equality checks."
  (let ((seen (make-hash-table :test #'equal))
        (unique-count 0)
        (xor-hash 0)
        (sum-hash 0))
    (dolist (op ops)
      (unless (gethash op seen)
        (setf (gethash op seen) t)
        (incf unique-count)
        (let ((h (sxhash op)))
          (setf xor-hash (logxor xor-hash h))
          (incf sum-hash h))))
    (list unique-count xor-hash sum-hash)))


(defun bt-choice-inconsistent-p (choice)
  "Return T when CHOICE encodes the inconsistent-state marker.
   Supports both incremental list updates and snapshot hash-table updates."
  (let ((update (choice.forward-update choice)))
    (etypecase update
      (list
       (member '(inconsistent-state) update :test #'equal))
      (hash-table
       (gethash (convert-to-integer-memoized '(inconsistent-state)) update)))))


(defun apply-update-forward-bt (update)
  "Apply UPDATE to *backtrack-state*.
   UPDATE may be a forward-op list or a hash-table idb snapshot."
  (etypecase update
    (list
     (when update
       (revise (problem-state.idb *backtrack-state*) update)))
    (hash-table
     (setf (problem-state.idb *backtrack-state*) (copy-idb update))))
  (invalidate-problem-state-hash *backtrack-state*))


(defun apply-update-inverse-bt (update)
  "Undo UPDATE from *backtrack-state*.
   UPDATE may be an inverse-op list or a hash-table idb snapshot."
  (etypecase update
    (list
     (when update
       (revise (problem-state.idb *backtrack-state*) update)))
    (hash-table
     (setf (problem-state.idb *backtrack-state*) (copy-idb update))))
  (invalidate-problem-state-hash *backtrack-state*))


(defun search-backtracking ()
  "Runs backtracking after DFS has initialized shared search state."
  ;; Initialize backtracking-specific state infrastructure
  (setf *backtrack-state* (copy-problem-state *start-state*))
  (setf *choice-stack* nil)
  ;(clrhash *proposition-cache*)
  ;(setf *last-object-index* 0)
  #+:ww-debug (when (and (<= *debug* 2) (>= *debug* 1))
                (setf *search-tree* nil)
                ;; Add initial state at depth 0
                (push `(start-state                     ; no action for initial state
                       0                        ; depth 0
                       ""                       ; no message
                       ,@(case *debug*
                           (1 nil)
                           (2 (list (list-database (problem-state.idb *backtrack-state*))))))
                      *search-tree*))
  ;; Initiate recursive backtracking search
  (backtrack 0)
  ;; Compute final statistics
  (setf *average-branching-factor* (if (> *program-cycles* 0)
                                     (coerce (/ (1- *total-states-processed*) *program-cycles*)
                                             'single-float)
                                     0.0))
  t)


(defun update-statistics (level)
  "Update search statistics."
  (increment-global *program-cycles* 1)
  (increment-global *total-states-processed* 1)
  (when (> (1+ level) *max-depth-explored*)
    (setf *max-depth-explored* (1+ level)))
  (print-search-progress))


(defun backtrack (level)
  "Recursive backtracking search over new states from assert clauses."
  
  ;; Step 1: Enforce depth cutoff
  (when (and (> *depth-cutoff* 0) (>= level *depth-cutoff*))
    (return-from backtrack nil))
  
  ;; Step 2: Update search statistics
  (update-statistics level)
  
  ;; Step 3: CSP-aware action selection and processing
  (let ((found-a-solution nil)
        ;; CSP RESTRICTION: Select actions based on problem type and level
        (actions (if (and (eql *problem-type* 'csp) (< level (length *actions*)))
                     (list (nth level *actions*))  ; CSP: single action per level
                     *actions*)))                   ; Planning: all actions
    
    (dolist (action actions)
      (let ((parameter-combinations (if (action.dynamic action)
                                      ;; Dynamic case: compute combinations from current state
                                      (eval-instantiated-spec (action.precondition-type-inst action) 
                                                              *backtrack-state*)
                                      ;; Static case: use pre-computed combinations
                                      (action.precondition-args action)))
            (precondition-fn (action.pre-defun-name action)))
        ;; Filter symmetric instantiations if symmetry pruning enabled
        (when *symmetry-pruning*
          (setf parameter-combinations 
                (filter-symmetric-instantiations action parameter-combinations *backtrack-state*)))
        ;; Process each parameter combination individually against current state
        (dolist (param-combo parameter-combinations)
          (let ((precondition-result (apply precondition-fn *backtrack-state* param-combo)))
            (when precondition-result  ; Only process if preconditions satisfied
              (let ((choices-from-combination 
                      (generate-choices-for-single-combination-bt action param-combo
                                                                  precondition-result level)))
                ;; Process each choice generated from this parameter combination
                ;; (Multiple choices possible due to multiple assert statements in an action)
                (dolist (choice choices-from-combination)
                  (if (detect-path-cycle choice)
                      ;; If this choice was already applied during generation, restore now.
                      (when (choice.pre-applied-p choice)
                        (apply-update-inverse-bt (choice.inverse-update choice)))
                      (when (register-choice-bt choice action level)
                        (unwind-protect
                          (cond
                            ;; Filter inconsistent states (parallels depth-first filtering in generate-children)
                            ((bt-choice-inconsistent-p choice)
                             (increment-global *inconsistent-states-dropped* 1))
                            ((and (search-prefix-validation-enabled-p)
                                  (search-prefix-validation-required-p
                                    (record-move *backtrack-state*)
                                    *backtrack-state*)
                                  (not (candidate-search-prefix-valid-p
                                         (reconstruct-solution-path)
                                         *backtrack-state*)))
                             (increment-global *search-prefix-pruned* 1))
                            ;; Solution found at current level - register and handle continuation
                             ((is-complete-solution)
                              (let ((candidate-path (reconstruct-solution-path)))
                                (if (candidate-solution-valid-p
                                      candidate-path *backtrack-state*)
                                  (progn
                                    (register-solution-bt (1+ level) candidate-path)
                                    (narrate-bt
                                      "Solution found ***"
                                      (first *choice-stack*) (1+ level))
                                    (when (> *debug* 0)
                                      (finish-output))
                                    (setf found-a-solution t)
                                    (when (solution-count-reached-p)
                                      (return-from backtrack t)))
                                  ;; The state goal is only a rejected prefix.  Later
                                  ;; actions may make the complete path valid.
                                  (let ((deeper-result (backtrack (1+ level))))
                                    (when deeper-result
                                      (setf found-a-solution t)
                                      (when (solution-count-reached-p)
                                        (return-from backtrack t)))))))
                            ;; No solution yet - continue recursive exploration
                            (t
                             (let ((deeper-result (backtrack (1+ level))))
                               (when deeper-result
                                 (setf found-a-solution t)
                                 (when (solution-count-reached-p)
                                   (return-from backtrack t))))))
                          (undo-choice-bt choice action level)))))))))))
    found-a-solution))


(defun generate-choices-for-single-combination-bt (action param-combo precondition-result level)
  "Generate choices by executing effect with incremental updates to *backtrack-state*.
   Effect modifies state, then changes are undone. Returns choices with forward/inverse ops."
  
  (let ((effect-fn (action.eff-defun-name action))
        (choices '()))
    ;; Execute effect function - MODIFIES *backtrack-state* incrementally
    (let ((pre-idb (copy-idb (problem-state.idb *backtrack-state*)))
          (updated-dbs 
            (if (eql precondition-result t)
                (funcall effect-fn *backtrack-state*)
                (apply effect-fn *backtrack-state* precondition-result))))
      ;; Process each updated-db into separate choice structure.
      ;; Fast path: if only one update exists, keep it applied and avoid undo/reapply.
      (let ((single-update-p (and (consp updated-dbs) (null (cdr updated-dbs))))
            (cycle-check-p (cycle-check-enabled-bt)))
        (dolist (updated-db updated-dbs)
          (let ((change-lists (update.changes updated-db)))
            (when change-lists
              (typecase change-lists
                (list
                 (destructuring-bind (forward-ops inverse-ops) change-lists
                   (let* ((combined-act (cons (action.name action)
                                              (copy-tree
                                               (update.instantiations updated-db))))
                          (new-choice (make-choice :act combined-act
                                                   :forward-update forward-ops
                                                   :inverse-update inverse-ops
                                                   :forward-sig (and cycle-check-p
                                                                     (update-set-signature forward-ops))
                                                   :inverse-sig (and cycle-check-p
                                                                     (update-set-signature inverse-ops))
                                                   :level level
                                                   :pre-applied-p single-update-p)))
                     (push new-choice choices)
                     ;; For multiple updates, restore immediately so each choice is explored from
                     ;; the same base state. For single update, defer restore to undo-choice-bt.
                     (unless single-update-p
                       (apply-update-inverse-bt inverse-ops)))))
                (hash-table
                 ;; Snapshot-style update: register by replacing idb; inverse restores pre-idb.
                 (let* ((combined-act (cons (action.name action)
                                            (copy-tree
                                             (update.instantiations updated-db))))
                        (new-choice (make-choice :act combined-act
                                                 :forward-update change-lists
                                                 :inverse-update pre-idb
                                                 :forward-sig nil
                                                 :inverse-sig nil
                                                 :level level
                                                 :pre-applied-p nil)))
                   (push new-choice choices))))))))
      ;; Return choices in forward execution order
      (nreverse choices))))


(defun register-choice-bt (choice action level)
  "Register a choice by applying its forward operations to *backtrack-state*."
    
  #+:ww-debug
  (when (>= *debug* 3)
    (format t "~%Current state: ~A~%" (list-database (problem-state.idb *backtrack-state*))))

  ;; Step 1: Apply forward operations unless already applied during generation
  (unless (choice.pre-applied-p choice)
    (apply-update-forward-bt (choice.forward-update choice)))

  ;; Step 2: Name and time update
  (setf (problem-state.name *backtrack-state*) (action.name action))
  (incf (problem-state.time *backtrack-state*) (action.duration action))

  ;; Step 3: Global invariants
  (when *global-invariants*
    (unless (validate-global-invariants nil *backtrack-state*)
      (apply-update-inverse-bt (choice.inverse-update choice))
      (decf (problem-state.time *backtrack-state*) (action.duration action))
      (error "Global invariant violation in successor state from action ~A" (choice.act choice))))

  ;; Step 4: Constraint
  (when (and (fboundp 'constraint-fn)
             (not (funcall (symbol-function 'constraint-fn) *backtrack-state*)))
    (apply-update-inverse-bt (choice.inverse-update choice))
    (decf (problem-state.time *backtrack-state*) (action.duration action))
    (return-from register-choice-bt nil))

  ;; Step 5: Choice stack
  (push choice *choice-stack*)

  ;; Step 6: Debug output
  (narrate-bt "" choice (1+ level))

  t)


(defun undo-choice-bt (choice action level)
  "Undo a choice from the current state with time reversal and stack management"

  ;; Inverse state update
  (apply-update-inverse-bt (choice.inverse-update choice))

  ;; Reverse name & time
  (setf (problem-state.name *backtrack-state*) 
        (if (cdr *choice-stack*)
          (first (choice.act (second *choice-stack*)))  ; Previous action name
          'start))
  (decf (problem-state.time *backtrack-state*) (action.duration action))

  ;; Debug
  (narrate-bt "Backtracking to" choice level)

  ;; Stack handling
  (pop *choice-stack*)

  t)


(defun is-complete-solution ()
  "Hook: Check if we have reached a complete solution"
  ;; Use wouldwork's existing goal checking mechanism
  (when (fboundp 'goal-fn)
    (funcall (symbol-function 'goal-fn) *backtrack-state*)))


(defun reconstruct-solution-path ()
  "Reconstruct the solution path from the choice stack with correct cumulative time"
  (let ((cumulative-time 0.0)
        (path '()))
    ;; Process choices in reverse order (oldest first) to build cumulative time
    (dolist (choice (reverse *choice-stack*))
      (let* ((action-name (first (choice.act choice)))
             (action (find action-name *actions* :key #'action.name))
             (action-duration (action.duration action)))
        ;; Update cumulative time
        (setf cumulative-time (+ cumulative-time action-duration))
        ;; Build move record with correct time
        (push (list cumulative-time (choice.act choice)) path)))
    (nreverse path)))


(defun update-search-tree-bt (choice depth message)
  (declare (type choice choice) (type fixnum depth) (type string message))
  (when (and (not (> *threads* 0)) (<= *debug* 2) (>= *debug* 1))
    (push `(,(choice.act choice)    ; Already formatted as (action-name arg1 arg2 ...)
           ,depth
           ,message
           ,@(case *debug*
               (1 nil)
               (2 (list (list-database (problem-state.idb *backtrack-state*))))))
          *search-tree*)))


(defun narrate-bt (string choice depth)
  "Enhanced narration function with refined progressive debug level disclosure"
  ;(declare (ignorable string choice depth))
  
  ;; Debug levels 1 & 2: Build search tree (but not for backtracking messages)
  #+:ww-debug (when (and (<= *debug* 2) (>= *debug* 1))
                (unless (and string (string= string "Backtracking to"))
                  (update-search-tree-bt choice depth string)))
  
  ;; Debug levels 3+: Immediate console output (no search tree)
  #+:ww-debug (when (>= *debug* 3)
                ;; Special handling for backtrack operations - simplified output
                (if (and string (string= string "Backtracking to"))
                    (when choice
                      (format t "~%Backtracking to: ~A~%" (choice.act choice)))
                    ;; Normal detailed output for non-backtrack operations
                    (progn
                      (when (and string (not (string= string "")))
                        (format t "~%~A:~%" string))
                      (when choice
                        (format t "~%Action: ~A~%" (choice.act choice))
                        (format t "Depth: ~A~%" depth)
                        (format t "Forward Update: ~A~%" (choice.forward-update choice))
                        (format t "Inverse Update: ~A~%" (choice.inverse-update choice)))
                      (unless choice
                        (format t "Choice: <nil>~%"))
                      (format t "Successor State IDB: ~A~%" (list-database (problem-state.idb *backtrack-state*)))
                      (when (problem-state.hidb *backtrack-state*)
                        (format t "Successor State HIDB: ~A~%" (list-database (problem-state.hidb *backtrack-state*))))
                        (format t "Successor Time: ~A~%" (problem-state.time *backtrack-state*))
                        (format t "Successor Value: ~A~%" (problem-state.value *backtrack-state*)))))
  
  ;; Debug level 4+: Add choice stack visualization  
  #+:ww-debug (when (>= *debug* 4)
                (format t "--- Choice Stack (Length ~A) ---~%" (length *choice-stack*))
                (if *choice-stack*
                    (loop for i from 0
                          for stack-choice in *choice-stack*
                          do (format t "  [~A] ~A~A~%" 
                                     i 
                                     (choice.act stack-choice)
                                     ;; Highlight current choice being processed
                                     (if (and choice (eq stack-choice choice))
                                         " ← current"
                                         "")))
                    (format t "  <empty>~%")))
  
  ;; Debug level 5: Interactive breakpoint
  #+:ww-debug (when (>= *debug* 5)
                (simple-break))
  
  nil)


(defun register-solution-bt (level &optional (solution-path (reconstruct-solution-path)))
  "Register a solution found via backtracking using the choice stack"
  (let* ((solution-depth (length *choice-stack*))
         (solution (make-solution
                     :depth solution-depth
                     :time (problem-state.time *backtrack-state*)
                     :value (problem-state.value *backtrack-state*)
                     :path solution-path
                     :goal (copy-problem-state *backtrack-state*))))
    (format t "~%New path to goal found at depth = ~:D" solution-depth)
    (when (eql *solution-type* 'min-time)
      (format t "Time = ~:A~%" (solution.time solution)))
    (finish-output)
    (push solution *solution-paths*)
    (when (not (member (problem-state.idb (solution.goal solution)) *unique-solution-states* 
                       :key (lambda (soln) (problem-state.idb (solution.goal soln)))
                       :test #'equalp))
      (push solution *unique-solution-states*))))


(defun detect-path-cycle (new-choice)
  "Check if new-choice immediately undoes the last choice using set-based comparison"
  (when (cycle-check-enabled-bt)
    (let ((last-choice (first *choice-stack*)))
    ;; Check if new forward-update matches last inverse-update (set comparison)
      (when last-choice
        (let ((new-forward (choice.forward-update new-choice))
              (last-inverse (choice.inverse-update last-choice)))
          (and (listp new-forward)
               (listp last-inverse)
               (equal (choice.forward-sig new-choice)
                      (choice.inverse-sig last-choice))
               (alexandria:set-equal new-forward
                                     last-inverse
                                     :test #'equal)))))))
