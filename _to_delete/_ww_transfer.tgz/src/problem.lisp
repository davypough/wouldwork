;;; Filename: problem-rumin-topo.lisp

;;; Coordinate/topology-driven version of Purgatory 'Rumination'.


(in-package :ww)


(ww-set *problem-name* rumin-topo)

(ww-set *problem-type* planning)

(ww-set *solution-type* first)

(ww-set *tree-or-graph* graph)

(ww-set *progress-reporting-interval* 1000000)

(ww-set *depth-cutoff* 25)


(defparameter *max-pairings* 2)


;;;; TYPES ;;;;


(define-types
  agent (agent1 agent1*)
  recorder (recorder1)
  gate  (gate1 gate2 gate3 gate4 gate5 gate6)
  wall (wall1 wall2 wall3 wall4 wall5 wall7 wall8 wall9 wall10 wall11 wall12 wall13 wall14 wall15 wall16)
  window (window1)
  edge (edge1 edge2 edge3 edge4 edge5)
  location (location1 location2 location3 location4 location5
            location6 location7 location8 location9 location10
            location11 location12 location13 location14 location15 location16)
  pressure-plate (pplate1 pplate2 pplate3 pplate4)
  box (box1 box1*)
  connector (connector1 connector2 connector1* connector2*)
  tray (tray1 tray1*)
  transmitter (transmitter1 transmitter2)
  receiver (receiver1 receiver2)
  ladder (ladder1 ladder2)
  hue (blue red)
)


;;;; TECHNOLOGY INCLUDES ;;;;



;;;; ==== begin technology gate ====

;;; Filename: gate.lisp

;;; Gate technology: a gate's open-state is derived each propagation pass as
;;;   open  <=>  jammed  OR  control-on
;;; Controllers are stored in disjunctive normal form (an OR-list of AND-lists); a clause is
;;; on when all its members are energized (a receiver when active, a plate when depressed).
;;; Inverted mode negates the control aggregate; jamming always overrides toward open.  An
;;; uncontrolled gate reduces to open <=> jammed.  (Only normal and inverted are recognized,
;;; matching claustro4a; toggle is reserved.)
;;;
;;; REQUIRES (supplied by other techs):
;;;   types     : (none bare)  --  jammer is declared optional here (define-optional-types);
;;;               plate, mode, and receiver come from nested -controls; gate itself comes
;;;               from nested -gate
;;;   nested    : -controls ((controls ...), energized; nests -beam-substrate for
;;;               (active receiver))  --  shared with the blower techs' gears (-gears-fan);
;;;               -gate (gate optional type, (open gate) relation) -- shared with
;;;               walkability (via -passability), reachability, visibility, beam-direct,
;;;               beam-crossing, and -passability, which all nest -gate instead of
;;;               hand-declaring it
;;;   conditional relations:
;;;               depressed (plate), guarded by plate
;;;               jamming (jammer), guarded by an exists over jammer
;;;               The owning tech is required only when the guarding optional type is nonempty;
;;;               translation removes the guarded reference when that type is empty.
;;;   driver    : the master propagate-consequences! must call update-gate-status!
;;; PROVIDES:
;;;   types     : jammer  --  declared optional here; a problem with no jammers need not
;;;               declare it.  Other techs (plate, jammer, box, beam-relay, -beam-substrate,
;;;               visibility, etc.) still declare their own jammer-alias for their own
;;;               pre-params; the bare and aliased forms resolve compatibly and do not conflict.
;;;   update    : update-gate-status!  --  the only file that ever asserts (open gate)


;;;; ==== begin technology -propagation ====

;;; Filename: -propagation.lisp

;;; Propagation substrate: the MASTER PROPAGATION DRIVER itself, contributed by the
;;; technologies rather than authored by the problem.  Every technology that supplies a
;;; zero-argument update nests this file, so any problem including any such technology
;;; receives both driver functions without writing either one.
;;;
;;; PROPAGATE-CHANGES! is the fixpoint loop, and it is fixed.  It was byte-identical in
;;; CLAUSTRO-TOPO, CORNER-TOPO, PHOBIA, PROBLEM-FLOOR-GEARS-TEST,
;;; PROBLEM-WALL-BLOWER-TEST, PROBLEM-PROPAGATION-STRATA-TEST and
;;; PROBLEM-REACTION-ORDER-TEST -- seven independent transcriptions of one loop, which is
;;; exactly the thing a technology should own.
;;;
;;; PROPAGATE-CONSEQUENCES! is the ordered call sequence, and it is derived per problem:
;;; the loaded technologies decide which updates exist, and the read/write graph over those
;;; updates decides their order.  Neither is known when this file is spliced, because a
;;; technology may still override a peer's query afterward and change the graph.  So what
;;; is spliced here is a SENTINEL, and INIT overwrites it with the derived body once every
;;; definition is in.  See WW-PROPAGATION-ORDER's DERIVED DRIVER section.
;;;
;;; The sentinel signals rather than returning NIL.  A no-op PROPAGATE-CONSEQUENCES!
;;; surviving to DO-INIT-ACTION-UPDATES would yield an unpropagated start state and a
;;; failure bearing no relation to its cause; an error names the defect where it is.
;;; PROPAGATION-DRIVER-NOT-DERIVED is the marker both halves agree on --
;;; AUTHORED-PROPAGATION-DRIVER-BODY tests :RAW-BODY against it to tell a problem's own
;;; driver from this placeholder, so the body below must stay in step with
;;; *PROPAGATION-DRIVER-SENTINEL*.
;;;
;;; A problem may still author its own driver.  Its definitions are spliced below its
;;; (include-tech ...) block and so are installed after these, and the later definition
;;; wins -- the same rule the peer-substrate technologies already rely on.  An authored
;;; PROPAGATE-CONSEQUENCES! displaces the sentinel, and INIT then leaves it alone.
;;;
;;; REQUIRES (supplied by the planner, not by another technology):
;;;   specials  : *detect-propagated-changes*, *propagated-state-changed* (ww-settings)
;;;   functions : inconsistent-state, propagation-driver-not-derived
;;; PROVIDES:
;;;   update    : propagate-changes!  --  the fixpoint loop, final
;;;   update    : propagate-consequences!  --  sentinel only; INIT installs the real body

(in-package :ww)


(define-update propagate-changes! ()
  ;; Binds the change-detection gate so add-prop/del-prop flag *propagated-state-changed*
  ;; on real derived-fact mutations during the fixpoint.  Each pass runs to convergence (no
  ;; change) or, failing that, the cap declares the state inconsistent.
  (let ((*detect-propagated-changes* t))
    (ww-loop for $iteration from 1 to 10
             do (if (not (propagate-consequences!))
                  (return t))
             finally (inconsistent-state)
                     (return nil))))


(define-update propagate-consequences! ()
  ;; Sentinel.  INIT replaces this body with the derived call sequence, or a problem's own
  ;; driver overrides it at load.  Reaching it means neither happened.
  (propagation-driver-not-derived))

;;;; ==== end technology -propagation ====

;;;; ==== begin technology -controls ====

;;; Filename: -controls.lisp

;;; Controls substrate: the shared DNF controller wiring for controlled devices (gates and
;;; gears) and the energized query that evaluates a single controller.  Owned in one
;;; place so gate.lisp and -gears-fan.lisp nest this file instead of each declaring
;;; controls/energized; both previously lived in gate.lisp.  CONTROL-ON evaluates the DNF
;;; aggregate once for every consumer -- gate, gears, and gun -- taking the uncontrolled
;;; default as an argument, since that is the only thing that varied between the copies it
;;; replaced (an uncontrolled gate reduces to open <=> jammed; uncontrolled gears and guns
;;; run until something disables them).
;;;
;;; Recorder's recording-side aggregate is deliberately a separate query in
;;; -recorder-controls-shadow.lisp rather than a view argument here.
;;; WW-PROPAGATION-ORDER's walker recurses into query
;;; bodies to compute each update's read set, and prunes only tests STATIC-FORM-TRUTH can
;;; decide; a view passed as a query parameter is not one, so a single body branching on it
;;; would credit UPDATE-GATE-STATUS! with reading RECORDING-LATCHED and
;;; UPDATE-RECORDING-GATE-STATUS! with reading LATCHED.  Those invented edges cross the
;;; playback and recording strata in both directions and can close a cycle in the derived
;;; driver.  Two textually separate aggregates keep the two read sets disjoint, which is
;;; the property the derivation actually needs.
;;;
;;; REQUIRES:
;;;   nested    : -beam-substrate ((active receiver)) -- pulls in the full receiver machinery
;;;               even in a receiver-free problem (e.g. blower-only or gun-only, reached
;;;               through -gears-fan); harmless and expected, since update-receiver-status!
;;;               quantifies over an empty receiver type there and report-inert-techs names it
;;;   conditional relations, owned by plate.lisp:
;;;               depressed (pressure-plate), guarded by pressure-plate
;;;               latched (toggle-plate), guarded by toggle-plate
;;;               Translation removes either guarded reference when its leaf type is empty.
;;; PROVIDES:
;;;   types     : mode (normal inverted), owned here; plate comes from -plate-types;
;;;               gate, the three gears leaves, the three fixed blower leaves, receiver,
;;;               and gun are
;;;               declared optional here.  The gears leaf types appear directly (not via
;;;               the gears union) because this file splices before -gears-fan installs
;;;               the union; gun likewise appears directly since gun.lisp nests this file
;;;               rather than the other way around.
;;;   relations : (controls $list (either gate floor-gears wall-gears angled-gears
;;;               floor-blower wall-blower angled-blower gun)
;;;               $mode)  --  $list = DNF OR-list of AND-lists of controllers
;;;               (receiver/plate); mode: normal | inverted
;;;   queries   : energized, control-on
;;;
;;; DEFINE-INIT VALIDATION:
;;;   - the DNF value and every clause must be lists
;;;   - every clause member must be a receiver or plate
;;;   - a controlled device may have only one CONTROLS fact
;;;   - only NORMAL and INVERTED modes are supported
;;;   - () and (()) are both valid and intentionally distinct


;;;; ==== begin technology -plate-types ====

;;; Filename: -plate-types.lisp

;;; Plate type substrate.  A problem declares concrete plate instances by physical
;;; behavior, while every consuming technology programs against the shared PLATE union.
;;; Keeping the union in this early nested role makes it available before support,
;;; position, control, and action schemas are translated, independent of public
;;; technology include order.
;;;
;;; PROVIDES:
;;;   types : pressure-plate, toggle-plate -- optional concrete leaf kinds
;;;           plate (either pressure-plate toggle-plate) -- shared plate role

(in-package :ww)


(define-optional-types pressure-plate toggle-plate)


(define-types
  plate (either pressure-plate toggle-plate))

;;;; ==== end technology -plate-types ====

;;;; ==== begin technology -beam-substrate ====

;;; Filename: -beam-substrate.lisp

;;; Beam substrate: the shared interface every beam capability programs against.  It owns
;;; the receiver-status driver, the direct/relay arrival and cut-liveness orchestrators,
;;; transmitter/receiver has-chroma and receiver-active relations, fixed coupling relations,
;;; and a null-object default for every pluggable hook.  beam-direct, beam-relay, and
;;; beam-crossing each include it and override only their own slots, so they compose in any
;;; combination.  Absent capabilities contribute no arrival, cuts, or relay lighting.
;;;
;;; Self-contained; spliced by (include-tech -beam-substrate).
;;;
;;; REQUIRES:
;;;   driver    : propagate-consequences! must call update-receiver-status!  (hue, transmitter,
;;;               and receiver are declared optional here via define-optional-types)
;;; PROVIDES:
;;;   types     : repeater, fixed-beam-source, fixed-beam-sink, beam-node; hue,
;;;               transmitter, receiver, location, floor-repeater, and wall-repeater are
;;;               declared optional here; other techs
;;;               (beam-relay, beam-direct, gate, visibility, etc.) independently declare
;;;               their own hue-alias/transmitter-alias/receiver-alias for their own
;;;               pre-params; the bare and aliased forms resolve compatibly
;;;   relations : (active receiver), has-chroma, coupled, beam-via
;;;   queries   : beam-reaches-receiver, beam-live-for-cutting,
;;;               recording-shadow-beam-reaches-receiver,
;;;               plus null-object defaults for direct-beam-reaches-receiver,
;;;               relay-beam-reaches-receiver, direct-beam-live-for-cutting,
;;;               relay-beam-live-for-cutting, beam-cut, beam-cut-in,
;;;               recording-shadow-direct-beam-reaches-receiver,
;;;               recording-shadow-relay-beam-reaches-receiver,
;;;               fixed-beam-corridor-clear, fixed-beam-corridor-clear-for-object,
;;;               current-crossing-set,
;;;               compute-relay-lighting, compute-relay-lighting-for-object,
;;;               beam-relay-source-distance
;;;   update    : update-receiver-status!

;; (include-tech -propagation): already included -- skipped

;;;; ==== begin technology -beam-substrate-init-checks ====

;;; Filename: -beam-substrate-init-checks.lisp

;;; Initialization validation for repeaters and fixed beam corridors.


(in-package :ww)


(define-init-check beam-substrate-init-check (literals)
  (:consumes gate location)
  (check-init-repeater-consistency literals)
  (check-init-list-relation-items-have-types
    literals 'beam-via '(gate location))
  (check-init-coupled-beam-consistency literals))


(define-init-check-helper check-init-repeater-consistency (literals)
  "Checks repeater mounting, and coordinates when that capability is installed."
  (let ((coordinates-required (init-relation-signature 'apparatus-coords>))
        (coordinate-literals
          (positive-init-literals-with-relation 'apparatus-coords> literals)))
    (dolist (repeater (init-type-instances 'repeater))
      (let ((floor-mounted (init-type-member-p repeater 'floor-repeater))
            (wall-mounted (init-type-member-p repeater 'wall-repeater))
            (coordinate-count
              (count repeater coordinate-literals
                     :key (lambda (literal)
                            (second (init-literal-proposition literal))))))
        (when (eql floor-mounted wall-mounted)
          (fail-init-check nil "~%Repeater must have exactly one mounting orientation.~%~
                  Repeater: ~S~%~
                  FLOOR-REPEATER: ~S~%~
                  WALL-REPEATER:  ~S"
                 repeater floor-mounted wall-mounted))
        (when (and coordinates-required
                   (/= coordinate-count 1))
          (fail-init-check nil "~%Repeater must have exactly one APPARATUS-COORDS> functional point.~%~
                  Repeater: ~S~%~
                  Coordinate facts: ~D"
                 repeater coordinate-count))))))


(define-init-check-helper init-chroma-map (literals)
  (let ((chromas (make-hash-table :test #'equal)))
    (dolist (literal (init-literals-with-relation 'has-chroma literals))
      (destructuring-bind (endpoint hue)
          (rest (init-literal-proposition literal))
        (setf (gethash endpoint chromas) hue)))
    chromas))


(define-init-check-helper init-coupled-p (source destination literals)
  (some (lambda (literal)
          (destructuring-bind (coupled-source coupled-destination)
              (rest (init-literal-proposition literal))
            (and (eql source coupled-source)
                 (eql destination coupled-destination))))
        (init-literals-with-relation 'coupled literals)))


(define-init-check-helper init-beam-via-p (source destination literals)
  (some (lambda (literal)
          (destructuring-bind (beam-source obstacles beam-destination)
              (rest (init-literal-proposition literal))
            (declare (ignore obstacles))
            (and (eql source beam-source)
                 (eql destination beam-destination))))
        (init-literals-with-relation 'beam-via literals)))


(define-init-check-helper check-init-coupled-beam-consistency (literals)
  "Checks directional fixed-apparatus beam declarations and their corridors."
  (let ((chromas (init-chroma-map literals)))
    (dolist (literal (init-literals-with-relation 'coupled literals))
      (destructuring-bind (source destination)
          (rest (init-literal-proposition literal))
        (let ((source-hue (gethash source chromas))
              (destination-hue (gethash destination chromas)))
          (when (and (init-type-member-p source 'transmitter)
                     (not source-hue))
            (fail-init-check nil "~%COUPLED transmitter has no HAS-CHROMA entry.~%~
                    Literal:     ~S~%~
                    Transmitter: ~S"
                   literal source))
          (when (and (init-type-member-p destination 'receiver)
                     (not destination-hue))
            (fail-init-check nil "~%COUPLED receiver has no HAS-CHROMA entry.~%~
                    Literal: ~S~%~
                    Receiver: ~S"
                   literal destination))
          (when (and (init-type-member-p source 'transmitter)
                     (init-type-member-p destination 'receiver)
                     (not (eql source-hue destination-hue)))
            (fail-init-check nil "~%COUPLED endpoints have mismatched HAS-CHROMA values.~%~
                    Literal:         ~S~%~
                    Transmitter hue: ~S~%~
                    Receiver hue:    ~S"
                   literal source-hue destination-hue))
          (unless (init-beam-via-p source destination literals)
            (fail-init-check nil "~%COUPLED pair has no matching BEAM-VIA corridor.~%~
                    Literal:       ~S~%~
                    Expected beam: (BEAM-VIA ~S ... ~S)"
                   literal source destination))))))
  (dolist (literal (init-literals-with-relation 'beam-via literals))
    (destructuring-bind (source obstacles destination)
        (rest (init-literal-proposition literal))
      (declare (ignore obstacles))
      (unless (init-coupled-p source destination literals)
        (fail-init-check nil "~%BEAM-VIA corridor has no matching COUPLED pair.~%~
                Literal:        ~S~%~
                Expected pair:  (COUPLED ~S ~S)"
               literal source destination)))))


;;;; ==== end technology -beam-substrate-init-checks ====

(in-package :ww)


(define-optional-types
  hue transmitter receiver location floor-repeater wall-repeater)


(define-types
  repeater (either floor-repeater wall-repeater)
  fixed-beam-source (either transmitter floor-repeater wall-repeater)
  fixed-beam-sink (either floor-repeater wall-repeater receiver)
  beam-node (either transmitter receiver floor-repeater wall-repeater location))


(define-dynamic-relations
  (active receiver))


(define-derived-relations
  active)


(define-static-relations
  (has-chroma (either transmitter receiver) $hue)
  (coupled fixed-beam-source fixed-beam-sink)
  (beam-via fixed-beam-source $list fixed-beam-sink))


(define-update update-receiver-status! ()
  ;; A receiver is active iff a chroma-matching direct or relay beam reaches it.
  (doall (?r receiver)
    (if (beam-reaches-receiver ?r)
      (active ?r)
      (not (active ?r)))))


(define-query beam-reaches-receiver (?receiver receiver)
  (or (direct-beam-reaches-receiver ?receiver)
      (relay-beam-reaches-receiver ?receiver)))


(define-query recording-shadow-beam-reaches-receiver
    (?view ?lighting ?receiver receiver)
  (or (recording-shadow-direct-beam-reaches-receiver ?view ?receiver)
      (recording-shadow-relay-beam-reaches-receiver
        ?view ?lighting ?receiver)))


(define-query beam-live-for-cutting
    (?from beam-node
     ?to beam-node
     ?lighting)
  (or (direct-beam-live-for-cutting ?from ?to)
      (relay-beam-live-for-cutting ?from ?to ?lighting)))


;;;; NULL-OBJECT DEFAULT HOOKS ;;;;
;;;; Each is overridden by the capability that owns it; absent capabilities keep the default.
;;;; An optional type with no objects does not remove or skip one of these definitions. The
;;;; hook remains callable and returns its neutral result. Only an action or quantifier that
;;;; enumerates the empty type produces no instantiations/calls.


(define-query direct-beam-reaches-receiver (?receiver receiver)
  (do ?receiver nil))


(define-query relay-beam-reaches-receiver (?receiver receiver)
  (do ?receiver nil))


(define-query recording-shadow-direct-beam-reaches-receiver
    (?view ?receiver receiver)
  (do ?view ?receiver nil))


(define-query recording-shadow-relay-beam-reaches-receiver
    (?view ?lighting ?receiver receiver)
  (do ?view ?lighting ?receiver nil))


(define-query direct-beam-live-for-cutting (?from beam-node ?to beam-node)
  (do ?from ?to nil))


(define-query relay-beam-live-for-cutting
    (?from beam-node
     ?to beam-node
     ?lighting)
  (do ?from ?to ?lighting nil))


(define-query beam-cut
    (?from beam-node
     ?to beam-node)
  (do ?from ?to nil))


(define-query beam-cut-in
    (?from beam-node
     ?to beam-node
     ?active)
  (do ?from ?to ?active nil))


(define-query current-crossing-set ()
  nil)


(define-query fixed-beam-corridor-clear (?from beam-node ?to beam-node)
  (do ?from ?to nil))


(define-query fixed-beam-corridor-clear-for-object
    (?view ?from beam-node ?to beam-node)
  (do ?view ?from ?to nil))


(define-query compute-relay-lighting (?active)
  (do ?active nil))


(define-query compute-relay-lighting-for-object (?view ?active)
  (do ?view ?active nil))


(define-query beam-relay-source-distance (?from beam-node ?lighting)
  (do ?from ?lighting most-positive-fixnum))

;;;; ==== end technology -beam-substrate ====

;;;; ==== begin technology -controls-init-checks ====

;;; Filename: -controls-init-checks.lisp

;;; Initialization validation for control wiring and modes.


(in-package :ww)


(define-init-check controls-init-check (literals)
  (:consumes receiver plate)
  (when (init-dnf-controls-relation-p)
    (check-init-controls-list-contents literals))
  (check-init-controls-modes literals))


(define-init-check-helper init-check-controls-clauses (literal clauses)
  (unless (listp clauses)
    (fail-init-check nil "~%CONTROLS relation must use a DNF list of controller clauses.~%~
            Literal: ~S~%~
            Clauses: ~S"
           literal clauses))
  (dolist (clause clauses)
    (unless (listp clause)
      (fail-init-check nil "~%CONTROLS relation must use a DNF list of controller clauses.~%~
              Literal: ~S~%~
              Clause:  ~S"
             literal clause))
    (init-check-list-items-have-types literal clause '(receiver plate))))


(define-init-check-helper check-init-controls-list-contents (literals)
  (dolist (literal (init-literals-with-relation 'controls literals))
    (init-check-controls-clauses
      literal
      (second (init-literal-proposition literal)))))


(define-init-check-helper init-dnf-controls-relation-p ()
  (equal (init-relation-fluent-indices 'controls) '(1 3)))


(define-init-check-helper check-init-controls-modes (literals)
  "Checks that CONTROLS uses only modes implemented by update-gate-status!."
  (when (init-dnf-controls-relation-p)
    (dolist (literal (init-literals-with-relation 'controls literals))
      (let ((mode (fourth (init-literal-proposition literal))))
        (unless (member mode '(normal inverted))
          (fail-init-check nil "~%CONTROLS uses an unsupported mode.~%~
                  Literal:          ~S~%~
                  Unsupported mode: ~S~%~
                  Supported modes:  (NORMAL INVERTED)"
                 literal mode))))))


;;;; ==== end technology -controls-init-checks ====

(in-package :ww)


(define-optional-types
  gate floor-gears wall-gears angled-gears
  floor-blower wall-blower angled-blower receiver gun)


(define-types
  mode (normal inverted))


(define-static-relations
  ;; $list is a DNF OR-list of AND-lists.  The init validator checks its nested
  ;; controller types because a fluent list value cannot express them in this signature.
  (controls $list
    (either gate floor-gears wall-gears angled-gears
            floor-blower wall-blower angled-blower gun)
    $mode))


(define-query energized
    (?controller (either receiver pressure-plate toggle-plate))
  ;; A receiver follows its beam state.  A pressure plate follows current physical pressure;
  ;; a toggle plate follows its remembered latch instead.
  (or (and (receiver ?controller)
           (active ?controller))
      (and (pressure-plate ?controller)
           (depressed ?controller))
      (and (toggle-plate ?controller)
           (latched ?controller))))


(define-query control-on (?device ?uncontrolled-default)
  ;; The DNF aggregate every controlled device shares: true (normal) iff some clause has
  ;; every member energized, negated under inverted, and ?UNCONTROLLED-DEFAULT when the
  ;; device has no CONTROLS fact at all -- NIL for a gate, whose uncontrolled reading is
  ;; jam-only, T for gears and guns, which run until something disables them.  What the
  ;; result then means is the caller's business: gate ORs it with jamming, gears and gun
  ;; AND it with not-jammed.
  (do (assign $control-on ?uncontrolled-default)
      (if (bind (controls $clauses ?device $mode))
        (do (assign $any-clause-on
              (ww-loop for $clause in $clauses
                       thereis (ww-loop for $controller in $clause
                                        always (energized $controller))))
            (if (eql $mode 'normal)
              (assign $control-on $any-clause-on)
              (if (eql $mode 'inverted)
                (assign $control-on (not $any-clause-on))))))
      $control-on))

;;;; ==== end technology -controls ====

;;;; ==== begin technology -gate ====

;;; Filename: -gate.lisp

;;; Gate substrate: the shared (open gate) relation and its gate optional type, owned in
;;; one place so every capability that reads gate openness -- walkability (via nested
;;; -passability), reachability, visibility, beam-direct, beam-crossing, and -passability
;;; itself -- nests this file instead of hand-copying the declaration.  Only gate.lisp's
;;; update-gate-status! ever asserts (open gate); an unincluded gate leaves the relation
;;; declared but never true, which is the correct default when a problem has no gates.
;;;
;;; REQUIRES:
;;;   types     : (none bare)
;;; PROVIDES:
;;;   types     : gate  --  declared optional here
;;;   nested    : -recording-shadow-policy (neutral recording-side state hooks)
;;;   relations : (open gate)  --  asserted only by gate.lisp's update-gate-status!
;;;   query     : gate-open-for-object -- playback state normally, recording state for a
;;;               recording-shadow object


;;;; ==== begin technology -recording-shadow-policy ====

;;; Filename: -recording-shadow-policy.lisp

;;; Neutral hooks for selecting an object's environmental state view.  Ordinary problems
;;; use only shared playback state.  -recorder-core selects the recording objects and their
;;; presence, while the gate and wall-drive shadow components override their capability
;;; hooks.  Beam peers consume those selections for recording-side beam state.
;;;
;;; PROVIDES:
;;;   queries : recording-shadow-object          -- object uses recording-side physics
;;;             recording-shadow-object-present  -- object exists in recording view
;;;             recording-shadow-turning         -- wall gears turn in recording-side state
;;;             recording-shadow-gate-open        -- gate is open in recording-side state

(in-package :ww)


(define-query recording-shadow-object (?object)
  (do ?object nil))


(define-query recording-shadow-object-present (?object)
  (do ?object t))


(define-query recording-shadow-turning (?gears)
  (do ?gears nil))


(define-query recording-shadow-gate-open (?gate)
  (do ?gate nil))

;;;; ==== end technology -recording-shadow-policy ====

(in-package :ww)


(define-optional-types gate)


(define-dynamic-relations
  (open gate))


(define-query gate-open-for-object (?object ?gate gate)
  (if (recording-shadow-object ?object)
    (recording-shadow-gate-open ?gate)
    (open ?gate)))

;;;; ==== end technology -gate ====

(in-package :ww)


(define-optional-types jammer)


(define-derived-relations
  open)


(define-update update-gate-status! ()
  ;; open <=> jammed OR control-on, with -controls' shared CONTROL-ON supplying the DNF
  ;; aggregate.  Jamming is the leading disjunct, so it overrides an inverted force-close.
  ;; The NIL uncontrolled default reduces an uncontrolled gate to open <=> jammed, which is
  ;; how jam-driven opening is realized.  Change detection is automatic, so an unchanged
  ;; re-assert is silent.
  (doall (?gate gate)
    (if (or (exists (?j jammer)
              (jamming ?j ?gate))
            (control-on ?gate nil))
      (open ?gate)
      (not (open ?gate)))))

;;;; ==== end technology gate ====

;;;; ==== begin technology plate ====

;;; Filename: plate.lisp

;;; Plate technology: plates physically depress under any movable object resting on them.
;;; Toggle plates additionally remember each clear-to-depressed transition.
;;;
;;; REQUIRES:
;;;   types  : pressure-plate, toggle-plate, and their plate union, from -plate-types
;;;   nested : -support-occupancy (support-occupant, support, on, cleartop)
;;;   special: *applying-init-action* (engine) distinguishes initial-state construction
;;;            from transitions during search
;;;   driver : the master propagate-consequences! must call update-plate-status!
;;; PROVIDES:
;;;   types    : pressure-plate, toggle-plate, plate -- from -plate-types
;;;   relations: (depressed plate)       -- current physical pressure
;;;              (latched toggle-plate)  -- remembered toggle output
;;;   update   : update-plate-status!

;; (include-tech -plate-types): already included -- skipped
;; (include-tech -propagation): already included -- skipped

;;;; ==== begin technology -support-occupancy ====

;;; Filename: -support-occupancy.lisp

;;; Support occupancy substrate: whether the top of a support is unoccupied.  This file owns
;;; the support-occupant type composition, declared identically by every other tech file that
;;; reads or writes (on $support-occupant $support :bijective).
;;;
;;; REQUIRES:
;;;   type     : support
;;; PROVIDES:
;;;   types    : support-occupant (either agent box jammer connector fan tray)  --  also
;;;              declared identically by box, jammer, walkability, and ladder
;;;              support (either pressure-plate toggle-plate box fan tray floor-blower
;;;              angled-blower)  --  also declared
;;;              identically by box, jammer, walkability, and ladder.  Gears are not a
;;;              support: only a fan can occupy them, via -gears-fan's (mounted-on ...)
;;;              attachment rather than (on ...).  A tray is a support only while held; on
;;;              the ground it is inert (see support-top-elevation)
;;;   relation : (on $support-occupant $support :bijective)  --  also declared identically
;;;              by box, jammer, walkability, and ladder; multiple techs both read
;;;              and write it.  Bijective so CLEARTOP can look up a support's occupant
;;;              (if any) by reverse index instead of scanning every support-occupant --
;;;              safe because a support holds at most one occupant, an invariant
;;;              -PHYSICAL-INIT-CHECKS enforces at init and every placement action
;;;              enforces thereafter by checking CLEARTOP first
;;;   nested   : -interaction-policy (neutral support-use-allowed hook)
;;;   query    : cleartop

;; (include-tech -plate-types): already included -- skipped

;;;; ==== begin technology -interaction-policy ====

;;; Filename: -interaction-policy.lisp

;;; Interaction-policy hooks.  Shared actions call these neutral interfaces without knowing
;;; whether a recorder is present.  -recorder-core overrides them after nesting this file,
;;; so include-tech deduplication preserves the overrides regardless of public include order.
;;;
;;; PROVIDES:
;;;   queries : object-manipulation-allowed  -- actor may pick up, carry, place, or mount object
;;;             support-use-allowed          -- occupant may rest or stand on support
;;;             connector-pairing-allowed    -- actor may pair connector to terminus

(in-package :ww)


(define-query object-manipulation-allowed (?actor ?object)
  (do ?actor ?object t))


(define-query support-use-allowed (?occupant ?support)
  (do ?occupant ?support t))


(define-query connector-pairing-allowed (?actor ?connector ?terminus)
  (do ?actor ?connector ?terminus t))

;;;; ==== end technology -interaction-policy ====

;;;; ==== begin technology -physical-init-checks ====

;;; Filename: -physical-init-checks.lisp

;;; Initialization validation for shared physical placement facts.


(in-package :ww)


(define-init-check physical-state-init-check (literals)
  (check-init-object-placement-consistency literals))


(define-init-check-helper init-object-location (object locations positions)
  (or (gethash object locations)
      (gethash object positions)))


(define-init-check-helper init-location-valued-relation-p (relation)
  (init-type-spec-includes-type-p
    (init-relation-argument-type relation 2)
    'location))


(define-init-check-helper init-relation-can-locate-object-p (relation object)
  (and (init-location-valued-relation-p relation)
       (init-type-spec-member-p
         object
         (init-relation-argument-type relation 1))))


(define-init-check-helper init-on-location-consistency-required-p (object support)
  (and (init-relation-can-locate-object-p 'has-location object)
       (or (init-relation-can-locate-object-p 'has-location support)
           (init-relation-can-locate-object-p 'has-position support))))


(define-init-check-helper init-binary-on-literals (literals)
  (remove-if-not (lambda (literal)
                   (= (length (rest (init-literal-proposition literal))) 2))
                 (positive-init-literals-with-relation 'on literals)))


(define-init-check-helper init-held-objects (literals)
  (let ((held-objects (make-hash-table :test #'equal)))
    (dolist (literal (positive-init-literals-with-relation 'holding literals)
                     held-objects)
      (setf (gethash (third (init-literal-proposition literal)) held-objects) t))))


(define-init-check-helper init-check-tray-support-held
    (literal support held-objects)
  (when (and (init-type-member-p support 'tray)
             (not (gethash support held-objects)))
    (fail-init-check nil "~%DEFINE-INIT places an object on an unheld tray.~%~
            Literal: ~S~%~
            Tray:    ~S"
           literal support)))


(define-init-check-helper init-check-object-not-held-and-has-location (literals locations)
  ;; A tray is the one deviation: it keeps its has-location fact even while held (synced
  ;; to its holder's location), so a support-occupant resting on it keeps resolving a
  ;; location through the ordinary consumers.  Every other held cargo type must still
  ;; have no has-location.
  (dolist (literal (init-literals-with-relation 'holding literals))
    (destructuring-bind (agent object)
        (rest (init-literal-proposition literal))
      (declare (ignore agent))
      (when (and (gethash object locations)
                 (not (init-type-member-p object 'tray)))
        (fail-init-check nil "~%DEFINE-INIT object is both held and assigned HAS-LOCATION.~%~
                Literal: ~S~%~
                Object:  ~S"
               literal object)))))


(define-init-check-helper init-check-support-has-one-object (literal object support support-occupants)
  (let ((occupant (gethash support support-occupants)))
    (when occupant
      (fail-init-check nil "~%DEFINE-INIT places multiple objects on the same support.~%~
              Literal:          ~S~%~
              Existing object:  ~S~%~
              New object:       ~S~%~
              Support:          ~S"
             literal occupant object support))
    (setf (gethash support support-occupants) object)))


(define-init-check-helper init-check-on-location-consistency
    (literal object support locations positions)
  (let ((object-location (gethash object locations))
        (support-location (init-object-location support locations positions)))
    (unless object-location
      (fail-init-check nil "~%DEFINE-INIT places an object on a support, but the object has no HAS-LOCATION.~%~
              Literal: ~S~%~
              Object:  ~S"
             literal object))
    (unless support-location
      (fail-init-check nil "~%DEFINE-INIT places an object on a support with no HAS-LOCATION or HAS-POSITION.~%~
              Literal: ~S~%~
              Support: ~S"
             literal support))
    (unless (eql object-location support-location)
      (fail-init-check nil "~%DEFINE-INIT object location does not match support location.~%~
              Literal:          ~S~%~
              Object location:  ~S~%~
              Support location: ~S"
             literal object-location support-location))))


(define-init-check-helper init-check-on-cycle (literal object on-map)
  (let ((seen nil)
        (current object))
    (loop
      (when (member current seen)
        (fail-init-check nil "~%DEFINE-INIT contains an ON cycle.~%~
                Literal: ~S~%~
                Cycle includes: ~S"
               literal current))
      (push current seen)
      (let ((support (gethash current on-map)))
        (unless support
          (return))
        (when (eql support current)
          (fail-init-check nil "~%DEFINE-INIT places an object on itself.~%~
                  Literal: ~S~%~
                  Object:  ~S"
                 literal current))
        (setf current support)))))


(define-init-check-helper check-init-object-placement-consistency (literals)
  "Checks physical consistency of HAS-LOCATION, HOLDING, ON, and HAS-POSITION facts."
  (let ((locations (init-literal-map 'has-location literals 1 2))
        (positions (init-literal-map 'has-position literals 1 2))
        (on-map (init-literal-map 'on literals 1 2))
        (held-objects (init-held-objects literals))
        (support-occupants (make-hash-table :test #'equal)))
    (init-check-object-not-held-and-has-location literals locations)
    (dolist (literal (init-binary-on-literals literals))
      (destructuring-bind (object support)
          (rest (init-literal-proposition literal))
        (let ((location-consistency-required-p
                (init-on-location-consistency-required-p object support)))
          (when (eql object support)
            (fail-init-check nil "~%DEFINE-INIT places an object on itself.~%~
                    Literal: ~S~%~
                    Object:  ~S"
                   literal object))
          (init-check-tray-support-held literal support held-objects)
          (when location-consistency-required-p
            (init-check-support-has-one-object
              literal object support support-occupants)
            (init-check-on-location-consistency
              literal object support locations positions)))
        (init-check-on-cycle literal object on-map)))))


;;;; ==== end technology -physical-init-checks ====

(in-package :ww)


(define-types
  support-occupant (either agent box jammer connector fan tray)  ;also declared identically by box/jammer/walkability/ladder
  support
    (either pressure-plate toggle-plate box fan tray floor-blower angled-blower))  ;fixed floor/angled blowers expose the same flush support surface as a mounted fan


(define-dynamic-relations
  (on $support-occupant $support :bijective))  ;also declared by box/jammer/walkability/ladder; support an occupant rests on (absent if ground)


(define-query cleartop (?support support)
  ;; A support top is clear iff no support occupant rests on it.  ON is bijective, so
  ;; this is a single reverse-indexed lookup instead of a scan over every support-occupant.
  (not (bind (on $occupant ?support))))

;;;; ==== end technology -support-occupancy ====

(in-package :ww)


(define-dynamic-relations
  (depressed plate)
  (latched toggle-plate))


(define-derived-relations
  depressed)


(define-update update-plate-status! ()
  ;; A plate is depressed iff something rests on it.  During initial-state construction,
  ;; existing occupancy establishes that physical baseline without changing a toggle
  ;; plate's authored latch state.  Thereafter a toggle plate flips its latch only on the
  ;; physical transition from clear to depressed.  Additional occupants arriving while
  ;; it remains depressed, and occupants leaving while another remains, do not flip the
  ;; latch.  Occupancy is delegated to CLEARTOP, keeping this update independent of the
  ;; problem's support-occupant roster.
  (doall (?p plate)
    (if (cleartop ?p)
      (not (depressed ?p))
      (do (if (and (not *applying-init-action*)
                   (toggle-plate ?p)
                   (not (depressed ?p)))
            (if (latched ?p)
              (not (latched ?p))
              (latched ?p)))
          (depressed ?p)))))

;;;; ==== end technology plate ====

;;;; ==== begin technology elevation ====

;;; Filename: elevation.lisp

;;; Elevation background capability: public wrapper for the shared elevation substrate.
;;; Include this from a problem when its authored initial facts use fixed elevation levels,
;;; without exposing the dash-prefixed substrate file as part of the problem-facing API.
;;;
;;; PROVIDES:
;;;   via -elevation: elevated-object, has-elevation, object-elevation,
;;;                   location-elevation, fixture-elevation
;;;                   (locations and barriers, including walls, default to base 0;
;;;                    transmitters/receivers/guns default to functional elevation 1)


;;;; ==== begin technology -elevation ====

;;; Filename: -elevation.lisp

;;; Elevation substrate: the fixed vertical level of a location's own floor, a fixed
;;; obstacle's base, or a fixed fixture's beam/sightline anchor.  Locations and barrier
;;; fixtures default to base elevation 0; transmitter, receiver, and gun functional anchors
;;; default to elevation 1.  A floor-repeater's declared elevation is its base level (default 0) and
;;; its anchor adds its declared height; a wall-repeater's declared elevation is directly
;;; its mounting/anchor level (default 1).  Nondefault objects assert an explicit fact.
;;;
;;; PROVIDES:
;;;   nested   : -height (repeater, declared-height)
;;;   types    : elevated-object (either location gate screen wall edge transmitter
;;;              receiver gun wall-gears wall-blower floor-repeater wall-repeater)  --
;;;              wall gears and fixed wall blowers may declare their stream elevation
;;;              (default 1, via -gears-fan's blower-elevation)
;;;   relation : (has-elevation elevated-object $rational)
;;;   queries  : object-elevation, location-elevation, repeater-mount-elevation,
;;;              repeater-anchor-elevation, fixture-elevation, apparatus-anchor-elevation


;;;; ==== begin technology -height ====

;;; Filename: -height.lisp

;;; Height substrate: the physical height of a heighted object, used for vertical reach,
;;; vaulting, and line-of-sight clearance checks.  This file owns the heighted-object type
;;; composition, the
;;; (has-height ...) relation, and the shared declared-or-default query, declared identically
;;; by every tech file that reads or writes it -- box, jump, jammer, and beam-direct --
;;; so consumers nest-include this file instead of each re-declaring the same union, relation,
;;; or default-fallback query.
;;;
;;; declared-height defaults gate, screen, and wall to 4; edge to 3/2; agent to 3/2; and
;;; box, jammer, connector, and repeater to 1.
;;; A repeater's height follows its mounting axis: vertical for a floor-repeater and
;;; horizontal for a wall-repeater.
;;;
;;; PROVIDES:
;;;   types    : repeater (either floor-repeater wall-repeater);
;;;              heighted-object (either box gate agent screen wall edge jammer connector
;;;              floor-repeater wall-repeater) -- what can have a declared height;
;;;              optional subtypes absent from the problem resolve to nil, a no-op
;;;   relation : (has-height heighted-object $rational)
;;;   query    : declared-height  --  declared value, or role default (gate/screen/wall 4,
;;;              edge 3/2, agent 3/2, box/jammer/connector/repeater 1)

(in-package :ww)


(define-optional-types wall edge floor-repeater wall-repeater)


(define-types
  repeater (either floor-repeater wall-repeater)
  heighted-object
    (either box gate agent screen wall edge jammer connector floor-repeater wall-repeater))


(define-static-relations
  (has-height heighted-object $rational))


(define-query declared-height (?object heighted-object)
  ;; Declared physical height, or the shared role default when undeclared.  Gate, screen,
  ;; and wall use 4; edge uses 3/2; agent uses 3/2; box, jammer, connector, and repeaters
  ;; use 1.
  (if (bind (has-height ?object $h))
    $h
    (if (or (gate ?object) (screen ?object) (wall ?object))
      4
      (if (edge ?object)
        3/2
        (if (agent ?object)
          3/2
          1)))))

;;;; ==== end technology -height ====

(in-package :ww)


(define-optional-types
  gate screen wall edge transmitter receiver gun wall-gears wall-blower)


(define-types
  elevated-object
    (either location gate screen wall edge transmitter receiver gun
            wall-gears wall-blower
            floor-repeater wall-repeater))


(define-static-relations
  (has-elevation elevated-object $rational))  ;fixed base/anchor level; absent default depends on role


(defparameter *object-elevation-cache* (make-hash-table :test #'eq)
  "Memoizes OBJECT-ELEVATION by object.  HAS-ELEVATION is static -- fixed for the whole
   problem instance and never asserted or retracted by any update -- so each object's
   elevation only needs computing once.  DEFPARAMETER (not DEFVAR) so the cache resets
   every time this file is respliced and loaded for a (possibly different) problem.")


(define-query object-elevation (?object elevated-object)
  ;; Declared fixed level of an elevated object, or zero if none was asserted.
  ;; Cached: see *OBJECT-ELEVATION-CACHE*.
  (multiple-value-bind (cached present) (gethash ?object *object-elevation-cache*)
    (if present
      cached
      (setf (gethash ?object *object-elevation-cache*)
            (if (bind (has-elevation ?object $level))
              $level
              0)))))


(define-query location-elevation (?location location)
  ;; Declared floor level of a location, or zero if none was asserted (ordinary ground).
  (object-elevation ?location))


(define-query repeater-mount-elevation (?repeater repeater)
  ;; HAS-ELEVATION names the base level of a floor repeater and the mounting/anchor level
  ;; of a wall repeater.  The omitted-value default therefore depends on orientation.
  (do (assign $floor-mounted (floor-repeater ?repeater))
      (assign $wall-mounted (wall-repeater ?repeater))
      (if (eql $floor-mounted $wall-mounted)
        (error "~%Repeater must have exactly one mounting orientation.~%~
                Repeater: ~S"
               ?repeater))
      (if (bind (has-elevation ?repeater $level))
        $level
        (if $floor-mounted 0 1))))


(define-query repeater-anchor-elevation (?repeater repeater)
  ;; A floor repeater stands vertically, so its tip is one declared height above its base.
  ;; A wall repeater extends horizontally, leaving its tip at its mounting elevation.
  (if (floor-repeater ?repeater)
    (+ (repeater-mount-elevation ?repeater)
       (declared-height ?repeater))
    (repeater-mount-elevation ?repeater)))


(defparameter *fixture-elevation-cache* (make-hash-table :test #'eq)
  "Memoizes FIXTURE-ELEVATION by fixture.  Every fact it can read -- HAS-ELEVATION,
   HAS-HEIGHT (via REPEATER-ANCHOR-ELEVATION), and fixed type membership -- is static,
   so the result never changes during a search.  Reset on every load; see
   *OBJECT-ELEVATION-CACHE*.")


(define-query fixture-elevation
    (?fixture (either gate transmitter receiver gun floor-repeater wall-repeater))
  ;; Declared fixed-fixture level.  Gates use base elevation 0, point-apparatus anchors
  ;; default to 1, and repeaters use their mounting-dependent anchor rule.
  ;; Cached: see *FIXTURE-ELEVATION-CACHE*.
  (multiple-value-bind (cached present) (gethash ?fixture *fixture-elevation-cache*)
    (if present
      cached
      (setf (gethash ?fixture *fixture-elevation-cache*)
            (if (repeater ?fixture)
              (repeater-anchor-elevation ?fixture)
              (if (bind (has-elevation ?fixture $level))
                $level
                (if (or (transmitter ?fixture)
                        (receiver ?fixture)
                        (gun ?fixture))
                  1
                  0)))))))


(define-query apparatus-anchor-elevation
    (?apparatus (either transmitter receiver gun floor-repeater wall-repeater))
  ;; The vertical coordinate paired with APPARATUS-COORDS>'s horizontal functional point.
  ;; Transmitters, receivers, and guns are point apparatus; repeaters apply their mounting rule.
  (if (repeater ?apparatus)
    (repeater-anchor-elevation ?apparatus)
    (fixture-elevation ?apparatus)))

;;;; ==== end technology -elevation ====

(in-package :ww)

;;;; ==== end technology elevation ====

;;;; ==== begin technology tray ====

;;; Filename: tray.lisp

;;; Tray technology: a carryable, stackable support -- but only while held.  An agent can
;;; pick up a tray within its own height of reach and put a held tray on the ground, a
;;; plate, a clear box top, or another agent's currently-held tray, exactly like a box.
;;; Unlike a box, a tray also supports occupants of its own while held: another agent may
;;; place an object on any currently-held tray (see -placement's held-tray clause), and
;;; that object's has-location tracks the holder's as it moves (see
;;; -configuration-transition's relocation cascade).  A tray resting on the ground is
;;; inert: putting it down unloads its rider onto the ground at the tray's current
;;; location, and nothing can be placed on it there.  A tray keeps its has-location fact
;;; even while held, the one deviation from held cargo having no location, so that its
;;; occupant's has-location consumers (beam-relay, visibility, etc.) keep working
;;; unchanged while the tray is held.
;;;
;;; REQUIRES:
;;;   types     : agent, location; tray is declared optional here
;;;   nested    : -placement (placement-options, place-held-object!; also brings in
;;;               support occupancy, location, position, height, elevation, and holding);
;;;               -reachability (identity-default reachable, overridden by reachability);
;;;               -pickup (pickup-clear, shared with box, jammer, and beam-relay)
;;;   driver    : propagate-changes! (master)
;;; PROVIDES:
;;;   types     : tray -- declared optional here
;;;   actions   : pickup-tray, put-tray


;;;; ==== begin technology -placement ====

;;; Filename: -placement.lisp

;;; Placement substrate: where a carried object may be set down -- a plate, a floor-mounted
;;; fan, a fixed floor/angled blower, a clear box top, another agent's currently-held tray,
;;; or bare ground -- gated by cleartop and the agent's vertical reach.  A fan qualifies as
;;; a support only while mounted on gears: a loose fan is mere cargo, like a connector, and
;;; a wall-mounted fan has no has-location.  A fixed floor/angled blower exposes the same
;;; flush support surface through its fixed position.  A tray qualifies as a support only
;;; while held: grounded, it is inert, so only currently-held trays are ever offered.  Shared by every carried-object
;;; technology that must choose where a held object comes to rest: box, jammer, beam-relay,
;;; and a fan mounted on floor-gears.  Declared identically by each until now; this file owns it
;;; once.  Mounting a fan on gears is an attachment, not a support placement, so it is
;;; -gears-fan's own mount-fan action rather than a case here.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   nested    : -support-elevation (support occupancy, location, position, height,
;;;               elevation, support-top-elevation, occupant-elevation, and
;;;               within-agent-vertical-reach); -holding (cargo, holding)
;;; PROVIDES:
;;;   queries   : placement-choice-allowed -- shared policy gate used by both option
;;;               generation and the placement update
;;;               placement-options  --  legal plate/fan/fixed-blower/box/tray/ground
;;;               placements at a location, excluding a given object (?self) as a
;;;               candidate support; only a floor-mounted fan and only a currently-held
;;;               tray are ever offered
;;;               placement-elevation -- the resting base elevation produced by an option
;;;   update    : place-held-object!  --  releases ?agent's hold, sets ?object's location,
;;;               unloads it first when it is a tray, and rests it on ?place unless
;;;               ?place is 'ground


;;;; ==== begin technology -support-elevation ====

;;; Filename: -support-elevation.lisp

;;; Support-elevation substrate: the vertical level of a support's top and of an
;;; occupant standing either on a support or directly at a location.  These queries
;;; are shared by cargo manipulation and barrier vaulting.
;;;
;;; REQUIRES:
;;;   nested  : -support-occupancy, -location, -position, -height, -elevation, -holding
;;;             (cargo, holding -- needed to find a tray's holder)
;;; PROVIDES:
;;;   parameter : *vertical-reach-limit*, default 1 -- the maximum elevation gap an agent
;;;               can act across vertically: reaching to pick up or place cargo above or
;;;               below its own elevation, or jumping up onto a higher support or clearing
;;;               a barrier (jump.lisp reuses this parameter rather than defining its own).
;;;               Independent of the agent's own declared height.  A problem overrides it
;;;               with its own DEFPARAMETER.
;;;   queries   : support-top-elevation, tray-top-elevation, occupant-elevation,
;;;               within-agent-vertical-reach

;; (include-tech -support-occupancy): already included -- skipped

;;;; ==== begin technology -location ====

;;; Filename: -location.lisp

;;; Location substrate: what "being at a location" means for any movable object.  This file
;;; owns the mobile-object type composition and the (has-location ...) relation, declared
;;; identically by every tech file that reads or writes it -- box, jammer, walkability,
;;; ladder, and beam-direct -- so consumers nest-include this file instead of each
;;; re-declaring the same union and relation.
;;;
;;; PROVIDES:
;;;   type     : mobile-object (either agent box jammer connector fan tray)  --  what can occupy
;;;              a location; subtypes absent from the problem's own define-types resolve to
;;;              nil, a no-op
;;;   relation : (has-location mobile-object $location)

;; (include-tech -physical-init-checks): already included -- skipped

(in-package :ww)


(define-types
  mobile-object (either agent box jammer connector fan tray))  ;what can be at a location


(define-dynamic-relations
  (has-location mobile-object $location))

;;;; ==== end technology -location ====

;;;; ==== begin technology -position ====

;;; Filename: -position.lisp

;;; Position substrate: the fixed placement of a fixture at a location.  This file
;;; owns the fixed-position-object type composition and the (has-position ...) relation, declared
;;; identically by every tech file that reads or writes it -- box, jammer, ladder, and recorder --
;;; so consumers nest-include this file instead of each re-declaring the same union and
;;; relation.
;;;
;;; PROVIDES:
;;;   type     : fixed-position-object (either pressure-plate toggle-plate ladder
;;;              floor-gears wall-gears angled-gears floor-blower wall-blower
;;;              angled-blower recorder)  --  what can be positioned
;;;              at a fixed location; subtypes
;;;              absent from the problem's own define-types resolve to nil, a no-op.  The
;;;              gears leaf types appear directly because this file splices before
;;;              -gears-fan installs the gears union.
;;;   relation : (has-position fixed-position-object $location)

;; (include-tech -plate-types): already included -- skipped
;; (include-tech -physical-init-checks): already included -- skipped

(in-package :ww)


(define-types
  fixed-position-object
    (either pressure-plate toggle-plate ladder
            floor-gears wall-gears angled-gears
            floor-blower wall-blower angled-blower recorder))  ;what can be positioned at a fixed location


(define-static-relations
  (has-position fixed-position-object $location))

;;;; ==== end technology -position ====
;; (include-tech -height): already included -- skipped
;; (include-tech -elevation): already included -- skipped

;;;; ==== begin technology -holding ====

;;; Filename: -holding.lisp

;;; Holding substrate: what an agent carries.  This file owns the cargo type composition and
;;; the (holding ...) relation, declared identically by every tech file that reads or writes
;;; it -- box, jammer, and walkability -- so consumers nest-include this file instead
;;; of each re-declaring the same union and relation.
;;;
;;; PROVIDES:
;;;   type     : cargo (either box jammer connector fan tray)  --  what an agent can carry; subtypes
;;;              absent from the problem's own define-types resolve to nil, a no-op
;;;   relation : (holding $agent $cargo :bijective)  --  bijective so a held tray's holder can
;;;              be found in reverse, eg (bind (holding $agent ?tray)), without a scan

;; (include-tech -physical-init-checks): already included -- skipped

(in-package :ww)


(define-types
  cargo (either box jammer connector fan tray))  ;what an agent can carry


(define-dynamic-relations
  (holding $agent $cargo :bijective))

;;;; ==== end technology -holding ====

(in-package :ww)


(define-optional-types box fan tray)


(defvar *vertical-reach-limit* 1
  "Maximum elevation gap an agent can act across vertically -- reaching to pick up or place
   cargo above or below its own elevation, or jumping up onto a higher support or clearing a
   barrier -- independent of the agent's own declared height.  Reach is symmetric: an object
   resting more than this far below the agent's elevation is out of reach exactly as one more
   than this far above it is.  Problem files can override this.")


(define-query support-top-elevation (?support support)
  ;; A box top is its resting level plus its declared-or-default height.  A fan is a
  ;; movable, zero-thickness support: its top is its own resting level, so a fan mounted
  ;; on gears stays flush with the floor.  A tray's top depends on whether it is currently
  ;; held (see tray-top-elevation).  A plate or fixed floor/angled blower top is the floor
  ;; elevation of the location where the fixture is positioned.
  (if (box ?support)
    (+ (occupant-elevation ?support) (declared-height ?support))
    (if (fan ?support)
      (occupant-elevation ?support)
      (if (tray ?support)
        (tray-top-elevation ?support)
        (do (bind (has-position ?support $location))
            (location-elevation $location))))))


(define-query tray-top-elevation (?tray tray)
  ;; A held tray's top is its holder's own top level -- occupant-elevation plus
  ;; declared-height, zero added for the zero-thickness tray itself.  A grounded tray is
  ;; inert, like a resting fan, contributing nothing beyond its own resting level.
  (if (bind (holding $holder ?tray))
    (+ (occupant-elevation $holder) (declared-height $holder))
    (occupant-elevation ?tray)))


(define-query occupant-elevation (?occupant support-occupant)
  ;; An occupant on a support stands at that support's top (for a plate this is the floor
  ;; elevation, so flush fixtures cost nothing; a box or fan support chains recursively).
  ;; An occupant on the ground -- including a fan mounted on gears, whose attachment is
  ;; not an (on ...) fact -- stands at the floor elevation of its own location.
  (if (bind (on ?occupant $support))
    (support-top-elevation $support)
    (do (bind (has-location ?occupant $location))
        (location-elevation $location))))


(define-query within-agent-vertical-reach (?agent agent ?target-elevation)
  ;; Cargo pickup and placement use one vertical-reach convention: measure from the agent's
  ;; standing elevation, capped by *vertical-reach-limit* in either direction, independent
  ;; of the agent's own declared height.
  (<= (abs (- ?target-elevation (occupant-elevation ?agent)))
      *vertical-reach-limit*))

;;;; ==== end technology -support-elevation ====
;; (include-tech -holding): already included -- skipped

(in-package :ww)


(define-optional-types fan floor-blower angled-blower)


(define-query placement-choice-allowed (?agent agent ?object cargo ?place)
  ;; ?place is either a support object or the Lisp marker GROUND.
  (and (object-manipulation-allowed ?agent ?object)
       (or (eql ?place 'ground)
           (and (support ?place)
                (support-use-allowed ?object ?place)))))


(define-query placement-options (?agent agent ?location location ?self cargo)
  ;; Every plate/fan/box/ground placement at ?location currently legal for ?agent,
  ;; excluding ?self as a candidate support (relevant only when ?self can itself be a box
  ;; or fan; harmless otherwise, since ?self can never be eql to a differently-typed
  ;; candidate).
  (do (assign $places nil)
      (doall (?plate plate)
        (if (and (has-position ?plate ?location)
                 (cleartop ?plate)
                 (placement-choice-allowed ?agent ?self ?plate)
                 (within-agent-vertical-reach ?agent (support-top-elevation ?plate)))
          (assign $places (cons ?plate $places))))
      (doall (?fan fan)
        (if (and (different ?fan ?self)
                 (bind (mounted-on ?fan $gears))  ;a fan supports only while gears-mounted; a loose fan is mere cargo
                 (has-location ?fan ?location)  ;and a wall-mounted fan has no has-location, so floor-mounted only
                 (cleartop ?fan)
                 (placement-choice-allowed ?agent ?self ?fan)
                 (within-agent-vertical-reach ?agent (support-top-elevation ?fan)))
          (assign $places (cons ?fan $places))))
      (doall (?fixed (either floor-blower angled-blower))
        (if (and (different ?fixed ?self)
                 (has-position ?fixed ?location)
                 (cleartop ?fixed)
                 (placement-choice-allowed ?agent ?self ?fixed)
                 (within-agent-vertical-reach ?agent
                                                (support-top-elevation ?fixed)))
          (assign $places (cons ?fixed $places))))
      (doall (?support-box box)
        (if (and (different ?support-box ?self)
                 (has-location ?support-box ?location)
                 (cleartop ?support-box)
                 (placement-choice-allowed ?agent ?self ?support-box)
                 (within-agent-vertical-reach ?agent (support-top-elevation ?support-box)))
          (assign $places (cons ?support-box $places))))
      (doall (?tray tray)
        (if (and (different ?tray ?self)
                 (bind (holding $holder ?tray))  ;a tray supports only while held; grounded, it is inert
                 (has-location ?tray ?location)  ;co-located with ?agent (synced to the holder's location)
                 (cleartop ?tray)
                 (placement-choice-allowed ?agent ?self ?tray)
                 (within-agent-vertical-reach ?agent (support-top-elevation ?tray)))
          (assign $places (cons ?tray $places))))
      (if (and (placement-choice-allowed ?agent ?self 'ground)
               (within-agent-vertical-reach ?agent (location-elevation ?location)))
        (assign $places (cons 'ground $places)))
      $places))


(define-query placement-elevation (?location location ?place)
  ;; ?place is either a support object or the Lisp marker GROUND.  This is the base level
  ;; an object will have after PLACE-HELD-OBJECT!, before its own height is added.
  (if (eql ?place 'ground)
    (location-elevation ?location)
    (support-top-elevation ?place)))


(define-update place-held-object!
    (?agent agent ?object cargo ?location location ?place)
  ;; ?place is either a support object or the Lisp marker GROUND, so it remains untyped.
  ;; A tray stops being a support as soon as its holder releases it.  Its direct rider's
  ;; HAS-LOCATION was kept synchronized while the tray moved, so retracting ON leaves that
  ;; rider on the ground at the release location.  Any stack above the rider stays intact.
  (if (placement-choice-allowed ?agent ?object ?place)
    (do (not (holding ?agent ?object))
        (has-location ?object ?location)
        (if (tray ?object)
          (if (bind (on $rider ?object))
            (not (on $rider ?object))))
        (if (not (eql ?place 'ground))
          (on ?object ?place)))
    (inconsistent-state)))

;;;; ==== end technology -placement ====

;;;; ==== begin technology -reachability ====

;;; Filename: -reachability.lisp

;;; Reachability substrate: the baseline meaning of physical reach for manipulation
;;; actions.  Objects at the same location are always mutually reachable.  The public
;;; reachability technology overrides this query to add authored reach-via edges.
;;;
;;; Nested-only; included by technologies that call reachable.
;;;
;;; REQUIRES:
;;;   type  : location
;;; PROVIDES:
;;;   query : reachable  --  identity default, overridden by reachability

(in-package :ww)


(define-query reachable (?location1 location ?location2 location)
  (eql ?location1 ?location2))

;;;; ==== end technology -reachability ====

;;;; ==== begin technology -pickup ====

;;; Filename: -pickup.lisp

;;; Pickup substrate: whether an agent may pick up a carried object -- empty-handed,
;;; the object's location reachable from the agent's own, and the object's resting
;;; elevation within the agent's vertical reach.  Shared by every carried-object
;;; technology's pickup action: box, jammer, and beam-relay.  Each caller still binds
;;; its own agent/object has-location facts locally (needed downstream for its own
;;; message and effect), and box alone adds its own cleartop check on top of this,
;;; since only box is itself a valid support for another object.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   nested    : -placement (holding, occupant-elevation, within-agent-vertical-reach);
;;;               -reachability (reachable); -interaction-policy arrives through
;;;               -placement's support substrate (object-manipulation-allowed)
;;; PROVIDES:
;;;   query     : pickup-clear  --  true when ?agent, currently at ?a-location, may
;;;               pick up ?object, currently at ?object-location

;; (include-tech -placement): already included -- skipped
;; (include-tech -reachability): already included -- skipped

(in-package :ww)


(define-query pickup-clear (?agent agent ?a-location location ?object cargo ?object-location location)
  (and (object-manipulation-allowed ?agent ?object)
       (not (bind (holding ?agent $any-held-object)))
       (reachable ?object-location ?a-location)
       (within-agent-vertical-reach ?agent (occupant-elevation ?object))))

;;;; ==== end technology -pickup ====

(in-package :ww)


(define-optional-types tray)


(define-action pickup-tray
  ;; Pick up a tray resting on the ground or on a support, within reach.  Unlike other
  ;; cargo, a tray keeps its has-location fact even while held (synced to its holder's
  ;; location by apply-agent-configuration!'s relocation cascade), so a tray already held
  ;; by someone else must be excluded explicitly instead of relying on a missing
  ;; has-location to rule it out.  A grounded tray is always cleartop by construction --
  ;; nothing can rest on a tray unless it is held -- so no cleartop check is needed here.
  1
  (?agent agent ?tray tray)
  (and (bind (has-location ?agent $a-location))
       (bind (has-location ?tray $tray-location))
       (not (bind (holding $holder ?tray)))
       (pickup-clear ?agent $a-location ?tray $tray-location))
  (">" ?agent "picks up" ?tray "at" $tray-location "from" $a-location)
  (assert (holding ?agent ?tray)
          (has-location ?tray $a-location)
          (if (bind (on ?tray $support))
            (not (on ?tray $support)))
          (finally (propagate-changes!))))


(define-action put-tray
  ;; Place a held tray on the ground or on a clear support at a reachable location
  ;; (including the agent's own): one successor per legal placement-options result.
  ;; PLACE-HELD-OBJECT! unloads any rider because a tray is a support only while held; the
  ;; relocation cascade has already kept the rider at the release location, where it lands
  ;; on the ground.
  1
  (?agent agent ?tray tray ?location location)
  (and (holding ?agent ?tray)
       (bind (has-location ?agent $a-location))
       (reachable ?location $a-location)
       (assign $places (placement-options ?agent ?location ?tray)))
  (">" ?agent "puts" ?tray "on" $place "at" ?location)
  (ww-loop for $placement-option in $places
           do (assert (assign $place $placement-option)
                      (place-held-object! ?agent ?tray ?location $placement-option)
                      (finally (propagate-changes!)))))

;;;; ==== end technology tray ====

;;;; ==== begin technology box ====

;;; Filename: box.lisp

;;; Box technology: a carryable, stackable support.  An agent can pick up a box within its own
;;; height of reach and put a held box on reachable ground, a plate, or a clear box top.  A box
;;; is movable cargo that occupies its support via the (on ...) relation; it has no derived
;;; state of its own.  Agent jumping and support changes belong to the separate jump technology.
;;;
;;; REQUIRES:
;;;   types     : agent, location; plate comes from nested -plate-types and box is
;;;               declared optional here
;;;   nested    : -placement (placement-options, place-held-object!; also brings in
;;;               support occupancy, location, position, height, elevation, and holding);
;;;               -reachability (identity-default reachable, overridden by reachability);
;;;               -pickup (pickup-clear, shared with jammer and beam-relay)
;;;   driver    : propagate-changes! (master)
;;; PROVIDES:
;;;   types     : box -- declared optional here
;;;   actions   : pickup-box, put-box

;; (include-tech -placement): already included -- skipped
;; (include-tech -reachability): already included -- skipped
;; (include-tech -pickup): already included -- skipped

(in-package :ww)


(define-optional-types box)


(define-action pickup-box
  1
  (?agent agent ?box box)
  (and (bind (has-location ?agent $a-location))
       (bind (has-location ?box $box-location))
       (cleartop ?box)
       (pickup-clear ?agent $a-location ?box $box-location))
  (">" ?agent "picks up" ?box "at" $box-location "from" $a-location)
  (assert (holding ?agent ?box)
          (not (has-location ?box $box-location))
          (if (bind (on ?box $support))
            (not (on ?box $support)))
          (finally (propagate-changes!))))


(define-action put-box
  ;; Place a held box on the ground or on a clear support at a reachable location (including
  ;; the agent's own): one successor per legal placement-options result.  Each destination is
  ;; gated by manual reach -- its resting level must be within the agent's height
  ;; (declared-height) of the agent's own level.
  1
  (?agent agent ?box box ?location location)
  (and (holding ?agent ?box)
       (bind (has-location ?agent $a-location))
       (reachable ?location $a-location)
       (assign $places (placement-options ?agent ?location ?box)))
  (">" ?agent "puts" ?box "on" $place "at" ?location)
  (ww-loop for $placement-option in $places
           do (assert (assign $place $placement-option)
                      (place-held-object! ?agent ?box ?location $placement-option)
                      (finally (propagate-changes!)))))

;;;; ==== end technology box ====

;;;; ==== begin technology recorder ====

;;; Filename: recorder.lisp

;;; Public recorder assembly.  Problems continue to write only (include-tech recorder).
;;; Identity and interaction isolation live in -recorder-core; each supported apparatus
;;; owns a private recording-shadow component.  Including this public assembly also installs
;;; recorder-specific prefix pruning, interleaving audit/pruning, candidate validation,
;;; solution reporting, and goal chaining after all implementations have been defined.
;;;
;;; Recorder start/stop transitions and their cycle count are planner-native and repeatable.
;;; The path parser accepts repeated setup/start/window/stop cycles and an optional
;;; final open window.  Every generated STOP successor validates its just-completed isolated
;;; recording and rejects a closed cycle without persistent progress before goal or duplicate
;;; processing.  At equal normalized boundaries, an equal-or-cheaper path with fewer cycles
;;; used dominates one with more cycles.  Final candidate validation checks all cycles plus
;;; the complete integrated path.  One ordinary SOLVE therefore optimizes across every
;;; permitted cycle.  The report reconstructs every cycle and its local metrics from the
;;; accepted path while retaining complete-solution totals.
;;;
;;; Recorder cycle chaining remains an explicitly guided convenience.  Each SOLVE-SUBGOAL
;;; is capped at and required to consume exactly one additional cycle, and the following
;;; SOLVE does the same for the final cycle.  The configured maximum limits the complete
;;; guided history.  Its retained history is locally optimized per search and makes no
;;; global claim.
;;;
;;; The component order preserves the established propagation seed:
;;; ordinary receiver state, recording plate state, recording receiver state, recording
;;; gate state, then recording wall-gears state.  The derived propagation driver still
;;; orders the final calls from their actual read/write graph.
;;;
;;; REQUIRES / PROVIDES VIA COMPONENTS:
;;;   -recorder-core               : RECORDING-COPY>, RECORDING-IN-PROGRESS, side identity,
;;;                                  object presence, and cross-layer interaction policy
;;;   -recorder-plate-shadow       : RECORDING-DEPRESSED / RECORDING-LATCHED
;;;   -recorder-receiver-shadow    : RECORDING-ACTIVE
;;;   -recorder-controls-shadow    : recording-side DNF controller evaluation
;;;   -recorder-jamming-shadow     : ghost-filtered RECORDING-JAMMED
;;;   -recorder-gate-shadow        : RECORDING-OPEN and gate-view hook
;;;   -recorder-wall-gears-shadow  : RECORDING-TURNING and gears-view hook
;;;   -recorder-solution           : multi-window parsing, mandatory stop validation,
;;;                                  optional open-prefix validation, interleaving
;;;                                  audit/pruning, candidate validation, and report
;;;   -recorder-session            : START-RECORDER / STOP-RECORDER actions and the
;;;                                  live-to-ghost state fork; nests -recorder-solution,
;;;                                  so its own list position is a readability choice, not
;;;                                  a load-order requirement
;;;   -recorder-cycle-boundary     : closed-cycle goal and fresh-shadow preparation
;;;   -recorder-cycle-chaining     : one-cycle solve, commit, final solve, and undo history
;;;   -recorder-init-checks        : mapping, isolation, and supported-scope validation
;;;
;;; The supported behavior remains unchanged: plates, direct/relay-fed receivers, gates,
;;; wall gears, and gate/wall-gears jamming have recording views.  Initialization rejects
;;; beam crossings, floor and angled blowers, threats, receiver-controlled wall gears,
;;; movable wall-fan copies, and any other explicitly unsupported combination rather than
;;; approximating it at runtime.


;;;; ==== begin technology -recorder-core ====

;;; Filename: -recorder-core.lisp

;;; Recorder identity and cross-layer interaction policy.  RECORDING-COPY> explicitly maps
;;; each live mobile object to the ghost that replays it.  The relation is directional and
;;; one-to-one, with static indexes in both directions; recorder initialization adds the disjoint,
;;; leaf-category-compatible, and exhaustive loose-cargo invariants.  The relation also
;;; registers its ordered tuples as coupled symmetry rows.
;;;
;;; This file deliberately owns no apparatus shadow state and no propagation update.  It
;;; identifies the recording view, selects which mapped objects existed in that view, and
;;; keeps shared manipulation actions within the appropriate layer.  Capability-specific
;;; state lives in the -recorder-*-shadow components assembled by recorder.lisp.  The core
;;; does own their lifecycle registry: each stateful component registers how its own shadow
;;; is reset and, when necessary, seeded at a chained-cycle boundary.
;;;
;;; REQUIRES:
;;;   nested : -location (mobile-object); -holding (cargo and holding, needed to
;;;            recognize a ghost-held tray); -position (recorder has-position role);
;;;            -interaction-policy (neutral action hooks); -recording-shadow-policy
;;;            (neutral environmental-view hooks)
;;; RECORDING-IN-PROGRESS is declared here, rather than alongside the START-RECORDER /
;;; STOP-RECORDER actions that set it (-recorder-session.lisp), because
;;; OBJECT-MANIPULATION-ALLOWED and CONNECTOR-PAIRING-ALLOWED below need to read it, and
;;; this file is the first component -recorder.lisp assembles.  -recorder-session.lisp
;;; nests this file for the relation, not the other way around.
;;;
;;; PROVIDES:
;;;   type     : recorder, connector, tray (optional)
;;;   relation : recording-copy> (indexed live mobile-object -> ghost mobile-object);
;;;              recording-in-progress, recorder-cycles-used,
;;;              recorder-cycle-closed
;;;   queries  : live-recording-object, ghost-recording-object, same-recording-side,
;;;              recording-shadow-view-object;
;;;              recorder-cycle-count;
;;;              overrides recording-shadow-object, recording-shadow-object-present,
;;;              object-manipulation-allowed, support-use-allowed, and
;;;              connector-pairing-allowed
;;;   functions: register-recorder-shadow-lifecycle,
;;;              clear-recorder-shadow-relation!

;; (include-tech -location): already included -- skipped
;; (include-tech -holding): already included -- skipped
;; (include-tech -position): already included -- skipped
;; (include-tech -interaction-policy): already included -- skipped
;; (include-tech -recording-shadow-policy): already included -- skipped

(in-package :ww)


(define-optional-types recorder connector tray)


(define-static-relations
  (recording-copy> $mobile-object $mobile-object :bijective))


(define-dynamic-relations
  (recording-in-progress)
  (recorder-cycles-used $fixnum)
  (recorder-cycle-closed))


(register-symmetry-coupling 'recording-copy>)


(defvar *recorder-shadow-lifecycles* nil
  "Registered (COMPONENT RESETTER SEEDER) callbacks in component assembly order.")

;; A staged recorder problem reloads this file in the same Lisp image.  Clear registrations
;; from the preceding problem before this recorder assembly registers its own components.
(setf *recorder-shadow-lifecycles* nil)


(defun register-recorder-shadow-lifecycle (component resetter &optional seeder)
  "Register COMPONENT's reset callback and optional seed callback for cycle preparation."
  (when (assoc component *recorder-shadow-lifecycles*)
    (error "Recorder shadow lifecycle registered twice for ~S." component))
  (setf *recorder-shadow-lifecycles*
        (append *recorder-shadow-lifecycles*
                (list (list component resetter seeder))))
  component)


(defun clear-recorder-shadow-relation! (state relation)
  "Remove every proposition for RELATION from STATE's dynamic database."
  (let ((idb (problem-state.idb state)))
    (dolist (proposition (list-database idb))
      (when (eql (first proposition) relation)
        (delete-proposition proposition idb))))
  (invalidate-problem-state-hash state))


(define-query live-recording-object (?object mobile-object)
  (bind (recording-copy> ?object $ghost)))


(define-query ghost-recording-object (?object mobile-object)
  (bind (recording-copy> $live ?object)))


(define-query recording-shadow-view-object ()
  ;; Environmental shadow queries need a side selector, not every ghost's identity.  Any
  ;; mapped ghost selects the same recording view, so bind one representative once per
  ;; recording-side propagation pass.
  (do (assign $view nil)
      (exists (?live mobile-object)
        (bind (recording-copy> ?live $view)))
      $view))


(define-query same-recording-side (?object1 mobile-object ?object2 mobile-object)
  (or (and (live-recording-object ?object1)
           (live-recording-object ?object2))
      (and (ghost-recording-object ?object1)
           (ghost-recording-object ?object2))))


(define-query recorder-cycle-count ()
  ;; A pre-counter open state is one already-started legacy cycle.  A closed legacy state
  ;; has used none.  Materializing the count at the next transition makes both forms enter
  ;; the new state model without a compatibility layer outside the planner state.
  (if (bind (recorder-cycles-used $count))
    $count
    (if (recording-in-progress) 1 0)))


(define-query recording-shadow-object (?object)
  ;; A reverse mapping exists only for a mobile ghost, so a separate type lookup and
  ;; nested GHOST-RECORDING-OBJECT call would repeat work on this hot path.
  (bind (recording-copy> $live ?object)))


(define-query recording-shadow-object-present (?object)
  ;; Fixed apparatus and genuinely unmapped objects exist in both views.  An explicit
  ;; closed-cycle marker removes mapped ghosts from the recording view.  Its absence also
  ;; preserves the legacy shadow-only view used by focused capability characterizations
  ;; that do not install the recorder session actions.  Classify each mobile object once
  ;; through the two recording-copy indexes instead of repeating live/ghost query calls.
  (or (not (mobile-object ?object))
      (if (bind (recording-copy> $live ?object))
        (not (recorder-cycle-closed))
        (not (bind (recording-copy> ?object $ghost))))))


(define-query object-manipulation-allowed (?actor ?object)
  ;; Recorder participants may manipulate only mapped objects on their own side.  A ghost
  ;; does not exist to act until recording is in progress (rule 5); a live actor is
  ;; unrestricted by session timing.
  (and (mobile-object ?actor)
       (mobile-object ?object)
       (same-recording-side ?actor ?object)
       (or (live-recording-object ?actor)
           (recording-in-progress))))


(define-query support-use-allowed (?occupant ?support)
  ;; Fixed supports such as plates are shared environmental apparatus.  Mobile supports
  ;; normally stay on their own recording side.  Rule 19 adds one directional playback
  ;; exception: a live occupant may use a ghost tray while a ghost is actively holding it.
  ;; The reverse dependency remains forbidden because the recorded ghost performance
  ;; cannot rely on a live support introduced during playback.
  (or (not (mobile-object ?support))
      (and (mobile-object ?occupant)
           (same-recording-side ?occupant ?support))
      (and (live-recording-object ?occupant)
           (ghost-recording-object ?support)
           (tray ?support)
           (recording-in-progress)
           (exists (?holder agent)
             (and (ghost-recording-object ?holder)
                  (holding ?holder ?support))))))


(define-query connector-pairing-allowed (?actor ?connector ?terminus)
  ;; Fixed beam apparatus is shared.  During playback a live connector may use either
  ;; layer's connector as a terminus, while a ghost connector may depend only on another
  ;; ghost connector -- never on a live movable connector absent from its recording.  The
  ;; live-to-ghost bridge additionally requires recording to be in progress: a ghost
  ;; terminus does not exist to reference before then (rule 5).  A ghost actor pairing with
  ;; a ghost terminus is already gated by OBJECT-MANIPULATION-ALLOWED above.
  (and (object-manipulation-allowed ?actor ?connector)
       (or (not (connector ?terminus))
           (and (live-recording-object ?actor)
                (or (live-recording-object ?terminus)
                    (and (ghost-recording-object ?terminus)
                         (recording-in-progress))))
           (and (ghost-recording-object ?actor)
                (ghost-recording-object ?terminus)))))

;;;; ==== end technology -recorder-core ====

;;;; ==== begin technology -recorder-controls-shadow ====

;;; Filename: -recorder-controls-shadow.lisp

;;; Recording-side controller evaluation shared by gates and wall gears.  It mirrors
;;; -controls' DNF polarity but reads recording plate and receiver state.  The aggregate
;;; remains textually separate from CONTROL-ON so the propagation walker sees disjoint
;;; playback and recording read sets.
;;;
;;; REQUIRES:
;;;   nested : -controls (CONTROLS and ordinary control schema); -recorder-plate-shadow;
;;;            -recorder-receiver-shadow
;;; PROVIDES:
;;;   queries : recording-controller-energized, recording-control-on

;; (include-tech -controls): already included -- skipped

;;;; ==== begin technology -recorder-plate-shadow ====

;;; Filename: -recorder-plate-shadow.lisp

;;; Recording-side plate state.  Shared ON facts carry both playback and recording
;;; occupants.  An open cycle reads mapped ghosts; a closed cycle reads their live
;;; counterparts, which seed the stable recording pressure/toggle state for the next
;;; start.  The resulting shadow remains distinct from ordinary plate state.
;;;
;;; REQUIRES:
;;;   nested      : -recorder-core (ghost identity); -support-occupancy (plate types, ON);
;;;                 -propagation
;;;   conditional : LATCHED from plate.lisp, guarded by optional TOGGLE-PLATE
;;; PROVIDES:
;;;   relations : recording-depressed, recording-latched
;;;   query     : recording-plate-occupied
;;;   update    : update-recording-plate-status!
;;;   lifecycle : reset-recording-plate-shadow!, seed-recording-plate-shadow!

;; (include-tech -recorder-core): already included -- skipped
;; (include-tech -support-occupancy): already included -- skipped
;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(define-dynamic-relations
  (recording-depressed plate)
  (recording-latched toggle-plate))


(define-derived-relations
  recording-depressed
  recording-latched)


(define-query recording-plate-occupied (?plate plate)
  (exists (?occupant support-occupant)
    (and (on ?occupant ?plate)
         (or (and (recorder-cycle-closed)
                  (live-recording-object ?occupant))
             (and (not (recorder-cycle-closed))
                  (ghost-recording-object ?occupant))))))


(defun reset-recording-plate-shadow! (state)
  "Clear the recording plate edge state inherited from the preceding cycle."
  (clear-recorder-shadow-relation! state 'recording-depressed)
  (clear-recorder-shadow-relation! state 'recording-latched)
  state)


(defun seed-recording-plate-shadow! (state)
  "Seed recording plate memory from the new playback baseline.

The toggle value starts from the ordinary latch.  Depression starts from the active view:
freshly forked ghosts for an open cycle, or live playback state after a stop.  The first
propagation pass therefore cannot mistake an already occupied plate for a new edge."
  (let* ((idb (problem-state.idb state))
         (propositions (list-database idb)))
    (dolist (plate (gethash 'toggle-plate *types*))
      (when (member (list 'latched plate) propositions :test #'equal)
        (add-proposition (list 'recording-latched plate) idb)))
    (dolist (plate (gethash 'plate *types*))
      (when (funcall (symbol-function 'recording-plate-occupied) state plate)
        (add-proposition (list 'recording-depressed plate) idb))))
  (invalidate-problem-state-hash state))


(define-update update-recording-plate-status! ()
  ;; An open or legacy view contains mapped ghost occupants.  An explicit stopped boundary
  ;; reads live playback occupants so its seeded edge memory remains stable under the same
  ;; propagation update.
  (doall (?plate plate)
    (do (if (and *applying-init-action*
                 (toggle-plate ?plate))
          (if (latched ?plate)
            (recording-latched ?plate)
            (not (recording-latched ?plate))))
        (if (recording-plate-occupied ?plate)
          (do (if (and (not *applying-init-action*)
                       (toggle-plate ?plate)
                       (not (recording-depressed ?plate)))
                (if (recording-latched ?plate)
                  (not (recording-latched ?plate))
                  (recording-latched ?plate)))
              (recording-depressed ?plate))
          (not (recording-depressed ?plate))))))


(register-recorder-shadow-lifecycle
  'plate 'reset-recording-plate-shadow! 'seed-recording-plate-shadow!)

;;;; ==== end technology -recorder-plate-shadow ====

;;;; ==== begin technology -recorder-receiver-shadow ====

;;; Filename: -recorder-receiver-shadow.lisp

;;; Recording-side receiver state.  Beam peers already provide recording-shadow arrival
;;; hooks; this component owns the receiver relation and the propagation update consuming
;;; their combined result.
;;;
;;; REQUIRES:
;;;   nested : -recorder-core (recording object/presence policy and the single shadow-view
;;;            selector); -beam-substrate (recording-shadow-beam-reaches-receiver and the
;;;            relay-lighting hook); -propagation
;;; PROVIDES:
;;;   relation : recording-active
;;;   update   : update-recording-receiver-status!
;;;   lifecycle: reset-recording-receiver-shadow!

;; (include-tech -recorder-core): already included -- skipped
;; (include-tech -beam-substrate): already included -- skipped
;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(define-dynamic-relations
  (recording-active receiver))


(define-derived-relations
  recording-active)


(defun reset-recording-receiver-shadow! (state)
  "Clear receiver facts inherited from the preceding recording cycle."
  (clear-recorder-shadow-relation! state 'recording-active))


(define-update update-recording-receiver-status! ()
  ;; Every mapped ghost observes the same recording-side environment.  Select that view
  ;; once and compute its relay lighting once, then reuse both for every receiver.
  (do (assign $view (recording-shadow-view-object))
      (assign $lighting (compute-relay-lighting-for-object $view nil))
      (doall (?receiver receiver)
        (if (recording-shadow-beam-reaches-receiver
              $view $lighting ?receiver)
          (recording-active ?receiver)
          (not (recording-active ?receiver))))))


(register-recorder-shadow-lifecycle
  'receiver 'reset-recording-receiver-shadow!)

;;;; ==== end technology -recorder-receiver-shadow ====

(in-package :ww)


(define-query recording-controller-energized
    (?controller (either receiver pressure-plate toggle-plate))
  (or (and (receiver ?controller)
           (recording-active ?controller))
      (and (pressure-plate ?controller)
           (recording-depressed ?controller))
      (and (toggle-plate ?controller)
           (recording-latched ?controller))))


(define-query recording-control-on (?device ?uncontrolled-default)
  ;; The recording-side twin of -controls' CONTROL-ON: identical DNF polarity and the same
  ;; uncontrolled-default argument, reading ghost-only controller state.
  (do (assign $control-on ?uncontrolled-default)
      (if (bind (controls $clauses ?device $mode))
        (do (assign $any-clause-on
              (ww-loop for $clause in $clauses
                       thereis
                         (ww-loop for $controller in $clause
                                  always
                                    (recording-controller-energized $controller))))
            (if (eql $mode 'normal)
              (assign $control-on $any-clause-on)
              (if (eql $mode 'inverted)
                (assign $control-on (not $any-clause-on))))))
      $control-on))

;;;; ==== end technology -recorder-controls-shadow ====

;;;; ==== begin technology -recorder-jamming-shadow ====

;;; Filename: -recorder-jamming-shadow.lisp

;;; Recording-side jamming view shared by gates and wall gears.  JAMMING remains the one
;;; action-owned relation; this component filters it to mapped ghost jammers rather than
;;; duplicating either the relation or its lifecycle.
;;;
;;; REQUIRES:
;;;   nested      : -recorder-core (ghost identity)
;;;   conditional : JAMMING from jammer.lisp, guarded by optional JAMMER
;;; PROVIDES:
;;;   query : recording-jammed

;; (include-tech -recorder-core): already included -- skipped

(in-package :ww)


(define-optional-types gate wall-gears wall-blower jammer)


(define-query recording-jammed (?target (either gate wall-gears wall-blower))
  ;; Only a mapped ghost jammer existed during the recording, so live-only playback jams
  ;; do not leak into the recording shadow.
  (exists (?jammer jammer)
    (and (ghost-recording-object ?jammer)
         (jamming ?jammer ?target))))

;;;; ==== end technology -recorder-jamming-shadow ====

;;;; ==== begin technology -recorder-gate-shadow ====

;;; Filename: -recorder-gate-shadow.lisp

;;; Recording-side gate state.  Ghost-only controller and jammer readings derive a distinct
;;; OPEN value, exposed through -recording-shadow-policy's gate-view hook.
;;;
;;; REQUIRES:
;;;   nested : -recorder-controls-shadow; -recorder-jamming-shadow; -gate
;;;            (recording-shadow-gate-open neutral hook); -propagation
;;; PROVIDES:
;;;   relation : recording-open
;;;   query    : recording-shadow-gate-open override
;;;   update   : update-recording-gate-status!
;;;   lifecycle: reset-recording-gate-shadow!

;; (include-tech -recorder-controls-shadow): already included -- skipped
;; (include-tech -recorder-jamming-shadow): already included -- skipped
;; (include-tech -gate): already included -- skipped
;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(define-dynamic-relations
  (recording-open gate))


(define-derived-relations
  recording-open)


(defun reset-recording-gate-shadow! (state)
  "Clear gate facts inherited from the preceding recording cycle."
  (clear-recorder-shadow-relation! state 'recording-open))


(define-query recording-shadow-gate-open (?gate)
  (and (gate ?gate)
       (recording-open ?gate)))


(define-update update-recording-gate-status! ()
  ;; A mapped ghost jammer supplies the same force-open override as ordinary playback; a
  ;; mapped live jammer is absent from this view.
  (doall (?gate gate)
    (if (or (recording-jammed ?gate)
            (recording-control-on ?gate nil))
      (recording-open ?gate)
      (not (recording-open ?gate)))))


(register-recorder-shadow-lifecycle
  'gate 'reset-recording-gate-shadow!)

;;;; ==== end technology -recorder-gate-shadow ====

;;;; ==== begin technology -recorder-wall-gears-shadow ====

;;; Filename: -recorder-wall-gears-shadow.lisp

;;; Recording-side wall-drive state for mountable wall gears and fixed wall blowers.
;;; Ghost-only control and jamming readings derive a distinct turning value, exposed
;;; through -recording-shadow-policy's turning-view hook.
;;;
;;; REQUIRES:
;;;   nested : -recorder-controls-shadow; -recorder-jamming-shadow;
;;;            -recording-shadow-policy (recording-shadow-turning neutral hook);
;;;            -propagation
;;; PROVIDES:
;;;   relation : recording-turning
;;;   query    : recording-shadow-turning override
;;;   update   : update-recording-gears-status!
;;;   lifecycle: reset-recording-wall-gears-shadow!

;; (include-tech -recorder-controls-shadow): already included -- skipped
;; (include-tech -recorder-jamming-shadow): already included -- skipped
;; (include-tech -recording-shadow-policy): already included -- skipped
;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(define-optional-types wall-gears wall-blower)


(define-dynamic-relations
  (recording-turning (either wall-gears wall-blower)))


(define-derived-relations
  recording-turning)


(defun reset-recording-wall-gears-shadow! (state)
  "Clear wall-drive facts inherited from the preceding recording cycle."
  (clear-recorder-shadow-relation! state 'recording-turning))


(define-query recording-shadow-turning (?gears)
  (and (or (wall-gears ?gears)
           (wall-blower ?gears))
       (recording-turning ?gears)))


(define-update update-recording-gears-status! ()
  ;; Uncontrolled wall gears turn; controlled wall gears evaluate their DNF against
  ;; recording-side controller state.  A mapped ghost jammer forces them stopped, while a
  ;; mapped live jammer affects only ordinary playback.  The plate-only control restriction
  ;; remains an initialization policy in -recorder-init-checks.
  (doall (?gears (either wall-gears wall-blower))
    (if (and (recording-control-on ?gears t)
             (not (recording-jammed ?gears)))
      (recording-turning ?gears)
      (not (recording-turning ?gears)))))


(register-recorder-shadow-lifecycle
  'wall-blower-drive 'reset-recording-wall-gears-shadow!)

;;;; ==== end technology -recorder-wall-gears-shadow ====

;;;; ==== begin technology -recorder-solution ====

;;; Filename: -recorder-solution.lisp

;;; Recorder path services: multi-window parsing, mandatory completed-cycle validation and
;;; no-progress rejection, closed-boundary cycle-resource dominance, optional open
;;; recording-prefix pruning, automatic exact live/ghost interleaving canonicalization,
;;; candidate validation, and integrated multi-cycle reporting.  Nested
;;; by recorder.lisp, whose public assembly installs pruning, validation, reporting,
;;; and goal chaining after all recorder components have been defined.  Lower-level tests may
;;; include this file for its mechanics without installing those public services.  Nothing
;;; here is a substrate hook, and nothing here reads recording-side state.  The recorder
;;; shadow components derive
;;; RECORDING-DEPRESSED, RECORDING-LATCHED, RECORDING-TURNING, RECORDING-ACTIVE and
;;; RECORDING-OPEN during propagation, while these services run only during prefix or
;;; candidate replay and touch none of them.  What they do read is identity from -recorder-core --
;;; LIVE-RECORDING-OBJECT and GHOST-RECORDING-OBJECT -- plus location, position, the
;;; mobility closure, and (since GHOST-STOPS-RECORDER was strengthened to require a
;;; genuinely closed session) RECORDING-IN-PROGRESS, which is session lifecycle state, not
;;; one of the per-apparatus shadow views above.
;;;
;;; Every intermediate recording is physically closed by STOP-RECORDER.  The parser also
;;; admits a final open cycle when the problem goal is reached first; its isolated recording
;;; must be executable, but physical closure is not added to that goal.  A problem that wants
;;; the final return and stop spelled out adds GHOST-STOPS-RECORDER as a goal conjunct.
;;;
;;; REQUIRES:
;;;   nested : -location ((has-location ...)); -position (recorder has-position role);
;;;            -mobility (mobility-results -- the identity default reduces
;;;            RECORDING-AGENT-CAN-CLOSE to standing on the recorder, which is the right
;;;            reading for a problem with no walking technology); -holding (cargo, holding
;;;            -- nested here rather than left to cargo-carrying techs, so a recording
;;;            session's closure rule is well-defined even in a cargo-free recorder
;;;            problem; empty CARGO there makes RECORDING-AGENT-EMPTY-HANDED a no-op)
;;;   soft   : -recorder-core's identity queries and RECORDING-IN-PROGRESS, assembled by
;;;            recorder.lisp before this component
;;; PROVIDES:
;;;   queries  : ghost-stops-recorder (optional goal conjunct), recording-agent-can-close,
;;;              recording-agent-return-route, recording-agent-at-recorder,
;;;              recording-agent-empty-handed
;;;   functions: parse-recorder-path, validate-recorder-solution,
;;;              validate-recorder-cycle-boundary-prefix,
;;;              validate-recorder-recording-prefix,
;;;              recorder-boundary-identity-state,
;;;              prune-recorder-boundary-dominated-successor-p,
;;;              build-recorder-report, print-recorder-report;
;;;              automatic recorder interleaving pruning;
;;;              recorder-recording-path, recorder-recording-window,
;;;              recorder-recording-snapshot and their helpers locate the real
;;;              START-RECORDER/STOP-RECORDER moves when the searched path contains them,
;;;              falling back to the whole path when it does not

;; (include-tech -location): already included -- skipped
;; (include-tech -position): already included -- skipped

;;;; ==== begin technology -mobility ====

;;; Filename: -mobility.lisp

;;; Mobility substrate: composes pure traversal providers into a canonical transparent
;;; movement closure.  Providers return normalized segments of the form
;;; (mode source witness destination).  MOBILITY-RESULTS returns
;;; (destination route) pairs, including (source nil) for reflexivity.
;;;
;;; REQUIRES:
;;;   types    : agent, location
;;; PROVIDES:
;;;   queries  : mobility-results, mobility-locations, traversable
;;;   functions: register-mobility-provider and canonical closure helpers

(in-package :ww)


(defparameter *mobility-providers* nil
  "Problem-local query names that return traversal segments from one source.")


(defparameter *mobility-route-keys* (make-hash-table :test #'equal)
  "Printed lexical keys for normalized semantic routes in the staged problem.")


(define-problem-helper register-mobility-provider (provider)
  "Register a pure traversal-provider query for the staged problem."
  (unless (and (symbolp provider)
               (member provider *query-names* :test #'eq))
    (error "Mobility provider must name an installed query: ~S" provider))
  (pushnew provider *mobility-providers* :test #'eq)
  provider)


(define-problem-helper mobility-route-key (route)
  "Return the stable lexical tie-break key for a normalized semantic route."
  (multiple-value-bind (key present)
      (gethash route *mobility-route-keys*)
    (if present
      key
      (let ((*print-case* :upcase)
            (*print-pretty* nil)
            (*package* (find-package :ww)))
        (setf (gethash route *mobility-route-keys*)
              (prin1-to-string route))))))


(define-problem-helper mobility-result-route-key (result)
  "Return RESULT's lexical route key."
  (mobility-route-key (second result)))


(define-problem-helper mobility-segment-route-key (segment)
  "Return SEGMENT's lexical key in its one-segment route representation."
  (mobility-route-key (list segment)))


(define-problem-helper mobility-sort-by-route-key (items key-function)
  "Sort ITEMS lexically after computing each item's route key exactly once."
  (loop for tail on items
        for item = (first tail)
        do (setf (first tail)
                 (cons (funcall key-function item) item)))
  (setf items (sort items #'string< :key #'first))
  (loop for tail on items
        do (setf (first tail) (rest (first tail))))
  items)


(define-problem-helper validate-mobility-segment (segment source)
  "Signal an error unless SEGMENT obeys the normalized provider contract."
  (unless (and (listp segment)
               (= (length segment) 4)
               (symbolp (first segment))
               (eql (second segment) source)
               (member (fourth segment) (gethash 'location *types*) :test #'eq))
    (error "Invalid mobility segment from ~S: ~S" source segment))
  segment)


(define-problem-helper mobility-provider-segments (state agent source)
  "Collect, validate, deduplicate, and canonically order provider segments."
  (let ((segments nil))
    (dolist (provider *mobility-providers*)
      (dolist (segment (funcall (symbol-function provider) state agent source))
        (push (validate-mobility-segment segment source) segments)))
    (mobility-sort-by-route-key
      (remove-duplicates segments :test #'equal)
      #'mobility-segment-route-key)))


(define-problem-helper mobility-expand-frontier (state agent frontier visited)
  "Return every unvisited one-segment extension of the current BFS layer."
  (let ((candidates nil))
    (dolist (result frontier)
      (let ((source (first result))
            (route (second result)))
        (dolist (segment (mobility-provider-segments state agent source))
          (let ((destination (fourth segment)))
            (unless (gethash destination visited)
              (push (list destination
                          (append route (list (copy-tree segment))))
                    candidates))))))
    (mobility-sort-by-route-key
      (remove-duplicates candidates :test #'equal)
      #'mobility-result-route-key)))


(define-problem-helper mobility-select-layer (candidates visited)
  "Retain the canonical shortest route for each new destination in a BFS layer."
  (let ((selected nil))
    (dolist (candidate candidates (nreverse selected))
      (let ((destination (first candidate)))
        (unless (gethash destination visited)
          (setf (gethash destination visited) t)
          (push candidate selected))))))


(define-problem-helper mobility-results-in-state (state agent source)
  "Compute canonical transparent mobility results from SOURCE in STATE."
  (let ((visited (make-hash-table :test #'eq))
        (frontier (list (list source nil)))
        (results (list (list source nil))))
    (setf (gethash source visited) t)
    (loop while frontier
          for candidates = (mobility-expand-frontier state agent frontier visited)
          do (setf frontier (mobility-select-layer candidates visited))
             (setf results (nconc results (copy-tree frontier))))
    results))


(define-query mobility-results (?agent agent ?from location)
  (do (assign $results (mobility-results-in-state state ?agent ?from))
      $results))


(define-query mobility-locations (?agent agent ?from location)
  (mapcar #'first (mobility-results ?agent ?from)))


(define-query traversable (?agent agent ?from location ?to location)
  (not (null (assoc ?to (mobility-results ?agent ?from) :test #'eq))))

;;;; ==== end technology -mobility ====
;; (include-tech -holding): already included -- skipped

(in-package :ww)


(define-query recording-agent-empty-handed (?agent agent)
  ;; Operating a recorder requires empty hands.  In particular, closing a recording session
  ;; -- either the strict GHOST-STOPS-RECORDER style below or the weaker
  ;; RECORDING-AGENT-CAN-CLOSE style -- requires the ghost to have already set down whatever
  ;; it was carrying, not merely to be standing at or within reach of a recorder.
  (not (bind (holding ?agent $anything))))


(define-query ghost-stops-recorder ()
  ;; STOP-RECORDER alone creates this marker, after its precondition has established
  ;; physical closure.  Its atomic followup removes all ghost state and normalizes the
  ;; recording shadow, so the marker is meaningful without a positional ghost test.
  (and (recorder-cycle-closed)
       (not (recording-in-progress))
       (recorder-closed-ghost-free)))


(define-query recording-agent-can-close (?agent agent)
  ;; The recording remains closable: ?agent is already empty-handed, and some recorder's
  ;; location lies in its current mobility closure, which for a ghost is computed against
  ;; recording-side gate and gears state.  An agent resting on a support changes to ground
  ;; before moving, and that configuration transition is not itself a traversal obstacle, so
  ;; support occupancy is not consulted here.  Reachability alone would let the report
  ;; silently append the walk back to a recorder, but it cannot also silently set down
  ;; cargo, so empty-handedness is checked now instead of deferred to the report.
  (and (recording-agent-empty-handed ?agent)
       (do (bind (has-location ?agent $agent-location))
           (assign $reachable (mobility-locations ?agent $agent-location))
           (exists (?recorder recorder)
             (exists (?location location)
               (and (has-position ?recorder ?location)
                    (member ?location $reachable)))))))


(define-query recording-agent-return-route (?agent agent)
  ;; (?agent route) for the move that closes ?agent's recording, or nil when ?agent already
  ;; stands on a recorder and no return trip is outstanding.  Consumed by the report, which
  ;; appends the move a goal-terminated search stopped short of.
  (do (bind (has-location ?agent $agent-location))
      (assign $outstanding (not (recording-agent-at-recorder ?agent)))
      (assign $results (mobility-results ?agent $agent-location))
      (assign $return-move nil)
      (ww-loop for $result in $results
               do (assign $location (first $result))
                  (if (and $outstanding
                           (not $return-move)
                           (exists (?recorder recorder)
                             (has-position ?recorder $location)))
                    (assign $return-move
                            (list ?agent
                                  (second $result)))))
      $return-move))


(define-query recording-agent-at-recorder (?agent agent)
  (exists (?recorder recorder)
    (exists (?location location)
      (and (has-position ?recorder ?location)
           (has-location ?agent ?location)))))

;;;; CANDIDATE VALIDATION AND REPORTING ;;;;


(defun recorder-move-agents (move)
  "The agents named among MOVE's action arguments, or NIL when MOVE is not an
   (index (action argument...)) pair at all."
  (when (and (listp move)
             (= (length move) 2)
             (listp (second move)))
    (remove-duplicates
      (remove-if-not
        (lambda (argument)
          (member argument (gethash 'agent *types*)))
        (rest (second move))))))


(defun recorder-report-agent (move)
  "Return the single agent named by a recorded solution MOVE."
  (let ((agents (recorder-move-agents move)))
    (unless (= (length agents) 1)
      (error "Recorder report move must name exactly one agent: ~S" move))
    (first agents)))


(defun recorder-report-agent-side (state agent)
  "Classify AGENT through RECORDING-COPY>, using STATE for the compiled queries."
  (cond
    ((funcall (symbol-function 'live-recording-object) state agent)
     :live)
    ((funcall (symbol-function 'ghost-recording-object) state agent)
     :ghost)
    (t
     (error "Recorder report agent is not mapped by RECORDING-COPY>: ~S" agent))))


(defun recorder-report-move-side (state move)
  (recorder-report-agent-side state (recorder-report-agent move)))


(defun recorder-interleaving-pruning-enabled-p ()
  "Whether this search path supports automatic recorder interleaving pruning."
  (and (eql *algorithm* 'depth-first)
       (zerop *threads*)
       (not *hybrid-mode*)))


(defun recorder-interleaving-action-side (state move)
  "Return MOVE's recorder side, or NIL unless it names exactly one mapped agent."
  (let ((agents (recorder-move-agents move)))
    (when (= (length agents) 1)
      (recorder-report-agent-side state (first agents)))))


(defun recorder-interleaving-inversion-p (state first-move second-move)
  "Whether the adjacent moves form a ghost-before-live canonical-order inversion."
  (let ((first-action (second first-move))
        (second-action (second second-move)))
    (when (or (member (first first-action) '(start-recorder stop-recorder))
              (member (first second-action) '(start-recorder stop-recorder)))
      (return-from recorder-interleaving-inversion-p nil))
    (let ((first-side (recorder-interleaving-action-side state first-move))
          (second-side (recorder-interleaving-action-side state second-move)))
      (and (eql first-side :ghost)
           (eql second-side :live)))))


(defun recorder-interleaving-other-prefix-validation-enabled-p ()
  "Whether certification must construct alternate paths for a non-recorder policy."
  (search-prefix-validation-enabled-p
    '(validate-recorder-cycle-boundary-prefix
      validate-recorder-recording-prefix)))


(defun recorder-interleaving-state-valid-p (state path)
  "Whether an alternate replay state passes non-redundant search validity checks."
  (and (not (state-is-inconsistent state))
       (or (not (and (boundp 'constraint-fn)
                     (symbol-value 'constraint-fn)))
           (funcall (symbol-function 'constraint-fn) state))
       (every (lambda (invariant)
                (funcall (symbol-function invariant) state))
              *global-invariants*)
       (candidate-search-prefix-valid-p
         path state '(validate-recorder-cycle-boundary-prefix
                      validate-recorder-recording-prefix))))


(defun recorder-interleaving-equivalent-state-p (state1 state2)
  "Whether two action orders produce the same complete search-relevant state."
  (and (equalp (problem-state.idb state1)
               (problem-state.idb state2))
       (= (problem-state.time state1)
          (problem-state.time state2))
       (= (problem-state.value state1)
          (problem-state.value state2))
       (equalp (problem-state.happenings state1)
               (problem-state.happenings state2))))


(defun replay-recorder-interleaving-step
    (action state next-action path validate-prefix-p)
  "Replay ACTION and return its state, extended path, and validity."
  (multiple-value-bind (next-state valid-p reason)
      (apply-action-to-state action state next-action)
    (declare (ignore reason))
    (unless valid-p
      (return-from replay-recorder-interleaving-step
        (values nil nil nil)))
    (let ((next-path
            (when validate-prefix-p
              (append path (list (record-move next-state))))))
      (if (recorder-interleaving-state-valid-p next-state next-path)
        (values next-state next-path t)
        (values nil nil nil)))))


(defun recorder-interleaving-swap-certified-p
    (source-node first-action second-action actual-final-state)
  "Whether replaying SECOND-ACTION before FIRST-ACTION yields the same valid state."
  (let* ((validate-prefix-p
           (recorder-interleaving-other-prefix-validation-enabled-p))
         (source-state (node.state source-node))
         (source-path
           (when validate-prefix-p
             (record-solution-path source-node))))
    (multiple-value-bind (alternate-first first-path first-valid-p)
        (replay-recorder-interleaving-step
          second-action source-state first-action source-path validate-prefix-p)
      (unless first-valid-p
        (return-from recorder-interleaving-swap-certified-p nil))
      (multiple-value-bind (alternate-final final-path final-valid-p)
          (replay-recorder-interleaving-step
            first-action alternate-first nil first-path validate-prefix-p)
        (declare (ignore final-path))
        (and final-valid-p
             (recorder-interleaving-equivalent-state-p
               alternate-final actual-final-state))))))


(defun prune-recorder-interleaving-successor-p (current-node successor-state)
  "Discard exactly certified ghost-before-live successors in favor of live-before-ghost."
  (let ((source-node (node.parent current-node)))
    (unless (node-p source-node)
      (return-from prune-recorder-interleaving-successor-p nil))
    (let* ((first-move (record-move (node.state current-node)))
           (second-move (record-move successor-state))
           (first-action (second first-move))
           (second-action (second second-move)))
      (and (recorder-interleaving-inversion-p
             (node.state source-node) first-move second-move)
           (recorder-interleaving-swap-certified-p
             source-node first-action second-action successor-state)))))


(defun recorder-path-moves-on-side (state integrated-path side)
  "Return the moves performed by SIDE in INTEGRATED-PATH."
  (remove-if-not
    (lambda (move)
      (eql side (recorder-report-move-side state move)))
    integrated-path))


(defun recorder-move-action-name (move)
  "The action name MOVE invokes, or NIL when MOVE is not an (index (action ...)) pair."
  (when (and (listp move)
             (= (length move) 2)
             (listp (second move)))
    (first (second move))))


(defstruct (recorder-path-cycle (:conc-name recorder-path-cycle.))
  "One parsed recorder cycle in an integrated planner path."
  number
  setup
  start
  moves
  stop)


(defun recorder-boundary-error (cycle detail)
  "Return a cycle-numbered malformed-boundary diagnostic."
  (list :phase :recording
        :reason :invalid-boundary
        :cycle cycle
        :detail detail))


(defun parse-recorder-path (start-state integrated-path)
  "Parse INTEGRATED-PATH into ordered recorder cycles and trailing setup.

Returns three values: cycles, trailing setup moves, and a diagnostic.  An authored start
state with RECORDING-IN-PROGRESS supplies one legacy implicit open cycle."
  (let* ((cycles-used
           (funcall (symbol-function 'recorder-cycle-count) start-state))
         (open-cycle
           (when (member '(recording-in-progress)
                         (database start-state)
                         :test #'equal)
             (make-recorder-path-cycle
               :number (max 1 cycles-used)
               :setup nil
               :start nil
               :moves nil
               :stop nil)))
         (cycles nil)
         (setup-reversed nil))
    (when (> cycles-used *max-recorder-cycles*)
      (return-from parse-recorder-path
        (values nil nil
                (recorder-boundary-error cycles-used :maximum-exceeded))))
    (dolist (move integrated-path)
      (case (recorder-move-action-name move)
        (start-recorder
          (when open-cycle
            (return-from parse-recorder-path
              (values nil nil
                      (recorder-boundary-error
                        (recorder-path-cycle.number open-cycle)
                        :multiple-starts))))
          (incf cycles-used)
          (when (> cycles-used *max-recorder-cycles*)
            (return-from parse-recorder-path
              (values nil nil
                      (recorder-boundary-error
                        cycles-used :maximum-exceeded))))
          (setf open-cycle
                (make-recorder-path-cycle
                  :number cycles-used
                  :setup (nreverse setup-reversed)
                  :start move
                  :moves nil
                  :stop nil)
                setup-reversed nil))
        (stop-recorder
          (unless open-cycle
            (return-from parse-recorder-path
              (values nil nil
                      (recorder-boundary-error
                        (1+ cycles-used) :stop-without-start))))
          (setf (recorder-path-cycle.moves open-cycle)
                (nreverse (recorder-path-cycle.moves open-cycle))
                (recorder-path-cycle.stop open-cycle) move)
          (push open-cycle cycles)
          (setf open-cycle nil))
        (otherwise
          (if open-cycle
            (push move (recorder-path-cycle.moves open-cycle))
            (push move setup-reversed)))))
    (when open-cycle
      (setf (recorder-path-cycle.moves open-cycle)
            (nreverse (recorder-path-cycle.moves open-cycle)))
      (push open-cycle cycles))
    (values (nreverse cycles) (nreverse setup-reversed) nil)))


(defun recorder-explicit-start (integrated-path)
  "The real START-RECORDER move in INTEGRATED-PATH, or NIL when none was searched."
  (find 'start-recorder integrated-path :key #'recorder-move-action-name))


(defun recorder-explicit-stop (integrated-path)
  "The real STOP-RECORDER move in INTEGRATED-PATH, or NIL when none was searched."
  (find 'stop-recorder integrated-path :key #'recorder-move-action-name))


(defun recorder-boundary-diagnostic
    (integrated-path &optional (start-state *start-state*))
  "Return the state-machine parser diagnostic for INTEGRATED-PATH, if any."
  (nth-value 2 (parse-recorder-path start-state integrated-path)))


(defun recorder-path-after (integrated-path move)
  "The tail of INTEGRATED-PATH strictly after MOVE, or the whole path when MOVE is NIL."
  (if move
    (rest (member move integrated-path))
    integrated-path))


(defun recorder-path-before (integrated-path move)
  "The prefix of INTEGRATED-PATH strictly before MOVE, or the whole path when MOVE is NIL."
  (if move
    (subseq integrated-path 0 (position move integrated-path))
    integrated-path))


(defun recorder-pre-recording-path (integrated-path)
  "Return the actions before INTEGRATED-PATH's real START-RECORDER.

There is no pre-recording prefix in the legacy no-explicit-start form."
  (let ((explicit-start (recorder-explicit-start integrated-path)))
    (and explicit-start
         (recorder-path-before integrated-path explicit-start))))


(defun recorder-recording-window (integrated-path)
  "INTEGRATED-PATH narrowed to strictly between its real START-RECORDER and STOP-RECORDER
moves.  Either or both edges default to the path's own start/end when the searched path
never invoked the real action -- exactly the pre-restructuring behavior, where recording
had no path-local edges at all."
  (recorder-path-before
    (recorder-path-after integrated-path (recorder-explicit-start integrated-path))
    (recorder-explicit-stop integrated-path)))


(defun recorder-recording-path (state integrated-path)
  "The path segment VALIDATE-RECORDER-SOLUTION treats as one recording: the real
START-RECORDER move when the searched path contains one, every ghost move within the
window it opens, and the real STOP-RECORDER move when present.  A ghost action's own
precondition now requires recording to be in progress, so the isolated replay needs
START-RECORDER's fork included to be viable at all -- it is no longer purely a ghost-only
subsequence.  Falls back to the whole path's ghost-only moves, with no edges, when neither
real action was searched."
  (let ((explicit-start (recorder-explicit-start integrated-path))
        (explicit-stop (recorder-explicit-stop integrated-path)))
    (append (and explicit-start (list explicit-start))
            (recorder-path-moves-on-side
              state (recorder-recording-window integrated-path) :ghost)
            (and explicit-stop (list explicit-stop)))))


(defun recorder-action-failure-diagnostic (phase validation &optional cycle)
  (append
    (list :phase phase
          :reason :action-failed
          :step (action-sequence-validation-failure-index validation)
          :action (action-sequence-validation-failure-action validation)
          :detail (action-sequence-validation-failure-reason validation))
    (when cycle (list :cycle cycle))))


(defun recorder-path-before-cycle (integrated-path cycle)
  "Return the integrated prefix strictly before CYCLE's explicit start."
  (let ((start (recorder-path-cycle.start cycle)))
    (and start (recorder-path-before integrated-path start))))


(defun recorder-path-cycle-recording-path (state cycle)
  "Return CYCLE's isolated start, ghost moves, and optional stop sequence."
  (append
    (when (recorder-path-cycle.start cycle)
      (list (recorder-path-cycle.start cycle)))
    (recorder-path-moves-on-side
      state (recorder-path-cycle.moves cycle) :ghost)
    (when (recorder-path-cycle.stop cycle)
      (list (recorder-path-cycle.stop cycle)))))


(defun recorder-path-cycle-snapshot (start-state integrated-path cycle)
  "Return CYCLE's pre-start snapshot and any cycle-numbered replay diagnostic."
  (unless (recorder-path-cycle.start cycle)
    (return-from recorder-path-cycle-snapshot
      (values (copy-problem-state start-state) nil)))
  (let ((validation
          (validate-action-sequence
            start-state (recorder-path-before-cycle integrated-path cycle))))
    (if (action-sequence-validation-success-p validation)
      (values (action-sequence-validation-final-state validation) nil)
      (values nil
              (recorder-action-failure-diagnostic
                :snapshot validation (recorder-path-cycle.number cycle))))))


(defun recorder-boundary-identity-state (state)
  "Return a copy of closed STATE with only its consumed-cycle resource removed.

The open/closed marker, live state, ghost state, recording shadow, and every ordinary
dynamic relation remain part of identity.  The cycle count is excluded because it is a
monotone search resource: otherwise equal closed boundaries compare it by dominance."
  (let ((identity-state (copy-problem-state state)))
    (dolist (proposition (database identity-state))
      (when (eql (first proposition) 'recorder-cycles-used)
        (delete-proposition proposition (problem-state.idb identity-state))))
    (invalidate-problem-state-hash identity-state)
    identity-state))


(defun recorder-boundary-identity-equal-p (identity1 identity2)
  "Whether two already-projected recorder boundary states are equal."
  (if (use-canonical-symmetry-p)
    (canonical-state-equal-p identity1 identity2)
    (equalp (problem-state.idb identity1)
            (problem-state.idb identity2))))


(defun recorder-boundary-equivalent-p (state1 state2)
  "Whether closed states have the same future-facing state apart from cycle usage."
  (let ((identity1 (recorder-boundary-identity-state state1))
        (identity2 (recorder-boundary-identity-state state2)))
    (recorder-boundary-identity-equal-p identity1 identity2)))


(defun recorder-cycle-objective-improved-p (start-state end-state)
  "Whether END-STATE strictly improves the active non-length objective."
  (case *solution-type*
    (min-time
     (< (problem-state.time end-state)
        (problem-state.time start-state)))
    (min-value
     (< (problem-state.value end-state)
        (problem-state.value start-state)))
    (max-value
     (> (problem-state.value end-state)
        (problem-state.value start-state)))
    (otherwise nil)))


(defun recorder-completed-cycle-made-progress-p (start-state end-state)
  "Whether a completed cycle changes persistent state or improves its objective.

Wouldwork permits graph search to ignore elapsed time only when there are no exogenous
happenings.  With happenings present, even an otherwise unchanged cycle may advance toward
an event, so this conservative test retains it."
  (or *happening-names*
      (recorder-cycle-objective-improved-p start-state end-state)
      (not (recorder-boundary-equivalent-p start-state end-state))))


(defun recorder-no-progress-diagnostic (cycle)
  (list :phase :recording
        :reason :no-persistent-progress
        :cycle (recorder-path-cycle.number cycle)))


(defstruct (recorder-boundary-dominance-entry
             (:conc-name recorder-boundary-dominance-entry.))
  "One nondominated normalized boundary in the current graph search."
  identity-state
  cycles-used
  cost)


(defvar *recorder-boundary-dominance-table*
  (make-hash-table :test #'eql)
  "Search-wide Pareto frontier keyed by recorder boundary identity hash.")


(defvar *recorder-boundary-dominance-pruned* 0
  "Number of generated boundaries rejected by recorder cycle-resource dominance.")


(defun reset-recorder-boundary-dominance ()
  "Clear recorder boundary dominance state before a new search."
  (setf *recorder-boundary-dominance-table*
        (make-hash-table :test #'eql)
        *recorder-boundary-dominance-pruned* 0))


(defun recorder-boundary-dominance-enabled-p ()
  "Whether this search can safely discard resource-dominated closed boundaries."
  (and (> *max-recorder-cycles* 1)
       (eql *tree-or-graph* 'graph)
       (not *hybrid-mode*)
       (null *happening-names*)
       (member *solution-type*
               '(first min-length min-time min-value max-value))))


(defun recorder-normalized-boundary-p (state)
  "Whether STATE is a ghost-free boundary at which cycle dominance applies."
  (and (not (member '(recording-in-progress)
                    (database state)
                    :test #'equal))
       (funcall (symbol-function 'recorder-closed-ghost-free) state)))


(defun recorder-boundary-dominance-cost (state depth)
  "Return a lower-is-better scalar for the active graph-search objective."
  (case *solution-type*
    ((first min-length) depth)
    (min-time (problem-state.time state))
    (min-value (problem-state.value state))
    (max-value (- (problem-state.value state)))))


(defun recorder-boundary-entry-matches-p (entry identity-state)
  (recorder-boundary-identity-equal-p
    (recorder-boundary-dominance-entry.identity-state entry)
    identity-state))


(defun recorder-boundary-entry-dominates-p (entry cycles-used cost)
  "Whether ENTRY has strictly more cycle capacity and no worse path cost."
  (and (< (recorder-boundary-dominance-entry.cycles-used entry)
          cycles-used)
       (<= (recorder-boundary-dominance-entry.cost entry) cost)))


(defun recorder-boundary-candidate-dominates-p (cycles-used cost entry)
  "Whether the candidate has strictly more cycle capacity and no worse path cost."
  (and (< cycles-used
          (recorder-boundary-dominance-entry.cycles-used entry))
       (<= cost (recorder-boundary-dominance-entry.cost entry))))


(defun update-recorder-boundary-dominance
    (identity-state cycles-used cost)
  "Record a nondominated boundary, returning true when an earlier entry dominates it."
  (ensure-idb-hash identity-state)
  (let* ((key (problem-state.idb-hash identity-state))
         (bucket (gethash key *recorder-boundary-dominance-table*))
         (matches
           (remove-if-not
             (lambda (entry)
               (recorder-boundary-entry-matches-p entry identity-state))
             bucket)))
    (when (some (lambda (entry)
                  (recorder-boundary-entry-dominates-p
                    entry cycles-used cost))
                matches)
      (incf *recorder-boundary-dominance-pruned*)
      (return-from update-recorder-boundary-dominance t))
    (when (some (lambda (entry)
                  (and (= cycles-used
                          (recorder-boundary-dominance-entry.cycles-used entry))
                       (<= (recorder-boundary-dominance-entry.cost entry)
                           cost)))
                matches)
      ;; Ordinary graph duplicate handling owns equal-resource rejection.  The dominance
      ;; frontier merely keeps its best representative for comparisons with other counts.
      (return-from update-recorder-boundary-dominance nil))
    (let ((new-bucket
            (remove-if
              (lambda (entry)
                (and (recorder-boundary-entry-matches-p entry identity-state)
                     (or
                       (recorder-boundary-candidate-dominates-p
                         cycles-used cost entry)
                       (and (= cycles-used
                               (recorder-boundary-dominance-entry.cycles-used entry))
                            (<= cost
                                (recorder-boundary-dominance-entry.cost entry))))))
              bucket)))
      (push
        (make-recorder-boundary-dominance-entry
          :identity-state identity-state
          :cycles-used cycles-used
          :cost cost)
        new-bucket)
      (setf (gethash key *recorder-boundary-dominance-table*) new-bucket))
    nil))


(defun prune-recorder-boundary-dominated-successor-p
    (current-node successor-state)
  "Discard a normalized boundary dominated by an equal state with fewer cycles used."
  (unless (recorder-normalized-boundary-p successor-state)
    (return-from prune-recorder-boundary-dominated-successor-p nil))
  (let ((identity-state (recorder-boundary-identity-state successor-state))
        (cycles-used
          (funcall (symbol-function 'recorder-cycle-count) successor-state))
        (cost
          (recorder-boundary-dominance-cost
            successor-state (1+ (node.depth current-node)))))
    (bt:with-lock-held (*search-lock*)
      (update-recorder-boundary-dominance
        identity-state cycles-used cost))))


(defun recorder-recording-snapshot (start-state integrated-path)
  "Return the state captured immediately before START-RECORDER and any replay diagnostic.

An explicit recording begins from the result of replaying every pre-recording action from
START-STATE.  The legacy form with no explicit START-RECORDER continues to use START-STATE
directly, because its focused tests author the already-open recording state there."
  (multiple-value-bind (cycles trailing-setup diagnostic)
      (parse-recorder-path start-state integrated-path)
    (declare (ignore trailing-setup))
    (when diagnostic
      (return-from recorder-recording-snapshot (values nil diagnostic)))
    (if cycles
      (recorder-path-cycle-snapshot start-state integrated-path (first cycles))
      (values (copy-problem-state start-state) nil))))


(defun recorder-recording-agents (state)
  "Return the mapped ghost agents that can act during recording."
  (remove-if-not
    (lambda (agent)
      (funcall (symbol-function 'ghost-recording-object) state agent))
    (gethash 'agent *types*)))


(defun recorder-prefix-pruning-enabled-p ()
  "Whether recorder recording-prefix pruning is enabled for the current search."
  *recorder-prefix-pruning*)


(defun recorder-cycle-boundary-validation-enabled-p ()
  "Completed recorder cycles are always validated during search."
  t)


(defun recorder-stop-prefix-trigger-p (start-state newest-move current-state)
  "Whether NEWEST-MOVE closes a cycle and therefore needs mandatory validation."
  (declare (ignore start-state current-state))
  (eql (recorder-move-action-name newest-move) 'stop-recorder))


(defun recorder-recording-prefix-changed-p (start-state integrated-path)
  "Whether the newest move changes the isolated recording sequence.

Ordinary live moves are absent from that sequence.  Their pre-recording effects are
captured when START-RECORDER is eventually checked, while live moves after the start
cannot alter a recording prefix already accepted at its preceding ghost move."
  (let* ((move (car (last integrated-path)))
         (action (recorder-move-action-name move)))
    (or (member action '(start-recorder stop-recorder))
        (some (lambda (agent)
                (funcall (symbol-function 'ghost-recording-object)
                         start-state agent))
              (recorder-move-agents move)))))


(defun validate-recorder-path-cycle (start-state integrated-path cycle)
  "Validate CYCLE's isolated recording from its exact integrated snapshot."
  (multiple-value-bind (snapshot-state snapshot-diagnostic)
      (recorder-path-cycle-snapshot start-state integrated-path cycle)
    (when snapshot-diagnostic
      (return-from validate-recorder-path-cycle
        (values nil snapshot-diagnostic)))
    (let* ((cycle-number (recorder-path-cycle.number cycle))
           (recording-path
             (recorder-path-cycle-recording-path snapshot-state cycle))
           (validation
             (validate-action-sequence snapshot-state recording-path)))
      (unless (action-sequence-validation-success-p validation)
        (return-from validate-recorder-path-cycle
          (values nil
                  (recorder-action-failure-diagnostic
                    :recording validation cycle-number))))
      (unless (recorder-recording-agents
                (action-sequence-validation-final-state validation))
        (return-from validate-recorder-path-cycle
          (values nil
                  (list :phase :recording
                        :reason :no-recording-agent
                        :cycle cycle-number))))
      (values t nil snapshot-state))))


(defun validate-recorder-cycle-boundary-prefix
    (start-state integrated-path current-state)
  "Validate the completed cycle ending at the newest STOP-RECORDER successor."
  (multiple-value-bind (cycles trailing-setup diagnostic)
      (parse-recorder-path start-state integrated-path)
    (declare (ignore trailing-setup))
    (when diagnostic
      (return-from validate-recorder-cycle-boundary-prefix
        (values nil diagnostic)))
    (let ((cycle (car (last cycles))))
      (unless (and cycle (recorder-path-cycle.stop cycle))
        (return-from validate-recorder-cycle-boundary-prefix
          (values nil
                  (recorder-boundary-error
                    (if cycle (recorder-path-cycle.number cycle) 1)
                    :stop-without-start))))
      (multiple-value-bind (valid-p cycle-diagnostic snapshot-state)
          (validate-recorder-path-cycle start-state integrated-path cycle)
        (unless valid-p
          (return-from validate-recorder-cycle-boundary-prefix
            (values nil cycle-diagnostic)))
        (if (recorder-completed-cycle-made-progress-p
              snapshot-state current-state)
          (values t nil)
          (values nil (recorder-no-progress-diagnostic cycle)))))))


(defun validate-recorder-recording-prefix (start-state integrated-path current-state)
  "Accept a search prefix while its isolated recording sub-path remains replayable.

This is deliberately narrower than VALIDATE-RECORDER-SOLUTION.  It checks session
boundaries, reconstructs the START-RECORDER snapshot, and replays the recording actions
seen so far.  It does not require the ghost to be able to close the recording and does not
validate playback or the goal, because later actions can still change those conditions.
Once an action in the isolated recording sequence fails, however, extending the integrated
  path cannot repair that earlier prefix, so the branch is safe to prune."
  (declare (ignore current-state))
  (unless (recorder-recording-prefix-changed-p start-state integrated-path)
    (return-from validate-recorder-recording-prefix (values t nil)))
  (multiple-value-bind (cycles trailing-setup boundary-diagnostic)
      (parse-recorder-path start-state integrated-path)
    (declare (ignore trailing-setup))
    (when boundary-diagnostic
      (return-from validate-recorder-recording-prefix
        (values nil boundary-diagnostic)))
    (let ((open-cycle
            (find-if-not #'recorder-path-cycle.stop cycles :from-end t)))
      (if open-cycle
        (validate-recorder-path-cycle start-state integrated-path open-cycle)
        (values t nil)))))


(defun validate-recorder-solution (start-state integrated-path goal-state)
  "Validate every recording cycle and the complete integrated playback path.

Each completed or final open cycle is replayed independently from the snapshot immediately
before its own START-RECORDER.  That snapshot includes every preceding integrated cycle,
its atomic stop normalization, and the following setup.  The final playback check then
replays the whole path once and applies the problem goal."
  (declare (ignore goal-state))
  (multiple-value-bind (cycles trailing-setup boundary-diagnostic)
      (parse-recorder-path start-state integrated-path)
    (declare (ignore trailing-setup))
    (when boundary-diagnostic
      (return-from validate-recorder-solution
        (values nil boundary-diagnostic)))
    (dolist (cycle cycles)
      (multiple-value-bind (valid-p diagnostic)
          (validate-recorder-path-cycle start-state integrated-path cycle)
        (unless valid-p
          (return-from validate-recorder-solution
            (values nil diagnostic)))))
    (let ((playback-validation
            (validate-action-sequence
              start-state integrated-path
              :goal-test (symbol-function 'goal-fn))))
      (unless (action-sequence-validation-success-p playback-validation)
        (return-from validate-recorder-solution
          (values nil
                  (recorder-action-failure-diagnostic
                    :playback playback-validation))))
      (unless (action-sequence-validation-goal-satisfied-p playback-validation)
        (return-from validate-recorder-solution
          (values nil '(:phase :playback :reason :goal-not-satisfied))))
      (values t nil))))


(defun recorder-cycle-recording-sequence (state cycle)
  "Build CYCLE's recording-side presentation from its accepted path segment.

Each contiguous live block becomes one PAUSE marker.  Real boundary actions remain in
place.  A legacy implicit opening or final goal-terminated closing is synthesized only in
the report; an open cycle also receives whatever ghost return moves STATE can supply."
  (let* ((start (recorder-path-cycle.start cycle))
         (stop (recorder-path-cycle.stop cycle))
         (sequence (list (or start '(start-recorder))))
         (previous-side nil))
    (dolist (move (recorder-path-cycle.moves cycle))
      (let ((side (recorder-report-move-side state move)))
        (when (and (eql side :live)
                   (not (eql previous-side :live)))
          (setf sequence (nconc sequence (list '(pause)))))
        (when (eql side :ghost)
          (setf sequence (nconc sequence (list move))))
        (setf previous-side side)))
    (nconc sequence
           (if stop
             (list stop)
             (nconc (recorder-return-moves state) (list '(stop-recorder)))))))


(defun recorder-return-moves (state)
  "Return one (MOVE agent route) marker per ghost away.

STATE is the completed integrated state.  A ghost's location there, and the recording-side
gate and gears state its mobility closure is computed against, are the same as at the end of
the ghost-only recording, so no second replay is needed.  A path that already carries the
return -- the GHOST-STOPS-RECORDER goal style -- yields no markers.  These are report
markers, not planner actions, and carry no step number for that reason."
  (loop for agent in (recorder-recording-agents state)
        for move = (funcall (symbol-function 'recording-agent-return-route) state agent)
        when move
          collect (cons 'move move)))


(defun recorder-cycle-playback-sequence (state cycle)
  "Present CYCLE's in-window moves, pausing live blocks and resuming ghost blocks.

Setup and explicit START-RECORDER/STOP-RECORDER boundaries are not playback actions."
  (let ((sequence nil)
        (previous-side nil))
    (dolist (move (recorder-path-cycle.moves cycle) sequence)
      (let ((side (recorder-report-move-side state move)))
        (when (not (eql side previous-side))
          (cond
            ((eql side :live)
             (setf sequence (nconc sequence (list '(pause)))))
            ((eql previous-side :live)
             (setf sequence (nconc sequence (list '(resume)))))))
        (setf sequence (nconc sequence (list move)))
        (setf previous-side side)))))


(defun recorder-cycle-integrated-path (cycle)
  "Return CYCLE's searched setup, opening, window, and optional closing in order."
  (append
    (recorder-path-cycle.setup cycle)
    (when (recorder-path-cycle.start cycle)
      (list (recorder-path-cycle.start cycle)))
    (recorder-path-cycle.moves cycle)
    (when (recorder-path-cycle.stop cycle)
      (list (recorder-path-cycle.stop cycle)))))


(defun recorder-report-metrics (start-state end-state depth)
  "Return path-local DEPTH, elapsed time, and value change between two states."
  (list :depth depth
        :elapsed-time (- (problem-state.time end-state)
                         (problem-state.time start-state))
        :value-change (- (problem-state.value end-state)
                         (problem-state.value start-state))))


(defun replay-recorder-report-segment (start-state path description)
  "Replay PATH for reporting, surfacing an accepted-path inconsistency as an error."
  (let ((validation (validate-action-sequence start-state path)))
    (unless (action-sequence-validation-success-p validation)
      (error "Recorder report cannot replay ~A at step ~D, action ~S: ~S"
             description
             (action-sequence-validation-failure-index validation)
             (action-sequence-validation-failure-action validation)
             (action-sequence-validation-failure-reason validation)))
    (action-sequence-validation-final-state validation)))


(defun build-recorder-cycle-report (start-state cycle)
  "Build one path-derived cycle report and return it with the cycle's ending state."
  (let* ((path (recorder-cycle-integrated-path cycle))
         (number (recorder-path-cycle.number cycle))
         (end-state
           (replay-recorder-report-segment
             start-state path (format nil "recorder cycle ~D" number)))
         (metrics (recorder-report-metrics start-state end-state (length path))))
    (values
      (append
        (list :number number
              :integrated path
              :setup (recorder-path-cycle.setup cycle)
              :recording (recorder-cycle-recording-sequence end-state cycle)
              :playback (recorder-cycle-playback-sequence end-state cycle)
              :closure (if (recorder-path-cycle.stop cycle)
                         :explicit
                         :synthesized))
        metrics)
      end-state)))


(defun recorder-report-cycles (start-state cycles)
  "Build ordered CYCLES by replaying each one from its preceding accepted boundary."
  (let ((reports nil)
        (current-state start-state))
    (dolist (cycle cycles)
      (multiple-value-bind (report end-state)
          (build-recorder-cycle-report current-state cycle)
        (push report reports)
        (setf current-state end-state)))
    (values (nreverse reports) current-state)))


(defun recorder-legacy-report-cycle (path)
  "Represent the pre-boundary report form as one synthesized cycle."
  (make-recorder-path-cycle
    :number 1
    :setup nil
    :start nil
    :moves path
    :stop nil))


(defun recorder-complete-solution-metrics (solution)
  "Return totals recorded for the complete accepted planner solution."
  (list :depth (solution.depth solution)
        :elapsed-time (- (solution.time solution)
                         (problem-state.time *start-state*))
        :value-change (- (solution.value solution)
                         (problem-state.value *start-state*))))


(defun build-recorder-report (&optional (solution (first *solution-paths*)))
  "Build a complete path-derived recorder report for integrated SOLUTION.

The original path remains under :INTEGRATED.  :CYCLES contains one ordered report per
setup/start/window/stop segment, :TRAILING-SETUP preserves searched actions after the last
closed cycle, and :TOTALS describes the complete solution.  A legacy path without an
explicit boundary is represented as one synthesized cycle.  Single-cycle reports retain
the top-level :SETUP, :RECORDING, and :PLAYBACK aliases used by guided chaining.  Report
markers are not planner actions and do not contribute to any metric."
  (unless solution
    (error "No completed solution is available for a recorder report."))
  (unless (solution-p solution)
    (error "Recorder report requires a SOLUTION, not ~S" solution))
  (let ((path (solution.path solution)))
    (multiple-value-bind (cycles trailing-setup diagnostic)
        (parse-recorder-path *start-state* path)
      (when diagnostic
        (error "Recorder report cannot parse the integrated path: ~S" diagnostic))
      (let ((report-cycles (or cycles (list (recorder-legacy-report-cycle path))))
            (report-trailing-setup (and cycles trailing-setup)))
        (multiple-value-bind (cycle-reports cycle-end-state)
            (recorder-report-cycles *start-state* report-cycles)
          (let* ((trailing-end-state
                   (replay-recorder-report-segment
                     cycle-end-state report-trailing-setup
                     "trailing recorder setup"))
                 (trailing-metrics
                   (recorder-report-metrics
                     cycle-end-state trailing-end-state
                     (length report-trailing-setup)))
                 (report
                   (list :integrated path
                         :cycles cycle-reports
                         :cycle-count (length cycle-reports)
                         :trailing-setup report-trailing-setup
                         :trailing-metrics trailing-metrics
                         :totals (recorder-complete-solution-metrics solution))))
            (when (= (length cycle-reports) 1)
              (let ((cycle (first cycle-reports)))
                (setf report
                      (append report
                              (list :setup (getf cycle :setup)
                                    :recording (getf cycle :recording)
                                    :playback (getf cycle :playback))))))
            report))))))


(defun print-recorder-report-sequence (heading sequence stream)
  "Print HEADING and every entry in one report SEQUENCE."
  (format stream "~&~%~A:~%" heading)
  (dolist (entry sequence)
    (format stream "~S~%" entry)))


(defun print-recorder-report-metrics (heading metrics stream)
  "Print one compact local or total recorder metric line."
  (format stream
          "~&~A: depth ~D, elapsed time ~S, value change ~S.~%"
          heading
          (getf metrics :depth)
          (getf metrics :elapsed-time)
          (getf metrics :value-change)))


(defun print-recorder-cycle-report (cycle stream)
  "Print the three phases, closure status, and local metrics for CYCLE."
  (print-recorder-report-sequence "Setup phase" (getf cycle :setup) stream)
  (print-recorder-report-sequence "Recording phase" (getf cycle :recording) stream)
  (print-recorder-report-sequence "Playback phase" (getf cycle :playback) stream)
  (format stream "~&Closure: ~(~A~).~%" (getf cycle :closure))
  (print-recorder-report-metrics "Cycle metrics" cycle stream))


(defun print-recorder-report
    (&optional (solution (first *solution-paths*)) (stream *standard-output*))
  "Print and return SOLUTION's complete single- or multi-cycle recorder report."
  (let* ((report (build-recorder-report solution))
         (cycles (getf report :cycles)))
    (if (= (length cycles) 1)
      (print-recorder-cycle-report (first cycles) stream)
      (dolist (cycle cycles)
        (format stream "~&~%Recorder cycle ~D:~%" (getf cycle :number))
        (print-recorder-cycle-report cycle stream)))
    (when (getf report :trailing-setup)
      (print-recorder-report-sequence
        "Trailing setup" (getf report :trailing-setup) stream)
      (print-recorder-report-metrics
        "Trailing metrics" (getf report :trailing-metrics) stream))
    (print-recorder-report-metrics
      "Complete solution totals" (getf report :totals) stream)
    report))

;;;; ==== end technology -recorder-solution ====

;;;; ==== begin technology -recorder-session ====

;;; Filename: -recorder-session.lisp

;;; Recording session lifecycle.  START-RECORDER and STOP-RECORDER are real planner
;;; actions, not report-only markers: the search itself chooses when a recording session
;;; opens and closes, giving ghost-state forking a well-defined, path-local moment instead
;;; of an inferred one.  START-RECORDER counts the cycle in planner state, clears the
;;; preceding closed marker, and performs the fork required by rules 5 and 11 of
;;; tech/Recorder-ghost operations in the Talos Principle.txt -- every mapped ghost object
;;; inherits its live counterpart's CURRENT has-location, holding, on, paired, jamming, and
;;; mounted-on state at the exact moment recording starts, not whatever -- if anything --
;;; define-init separately declared for it.  The agent operating the recorder must itself
;;; be empty-handed; holdings elsewhere in the mapped state still belong to the complete
;;; snapshot.  RECORDING-IN-PROGRESS also gates ghost
;;; existence itself (see -recorder-core.lisp's OBJECT-MANIPULATION-ALLOWED and
;;; CONNECTOR-PAIRING-ALLOWED): a ghost cannot act, and a live connector cannot reference a
;;; ghost terminus, before this action has run.  That gate is not just faithfulness to rule
;;; 5 -- it guarantees the live-side state START-RECORDER reads can never already contain a
;;; cross-layer reference, so the fork has no such edge case to handle.
;;;
;;; RECORDING-IN-PROGRESS is deliberately not named RECORDING-ACTIVE: that name is already
;;; taken by -recorder-receiver-shadow.lisp's per-receiver relation, which means something
;;; unrelated (recording-side beam power reaching one receiver).
;;;
;;; CONNECTOR, JAMMER, and FAN are redeclared optional here (idempotent and order-
;;; independent, per tech/README.html).  PAIRED, JAMMING, and MOUNTED-ON cannot be
;;; redeclared unconditionally the same way: each takes a composite TERMINUS / TARGET /
;;; GEARS argument type that only exists when the relation's real owner (beam-relay.lisp,
;;; jammer.lisp, -gears-fan.lisp) is also included, and a problem may type CONNECTOR or FAN
;;; instances without including that behavioral tech at all -- test/problem-recorder-test.lisp
;;; does exactly this, to exercise RECORDING-COPY>'s own mapping machinery in isolation.  The
;;; empty-domain quantifier guard that protects a relation reference when a TYPE has no
;;; instances does not help here, since CONNECTOR and FAN are not empty in that test.
;;;
;;; So START-RECORDER's relation declaration and its three optional fork clauses are built
;;; below with ordinary Lisp, calling INSTALL-DYNAMIC-RELATIONS and INSTALL-ACTION directly
;;; instead of going through the DEFINE-DYNAMIC-RELATIONS / DEFINE-ACTION macros -- both
;;; macros only quote their argument text and call these same functions, so nothing is lost.
;;; Each composite type's presence in *TYPES* is checked once and reused for both the
;;; relation declaration and the fork clause that depends on it, since a relation and its
;;; own composite argument type are always declared together in the same owning file.
;;; HAS-LOCATION, HOLDING, and ON need no such guard -- they are already unconditionally
;;; available in any recorder problem via -recorder-core, -recorder-solution, and
;;; -recorder-controls-shadow's existing nesting.
;;;
;;; REQUIRES:
;;;   nested : -recorder-cycle-boundary (cycle count, physical closure, ghost removal,
;;;            and shadow normalization); -location (HAS-LOCATION); -holding (HOLDING);
;;;            -support-occupancy (ON)
;;; PROVIDES:
;;;   relations : paired, jamming, mounted-on -- redeclared, not owned, here, and only when
;;;               their own composite argument type is already present
;;;   actions   : start-recorder, stop-recorder


;;;; ==== begin technology -recorder-cycle-boundary ====

;;; Filename: -recorder-cycle-boundary.lisp

;;; Recorder-specific continuation policy.  A chained cycle has a stronger termination
;;; contract than a standalone recorder solve: its searched path itself returns every
;;; mapped ghost agent to a recorder.  Report-only return markers therefore never become a
;;; committed boundary by accident.
;;;
;;; STOP-RECORDER performs the same normalization directly in its successor: it removes
;;; every dynamic ghost reference, resets every capability-owned recording shadow, seeds
;;; stateful memory from the committed live playback baseline, and propagates consequences.
;;; PREPARE-RECORDER-CYCLE-STATE remains the copy-preserving entry point used by guided
;;; chaining, but delegates to that shared normalization.
;;;
;;; REQUIRES:
;;;   nested : -recorder-core (lifecycle registry); -recorder-solution
;;;            (GHOST-STOPS-RECORDER); -propagation
;;; PROVIDES:
;;;   queries   : recorder-cycle-boundary-safe, recorder-closed-ghost-free
;;;   functions : recorder-cycle-goal, close-recorder-cycle-state!,
;;;               normalize-recorder-cycle-shadow!, prepare-recorder-cycle-state

;; (include-tech -recorder-core): already included -- skipped
;; (include-tech -recorder-solution): already included -- skipped
;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(defun recorder-object-side (state object)
  "Return OBJECT's mapped recorder side, or NIL when it is fixed or unmapped."
  (when (member object (gethash 'mobile-object *types*))
    (cond
      ((funcall (symbol-function 'live-recording-object) state object) :live)
      ((funcall (symbol-function 'ghost-recording-object) state object) :ghost))))


(defun recorder-value-contains-ghost-p (state value)
  "Whether VALUE, including a nested list value, names a mapped ghost."
  (if (consp value)
    (or (recorder-value-contains-ghost-p state (car value))
        (recorder-value-contains-ghost-p state (cdr value)))
    (eql (recorder-object-side state value) :ghost)))


(defun recorder-state-contains-ghost-reference-p (state)
  "Whether STATE's dynamic database contains any reference to a mapped ghost."
  (some (lambda (proposition)
          (recorder-value-contains-ghost-p state (rest proposition)))
        (list-database (problem-state.idb state))))


(define-query recorder-closed-ghost-free ()
  (not (recorder-state-contains-ghost-reference-p state)))


(defun recorder-cross-layer-arguments-p (state arguments)
  "Whether ARGUMENTS contain both live and ghost mapped objects."
  (and (some (lambda (argument)
               (eql (recorder-object-side state argument) :live))
             arguments)
       (some (lambda (argument)
               (eql (recorder-object-side state argument) :ghost))
             arguments)))


(defun recorder-boundary-reference-relations ()
  "Physical relations whose live/ghost dependencies cannot cross a disappearing boundary."
  ;; A PAIRED link may safely disappear with its ghost endpoint; it neither supports nor
  ;; relocates the surviving live connector.  HOLDING and ON would leave physical state
  ;; undefined, so those dependencies must be resolved before STOP-RECORDER.
  (append '(holding on)
          (copy-list (gethash 'holding *bijective-relations*))
          (copy-list (gethash 'on *bijective-relations*))))


(defun recorder-cross-layer-boundary-reference-p (state)
  "Whether STATE contains a live/ghost support or holding dependency."
  (let ((relations (recorder-boundary-reference-relations)))
    (some (lambda (proposition)
            (and (member (first proposition) relations)
                 (recorder-cross-layer-arguments-p state (rest proposition))))
          (list-database (problem-state.idb state)))))


(defun recorder-cycle-agents-ready-p (state)
  "Whether every mapped ghost agent is at a recorder and empty-handed."
  (every (lambda (agent)
           (or (not (eql (recorder-object-side state agent) :ghost))
               (and (funcall (symbol-function 'recording-agent-at-recorder)
                             state agent)
                    (funcall (symbol-function 'recording-agent-empty-handed)
                             state agent))))
         (gethash 'agent *types*)))


(defun recorder-cycle-boundary-safe-p (state)
  "Whether an open cycle can close without preserving a cross-layer dependency."
  (and (recorder-cycle-agents-ready-p state)
       (not (recorder-cross-layer-boundary-reference-p state))))


(define-query recorder-cycle-boundary-safe ()
  (recorder-cycle-boundary-safe-p state))


(defun recorder-cycle-goal (subgoal)
  "Return SUBGOAL strengthened with the recorder's physical closure requirement."
  `(and ,(copy-tree subgoal)
        (ghost-stops-recorder)))


(defun recorder-cycle-boundary-closed-p (state)
  "Whether STATE is ready to terminate one cycle and start the next."
  (funcall (symbol-function 'ghost-stops-recorder) state))


(defun reset-recorder-cycle-shadow! (state)
  "Run every capability-owned reset callback against STATE."
  (dolist (lifecycle *recorder-shadow-lifecycles* state)
    (funcall (symbol-function (second lifecycle)) state)))


(defun seed-recorder-cycle-shadow! (state)
  "Run every capability-owned seed callback against STATE."
  (dolist (lifecycle *recorder-shadow-lifecycles* state)
    (when (third lifecycle)
      (funcall (symbol-function (third lifecycle)) state))))


(defun recorder-cycle-state-consistent-p (state)
  "Normalize STATE and report whether propagation converged without inconsistency."
  (and (funcall (symbol-function 'propagate-changes!) state)
       (not (state-is-inconsistent state))))


(defun normalize-recorder-cycle-shadow! (state)
  "Reset, seed, and propagate every recording shadow in STATE."
  (reset-recorder-cycle-shadow! state)
  (seed-recorder-cycle-shadow! state)
  (unless (recorder-cycle-state-consistent-p state)
    (add-proposition '(inconsistent-state) (problem-state.idb state))
    (invalidate-problem-state-hash state))
  state)


(defun remove-recorder-ghost-state! (state)
  "Remove every dynamic proposition that refers to a mapped ghost."
  (let ((idb (problem-state.idb state)))
    (dolist (proposition (list-database idb))
      (when (recorder-value-contains-ghost-p state (rest proposition))
        (delete-proposition proposition idb))))
  (invalidate-problem-state-hash state))


(defun close-recorder-cycle-state! (state)
  "Remove completed ghosts and normalize the recording view from live persistent state."
  (remove-recorder-ghost-state! state)
  (normalize-recorder-cycle-shadow! state)
  (when (recorder-state-contains-ghost-reference-p state)
    (add-proposition '(inconsistent-state) (problem-state.idb state))
    (invalidate-problem-state-hash state))
  state)


(defun prepare-recorder-cycle-state (boundary-state)
  "Return a fresh next-cycle state from closed integrated BOUNDARY-STATE.

The original state is never modified.  Preparation fails if the accepted cycle was not
explicitly closed, shadow propagation is inconsistent, or normalization retains a dynamic
ghost reference."
  (unless (recorder-cycle-boundary-closed-p boundary-state)
    (error "Recorder cycle boundary was not produced by STOP-RECORDER."))
  (let ((prepared-state (copy-problem-state boundary-state)))
    (close-recorder-cycle-state! prepared-state)
    (when (state-is-inconsistent prepared-state)
      (error "Recorder cycle shadow did not propagate to a consistent state."))
    (unless (recorder-cycle-boundary-closed-p prepared-state)
      (error "Recorder cycle preparation did not retain a closed ghost-free boundary."))
    prepared-state))

;;;; ==== end technology -recorder-cycle-boundary ====
;; (include-tech -location): already included -- skipped
;; (include-tech -holding): already included -- skipped
;; (include-tech -support-occupancy): already included -- skipped

(in-package :ww)


(define-optional-types recorder connector jammer fan)


(let* ((paired-p (nth-value 1 (gethash 'terminus *types*)))
       (jamming-p (nth-value 1 (gethash 'target *types*)))
       (mounting-p (nth-value 1 (gethash 'gears *types*)))
       relations
       optional-forks)
  ;; Each composite argument type's presence stands in for its relation's own owning tech
  ;; being included, since a relation and its composite argument type are always declared
  ;; together in the same file (TERMINUS with PAIRED in beam-relay.lisp; TARGET with
  ;; JAMMING in jammer.lisp; GEARS with MOUNTED-ON in -gears-fan.lisp).
  (when paired-p
    (push '(paired connector terminus) relations)
    ;; paired: PAIRED declares no fluent argument -- either side may be a plain connector
    ;; or fixed apparatus -- so BIND cannot extract a terminus the way it does for JAMMING
    ;; and MOUNTED-ON below.  The fork instead walks every stored (connector terminus)
    ;; pair directly.  A connector-to-connector pairing may have been stored with either
    ;; connector first, depending on which one was placed second during the recording, so
    ;; both sides are substituted with their own ghost independently; a side with no ghost
    ;; keeps its live value, which covers shared fixed apparatus and any unmapped connector.
    (push '(doall (?connector connector)
             (doall (?terminus terminus)
               (if (paired ?connector ?terminus)
                 (if (bind (recording-copy> ?connector $connector-ghost))
                   (if (bind (recording-copy> ?terminus $terminus-ghost))
                     (paired $connector-ghost $terminus-ghost)
                     (paired $connector-ghost ?terminus))
                   (if (bind (recording-copy> ?terminus $terminus-ghost))
                     (paired ?connector $terminus-ghost))))))
          optional-forks))
  (when jamming-p
    (push '(jamming jammer $target) relations)
    ;; jamming: the target (gate/wall-gears/wall-blower) is never itself mapped
    (push '(doall (?live jammer)
             (if (bind (recording-copy> ?live $ghost))
               (if (bind (jamming ?live $target))
                 (jamming $ghost $target))))
          optional-forks))
  (when mounting-p
    (push '(mounted-on fan $gears) relations)
    ;; mounted-on: the gears are never themselves mapped
    (push '(doall (?live fan)
             (if (bind (recording-copy> ?live $ghost))
               (if (bind (mounted-on ?live $gears))
                 (mounted-on $ghost $gears))))
          optional-forks))
  (when relations
    (install-dynamic-relations relations))
  (install-action
    'start-recorder
    1
    '(?agent agent)
    '(and (live-recording-object ?agent)
          (not (recording-in-progress))
          (recording-agent-at-recorder ?agent)
          (recording-agent-empty-handed ?agent)
          (recorder-closed-ghost-free)
          (assign $cycles-used (recorder-cycle-count))
          (assign $objective-value (problem-state.value state))
          (< $cycles-used *max-recorder-cycles*))
    '(">" ?agent "starts the recorder")
    `(assert
       (assign $next-cycle (1+ $cycles-used))
       (recorder-cycles-used $next-cycle)
       (not (recorder-cycle-closed))
       (recording-in-progress)
       ;; has-location: every mapped mobile object, wherever it currently stands
       (doall (?live mobile-object)
         (if (bind (recording-copy> ?live $ghost))
           (if (bind (has-location ?live $loc))
             (has-location $ghost $loc))))
       ;; holding: mirror both the holder and whatever it currently holds
       (doall (?live mobile-object)
         (if (bind (recording-copy> ?live $ghost))
           (if (bind (holding ?live $cargo))
             (if (bind (recording-copy> $cargo $cargo-ghost))
               (holding $ghost $cargo-ghost)))))
       ;; on: the support itself may or may not be a mapped mobile object
       (doall (?live mobile-object)
         (if (bind (recording-copy> ?live $ghost))
           (if (bind (on ?live $support))
             (if (bind (recording-copy> $support $support-ghost))
               (on $ghost $support-ghost)
               (on $ghost $support)))))
       ,@optional-forks
       (finally (normalize-recorder-cycle-shadow!)))))


(define-action stop-recorder
  1
  (?agent agent)
  (and (ghost-recording-object ?agent)
       (recording-in-progress)
       (recorder-cycle-boundary-safe)
       (assign $cycles-used (recorder-cycle-count))
       (assign $objective-value (problem-state.value state)))
  (">" ?agent "stops the recorder")
  (assert (not (recording-in-progress))
          (recorder-cycles-used $cycles-used)
          (recorder-cycle-closed)
          (finally (close-recorder-cycle-state!))))

;;;; ==== end technology -recorder-session ====
;; (include-tech -recorder-cycle-boundary): already included -- skipped

;;;; ==== begin technology -recorder-cycle-chaining ====

;;; Filename: -recorder-cycle-chaining.lisp

;;; Explicit recorder orchestration behind the generic goal-chaining interface.  Each
;;; dispatched call requires and searches exactly one new closed, validator-approved
;;; recorder cycle.  An intermediate cycle commits its integrated playback boundary
;;; immediately, retains an
;;; independent history record, prepares a fresh recording shadow, and discards the
;;; just-searched program.
;;; The final operation records the last cycle but retains its ordinary solution result.
;;;
;;; REQUIRES:
;;;   nested  : -recorder-cycle-boundary
;;;   planner : goal-chaining checkpoints, WW-SOLVE, solution selection
;;; PROVIDES:
;;;   functions : solve-recorder-subgoal-form and solve-recorder-final (policy handlers),
;;;               print-recorder-chain-report
;;;   structure : recorder-cycle-record

;; (include-tech -recorder-cycle-boundary): already included -- skipped

(in-package :ww)


(defstruct (recorder-cycle-record (:conc-name recorder-cycle-record.))
  "One committed closed recorder cycle."
  subgoal
  closed-goal
  solution
  report
  boundary-state
  solution-type
  depth
  elapsed-time
  value-change
  cumulative-depth
  cumulative-time
  cumulative-value)


(defvar *recorder-cycle-history* nil
  "Committed recorder cycles in chronological order.")

;; Recorder problems are staged repeatedly in one Lisp image.  A newly staged problem
;; starts a new chain rather than inheriting records from the preceding problem.
(setf *recorder-cycle-history* nil)


(defun copy-recorder-cycle-record-deeply (record)
  "Return an independent copy of recorder cycle RECORD."
  (make-recorder-cycle-record
    :subgoal (copy-tree (recorder-cycle-record.subgoal record))
    :closed-goal (copy-tree (recorder-cycle-record.closed-goal record))
    :solution (copy-solution-deeply (recorder-cycle-record.solution record))
    :report (copy-tree (recorder-cycle-record.report record))
    :boundary-state
      (copy-problem-state (recorder-cycle-record.boundary-state record))
    :solution-type (recorder-cycle-record.solution-type record)
    :depth (recorder-cycle-record.depth record)
    :elapsed-time (recorder-cycle-record.elapsed-time record)
    :value-change (recorder-cycle-record.value-change record)
    :cumulative-depth (recorder-cycle-record.cumulative-depth record)
    :cumulative-time (recorder-cycle-record.cumulative-time record)
    :cumulative-value (recorder-cycle-record.cumulative-value record)))


(defun copy-recorder-cycle-history ()
  "Return independent copies of the committed recorder cycle history."
  (mapcar #'copy-recorder-cycle-record-deeply *recorder-cycle-history*))


(defun restore-recorder-cycle-history (history)
  "Replace recorder cycle history with an independent copy of HISTORY."
  (setf *recorder-cycle-history*
        (mapcar #'copy-recorder-cycle-record-deeply history)))


(register-goal-chaining-checkpoint-extension
  'recorder-cycle-history
  'copy-recorder-cycle-history
  'restore-recorder-cycle-history)


(defun validate-recorder-cycle-orchestration ()
  "Validate a guided baseline and return the one permitted next cycle number."
  (validate-continuation-preconditions)
  (unless (member 'validate-recorder-solution *solution-validators*)
    (error "Recorder cycle solving requires the services installed by (include-tech recorder)."))
  (when *solutions-valid*
    (error "A completed solution is still active. Undo or stage a fresh recorder chain ~
            before starting another recorder cycle."))
  (when (member '(recording-in-progress) (database *start-state*) :test #'equal)
    (error "Guided recorder chaining requires a closed starting state."))
  (unless (funcall (symbol-function 'recorder-closed-ghost-free) *start-state*)
    (error "Guided recorder chaining cannot start from stale ghost state."))
  (let ((next-cycle
          (1+ (funcall (symbol-function 'recorder-cycle-count) *start-state*))))
    (when (> next-cycle *max-recorder-cycles*)
      (error "Guided recorder cycle ~D exceeds *MAX-RECORDER-CYCLES* = ~D."
             next-cycle *max-recorder-cycles*))
    next-cycle))


(defun recorder-cycle-final-goal ()
  "Return the original problem goal, or the current goal for a single-cycle solve."
  (copy-tree (or *final-goal* *goal*)))


(defun recorder-guided-cycle-goal (subgoal cycle-number)
  "Require SUBGOAL at the closed end of exactly the next guided recorder cycle."
  `(and ,(copy-tree subgoal)
        (recorder-cycles-used ,cycle-number)
        (ghost-stops-recorder)))


(defun make-committed-recorder-cycle (subgoal closed-goal)
  "Build a stable history record from the canonical completed solution."
  (let* ((solution
           (copy-solution-deeply (select-continuation-solution)))
         (boundary
           (copy-problem-state (solution.goal solution)))
         (report (build-recorder-report solution))
         (previous (car (last *recorder-cycle-history*)))
         (depth (solution.depth solution))
         (elapsed-time
           (- (solution.time solution) (problem-state.time *start-state*)))
         (value-change
           (- (solution.value solution) (problem-state.value *start-state*))))
    (unless (recorder-cycle-boundary-closed-p boundary)
      (error "Validated recorder cycle ended at an open boundary."))
    (unless (= (getf report :cycle-count) 1)
      (error "A guided recorder search must commit exactly one cycle, not ~D."
             (getf report :cycle-count)))
    (make-recorder-cycle-record
      :subgoal (copy-tree subgoal)
      :closed-goal (copy-tree closed-goal)
      :solution solution
      :report report
      :boundary-state boundary
      :solution-type *solution-type*
      :depth depth
      :elapsed-time elapsed-time
      :value-change value-change
      :cumulative-depth
        (+ depth (if previous (recorder-cycle-record.cumulative-depth previous) 0))
      :cumulative-time
        (+ elapsed-time (if previous (recorder-cycle-record.cumulative-time previous) 0))
      :cumulative-value
        (+ value-change (if previous (recorder-cycle-record.cumulative-value previous) 0)))))


(defun print-recorder-cycle-record (record cycle-number stream)
  "Print one committed recorder cycle RECORD."
  (format stream "~&~%Cycle ~D~%" cycle-number)
  (format stream "Closed goal: ~S~%" (recorder-cycle-record.closed-goal record))
  (format stream "Search policy: ~A~%" (recorder-cycle-record.solution-type record))
  (format stream "Cycle metrics: depth ~D; elapsed time ~A; value change ~A~%"
          (recorder-cycle-record.depth record)
          (recorder-cycle-record.elapsed-time record)
          (recorder-cycle-record.value-change record))
  (let* ((report (recorder-cycle-record.report record))
         (cycles (getf report :cycles)))
    (unless (= (length cycles) 1)
      (error "A guided recorder record must contain exactly one cycle."))
    (print-recorder-report-sequence
      "Integrated sequence" (getf report :integrated) stream)
    (print-recorder-cycle-report (first cycles) stream))
  record)


(defun print-recorder-chain-totals (record stream)
  "Print the cumulative metrics and optimization scope through RECORD."
  (format stream "~&~%Chain totals: depth ~D; elapsed time ~A; value change ~A~%"
          (recorder-cycle-record.cumulative-depth record)
          (recorder-cycle-record.cumulative-time record)
          (recorder-cycle-record.cumulative-value record))
  (format stream
          "Any optimization is local to its cycle; this chain is not globally optimized.~%")
  record)


(defun print-recorder-chain-report
    (&optional (history *recorder-cycle-history*) (stream *standard-output*))
  "Print committed recorder HISTORY in cycle order with local and cumulative metrics."
  (unless history
    (error "No committed recorder cycles are available for a chain report."))
  (format stream "~&~%===== Recorder cycle chain =====~%")
  (loop for record in history
        for cycle-number from 1
        do (print-recorder-cycle-record record cycle-number stream))
  (print-recorder-chain-totals (car (last history)) stream)
  history)


(defun install-next-recorder-cycle-baseline (prepared-state)
  "Commit PREPARED-STATE as the next cycle's independent search baseline."
  (setf (problem-state.name prepared-state) 'recorder-cycle-start
        (problem-state.instantiations prepared-state) nil
        *start-state* prepared-state
        *solution-paths* nil
        *solutions-valid* nil)
  prepared-state)


(defun commit-intermediate-recorder-cycle (subgoal closed-goal)
  "Record one cycle, prepare its next baseline, and discard its searched program."
  (let* ((record (make-committed-recorder-cycle subgoal closed-goal))
         (prepared
           (prepare-recorder-cycle-state
             (recorder-cycle-record.boundary-state record))))
    (setf *recorder-cycle-history*
          (append *recorder-cycle-history* (list record)))
    (install-next-recorder-cycle-baseline prepared)
    (format t "~&Recorder cycle committed; the next cycle has a fresh recording shadow.~%")
    record))


(defun commit-final-recorder-cycle (subgoal closed-goal)
  "Record the final cycle while retaining its completed solution."
  (let ((record (make-committed-recorder-cycle subgoal closed-goal)))
    ;; Restore the user's unstrengthened final goal after the closed solution was accepted.
    (install-compiled-goal subgoal)
    (setf *recorder-cycle-history*
          (append *recorder-cycle-history* (list record))
          *final-goal* nil)
    (format t "~&Final recorder cycle committed.~%")
    record))


(defun run-recorder-cycle-planner ()
  "Run WW-SOLVE without duplicating its single-cycle recorder supplement."
  (let ((saved-printers *solution-report-printers*))
    (unwind-protect
        (progn
          (setf *solution-report-printers*
                (remove 'print-recorder-report *solution-report-printers*))
          (ww-solve))
      (setf *solution-report-printers* saved-printers))))


(defun run-recorder-cycle-search (subgoal final-p cycle-number)
  "Search and commit one closed recorder SUBGOAL, final when FINAL-P is true."
  (let* ((closed-goal (recorder-guided-cycle-goal subgoal cycle-number))
         (completed nil))
    ;; The stateful configured maximum still limits the complete guided history.  This
    ;; narrower dynamic limit prevents one guided call from consuming later cycle slots.
    (let ((*max-recorder-cycles* cycle-number))
      (unwind-protect
          (progn
            (install-compiled-goal closed-goal)
            (run-recorder-cycle-planner)
            (let ((record
                    (when *solutions-valid*
                      (if final-p
                        (commit-final-recorder-cycle subgoal closed-goal)
                        (commit-intermediate-recorder-cycle subgoal closed-goal)))))
              (setf completed t)
              (unless record
                (format t "~&Recorder cycle produced no solution. Retry this cycle, or use ~
                           (ww-undo) to restore the preceding session.~%"))
              (when record
                (print-recorder-chain-report))
              t))
        (unless completed
          (setf *solution-paths* nil
                *solutions-valid* nil)
          (format t "~&Recorder cycle interrupted. Use (ww-undo) to restore the preceding ~
                     session.~%"))))))


(defun solve-recorder-subgoal-form (goal-form)
  "Solve and commit one closed intermediate recorder cycle for GOAL-FORM."
  (let ((cycle-number (validate-recorder-cycle-orchestration)))
    (save-undo-checkpoint)
    (unless *final-goal*
      (setf *final-goal* (copy-tree *goal*)))
    (run-recorder-cycle-search goal-form nil cycle-number)))


(defun solve-recorder-final ()
  "Solve and commit the original goal as the final closed recorder cycle."
  (let ((cycle-number (validate-recorder-cycle-orchestration))
        (goal-form (recorder-cycle-final-goal)))
    (save-undo-checkpoint)
    (run-recorder-cycle-search goal-form t cycle-number)))

;;;; ==== end technology -recorder-cycle-chaining ====

;;;; ==== begin technology -recorder-init-checks ====

;;; Filename: -recorder-init-checks.lisp

;;; Initialization validation for -recorder-core identity, exhaustive cargo copying,
;;; recording-layer isolation, and the explicitly supported shadow components.


(in-package :ww)


(define-init-check recorder-init-check (literals)
  (check-init-recorder-consistency literals)
  (init-check-recorder-supported-scope)
  (init-check-recording-cargo-mapping-complete literals))


(define-init-check-helper check-init-recorder-consistency (literals)
  "Checks recorder mappings and cross-layer initial interactions."
  (let ((live-objects (make-hash-table :test #'equal))
        (ghost-objects (make-hash-table :test #'equal)))
    (dolist (literal
              (positive-init-literals-with-relation 'recording-copy> literals))
      (destructuring-bind (live ghost)
          (rest (init-literal-proposition literal))
        (when (eql live ghost)
          (fail-init-check nil "~%RECORDING-COPY> maps an object to itself.~%~
                  Literal: ~S~%~
                  Object:  ~S"
                 literal live))
        (when (or (gethash live ghost-objects)
                  (gethash ghost live-objects))
          (fail-init-check nil "~%RECORDING-COPY> uses an object on both live and ghost sides.~%~
                  Literal:     ~S~%~
                  Live object:  ~S~%~
                  Ghost object: ~S"
                 literal live ghost))
        (unless (init-recording-copy-compatible-p live ghost)
          (fail-init-check nil "~%RECORDING-COPY> connects incompatible object categories.~%~
                  Literal:     ~S~%~
                  Live object:  ~S~%~
                  Ghost object: ~S"
                 literal live ghost))
        (setf (gethash live live-objects) t)
        (setf (gethash ghost ghost-objects) t)))
    (when (init-relation-signature 'recording-copy>)
      (init-check-recording-locations literals live-objects ghost-objects)
      (init-check-recording-holdings literals live-objects ghost-objects)
      (init-check-recording-supports literals live-objects ghost-objects)
      (init-check-recording-pairings literals live-objects ghost-objects)
      (init-check-recording-jamming-facts literals live-objects ghost-objects)
      (init-check-recording-mapped-wall-fans live-objects ghost-objects)
      (init-check-recording-wall-gears-controls literals))))


(define-init-check-helper init-recording-copy-compatible-p (live ghost)
  (some (lambda (category)
          (and (init-type-member-p live category)
               (init-type-member-p ghost category)))
        (init-type-components 'mobile-object)))


(define-init-check-helper init-recording-side (object live-objects ghost-objects)
  (cond ((gethash object live-objects) 'live)
        ((gethash object ghost-objects) 'ghost)))


(define-init-check-helper init-same-recording-side-p (object1 object2 live-objects ghost-objects)
  (let ((side1 (init-recording-side object1 live-objects ghost-objects))
        (side2 (init-recording-side object2 live-objects ghost-objects)))
    (and side1 (eql side1 side2))))


(define-init-check-helper init-check-recording-cargo-completeness
    (live-objects ghost-objects)
  "Require every cargo instance to occur on exactly one side of a copy pair."
  (dolist (object (init-type-instances 'cargo))
    (unless (init-recording-side object live-objects ghost-objects)
      (fail-init-check nil "~%Recorder cargo is missing from RECORDING-COPY>.~%~
              Object: ~S~%~
              Every cargo object must be a live or ghost endpoint.  Fixed combined ~
              blowers are shared BLOWER objects, not cargo fans."
             object))))


(define-init-check-helper init-check-recording-cargo-mapping-complete (literals)
  "Collect the already-validated mapping and enforce cargo completeness last."
  (let ((live-objects (make-hash-table :test #'equal))
        (ghost-objects (make-hash-table :test #'equal)))
    (dolist (literal
              (positive-init-literals-with-relation 'recording-copy> literals))
      (let ((proposition (init-literal-proposition literal)))
        (setf (gethash (second proposition) live-objects) t
              (gethash (third proposition) ghost-objects) t)))
    (init-check-recording-cargo-completeness live-objects ghost-objects)))


(define-init-check-helper init-check-recording-locations
    (literals live-objects ghost-objects)
  "Requires every located mobile object to have an explicit recording side."
  (dolist (literal (positive-init-literals-with-relation 'has-location literals))
    (destructuring-bind (object location)
        (rest (init-literal-proposition literal))
      (declare (ignore location))
      (when (and (init-type-member-p object 'mobile-object)
                 (not (init-recording-side object live-objects ghost-objects)))
        (fail-init-check nil "~%HAS-LOCATION gives an unmapped mobile object physical state.~%~
                Literal: ~S~%~
                Object:  ~S~%~
                Every located mobile object in a recorder problem needs a RECORDING-COPY> pair."
               literal object)))))


(define-init-check-helper init-check-recording-holdings (literals live-objects ghost-objects)
  (dolist (literal (positive-init-literals-with-relation 'holding literals))
    (destructuring-bind (agent object)
        (rest (init-literal-proposition literal))
      (unless (init-same-recording-side-p
                agent object live-objects ghost-objects)
        (fail-init-check nil "~%HOLDING crosses recording layers or uses an unmapped object.~%~
                Literal: ~S~%~
                Agent:   ~S~%~
                Object:  ~S"
               literal agent object)))))


(define-init-check-helper init-check-recording-supports (literals live-objects ghost-objects)
  (dolist (literal (init-binary-on-literals literals))
    (destructuring-bind (occupant support)
        (rest (init-literal-proposition literal))
      (when (and (init-type-member-p support 'mobile-object)
                 (not (init-same-recording-side-p
                        occupant support live-objects ghost-objects)))
        (fail-init-check nil "~%ON crosses recording layers or uses an unmapped mobile support.~%~
                Literal:  ~S~%~
                Occupant: ~S~%~
                Support:  ~S"
               literal occupant support)))))


(define-init-check-helper init-check-recording-pairings (literals live-objects ghost-objects)
  (dolist (literal (positive-init-literals-with-relation 'paired literals))
    (destructuring-bind (connector terminus)
        (rest (init-literal-proposition literal))
      (let ((connector-side
              (init-recording-side connector live-objects ghost-objects))
            (terminus-side
              (init-recording-side terminus live-objects ghost-objects)))
        (unless (and connector-side
                     (or (not (init-type-member-p terminus 'connector))
                         (and terminus-side
                              (or (eql connector-side 'live)
                                  (and (eql connector-side 'ghost)
                                       (eql terminus-side 'ghost))))))
          (fail-init-check nil "~%PAIRED violates recorder connector isolation.~%~
                  Literal:  ~S~%~
                  Connector: ~S~%~
                  Terminus:  ~S"
                 literal connector terminus))))))


(define-init-check-helper init-check-recording-mapped-wall-fans
    (live-objects ghost-objects)
  "Rejects movable fan copies while wall-fan presence is not recording-view aware."
  (when (and (init-relation-signature 'mounted-on)
             (init-type-instances 'wall-gears))
    (dolist (fan (init-type-instances 'fan))
      (when (or (gethash fan live-objects)
                (gethash fan ghost-objects))
        (fail-init-check nil "~%Recorder technology does not yet support mapped wall-fan mounting.~%~
                Fan: ~S"
               fan)))))


(define-init-check-helper init-check-recording-wall-gears-controls (literals)
  "Rejects control sources that Stage 3's recording shadow cannot derive."
  (when (init-dnf-controls-relation-p)
    (dolist (literal (positive-init-literals-with-relation 'controls literals))
      (destructuring-bind (clauses controlled-object mode)
          (rest (init-literal-proposition literal))
        (declare (ignore mode))
        (when (or (init-type-member-p controlled-object 'wall-gears)
                  (init-type-member-p controlled-object 'wall-blower))
          (dolist (clause clauses)
            (dolist (controller clause)
              (unless (init-type-member-p controller 'plate)
                (fail-init-check nil "~%Recording-side wall blower controls support only plates.~%~
                        Literal:          ~S~%~
                        Wall drive:        ~S~%~
                        Unsupported item: ~S"
                       literal controlled-object controller)))))))))


(define-init-check-helper init-check-recording-jamming-facts
    (literals live-objects ghost-objects)
  "Requires every initially active jammer to have an explicit recording side."
  (dolist (literal (positive-init-literals-with-relation 'jamming literals))
    (destructuring-bind (jammer target)
        (rest (init-literal-proposition literal))
      (declare (ignore target))
      (unless (init-recording-side jammer live-objects ghost-objects)
        (fail-init-check nil "~%JAMMING uses an unmapped jammer in a recorder problem.~%~
                Literal: ~S~%~
                Jammer:  ~S~%~
                Every active jammer needs a RECORDING-COPY> pair."
               literal jammer)))))


(define-init-check-helper init-check-recorder-unsupported-type (type capability)
  "Rejects instances of TYPE while CAPABILITY has no recording-side model."
  (let ((instances (init-type-instances type)))
    (when instances
      (fail-init-check nil "~%Recorder technology does not yet support ~A.~%~
              Type:   ~S~%~
              Object: ~S"
             capability type (first instances)))))


(define-init-check-helper init-check-recording-threats ()
  "Rejects threats until lethal state and safety are recording-view aware."
  (if (init-type-instances 'threat)
    (init-check-recorder-unsupported-type 'threat "recording-side threats")
    (init-check-recorder-unsupported-type 'gun "recording-side threats")))


(define-init-check-helper init-check-recording-beam-crossings ()
  "Rejects the beam-crossing peer until crossing and cut state have a recording view."
  (when (init-relation-signature 'crossings-along-beam>)
    (fail-init-check nil
      "Recorder technology does not yet support recording-side beam crossings.")))


(define-init-check-helper init-check-recorder-supported-scope ()
  "Rejects installed objects and capabilities outside the recorder shadow."
  (init-check-recorder-unsupported-type 'floor-gears "recording-side floor blowers")
  (init-check-recorder-unsupported-type 'floor-blower "recording-side floor blowers")
  (init-check-recorder-unsupported-type 'angled-gears "recording-side angled blowers")
  (init-check-recorder-unsupported-type 'angled-blower "recording-side angled blowers")
  (init-check-recording-threats)
  (init-check-recording-beam-crossings))

;;;; ==== end technology -recorder-init-checks ====

(in-package :ww)


;; These registries are reset before every stage.  Keeping installation at the end of the
;; public assembly scopes the complete recorder policy to problems that include RECORDER and
;; guarantees that every registered implementation has already been defined.  Exact
;; live/ghost interleaving pruning is automatic on the supported serial search path.
(register-solution-validator 'validate-recorder-solution)
(register-search-prefix-validator
  'validate-recorder-cycle-boundary-prefix
  'recorder-cycle-boundary-validation-enabled-p
  'recorder-stop-prefix-trigger-p)
(register-search-prefix-validator
  'validate-recorder-recording-prefix
  'recorder-prefix-pruning-enabled-p)
(register-search-successor-pruner
  'prune-recorder-interleaving-successor-p
  'recorder-interleaving-pruning-enabled-p)
(register-search-successor-pruner
  'prune-recorder-boundary-dominated-successor-p
  'recorder-boundary-dominance-enabled-p
  'reset-recorder-boundary-dominance)
(register-solution-report-printer 'print-recorder-report)
(register-goal-chaining-policy
  'solve-recorder-subgoal-form
  'solve-recorder-final)

;;;; ==== end technology recorder ====

;;;; ==== begin technology stairs ====

;;; Filename: stairs.lisp

;;; Stairs mobility provider.  Authored STAIRS-VIA/STAIRS-VIA> edges connect grounded
;;; locations without imposing an elevation-difference limit.  Their enabling-means list
;;; is conjunctive: every listed obstacle must be passable for the moving agent.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   nested    : -passability; -threat; -mobility-action
;;; PROVIDES:
;;;   relations : (stairs-via location $list location)
;;;               (stairs-via> location $list location)
;;;   queries   : stairs-traversal-segments
;;;   provider  : stairs-traversal-segments registered with -mobility
;;;   action    : move (from -mobility-action)


;;;; ==== begin technology -passability ====

;;; Filename: -passability.lisp

;;; Passability substrate: whether an agent may pass each obstacle or enabling
;;; implement on a traversal edge.  Shared by walking, stairs, jumping, and ladder traversal.
;;;
;;; Gate, screen, and ladder are owned outright here.  The gears and fixed-blower leaf
;;; types are reserved as a fourth obstacle kind through a null-object default hook,
;;; STREAM-OBSTACLE-CLEAR, so a
;;; technology like -stream-passability can override just that one slot instead of
;;; redefining OBSTACLE-CLEAR whole -- the same pattern -beam-substrate uses for its
;;; peers.  The leaf types are declared optional here without nesting -gears-fan, so a
;;; walking-only problem never pulls in mounting machinery it doesn't use.
;;;
;;; REQUIRES:
;;;   types     : agent
;;;   nested    : -holding (cargo, holding); -gate (gate optional type, (open gate) relation)
;;; PROVIDES:
;;;   types     : screen, ladder, the three gears leaves, and the three fixed-blower leaves -- declared
;;;               optional, populated for real only when a problem declares those leaves
;;;   queries   : obstacle-clear, all-clear, and an actor-aware null-object default for
;;;               stream-obstacle-clear (overridden by -stream-passability)
;;;   functions : canonical-enabling-means

;; (include-tech -holding): already included -- skipped
;; (include-tech -gate): already included -- skipped

(in-package :ww)


(define-optional-types
  screen ladder floor-gears wall-gears angled-gears
  floor-blower wall-blower angled-blower)


(define-problem-helper canonical-enabling-means (means)
  "Return a stable set representation for a flat conjunction of enabling means."
  (sort (copy-list (remove-duplicates means :test #'eq))
        #'string< :key #'symbol-name))


(define-query all-clear (?agent agent ?obstacles)
  ;; The empty list is clear.  Otherwise every listed obstacle or enabling
  ;; implement must be usable by the agent. ?obstacles is computed Lisp list data.
  (ww-loop for $obstacle in ?obstacles
           always (obstacle-clear ?agent $obstacle)))


(define-query obstacle-clear
    (?agent agent
     ?obstacle (either gate screen ladder
                       floor-gears wall-gears angled-gears
                       floor-blower wall-blower angled-blower))
  ;; An open gate passes.  A screen or ladder passes only when the agent is
  ;; empty-handed.  A gears obstacle defers to stream-obstacle-clear, whose default
  ;; passes everything until a technology like -stream-passability overrides it with
  ;; real stream logic.
  (or (and (gate ?obstacle)
           (gate-open-for-object ?agent ?obstacle))
      (and (screen ?obstacle)
           (not (bind (holding ?agent $any-held-object))))
      (and (ladder ?obstacle)
           (not (bind (holding ?agent $any-held-object))))
      (and (or (floor-gears ?obstacle)
               (wall-gears ?obstacle)
               (angled-gears ?obstacle)
               (floor-blower ?obstacle)
               (wall-blower ?obstacle)
               (angled-blower ?obstacle))
           (stream-obstacle-clear ?agent ?obstacle))))


;;;; NULL-OBJECT DEFAULT HOOK ;;;;
;;;; Overridden by whichever technology owns a gears obstacle's real clearance rule.
;;;; When every gears leaf type is empty, obstacle-clear's gears branch never binds and
;;;; this default is never called.


(define-query stream-obstacle-clear
    (?agent agent
     ?obstacle (either floor-gears wall-gears angled-gears
                       floor-blower wall-blower angled-blower))
  (do ?agent ?obstacle t))

;;;; ==== end technology -passability ====

;;;; ==== begin technology -threat ====

;;; Filename: -threat.lisp

;;; Threat substrate: the shared interface for anything that makes a location lethal to
;;; occupy.  A threat instance (gun today; a future hazard technology joins the same
;;; union) authors the fixed set of locations it endangers via THREATENS; its own
;;; technology is the sole asserter of LETHAL when that threat is currently live -- gun's
;;; update-gun-status! for gun, mirroring how -gate.lisp's OPEN is asserted only by
;;; gate.lisp.  SAFE is the query any relocating action can consult at its own precondition
;;; to exclude an unsafe destination outright -- the walking, stairs, and ladder mobility
;;; providers and support-changing jump transitions all do.  But
;;; a location can also become unsafe with no relocation at all (a threat arming remotely
;;; while an agent already stands where it reaches), and a blower's forced physics has no
;;; precondition to gate in the first place, so ENFORCE-THREAT-SAFETY! is the general
;;; backstop: it runs every propagation pass and marks the whole state inconsistent -- see
;;; ww-planner.lisp's generate-children, which drops any successor carrying that marker --
;;; if any agent's current location isn't safe, however it got there.  This file is
;;; nested unconditionally by gun.lisp, so the backstop is present whenever a threat
;;; exists, regardless of which relocation technologies (walkability, stairs, jump, ladder, the
;;; blowers) the problem also includes -- deliberately breaking the usual role convention
;;; of owning no driver logic, since only a file present under every combination
;;; guarantees the invariant actually holds.  A problem with no threats pays nothing: the
;;; THREAT type is empty, SAFE reduces to T, and the backstop's doall is vacuous.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   functions : inconsistent-state  --  supplied by the planner (ww-planner.lisp), not
;;;               by another technology
;;; PROVIDES:
;;;   types     : threat (either gun)  --  extensible; a future hazard technology adds its
;;;               own leaf type to this either form.  gun is declared optional here.
;;;   relations : (threatens threat location)  --  static; one fact per location a threat
;;;               instance endangers while lethal
;;;               (lethal threat)  --  dynamic; asserted only by each threat technology's
;;;               own status update
;;;   query     : safe
;;;   update    : enforce-threat-safety!  --  the general inconsistent-state backstop

;; (include-tech -propagation): already included -- skipped

(in-package :ww)


(define-optional-types gun)


(define-types
  threat (either gun))


(define-static-relations
  (threatens threat location))


(define-dynamic-relations
  (lethal threat))  ;derived; asserted only by each threat technology's own status update


(define-query safe (?location location)
  ;; True unless some currently-lethal threat has a THREATENS fact for ?location.
  (not (exists (?t threat)
         (and (lethal ?t)
              (threatens ?t ?location)))))


(define-update enforce-threat-safety! ()
  ;; The general backstop, run every propagation pass: if any agent's current location
  ;; isn't safe -- however it got there, whether by a precondition-gated move or
  ;; configuration transition that somehow still landed unsafely, a blower's
  ;; unconditional physics, or a
  ;; threat arming remotely while the agent already stood in its reach -- the whole state
  ;; is marked inconsistent and dropped from the search.  Even transient exposure during a
  ;; single fixpoint is fatal: nothing here retracts the marker once set.
  (doall (?agent agent)
    (if (and (bind (has-location ?agent $location))
             (not (safe $location)))
      (inconsistent-state))))

;;;; ==== end technology -threat ====

;;;; ==== begin technology -mobility-action ====

;;; Filename: -mobility-action.lisp

;;; Central movement action.  Transparent traversal providers compute grounded routes
;;; without mutating state, while configuration-transition providers expose one explicit
;;; support-changing boundary at a time.  MOVE presents both as routes between normalized
;;; (location ground-or-support) configurations and applies exactly one result.
;;;
;;; REQUIRES:
;;;   nested   : -mobility; -configuration-transition
;;; PROVIDES:
;;;   query    : movement-results
;;;   action   : move

;; (include-tech -mobility): already included -- skipped

;;;; ==== begin technology -configuration-transition ====

;;; Filename: -configuration-transition.lisp

;;; Explicit agent-configuration transitions.  Providers describe one state-changing
;;; transition at a time as
;;;
;;;   (mode source-configuration witness destination-configuration)
;;;
;;; where each configuration is (location ground-or-support).  Unlike mobility, these
;;; transitions are never transitively closed: changing support is a planning boundary
;;; because it can clear or occupy supports and trigger propagation.  This is also the
;;; sole place any agent's has-location is ever asserted, so it is the single insertion
;;; point for a held tray to follow its holder: apply-agent-configuration! relocates a
;;; held tray, and everything riding on it, to the agent's destination.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   nested    : -support-occupancy; -location; -propagation; -holding (cargo, holding;
;;;               tray declared optional here so agent movement never requires a problem
;;;               to declare tray objects)
;;; PROVIDES:
;;;   query     : agent-configuration, configuration-transition-results
;;;   functions : register-configuration-transition-provider and canonical selection helpers
;;;   update    : apply-agent-configuration!  --  also relocates a held tray and its
;;;               riders, keeping the tray's has-location synced to its holder's
;;;               relocate-tray-and-riders!  --  breadth-first (on ...)-chain relocation,
;;;               modeled on -gears-fan's relocate-stack!; kept local so agent movement
;;;               never depends on optional blower technology

;; (include-tech -support-occupancy): already included -- skipped
;; (include-tech -location): already included -- skipped
;; (include-tech -propagation): already included -- skipped
;; (include-tech -holding): already included -- skipped

(in-package :ww)


(define-optional-types tray)


(defparameter *configuration-transition-providers* nil
  "Problem-local query names that return explicit agent-configuration transitions.")


(define-problem-helper register-configuration-transition-provider (provider)
  "Register a pure configuration-transition provider query for the staged problem."
  (unless (and (symbolp provider)
               (member provider *query-names* :test #'eq))
    (error "Configuration-transition provider must name an installed query: ~S"
           provider))
  (pushnew provider *configuration-transition-providers* :test #'eq)
  provider)


(define-problem-helper configuration-transition-key (transition)
  "Return the stable lexical key for a normalized semantic transition."
  (let ((*print-case* :upcase)
        (*print-pretty* nil)
        (*package* (find-package :ww)))
    (prin1-to-string transition)))


(define-problem-helper configuration-transition-precedes-p
    (transition1 transition2)
  "Order transitions by their normalized semantic representation."
  (string< (configuration-transition-key transition1)
           (configuration-transition-key transition2)))


(define-problem-helper valid-agent-configuration-p (configuration)
  "Whether CONFIGURATION is a normalized (location ground-or-support) pair."
  (and (listp configuration)
       (= (length configuration) 2)
       (member (first configuration) (gethash 'location *types*) :test #'eq)
       (or (eql (second configuration) 'ground)
           (member (second configuration) (gethash 'support *types*) :test #'eq))))


(define-problem-helper validate-configuration-transition (transition source)
  "Signal an error unless TRANSITION obeys the normalized provider contract."
  (unless (and (listp transition)
               (= (length transition) 4)
               (symbolp (first transition))
               (equal (second transition) source)
               (valid-agent-configuration-p (second transition))
               (valid-agent-configuration-p (fourth transition))
               (not (equal (second transition) (fourth transition))))
    (error "Invalid configuration transition from ~S: ~S" source transition))
  transition)


(define-problem-helper configuration-provider-transitions
    (state agent source)
  "Collect, validate, deduplicate, and canonically order provider transitions."
  (let ((transitions nil))
    (dolist (provider *configuration-transition-providers*)
      (dolist (transition (funcall (symbol-function provider) state agent source))
        (push (validate-configuration-transition transition source)
              transitions)))
    (sort (remove-duplicates transitions :test #'equal)
          #'configuration-transition-precedes-p)))


(define-problem-helper canonical-configuration-transitions (transitions)
  "Retain the first canonical transition to each distinct destination configuration."
  (let ((destinations (make-hash-table :test #'equal))
        (selected nil))
    (dolist (transition transitions (nreverse selected))
      (let ((destination (fourth transition)))
        (unless (gethash destination destinations)
          (setf (gethash destination destinations) t)
          (push transition selected))))))


(define-query agent-configuration (?agent agent)
  (do (bind (has-location ?agent $location))
      (assign $place
              (if (bind (on ?agent $support))
                $support
                'ground))
      (list $location $place)))


(define-query configuration-transition-results (?agent agent)
  (do (assign $source (agent-configuration ?agent))
      (assign $transitions
              (configuration-provider-transitions state ?agent $source))
      (canonical-configuration-transitions $transitions)))


(define-update relocate-tray-and-riders! (?tray tray ?destination location)
  ;; Move ?tray and, transitively, every occupant riding on it to ?destination, keeping a
  ;; held tray's has-location synced to its holder's as the holder moves.  Breadth-first
  ;; over the (on ...) links, modeled on -gears-fan's relocate-stack!, so arbitrary stack
  ;; depth needs no recursion.  Kept local rather than calling -gears-fan's version so
  ;; agent movement never depends on optional blower technology.
  (do (assign $moving (list ?tray))
      (ww-loop while $moving
               do (assign $next nil)
                  (ww-loop for $object in $moving
                           do (has-location $object ?destination)
                              (doall (?y support-occupant)
                                (if (on ?y $object)
                                  (push ?y $next))))
                  (assign $moving $next))))


(define-update apply-agent-configuration!
    (?agent agent ?destination-configuration)
  (do (if (bind (on ?agent $source-support))
        (not (on ?agent $source-support)))
      (has-location ?agent (first ?destination-configuration))
      (if (not (eql (second ?destination-configuration) 'ground))
        (on ?agent (second ?destination-configuration)))
      (if (and (bind (holding ?agent $held))
               (tray $held))
        (relocate-tray-and-riders! $held (first ?destination-configuration)))))

;;;; ==== end technology -configuration-transition ====

(in-package :ww)


(define-problem-helper grounded-movement-results-in-state
    (state agent source-location)
  "Return non-reflexive mobility results with normalized ground configurations."
  (loop for result in
          (funcall (symbol-function 'mobility-results)
                   state agent source-location)
        unless (eql (first result) source-location)
          collect (list (list (first result) 'ground)
                        (second result))))


(define-problem-helper transition-movement-results-in-state (state agent)
  "Return configuration transitions as singleton movement routes."
  (mapcar
    (lambda (transition)
      (list (fourth transition) (list transition)))
    (funcall (symbol-function 'configuration-transition-results)
             state agent)))


(define-problem-helper movement-results-in-state (state agent source-configuration)
  "Collect grounded routes before explicit support transitions for AGENT."
  (let ((transitions
          (transition-movement-results-in-state state agent)))
    (if (eql (second source-configuration) 'ground)
      (nconc
        (grounded-movement-results-in-state
          state agent (first source-configuration))
        transitions)
      transitions)))


(define-query movement-results (?agent agent)
  (do (assign $source-configuration (agent-configuration ?agent))
      (assign $results
              (movement-results-in-state
                state ?agent $source-configuration))
      $results))


(define-action move
  1
  (?agent agent)
  (do (assign $source-configuration (agent-configuration ?agent))
      (assign $movement-results
              (movement-results-in-state
                state ?agent $source-configuration)))
  (">" ?agent "moves via" $route)
  (ww-loop for $result in $movement-results
           do (assert
                (assign $destination-configuration (first $result))
                (assign $route (second $result))
                (apply-agent-configuration!
                  ?agent $destination-configuration)
                (finally (propagate-changes!)))))

;;;; ==== end technology -mobility-action ====

(in-package :ww)


(define-static-relations
  (stairs-via location $list location)
  (stairs-via> location $list location))


(define-init-check stairs-init-check (literals)
  (:consumes gate screen ladder gears)
  (dolist (relation '(stairs-via stairs-via>))
    (check-init-list-relation-items-have-types
      literals relation
      '(gate screen ladder
        floor-gears wall-gears angled-gears
        floor-blower wall-blower angled-blower))))


(define-problem-helper stairs-segment-for-means
    (state agent source destination means)
  "Return a normalized STAIRS segment when its means and destination are enabled."
  (let ((canonical-means (canonical-enabling-means means)))
    (when (and (funcall (symbol-function 'all-clear)
                        state agent canonical-means)
               (funcall (symbol-function 'safe) state destination))
      (list 'stairs source canonical-means destination))))


(define-query stairs-traversal-segments (?agent agent ?from location)
  (do (assign $segments nil)
      (doall (?to location)
        (do (assign $symmetric-segment nil)
            (assign $directional-segment nil)
            (if (bind (stairs-via ?from $symmetric-means ?to))
              (assign $symmetric-segment
                      (stairs-segment-for-means
                        state ?agent ?from ?to $symmetric-means)))
            (if (bind (stairs-via> ?from $directional-means ?to))
              (assign $directional-segment
                      (stairs-segment-for-means
                        state ?agent ?from ?to $directional-means)))
            (if $symmetric-segment
              (assign $segments (cons $symmetric-segment $segments)))
            (if $directional-segment
              (assign $segments (cons $directional-segment $segments)))))
      $segments))


(register-mobility-provider 'stairs-traversal-segments)

;;;; ==== end technology stairs ====

;;;; ==== begin technology ladder ====

;;; Filename: ladder.lisp

;;; Ladder mobility provider.  A directed CLIMB-VIA> edge contributes a LADDER traversal
;;; segment when one of its listed ladder fixtures is positioned exactly at the segment
;;; source and every enabling implement is usable.  The segment witness places the selected
;;; ladder first, followed by the other canonicalized enabling means.
;;;
;;; REQUIRES:
;;;   types     : agent, location  --  ladder is declared optional here (define-optional-types)
;;;   nested    : -position; -passability; -threat; -mobility-action
;;; PROVIDES:
;;;   types     : ladder  --  declared optional here and by nested -passability; the
;;;               declarations resolve compatibly
;;;   relations : (climb-via> location $list location)
;;;   queries   : usable-ladder-at-source, positioned-ladders-for-means,
;;;               ladder-traversal-segments
;;;   provider  : ladder-traversal-segments registered with -mobility
;;;   action    : move (from -mobility-action)

;; (include-tech -position): already included -- skipped
;; (include-tech -passability): already included -- skipped
;; (include-tech -threat): already included -- skipped
;; (include-tech -mobility-action): already included -- skipped

(in-package :ww)


(define-optional-types ladder)


(define-static-relations
  (climb-via> location $list location))  ;directed climb edge; $list = enabling means


(define-init-check ladder-init-check (literals)
  (:consumes gate screen ladder)
  (check-init-list-relation-items-have-types
    literals 'climb-via> '(gate screen ladder)))


(define-query usable-ladder-at-source
    (?ladder ladder ?source location ?means)
  (and (member ?ladder ?means)
       (has-position ?ladder ?source)))


(define-query positioned-ladders-for-means (?source location ?means)
  (do (assign $ladders nil)
      (doall (?ladder ladder)
        (if (usable-ladder-at-source ?ladder ?source ?means)
          (assign $ladders (cons ?ladder $ladders))))
      (sort $ladders #'string< :key #'symbol-name)))


(define-problem-helper ladder-segment-witness (ladder means)
  "Place the selected LADDER first, followed by every other required enabling means."
  (cons ladder
        (remove ladder (canonical-enabling-means means)
                :test #'eq :count 1)))


(define-query ladder-traversal-segments (?agent agent ?from location)
  (do (assign $segments nil)
      (doall (?to location)
        (if (bind (climb-via> ?from $raw-means ?to))
          (do (assign $means (canonical-enabling-means $raw-means))
              (assign $ladders
                      (positioned-ladders-for-means ?from $means))
              (if (and $ladders
                       (all-clear ?agent $means)
                       (safe ?to))
                (assign $segments
                        (cons
                          (list 'ladder ?from
                                (ladder-segment-witness
                                  (first $ladders) $means)
                                ?to)
                          $segments))))))
      $segments))


(register-mobility-provider 'ladder-traversal-segments)

;;;; ==== end technology ladder ====

;;;; ==== begin technology step ====

;;; Filename: step.lisp

;;; Step technology: provide ground-level mounting and dismounting transitions for flush
;;; supports (plates and
;;; gears-mounted fans).  A steppable's top sits exactly at its location's floor elevation,
;;; so stepping involves no elevation change -- that is what distinguishes step transitions
;;; from the jump technology, which handles exclusively elevation-related support changes
;;; (box tops) and authored jump edges.  A fan is steppable only while mounted on gears: a
;;; fan lying on the ground or resting on a box top cannot be stepped on (nor jumped to).
;;; Stepping on a plate depresses it (plate's update-plate-status! derives depression from
;;; cleartop), so an agent can hold a gate or gears control active with its own weight;
;;; stepping on a fan whose gears are turning launches the agent to the gears' aimed-at
;;; destination during the ensuing propagation.
;;;
;;; REQUIRES:
;;;   types     : agent, location; plate comes from nested -plate-types; fan,
;;;               floor-blower, and angled-blower are declared optional here
;;;   nested    : -mobility-action (central MOVE action, configuration representation,
;;;               transition registry, support mutation, and propagation);
;;;               -position ((has-position ...))
;;;   conditional relations:
;;;               mounted-on (fan), guarded by fan  --  owned by -gears-fan.lisp;
;;;               translation removes the guarded reference when the fan type is empty
;;; PROVIDES:
;;;   types     : steppable-object (either pressure-plate toggle-plate fan floor-blower
;;;               angled-blower)
;;;   queries   : step-source-can-mount, step-source-can-dismount,
;;;               steppable-fixture-at, step-configuration-transitions
;;;   provider  : step-configuration-transitions registered with
;;;               -configuration-transition
;;;   action    : move (from -mobility-action)

;; (include-tech -mobility-action): already included -- skipped
;; (include-tech -position): already included -- skipped

(in-package :ww)


(define-optional-types fan floor-blower angled-blower)


(define-types
  steppable-object
    (either pressure-plate toggle-plate fan floor-blower angled-blower))


(define-query step-source-can-mount (?source-place)
  (eql ?source-place 'ground))


(define-query step-source-can-dismount (?source-place)
  (and (not (eql ?source-place 'ground))
       (steppable-object ?source-place)))


(define-query steppable-fixture-at
    (?fixture steppable-object ?location location)
  ;; A plate or combined floor/angled blower is fixed.  A removable fan is steppable only
  ;; while attached to gears and carrying a floor location; a wall-mounted fan has no
  ;; location and therefore cannot match.
  (or (and (plate ?fixture)
           (has-position ?fixture ?location))
      (and (or (floor-blower ?fixture)
               (angled-blower ?fixture))
           (has-position ?fixture ?location))
      (and (fan ?fixture)
           (bind (mounted-on ?fixture $gears))
           (has-location ?fixture ?location))))


(define-query step-configuration-transitions (?agent agent ?source-configuration)
  (do (assign $location (first ?source-configuration))
      (assign $source-place (second ?source-configuration))
      (assign $transitions nil)
      (if (step-source-can-mount $source-place)
        (doall (?fixture steppable-object)
          (if (and (steppable-fixture-at ?fixture $location)
                   (cleartop ?fixture)
                   (support-use-allowed ?agent ?fixture))
            (assign $transitions
                    (cons
                      (list 'step ?source-configuration nil
                            (list $location ?fixture))
                      $transitions)))))
      (if (step-source-can-dismount $source-place)
        (assign $transitions
                (cons
                  (list 'step ?source-configuration nil
                        (list $location 'ground))
                  $transitions)))
      $transitions))


(register-configuration-transition-provider
  'step-configuration-transitions)

;;;; ==== end technology step ====

;;;; ==== begin technology jump ====

;;; Filename: jump.lisp

;;; Jumping technology: contribute grounded jumps across authored edges to the mobility
;;; closure, or provide one explicit agent-configuration transition.  Support-changing
;;; landings may be local ground, remote ground, or a clear box top.  Level and downward
;;; landings are unrestricted; upward landings -- whether reaching a higher support or
;;; clearing a vaultable barrier's top -- are limited to *vertical-reach-limit* (default
;;; 1), independent of the jumping agent's own declared height.
;;; Jumping handles exclusively elevation-related moves: local support changes involve box
;;; tops only (mounting and dismounting flush supports like plates and gears-mounted fans
;;; belongs to the step technology; a fan resting on a box top is not a jump landing).
;;; Open gates and passable screens impose no clearance requirement.  Closed gates,
;;; non-passable screens, and walls contribute their top elevations; a multi-feature jump
;;; must clear the highest feature that is not currently passable, within that same fixed
;;; elevation limit.
;;; Each produced segment or transition is tagged JUMP when nothing required clearance, or
;;; VAULT when some feature genuinely did (accounting for passability) -- a move-type label
;;; a printed route displays alongside WALK, STAIRS, and CLIMB; it does not affect
;;; feasibility.
;;;
;;; REQUIRES:
;;;   types     : agent, location  --  box and wall are declared optional here
;;;   nested    : -support-elevation (support occupancy, location, height, elevation,
;;;               support-top-elevation, occupant-elevation, and *vertical-reach-limit*,
;;;               which this file reuses rather than defining its own jump-specific
;;;               parameter); -passability (holding and obstacle-clear); -threat (safe --
;;;               true unless an armed gun or other threat endangers the landing location);
;;;               -mobility-action
;;; PROVIDES:
;;;   types     : box, wall  --  declared optional; jumping remains usable without them
;;;               vaultable-object (either gate screen wall)
;;;   relations : (jump-via location $list location)
;;;               (jump-via> location $list location)
;;;   queries   : jump-elevation-reachable, vaultable-object-passable,
;;;               jump-barrier-top-elevation, vaultable-object-list,
;;;               jump-required-clearance-height, jump-path-clear,
;;;               jump-traversal-segments, jump-configuration-transitions
;;;   provider  : jump-traversal-segments registered with -mobility
;;;               jump-configuration-transitions registered with
;;;               -configuration-transition
;;;   action    : move (grounded mobility and explicit support changes)

;; (include-tech -support-elevation): already included -- skipped
;; (include-tech -passability): already included -- skipped
;; (include-tech -threat): already included -- skipped
;; (include-tech -mobility-action): already included -- skipped

(in-package :ww)


(define-optional-types box wall)


(define-types
  vaultable-object (either gate screen wall))


(define-static-relations
  (jump-via location $list location)  ;symmetric jump edge; $list = path features
  (jump-via> location $list location))  ;directed jump edge; $list = path features


(define-init-check jump-init-check (literals)
  (:consumes gate screen wall)
  (check-init-list-relation-items-have-types
    literals 'jump-via '(gate screen wall))
  (check-init-list-relation-items-have-types
    literals 'jump-via> '(gate screen wall)))


(define-query jump-elevation-reachable
    (?agent agent ?source-elevation ?target-elevation)
  ;; Downward and level jumps are unrestricted.  An upward landing may rise no more than
  ;; *vertical-reach-limit* above the explicit source elevation.  Keeping the source
  ;; explicit lets mobility test an intermediate location without moving the agent there.
  (do ?agent
      (<= (- ?target-elevation ?source-elevation)
          *vertical-reach-limit*)))


(define-query vaultable-object-passable (?agent agent ?feature vaultable-object)
  ;; Gates and screens may be crossed without vaulting when their ordinary passability rule
  ;; permits it.  Walls always require clearance.
  (or (and (gate ?feature)
           (obstacle-clear ?agent ?feature))
      (and (screen ?feature)
           (obstacle-clear ?agent ?feature))))


(define-query jump-barrier-top-elevation (?feature vaultable-object)
  (+ (object-elevation ?feature)
     (declared-height ?feature)))


(define-query vaultable-object-list (?features)
  (ww-loop for $feature in ?features
           always (vaultable-object $feature)))


(define-query jump-required-clearance-height (?agent agent ?features)
  ;; Passable features need no clearance.  Every remaining feature is physically vaulted, so
  ;; the required clearance is the highest of their top elevations.  NIL means all features
  ;; are currently passable or the edge has no features.
  (do (assign $required nil)
      (ww-loop for $feature in ?features
               do (if (not (vaultable-object-passable ?agent $feature))
                    (do (assign $top (jump-barrier-top-elevation $feature))
                        (assign $required
                                (if $required
                                  (max $required $top)
                                  $top)))))
      $required))


(define-query jump-path-clear (?agent agent ?source-elevation ?features)
  ;; A vaultable barrier's top may rise no more than *vertical-reach-limit* above the
  ;; explicit launch elevation -- the same fixed bound JUMP-ELEVATION-REACHABLE applies to
  ;; a raised landing.  Clearing a barrier and rising in elevation are the same physical
  ;; constraint, independent of the jumping agent's own declared height; ?agent still
  ;; matters here only through VAULTABLE-OBJECT-PASSABLE's holding-state check.
  (and (vaultable-object-list ?features)
       (assign $required
               (jump-required-clearance-height ?agent ?features))
       (or (not $required)
           (<= (- $required ?source-elevation)
               *vertical-reach-limit*))))


(define-problem-helper jump-segment-for-features
    (state agent source destination features)
  "Return a normalized JUMP or VAULT segment for a feasible grounded traversal.  The
   move-type tag is VAULT when some feature genuinely required clearance for this agent,
   else JUMP."
  (let ((canonical-features (canonical-enabling-means features))
        (source-elevation
          (funcall (symbol-function 'location-elevation) state source))
        (target-elevation
          (funcall (symbol-function 'location-elevation) state destination)))
    (when (and
            (funcall (symbol-function 'jump-path-clear)
                     state agent source-elevation canonical-features)
            (funcall (symbol-function 'jump-elevation-reachable)
                     state agent source-elevation target-elevation)
            (funcall (symbol-function 'safe) state destination))
      (list (if (funcall (symbol-function 'jump-required-clearance-height)
                         state agent canonical-features)
              'vault
              'jump)
            source canonical-features destination))))


(define-query jump-traversal-segments (?agent agent ?from location)
  (do (assign $segments nil)
      (doall (?to location)
        (do (assign $symmetric-segment nil)
            (assign $directional-segment nil)
            (if (bind (jump-via ?from $symmetric-features ?to))
              (assign $symmetric-segment
                      (jump-segment-for-features
                        state ?agent ?from ?to $symmetric-features)))
            (if (bind (jump-via> ?from $directional-features ?to))
              (assign $directional-segment
                      (jump-segment-for-features
                        state ?agent ?from ?to $directional-features)))
            (if $symmetric-segment
              (assign $segments (cons $symmetric-segment $segments)))
            (if $directional-segment
              (assign $segments (cons $directional-segment $segments)))))
      $segments))


(register-mobility-provider 'jump-traversal-segments)


(define-problem-helper jump-configuration-transition-for-features
    (state agent source-configuration source-elevation
           destination-configuration target-elevation features)
  "Return one feasible support-changing JUMP or VAULT transition across an authored edge.
   The move-type tag is VAULT when some feature genuinely required clearance for this
   agent, else JUMP."
  (let ((canonical-features (canonical-enabling-means features))
        (destination (first destination-configuration)))
    (when (and
            (funcall (symbol-function 'jump-path-clear)
                     state agent source-elevation canonical-features)
            (funcall (symbol-function 'jump-elevation-reachable)
                     state agent source-elevation target-elevation)
            (funcall (symbol-function 'safe) state destination))
      (list (if (funcall (symbol-function 'jump-required-clearance-height)
                         state agent canonical-features)
              'vault
              'jump)
            source-configuration canonical-features
            destination-configuration))))


(define-query jump-configuration-transitions
    (?agent agent ?source-configuration)
  (do (assign $source-location (first ?source-configuration))
      (assign $source-place (second ?source-configuration))
      (assign $source-elevation
              (if (eql $source-place 'ground)
                (location-elevation $source-location)
                (support-top-elevation $source-place)))
      (assign $transitions nil)

      ;; Local box mounts and transfers.  A box may itself be part of a stack; its top
      ;; elevation already follows that support chain through SUPPORT-TOP-ELEVATION.
      (doall (?box box)
        (if (and (has-location ?box $source-location)
                 (different ?box $source-place)
                 (cleartop ?box)
                 (support-use-allowed ?agent ?box)
                 (jump-elevation-reachable
                   ?agent $source-elevation (support-top-elevation ?box)))
          (assign $transitions
                  (cons
                    (list 'jump ?source-configuration nil
                          (list $source-location ?box))
                    $transitions))))

      ;; A local drop belongs to jump only from a box top.  Flush plate/fan dismounts are
      ;; supplied by the step provider.
      (if (and (not (eql $source-place 'ground))
               (box $source-place))
        (assign $transitions
                (cons
                  (list 'jump ?source-configuration nil
                        (list $source-location 'ground))
                  $transitions)))

      ;; Remote clear-box landings are configuration transitions whether the launch is
      ;; grounded or supported.
      (doall (?landing-box box)
        (if (and (bind (has-location ?landing-box $destination))
                 (different $source-location $destination)
                 (cleartop ?landing-box)
                 (support-use-allowed ?agent ?landing-box))
          (do (assign $destination-configuration
                      (list $destination ?landing-box))
              (assign $target-elevation
                      (support-top-elevation ?landing-box))
              (assign $symmetric-transition nil)
              (assign $directional-transition nil)
              (if (bind (jump-via
                          $source-location $symmetric-features $destination))
                (assign $symmetric-transition
                        (jump-configuration-transition-for-features
                          state ?agent ?source-configuration $source-elevation
                          $destination-configuration $target-elevation
                          $symmetric-features)))
              (if (bind (jump-via>
                          $source-location $directional-features $destination))
                (assign $directional-transition
                        (jump-configuration-transition-for-features
                          state ?agent ?source-configuration $source-elevation
                          $destination-configuration $target-elevation
                          $directional-features)))
              (if $symmetric-transition
                (assign $transitions
                        (cons $symmetric-transition $transitions)))
              (if $directional-transition
                (assign $transitions
                        (cons $directional-transition $transitions))))))

      ;; Only a supported source uses an authored jump edge to land on remote ground;
      ;; grounded versions of the same edges belong to the mobility provider.
      (if (not (eql $source-place 'ground))
        (doall (?destination location)
          (do (assign $destination-configuration
                      (list ?destination 'ground))
              (assign $target-elevation
                      (location-elevation ?destination))
              (assign $symmetric-transition nil)
              (assign $directional-transition nil)
              (if (bind (jump-via
                          $source-location $symmetric-features ?destination))
                (assign $symmetric-transition
                        (jump-configuration-transition-for-features
                          state ?agent ?source-configuration $source-elevation
                          $destination-configuration $target-elevation
                          $symmetric-features)))
              (if (bind (jump-via>
                          $source-location $directional-features ?destination))
                (assign $directional-transition
                        (jump-configuration-transition-for-features
                          state ?agent ?source-configuration $source-elevation
                          $destination-configuration $target-elevation
                          $directional-features)))
              (if $symmetric-transition
                (assign $transitions
                        (cons $symmetric-transition $transitions)))
              (if $directional-transition
                (assign $transitions
                        (cons $directional-transition $transitions))))))
      $transitions))


(register-configuration-transition-provider
  'jump-configuration-transitions)

;;;; ==== end technology jump ====

;;;; ==== begin technology beam-relay ====

;;; Filename: beam-relay.lisp

;;; Relay beam technology: movable connectors and fixed repeaters propagate beam color
;;; through one graph.  Connector links are dynamic PAIRED facts and require authored live
;;; visibility; fixed apparatus links are directional COUPLED facts and use BEAM-VIA
;;; corridors.  A relay lights only when every source reaching it in the same propagation
;;; layer carries one hue.  Conflicting hues leave it unlit.
;;;
;;; Connectors retain their pickup/placement/pairing actions.  Repeaters have no
;;; HAS-LOCATION and no actions; repeater.lisp assembles this peer with beam-direct and
;;; visibility so fixed corridors and apparatus sightlines are live.
;;;
;;; REQUIRES:
;;;   types      : agent, location -- connector/transmitter/receiver/repeater and related
;;;                leaf types are optional through the nested roles
;;;   nested     : -beam-substrate (beam relations and hooks); -placement;
;;;                -visibility (null defaults); -support-elevation; -elevation;
;;;                -mobility; -reachability; -pickup
;;;   parameter  : *max-pairings* -- defaults to 3; connector pairings only; fixed
;;;                couplings are unlimited; a problem may set a smaller value first
;;;   driver     : propagate-consequences! must call
;;;                  update-relay-status! -> update-receiver-status!
;;; PROVIDES:
;;;   types      : relay (either connector floor-repeater wall-repeater);
;;;                terminus (either transmitter receiver connector floor-repeater
;;;                wall-repeater)
;;;   relations  : paired, color
;;;   queries    : relay-beam-reaches-receiver,
;;;                recording-shadow-relay-beam-reaches-receiver,
;;;                compute-relay-lighting, compute-relay-lighting-for-object,
;;;                relay-anchor, beam-anchor-elevation, relay-linked,
;;;                relay-link-clear, relay-link-clear-for-object,
;;;                paired-relay-visible, paired-relay-visible-for-object,
;;;                relay-beam-live-for-cutting, beam-relay-source-distance,
;;;                connectable-location, connectable-terminus
;;;   updates    : update-relay-status!
;;;   actions    : pickup-connector, put-connector, connect-connector

;; (include-tech -propagation): already included -- skipped
;; (include-tech -beam-substrate): already included -- skipped
;; (include-tech -placement): already included -- skipped

;;;; ==== begin technology -visibility ====

;;; Filename: -visibility.lisp

;;; Visibility substrate: the shared interface for technologies that require a
;;; sightline.  The default exposes no visibility; the public visibility technology
;;; overrides it with authored line-of-sight relations and gate checks.
;;;
;;; REQUIRES:
;;;   type     : location
;;; PROVIDES:
;;;   types    : apparatus (either transmitter receiver floor-repeater wall-repeater gun);
;;;              gate, transmitter, receiver, both repeater leaf types, and gun are optional.
;;;              APPARATUS-COORDS> names each apparatus's functional point: beam
;;;              emission/reception/relay for beam apparatus, and the firing/targeting point
;;;              for a gun.
;;;   queries  : visible, visible-for-object, potentially-visible, beam-visible,
;;;              beam-visible-for-object, elevation-visible-for-object -- null defaults,
;;;              overridden by visibility.
;;;              The FOR-OBJECT forms select actor/view-specific gate state.  Their typed
;;;              object parameters remain valid when an optional type has no objects: the
;;;              query is still installed and its null body returns NIL; only iteration
;;;              over that empty type produces no calls.

(in-package :ww)


(define-optional-types
  gate transmitter receiver gun floor-repeater wall-repeater)


(define-types
  repeater (either floor-repeater wall-repeater))


(define-types
  apparatus
    (either transmitter receiver floor-repeater wall-repeater gun))


(define-query visible
    (?location location
     ?object (either gate transmitter receiver floor-repeater wall-repeater gun location))
  (do ?location ?object nil))


(define-query visible-for-object
    (?view
     ?location location
     ?object (either gate transmitter receiver floor-repeater wall-repeater gun location))
  (do ?view ?location ?object nil))


(define-query potentially-visible
    (?location location
     ?object (either gate transmitter receiver floor-repeater wall-repeater gun location))
  (do ?location ?object nil))


(define-query beam-visible
    (?location location
     ?near-elevation
     ?object (either transmitter receiver floor-repeater wall-repeater gun location)
     ?far-elevation)
  ;; Locations/apparatus are Wouldwork objects. Elevations are computed Lisp values and
  ;; therefore deliberately have no Wouldwork object type.
  (do ?location ?near-elevation ?object ?far-elevation nil))


(define-query beam-visible-for-object
    (?view
     ?location location
     ?near-elevation
     ?object (either transmitter receiver floor-repeater wall-repeater gun location)
     ?far-elevation)
  (do ?view ?location ?near-elevation ?object ?far-elevation nil))


(define-query elevation-visible-for-object
    (?view
     ?location location
     ?near-elevation
     ?object (either gate transmitter receiver floor-repeater wall-repeater gun location)
     ?far-elevation)
  (do ?view ?location ?near-elevation ?object ?far-elevation nil))

;;;; ==== end technology -visibility ====
;; (include-tech -support-elevation): already included -- skipped
;; (include-tech -elevation): already included -- skipped
;; (include-tech -mobility): already included -- skipped
;; (include-tech -reachability): already included -- skipped
;; (include-tech -pickup): already included -- skipped

;;;; ==== begin technology -beam-relay-init-checks ====

;;; Filename: -beam-relay-init-checks.lisp

;;; Initialization validation for connector pairing and relay sightlines.


(in-package :ww)


(define-init-check beam-relay-init-check (literals)
  (check-init-paired-consistency literals)
  (check-init-paired-connector-graph-acyclic literals)
  (check-init-paired-sightlines literals))


(define-init-check-helper init-connector-paired-relation-p ()
  (init-type-spec-includes-type-p
    (init-relation-argument-type 'paired 1)
    'connector))


(define-init-check-helper check-init-paired-consistency (literals)
  "Checks basic consistency of initial connector pairings."
  (when (init-connector-paired-relation-p)
    (let ((locations (init-literal-map 'has-location literals 1 2))
          (pair-counts (make-hash-table :test #'equal)))
      (dolist (literal (init-literals-with-relation 'paired literals))
        (destructuring-bind (connector terminus)
            (rest (init-literal-proposition literal))
          (unless (gethash connector locations)
            (fail-init-check nil "~%PAIRED connector has no HAS-LOCATION.~%~
                    Literal:  ~S~%~
                    Connector: ~S"
                   literal connector))
          (when (eql connector terminus)
            (fail-init-check nil "~%PAIRED connector is paired to itself.~%~
                    Literal:  ~S~%~
                    Connector: ~S"
                   literal connector))
          (when (and (init-type-member-p terminus 'connector)
                     (not (gethash terminus locations)))
            (fail-init-check nil "~%PAIRED connector target has no HAS-LOCATION.~%~
                    Literal: ~S~%~
                    Target:  ~S"
                   literal terminus))
          (incf (gethash connector pair-counts 0))))
      (maphash (lambda (connector count)
                 (when (> count *max-pairings*)
                   (fail-init-check nil "~%PAIRED connector exceeds *MAX-PAIRINGS*.~%~
                           Connector: ~S~%~
                           Pairings:  ~D~%~
                           Limit:     ~D"
                          connector count *max-pairings*)))
               pair-counts))))


(define-init-check-helper init-paired-connector-edges (literals)
  (let ((edges (make-hash-table :test #'equal)))
    (dolist (literal (init-literals-with-relation 'paired literals))
      (destructuring-bind (connector terminus)
          (rest (init-literal-proposition literal))
        (when (init-type-member-p terminus 'connector)
          (push terminus (gethash connector edges)))))
    edges))


(define-init-check-helper init-connector-pairing-path-exists-p (start target edges)
  (let ((frontier (copy-list (gethash start edges)))
        (visited nil))
    (loop while frontier
          do (let ((current (pop frontier)))
               (when (eql current target)
                 (return t))
               (unless (member current visited)
                 (push current visited)
                 (setf frontier
                       (append (copy-list (gethash current edges))
                               frontier)))))))


(define-init-check-helper check-init-paired-connector-graph-acyclic (literals)
  "Checks that initial connector-to-connector pairings do not form cycles."
  (when (init-connector-paired-relation-p)
    (let ((edges (init-paired-connector-edges literals)))
      (maphash (lambda (connector targets)
                 (dolist (target targets)
                   (when (init-connector-pairing-path-exists-p
                           target connector edges)
                     (fail-init-check nil "~%Initial connector pairings contain a cycle.~%~
                             Connector: ~S~%~
                             Target:    ~S"
                            connector target))))
               edges))))


(define-init-check-helper init-los-to-apparatus-p (location apparatus literals)
  (some (lambda (literal)
          (destructuring-bind (los-location occluders los-apparatus)
              (rest (init-literal-proposition literal))
            (declare (ignore occluders))
            (and (eql location los-location)
                 (eql apparatus los-apparatus))))
        (init-literals-with-relation 'los-to-apparatus literals)))


(define-init-check-helper init-los-to-location-p (location1 location2 literals)
  (some (lambda (literal)
          (destructuring-bind (los-location1 occluders los-location2)
              (rest (init-literal-proposition literal))
            (declare (ignore occluders))
            (or (and (eql location1 los-location1)
                     (eql location2 los-location2))
                (and (eql location1 los-location2)
                     (eql location2 los-location1)))))
        (init-literals-with-relation 'los-to-location literals)))


(define-init-check-helper init-apparatus-has-potential-sightline-p (apparatus literals)
  (some (lambda (literal)
          (destructuring-bind (los-location occluders los-apparatus)
              (rest (init-literal-proposition literal))
            (declare (ignore los-location occluders))
            (eql apparatus los-apparatus)))
        (positive-init-literals-with-relation 'los-to-apparatus literals)))


(define-init-check-helper init-location-has-potential-sightline-p (location literals)
  (some (lambda (literal)
          (destructuring-bind (los-location1 occluders los-location2)
              (rest (init-literal-proposition literal))
            (declare (ignore occluders))
            (or (eql location los-location1)
                (eql location los-location2))))
        (positive-init-literals-with-relation 'los-to-location literals)))


(define-init-check-helper init-check-paired-apparatus-sightline
    (literal connector apparatus literals)
  (unless (init-apparatus-has-potential-sightline-p apparatus literals)
    (fail-init-check nil "~%PAIRED apparatus target has no potential LOS-TO-APPARATUS from any location.~%~
            Literal:   ~S~%~
            Connector: ~S~%~
            Target:    ~S"
           literal connector apparatus)))


(define-init-check-helper init-check-paired-connector-sightline
    (literal connector connector-location terminus terminus-location literals)
  (when (eql connector-location terminus-location)
    (fail-init-check nil "~%PAIRED connector target is at the same location.~%~
            Literal:  ~S~%~
            Connector: ~S~%~
            Target:    ~S~%~
            Location:  ~S"
           literal connector terminus connector-location))
  (unless (init-location-has-potential-sightline-p terminus-location literals)
    (fail-init-check nil "~%PAIRED connector target location has no potential LOS-TO-LOCATION from any location.~%~
            Literal:            ~S~%~
            Connector:          ~S~%~
            Connector location: ~S~%~
            Target:             ~S~%~
            Target location:    ~S"
           literal connector connector-location terminus terminus-location)))


(define-init-check-helper check-init-paired-sightlines (literals)
  "Checks that each initial pairing target has potential sightline topology."
  (when (init-connector-paired-relation-p)
    (let ((locations (init-literal-map 'has-location literals 1 2)))
      (dolist (literal (init-literals-with-relation 'paired literals))
        (destructuring-bind (connector terminus)
            (rest (init-literal-proposition literal))
          (let ((connector-location (gethash connector locations)))
            (when connector-location
              (cond
                ((or (init-type-member-p terminus 'transmitter)
                     (init-type-member-p terminus 'receiver)
                     (init-type-member-p terminus 'repeater))
                 (init-check-paired-apparatus-sightline
                   literal connector terminus literals))
                ((init-type-member-p terminus 'connector)
                 (let ((terminus-location (gethash terminus locations)))
                   (when terminus-location
                     (init-check-paired-connector-sightline
                       literal connector connector-location
                       terminus terminus-location literals))))))))))))



;;;; ==== end technology -beam-relay-init-checks ====

(in-package :ww)


(setf *max-pairings* (or *max-pairings* 3))


(define-types
  relay (either connector floor-repeater wall-repeater)
  terminus
    (either transmitter receiver connector floor-repeater wall-repeater))


(define-optional-types box hue connector transmitter receiver)


(define-dynamic-relations
  (paired connector terminus)
  (color relay $hue))


(define-derived-relations
  color)


;;;; ACTIONS ;;;;


(define-action pickup-connector
  1
  (?agent agent ?connector connector)
  (and (bind (has-location ?agent $a-location))
       (bind (has-location ?connector $connector-location))
       (pickup-clear ?agent $a-location ?connector $connector-location))
  (">" ?agent "picks up" ?connector "at" $a-location)
  (assert (holding ?agent ?connector)
          (not (has-location ?connector $connector-location))
          (do (doall (?t terminus)
                (if (paired ?connector ?t)
                  (not (paired ?connector ?t))))
              (doall (?c connector)
                (if (paired ?c ?connector)
                  (not (paired ?c ?connector)))))
          (if (bind (on ?connector $support))
            (not (on ?connector $support)))
          (finally (propagate-changes!))))


(define-action put-connector
  1
  (?agent agent ?connector connector ?location location)
  (and (holding ?agent ?connector)
       (bind (has-location ?agent $a-location))
       (reachable ?location $a-location)
       (assign $places (placement-options ?agent ?location ?connector)))
  (">" ?agent "puts" ?connector "at" ?location "on" $place "without pairings")
  (ww-loop for $placement-option in $places
           do (assert (assign $place $placement-option)
                      (place-held-object!
                        ?agent ?connector ?location $placement-option)
                      (finally (propagate-changes!)))))


(define-action connect-connector
  1
  (?agent agent ?location location)
  (and (bind (holding ?agent $connector))
       (connector $connector)
       (bind (has-location ?agent $a-location))
       (reachable ?location $a-location)
       (connectable-location $connector ?location)
       (assign $places (placement-options ?agent ?location $connector))
       (assign $pairing-vantages (mobility-locations ?agent $a-location))
        (exists (?t terminus)
          (connectable-terminus
            ?agent $pairing-vantages ?location $connector ?t)))
  (">" ?agent "connects" $connector "at" ?location "on" $place "to" $termini)
  (do (assign $connectable nil)
      (doall (?terminus terminus)
        (if (connectable-terminus
              ?agent $pairing-vantages ?location $connector ?terminus)
          (assign $connectable (cons ?terminus $connectable))))
      (ww-loop for $selected-termini in
                 (rest (subsets-up-to $connectable *max-pairings*))
               do (ww-loop for $placement-option in $places
                           do (assert
                                (assign $termini $selected-termini)
                                (assign $place $placement-option)
                                (place-held-object!
                                  ?agent $connector ?location $placement-option)
                                (ww-loop for $terminus in $selected-termini
                                         do (paired $connector $terminus))
                                (finally (propagate-changes!)))))))


;;;; UPDATE FUNCTIONS ;;;;


(define-update update-relay-status! ()
  (do (assign $lighting (compute-relay-lighting (current-crossing-set)))
      (doall (?relay relay)
        (do (assign $record (assoc ?relay $lighting))
            (if $record
              (color ?relay (second $record))
              (if (bind (color ?relay $old-hue))
                (not (color ?relay $old-hue))))))))


;;;; QUERY FUNCTIONS ;;;;


(define-query relay-beam-reaches-receiver (?receiver receiver)
  (do (assign $reaches nil)
      (doall (?relay relay)
        (if (and (bind (color ?relay $relay-hue))
                 (bind (has-chroma ?receiver $required-hue))
                 (eql $relay-hue $required-hue)
                 (or (and (connector ?relay)
                          (paired ?relay ?receiver)
                          (bind (has-location ?relay $location))
                          (beam-visible
                            $location (beam-anchor-elevation ?relay)
                            ?receiver (fixture-elevation ?receiver))
                          (not (beam-cut $location ?receiver)))
                     (and (repeater ?relay)
                          (coupled ?relay ?receiver)
                          (fixed-beam-corridor-clear ?relay ?receiver)
                          (not (beam-cut ?relay ?receiver)))))
          (assign $reaches t)))
      $reaches))


(define-query recording-shadow-relay-beam-reaches-receiver
    (?view ?lighting ?receiver receiver)
  (do (assign $reaches nil)
      (doall (?relay relay)
        (if (and (relay-available-for-object ?view ?relay)
                 (assign $record (assoc ?relay ?lighting))
                 $record
                 (bind (has-chroma ?receiver $required-hue))
                 (eql (second $record) $required-hue)
                 (or (and (connector ?relay)
                          (paired ?relay ?receiver)
                          (bind (has-location ?relay $location))
                          (beam-visible-for-object
                            ?view $location (beam-anchor-elevation ?relay)
                            ?receiver (fixture-elevation ?receiver)))
                     (and (repeater ?relay)
                          (coupled ?relay ?receiver)
                          (fixed-beam-corridor-clear-for-object
                            ?view ?relay ?receiver))))
          (assign $reaches t)))
      $reaches))


(define-query compute-relay-lighting (?active)
  (compute-relay-lighting-for-object nil ?active))


(define-query compute-relay-lighting-for-object (?view ?active)
  ;; Breadth-first propagation from every transmitter.  Each lighting record is
  ;; (relay hue distance); frontier records additionally carry the relay's beam endpoint.
  (do (assign $lit nil)
      (assign $lit-locations nil)
      (assign $visited nil)
      (assign $frontier nil)
      (doall (?transmitter transmitter)
        (if (bind (has-chroma ?transmitter $hue))
          (assign $frontier
                  (cons (list ?transmitter ?transmitter $hue 0) $frontier))))
      (ww-loop for $pass from 1 to 99
               do (assign $next-frontier nil)
                  (doall (?target relay)
                    (if (and (relay-available-for-object ?view ?target)
                             (not (member ?target $visited)))
                      (do (assign $target-anchor (relay-anchor ?target))
                          (if $target-anchor
                            (do (assign $hues nil)
                                (assign $reach-hue nil)
                                (assign $reach-distance nil)
                                (ww-loop for $source-record in $frontier
                                         do (assign $source (first $source-record))
                                            (assign $source-anchor
                                                    (second $source-record))
                                            (assign $source-hue (third $source-record))
                                            (assign $source-distance
                                                    (fourth $source-record))
                                            (if (relay-link-clear-for-object
                                                  ?view $source $source-anchor
                                                  ?target $target-anchor ?active)
                                              (do (if (not (member $source-hue $hues))
                                                    (assign $hues
                                                            (cons $source-hue $hues)))
                                                  (assign $reach-hue $source-hue)
                                                  (assign $reach-distance
                                                          (1+ $source-distance)))))
                                (if $hues
                                  (do (assign $visited (cons ?target $visited))
                                      (if (and (not (cdr $hues))
                                               (or (repeater ?target)
                                                   (not (member
                                                          $target-anchor
                                                          $lit-locations))))
                                        (do (assign $lit
                                                    (cons
                                                      (list ?target
                                                            $reach-hue
                                                            $reach-distance)
                                                      $lit))
                                            (if (connector ?target)
                                              (assign $lit-locations
                                                      (cons
                                                        $target-anchor
                                                        $lit-locations)))
                                            (assign $next-frontier
                                                    (cons
                                                      (list ?target
                                                            $target-anchor
                                                            $reach-hue
                                                            $reach-distance)
                                                      $next-frontier)))))))))))
                  (assign $frontier $next-frontier)
                  (if (not $frontier)
                    (return t)))
      $lit))


(define-query relay-available-for-object (?view ?relay relay)
  (or (not (recording-shadow-object ?view))
      (recording-shadow-object-present ?relay)))


(define-query relay-anchor (?relay relay)
  ;; Movable connectors beam from their current location; fixed repeaters are apparatus
  ;; endpoints in their own right.
  (if (connector ?relay)
    (do (bind (has-location ?relay $location))
        $location)
    ?relay))


(define-query beam-anchor-elevation
    (?anchor (either transmitter receiver connector floor-repeater wall-repeater))
  (cond ((or (transmitter ?anchor)
             (receiver ?anchor))
         (fixture-elevation ?anchor))
        ((connector ?anchor)
         (+ (occupant-elevation ?anchor)
            (declared-height ?anchor)))
        (t
         (repeater-anchor-elevation ?anchor))))


(define-query relay-linked
    (?source (either transmitter connector floor-repeater wall-repeater) ?target relay)
  ;; PAIRED is structurally undirected but is always stored with a connector first.
  ;; COUPLED is directional and can target only a repeater or receiver.
  (if (connector ?target)
    (or (paired ?target ?source)
        (and (connector ?source)
             (paired ?source ?target)))
    (or (coupled ?source ?target)
        (and (connector ?source)
             (paired ?source ?target)))))


(define-query relay-link-clear
    (?source (either transmitter connector floor-repeater wall-repeater)
     ?source-anchor beam-node
     ?target relay
     ?target-anchor beam-node
     ?active)
  (relay-link-clear-for-object
    nil ?source ?source-anchor ?target ?target-anchor ?active))


(define-query relay-link-clear-for-object
    (?view
     ?source (either transmitter connector floor-repeater wall-repeater)
     ?source-anchor beam-node
     ?target relay
     ?target-anchor beam-node
     ?active)
  (and (relay-linked ?source ?target)
       (if (coupled ?source ?target)
         (fixed-beam-corridor-clear-for-object ?view ?source ?target)
         (paired-relay-visible-for-object
           ?view ?source ?source-anchor ?target ?target-anchor))
       (not (beam-cut-in ?source-anchor ?target-anchor ?active))))


(define-query paired-relay-visible
    (?source (either transmitter connector floor-repeater wall-repeater)
     ?source-anchor beam-node
     ?target relay
     ?target-anchor beam-node)
  (paired-relay-visible-for-object
    nil ?source ?source-anchor ?target ?target-anchor))


(define-query paired-relay-visible-for-object
    (?view
     ?source (either transmitter connector floor-repeater wall-repeater)
     ?source-anchor beam-node
     ?target relay
     ?target-anchor beam-node)
  ;; A paired link always has at least one connector.  BEAM-VISIBLE is location-first, so
  ;; orient the test from whichever endpoint is the connector.
  (if (connector ?target)
    (beam-visible-for-object
      ?view ?target-anchor (beam-anchor-elevation ?target)
      ?source-anchor (beam-anchor-elevation ?source))
    (do (connector ?source)
        (beam-visible-for-object
          ?view ?source-anchor (beam-anchor-elevation ?source)
          ?target-anchor (beam-anchor-elevation ?target)))))


(define-query relay-beam-live-for-cutting
    (?from beam-node ?to beam-node ?lighting)
  ;; Arrival/visibility gates whether a relay becomes lit.  Once lit, its outbound segment
  ;; is live for crossing analysis; fixed coupled segments additionally require their
  ;; authored corridor to be clear.
  (or (and (transmitter ?from)
           (location ?to)
           (exists (?connector connector)
             (and (has-location ?connector ?to)
                  (paired ?connector ?from))))
      (and (repeater ?from)
           (assoc ?from ?lighting)
           (or (and (or (repeater ?to) (receiver ?to))
                    (fixed-beam-corridor-clear ?from ?to))
               (and (location ?to)
                    (exists (?connector connector)
                      (and (has-location ?connector ?to)
                           (paired ?connector ?from))))))
      (and (location ?from)
           (exists (?connector connector)
             (and (has-location ?connector ?from)
                  (assoc ?connector ?lighting)
                  (or (and (receiver ?to)
                           (paired ?connector ?to))
                      (and (repeater ?to)
                           (paired ?connector ?to))
                      (and (location ?to)
                           (exists (?other connector)
                             (and (different ?other ?connector)
                                  (has-location ?other ?to)
                                  (or (paired ?other ?connector)
                                      (paired ?connector ?other)))))))))))


(define-query beam-relay-source-distance (?from beam-node ?lighting)
  (if (repeater ?from)
    (do (assign $record (assoc ?from ?lighting))
        (if $record (third $record) most-positive-fixnum))
    (if (location ?from)
      (do (assign $distance most-positive-fixnum)
          (doall (?connector connector)
            (if (has-location ?connector ?from)
              (do (assign $record (assoc ?connector ?lighting))
                  (if $record
                    (assign $distance (third $record))))))
          $distance)
      most-positive-fixnum)))


(define-query connectable-location (?connector connector ?location location)
  (not (exists (?other connector)
         (and (different ?other ?connector)
              (has-location ?other ?location)
              (bind (color ?other $hue))))))


(define-query connectable-terminus
    (?agent agent
     ?pairing-vantages
     ?placement-location location
     ?connector connector
     ?terminus terminus)
  ;; Pairing selection uses structural LOS from any currently traversable vantage.  Exact
  ;; placement and live visibility subsequently determine whether the beam carries color.
  (and (connector-pairing-allowed ?agent ?connector ?terminus)
       (ww-loop for $vantage in ?pairing-vantages
                thereis
                  (or (and (or (transmitter ?terminus)
                               (receiver ?terminus)
                               (repeater ?terminus))
                           (potentially-visible $vantage ?terminus))
                      (and (connector ?terminus)
                           (different ?terminus ?connector)
                           (bind (has-location ?terminus $terminus-location))
                           (different ?placement-location $terminus-location)
                           (potentially-visible $vantage $terminus-location))))))

;;;; ==== end technology beam-relay ====

;;;; ==== begin technology walkability ====

;;; Filename: walkability.lisp

;;; Walking mobility provider.  Enabled WALK-VIA/WALK-VIA> edges become normalized WALK
;;; traversal segments.  The central mobility closure composes them and MOVE applies one
;;; canonical route per grounded destination.
;;;
;;; REQUIRES:
;;;   types     : agent, location
;;;   nested    : -support-occupancy; -location; -passability; -elevation;
;;;               -walkability; -walkability-coordinates; -threat; -mobility-action
;;; PROVIDES:
;;;   relations : (walk-via location $list location), (walk-via> location $list location)
;;;   queries   : walking-traversal-segments, one-step-walkable
;;;   provider  : walking-traversal-segments registered with -mobility
;;;   action    : move (from -mobility-action)

;; (include-tech -support-occupancy): already included -- skipped
;; (include-tech -location): already included -- skipped
;; (include-tech -passability): already included -- skipped
;; (include-tech -elevation): already included -- skipped

;;;; ==== begin technology -walkability ====

;;; Filename: -walkability.lisp

;;; Walkability substrate: shared topology and canonical obstacle-family algebra for the
;;; walking mobility provider.  WALK-VIA/WALK-VIA> hold authored or coordinate-derived
;;; topology; public WALKABILITY converts enabled edges into normalized traversal segments.
;;;
;;; REQUIRES:
;;;   types    : agent, location
;;; PROVIDES:
;;;   relations: (walk-via location $list location), (walk-via> location $list location)
;;;              -- $list is a DNF clause list: () direct, else OR over clauses, AND within
;;;   functions: canonical minimal-family algebra used by the coordinate zone-graph
;;;              derivation in -walkability-coordinates

(in-package :ww)


(define-static-relations
  (walk-via location $list location)  ;symmetric walking edge; $list = DNF door clauses: () direct, else OR over clauses, AND within, e.g. ((gate1) (gate2 gate3))
  (walk-via> location $list location))  ;directional walking edge, same $list convention; emitted by -walkability-coordinates for rides into a stream's destination (inbound widened by side-curtain rides, outbound ordinary)


(define-init-check walkability-init-check (literals)
  (:consumes gate screen ladder gears)
  (dolist (relation '(walk-via walk-via>))
    (dolist (literal (init-literals-with-relation relation literals))
      (init-check-dnf-list-items-have-types
        literal
        (third (init-literal-proposition literal))
        '(gate screen ladder gears)))))


;;;; MINIMAL WALK-OBSTACLE FAMILIES ;;;;
;;;; Shared by coordinate topology derivation and optional runtime routes.  A
;;;; family is an antichain of obstacle sets: OR over clauses, AND within each clause.


(defparameter *walkability-canonical-families*
  (make-hash-table :test #'equal)
  "Canonical forms of static walking families encountered in the staged problem.")


(defun walkability-family-union (family1 family2)
  ;; Alternative routes: all clauses of both, minimized and canonicalized.
  (walkability-minimize-family (append family1 family2)))


(defun walkability-family-add-obstacle (family obstacle)
  ;; Path extension by one obstacle, retained for the coordinate zone graph.
  (walkability-minimize-family
    (mapcar (lambda (clause) (cons obstacle clause)) family)))


(defun walkability-minimize-family (family)
  ;; Canonical clauses, duplicates removed, and every nonminimal superset discarded.
  (let* ((clauses (remove-duplicates
                    (mapcar #'walkability-canonical-clause family)
                    :test #'equal))
         (minimal (remove-if (lambda (clause)
                               (some (lambda (other)
                                       (and (not (equal other clause))
                                            (subsetp other clause)))
                                     clauses))
                             clauses)))
    (sort (copy-list minimal) #'walkability-clause-precedes-p)))


(define-problem-helper walkability-canonical-family (family)
  "Return FAMILY's canonical form, computing it once per staged static value."
  (multiple-value-bind (canonical present)
      (gethash family *walkability-canonical-families*)
    (if present
      canonical
      (setf (gethash family *walkability-canonical-families*)
            (walkability-minimize-family family)))))


(defun walkability-canonical-clause (clause)
  (sort (copy-list (remove-duplicates clause)) #'string< :key #'symbol-name))


(defun walkability-clause-precedes-p (clause1 clause2)
  (cond ((/= (length clause1) (length clause2))
         (< (length clause1) (length clause2)))
        (t (loop for obstacle1 in clause1
                 for obstacle2 in clause2
                 unless (eq obstacle1 obstacle2)
                   return (string< (symbol-name obstacle1)
                                   (symbol-name obstacle2))
                 finally (return nil)))))


(defun walkability-normalize-family (family)
  ;; WALK-VIA represents the family containing one empty clause as NIL.
  (if (equal family '(nil))
    nil
    family))

;;;; ==== end technology -walkability ====

;;;; ==== begin technology -walkability-coordinates ====

;;; Filename: -walkability-coordinates.lisp

;;; Walkability coordinates substrate: derives WALK-VIA (and, for rides into an
;;; air stream's destination, WALK-VIA>) from raw segment geometry, for a problem that
;;; would rather author 2D positions than hand-list which locations can walk to which.
;;; Nested under public walkability and under -stream-passability; entirely inert unless
;;; the problem actually asserts WALL-SEGMENT>, EDGE-SEGMENT>, or BOUNDARY-WALL -- a
;;; problem that hand-authors WALK-VIA directly is unaffected.  Edge segments block
;;; walking exactly like wall segments -- both feed the same solids list below.  LOS gives
;;; edges finite height, but walking remains elevation-blind and jumping excludes edges.
;;;
;;; Walking connectivity is a region-adjacency question.  Every wall/gate/window/screen
;;; segment and boundary edge is axis-aligned (a diagonal one is an authoring mistake,
;;; caught during initialization validation; the derivation also checks its own
;;; invariant).  The segments' own coordinates induce a coordinate-compressed
;;; arrangement: a grid of cells whose edge-intervals are each classified from the
;;; segments covering them -- solid (wall/window/boundary), a single named door
;;; (gate/screen/stream curtain), or open.  Two doors covering one interval, or a
;;; gate/screen overlapping a solid, are authoring contradictions and error.  Cells
;;; united across open intervals form zones; door intervals between distinct zones form
;;; a labeled zone graph.  For every zone pair, a fixpoint over antichains of door-sets
;;; computes ALL subset-minimal door-sets -- each a set of doors sufficient for some
;;; physical route -- and a location pair's WALK-VIA value is that family in DNF: ()
;;; still means direct/unguarded, and a nonempty value is a list of clauses, OR over
;;; clauses, AND within (matching the CONTROLS convention).  Families are emitted in
;;; canonical order (doors within a clause by name; clauses by length then
;;; lexicographically) so derived facts are deterministic and diffable.
;;;
;;; A wall-mounted fan's air stream is DERIVED geometry, not authored: its center line
;;; runs from the gears' HAS-POSITION location (the swept location) to the AIMED-AT
;;; destination (error unless axis-aligned), extended backward behind the fan to the
;;; nearest solid (the backstop -- the wall the gears hang on), and widened to the
;;; stream's width -- 3 units by default, overridable per gears with a STREAM-WIDTH
;;; fact (see -stream-passability.lisp, which owns that relation and redefines
;;; WALKABILITY-COORDINATES-STREAM-SPECS to gather the facts; the default here
;;; returns none, so walkability alone never references blower relations).  The
;;; resulting band is a conditional barrier region: its perimeter -- the front edge at
;;; the destination and the two sides, never the backstop edge -- enters the
;;; arrangement as curtain intervals labeled with the GEARS name (passable only while
;;; no blowing fan is mounted -- see -stream-passability's OBSTACLE-CLEAR extension),
;;; clipped silently wherever a solid already covers them.  Crossing the band anywhere
;;; costs its gears once: two curtains on one route dedupe in the door-set algebra.
;;;
;;; A location on a stream curtain -- the AIMED-AT destination's normal situation,
;;; mid-interval on the front curtain -- belongs to the zone OUTSIDE the band only, and
;;; the swept location in the band's interior belongs to the band's own zone only, so
;;; every walking edge to or from either spot's band side carries the gears in each
;;; clause automatically: the flowing stream is a wall, and its interior is standable
;;; exactly while it is off.  Riding the stream is instead a property of the
;;; destination: from every zone flanking the band across a SIDE curtain, the
;;; destination's inbound direction additionally unions that zone's own family --
;;; while blowing, stepping laterally into the flow carries the walker to the
;;; destination; while off, the same trip is an ordinary walk across the dead band; so
;;; the unconditional edge is correct in both regimes, and such pairs are emitted as
;;; directional WALK-VIA> facts (rides widen inbound, never outbound).  The front
;;; curtain grants no ride -- walking in against the flow is barred like any other
;;; gears-gated crossing.  Any other location inside a
;;; band, on a covered solid interval, inside a gate/screen doorway, at a corner whose
;;; surrounding cells span several zones, or outside a declared boundary, errors.
;;; Location coordinates never induce grid lines -- they are points looked up in the
;;; arrangement afterward, so fractional authoring offsets need no grid alignment.
;;;
;;; The derivation is single-layer: segments are elevation-blind, blocking every walking
;;; pair that crosses them regardless of level.  Multi-level maps therefore author an
;;; elevated platform's ground-level footprint as wall or edge segments (edge is the
;;; better fit -- it is precisely the vertical surface between two different-elevation
;;; regions), keep the platform's own locations inside that footprint, and connect the
;;; levels only with authored stairs-via, jump-via, or climb-via> edges (which this
;;; derivation never touches); ONE-STEP-WALKABLE's
;;; elevation-equality check rejects any derived edge between different levels.  See
;;; problem-claustro-topo's slab (edge1/edge2) for the pattern.
;;;
;;; Reuses LOCATION-COORDS> (nested from -location-coordinates, shared with
;;; visibility's -beam-los-coordinates substrate) for location coordinates.  Reuses the
;;; individually authored segment relations from nested -segment-geometry, shared with
;;; -beam-los-coordinates without requiring any beam tech.  SCREEN-SEGMENT> has no beam
;;; consumer, and streams none at
;;; all -- they affect walking only, never a sightline.
;;;
;;; Self-contained; spliced by (include-tech -walkability-coordinates), nested from
;;; walkability and from -stream-passability.
;;;
;;; REQUIRES:
;;;   types     : location  --  declared by the problem, as walkability itself already
;;;               requires; screen declared optional by nested -passability, spliced by
;;;               walkability.lisp before this file
;;;   nested    : -walkability (WALK-VIA/WALK-VIA> topology relations);
;;;               -location-coordinates (LOCATION-COORDS>)
;;; PROVIDES:
;;;   relations : wall-segment>, edge-segment>, gate-segment>, window-segment>,
;;;               screen-segment>, boundary-wall  --  default to no facts; a problem
;;;               that asserts wall-segment>, edge-segment>, or boundary-wall gets
;;;               WALK-VIA/WALK-VIA> derived automatically instead of hand-authoring them
;;;   queries   : walkability-coordinates-stream-specs  --  default no streams;
;;;               redefined by -stream-passability where wall blowers exist
;;;   init      : derive-walk-via-from-segments

;; (include-tech -walkability): already included -- skipped

;;;; ==== begin technology -location-coordinates ====

;;; Filename: -location-coordinates.lisp

;;; Location-coordinates substrate: the fixed 2D placement of a location, as its own
;;; capability independent of walking, beams, or anything else.  Owns LOCATION-COORDS>
;;; so that walkability-tech's own coordinate-driven WALK-VIA derivation and beam-
;;; crossing-tech's -beam-coordinates substrate share one source of truth for where each
;;; location is, without either technology depending on the other.  A problem that only
;;; needs walking between locations, with no transmitters/receivers/connectors, never
;;; needs to know beam-crossing exists; a problem using both capabilities enters each
;;; location's coordinates exactly once.
;;;
;;; Self-contained; spliced by (include-tech -location-coordinates).
;;;
;;; REQUIRES:
;;;   types     : location  --  declared by the problem
;;; PROVIDES:
;;;   relation  : (location-coords> location $rational $rational)

(in-package :ww)


(define-static-relations
  (location-coords> location $rational $rational))

;;;; ==== end technology -location-coordinates ====

;;;; ==== begin technology -segment-geometry ====

;;; Filename: -segment-geometry.lisp

;;; Shared coordinate segment geometry: typed, individually authored wall/edge/gate/window/
;;; screen segments, the ordered boundary polygon, list-gathering queries for the geometry
;;; algorithms, and initialization validation.  A wall is a vertical linear partition; an
;;; edge is a vertical surface separating two regions of different elevation (eg, the
;;; ground-level footprint of a raised slab).  Both block walking identically and both have
;;; finite height for LOS.  Only wall participates in vaulting: an edge is not a physical
;;; feature whose top an agent can vault onto, so jump.lisp deliberately excludes it.


(in-package :ww)


(define-optional-types wall edge gate window screen)


(define-static-relations
  (wall-segment> wall $rational $rational $rational $rational)
  (edge-segment> edge $rational $rational $rational $rational)
  (gate-segment> gate $rational $rational $rational $rational)
  (window-segment> window $rational $rational $rational $rational)
  (screen-segment> screen $rational $rational $rational $rational)
  (boundary-wall $list))  ;closed polygon ((x1 y1) ... (x1 y1)); final point must repeat first


;;;; SEGMENT GATHERING ;;;;


(define-query wall-segment-records ()
  (do (assign $records nil)
      (doall (?wall wall)
        (if (bind (wall-segment> ?wall $x1 $y1 $x2 $y2))
          (push (list ?wall $x1 $y1 $x2 $y2) $records)))
      $records))


(define-query edge-segment-records ()
  (do (assign $records nil)
      (doall (?edge edge)
        (if (bind (edge-segment> ?edge $x1 $y1 $x2 $y2))
          (push (list ?edge $x1 $y1 $x2 $y2) $records)))
      $records))


(define-query gate-segment-records ()
  (do (assign $records nil)
      (doall (?gate gate)
        (if (bind (gate-segment> ?gate $x1 $y1 $x2 $y2))
          (push (list ?gate $x1 $y1 $x2 $y2) $records)))
      $records))


(define-query window-segment-records ()
  (do (assign $records nil)
      (doall (?window window)
        (if (bind (window-segment> ?window $x1 $y1 $x2 $y2))
          (push (list ?window $x1 $y1 $x2 $y2) $records)))
      $records))


(define-query screen-segment-records ()
  (do (assign $records nil)
      (doall (?screen screen)
        (if (bind (screen-segment> ?screen $x1 $y1 $x2 $y2))
          (push (list ?screen $x1 $y1 $x2 $y2) $records)))
      $records))


;;;; INITIALIZATION VALIDATION ;;;;


(define-init-check segment-geometry-init-check (literals)
  (check-init-boundary-walls literals)
  (check-init-segment-geometry literals)
  (check-init-segment-names-unique literals)
  (check-init-segment-types-covered literals))


(define-init-check-helper check-init-boundary-walls (literals)
  "Checks BOUNDARY-WALL point lists independently of any geometry consumer.
   A boundary has at least four explicitly authored edges and closes by repeating
   its first point as its final point.  Every edge is horizontal or vertical, matching
   the shared coordinate-geometry contract used by the segment relations."
  (dolist (literal (positive-init-literals-with-relation 'boundary-wall literals))
    (init-check-boundary-wall
      literal
      (second (init-literal-proposition literal)))))


(define-init-check-helper init-check-boundary-wall (literal points)
  (unless (and (listp points)
               (>= (length points) 5))
    (fail-init-check nil "~%BOUNDARY-WALL must contain at least four edges and an explicit closing point.~%~
            Literal: ~S~%~
            Points:  ~S"
           literal points))
  (dolist (point points)
    (unless (and (listp point)
                 (= (length point) 2)
                 (every #'rationalp point))
      (fail-init-check nil "~%Malformed point in BOUNDARY-WALL.~%~
              Literal: ~S~%~
              Point:   ~S~%~
              Expected shape: (x y), with rational coordinates."
             literal point)))
  (unless (equal (first points) (car (last points)))
    (fail-init-check nil "~%BOUNDARY-WALL must repeat its first point as its final point.~%~
            Literal:     ~S~%~
            First point: ~S~%~
            Final point: ~S"
           literal (first points) (car (last points))))
  (loop for (point1 point2) on points
        while point2
        when (equal point1 point2)
          do (fail-init-check nil "~%BOUNDARY-WALL contains a zero-length edge.~%~
                     Literal: ~S~%~
                     Point:   ~S"
                    literal point1)
        unless (or (= (first point1) (first point2))
                   (= (second point1) (second point2)))
          do (fail-init-check nil "~%BOUNDARY-WALL contains an edge that is not axis-aligned.~%~
                     Literal: ~S~%~
                     Edge:    ~S -> ~S~%~
                     Edges must be horizontal or vertical."
                    literal point1 point2)))


(define-init-check-helper init-segment-relation-types ()
  "The individually authored segment relations and their keyed object types."
  '((wall-segment> . wall)
    (edge-segment> . edge)
    (gate-segment> . gate)
    (window-segment> . window)
    (screen-segment> . screen)))


(define-init-check-helper init-segment-records (relation literals)
  (loop for literal in (positive-init-literals-with-relation relation literals)
        collect (rest (init-literal-proposition literal))))


(define-init-check-helper check-init-segment-geometry (literals)
  (dolist (entry (init-segment-relation-types))
    (dolist (record (init-segment-records (car entry) literals))
      (init-check-segment-record (car entry) record))))


(define-init-check-helper init-check-segment-record (kind record)
  (let ((x1 (second record))
        (y1 (third record))
        (x2 (fourth record))
        (y2 (fifth record)))
    (when (and (= x1 x2) (= y1 y2))
      (fail-init-check nil "~%Zero-length ~S record in DEFINE-INIT.~%~
              Record: ~S"
             kind record))
    (unless (or (= x1 x2) (= y1 y2))
      (fail-init-check nil "~%~S record in DEFINE-INIT is not axis-aligned.~%~
              Record: ~S~%~
              Segments must be horizontal (y1 = y2) or vertical (x1 = x2)."
             kind record))))


(define-init-check-helper check-init-segment-names-unique (literals)
  (let ((seen (make-hash-table :test #'eql)))
    (dolist (entry (init-segment-relation-types))
      (dolist (record (init-segment-records (car entry) literals))
        (ut::if-it (gethash (first record) seen)
          (fail-init-check nil "~%Duplicate segment name in DEFINE-INIT.~%~
                  Name:        ~S~%~
                  First kind:  ~S~%~
                  Second kind: ~S"
                 (first record) ut::it (car entry))
          (setf (gethash (first record) seen) (car entry)))))))


(define-init-check-helper check-init-segment-types-covered (literals)
  (when (or (positive-init-literals-with-relation 'wall-segment> literals)
            (positive-init-literals-with-relation 'edge-segment> literals))
    (dolist (entry (init-segment-relation-types))
      (init-check-segment-type-coverage (car entry) (cdr entry) literals))))


(define-init-check-helper init-check-segment-type-coverage (kind type literals)
  (let ((names (mapcar #'first (init-segment-records kind literals))))
    (dolist (instance (init-type-instances type))
      (unless (member instance names)
        (fail-init-check nil "~%Declared ~S instance has no ~S record in DEFINE-INIT.~%~
                Instance:       ~S~%~
                Record names:   ~S~%~
                Every ~S instance in a coordinate-driven problem must contribute a segment."
               type kind instance names type)))))

;;;; ==== end technology -segment-geometry ====

(in-package :ww)


;;;; DERIVATION CORE ;;;;
;;;; Plain Lisp functions operating on segments/positions passed as arguments -- no live
;;;; database access, so no WW query wrapper is needed for these.  High-level first.


(defun walkability-coordinates-build-arrangement (positions walls gates windows screens stream-specs boundary-points)
  ;; Computes the full walking arrangement once: solids, derived stream bands with their
  ;; curtain segments, coordinate-compressed cells, per-interval coverage
  ;; classification, flood-filled zones, the door-labeled zone graph, every location's
  ;; zone membership (with its ride zones, if it is a stream's destination), and the
  ;; minimal door-set family between every membership zone and every zone.  Returned as
  ;; a plist consumed pairwise by WALKABILITY-COORDINATES-PAIR-SPEC.
  (let* ((solids (append (mapcar (lambda (segment) (list :wall segment)) walls)
                         (mapcar (lambda (segment) (list :window segment)) windows)
                         (mapcar (lambda (segment) (list :boundary segment))
                                 (walkability-coordinates-boundary-segments boundary-points))))
         (bands (mapcar (lambda (spec) (walkability-coordinates-stream-band spec solids))
                        stream-specs))
         (tagged (append solids
                         (mapcar (lambda (segment) (list :gate segment)) gates)
                         (mapcar (lambda (segment) (list :screen segment)) screens)
                         (loop for band in bands append (eighth band))))
         (xs (walkability-coordinates-axis-coordinates tagged :x))
         (ys (walkability-coordinates-axis-coordinates tagged :y))
         (coverage (walkability-coordinates-coverage-table tagged xs ys))
         (classified (walkability-coordinates-classify-coverage coverage))
         (zones (walkability-coordinates-flood-fill (length xs) (length ys) classified))
         (edges (walkability-coordinates-door-edges classified zones))
         (memberships (walkability-coordinates-memberships
                        positions xs ys classified zones boundary-points bands))
         (sources (remove-duplicates
                    (loop for (nil zone-list nil) in memberships append zone-list)))
         (families (walkability-coordinates-family-table edges sources)))
    (list :memberships memberships :families families)))


(defun walkability-coordinates-pair-spec (arrangement loc-a loc-b)
  ;; Resolves one location pair against the arrangement.  Returns NIL if no zone pair
  ;; across the two memberships is connected (blocked -- no fact), (:sym family) for an
  ;; ordinary symmetric WALK-VIA, or (:dir family-a->b family-b->a) when either endpoint
  ;; is a stream destination whose ride edges widen its inbound direction: the inbound
  ;; family additionally unions the source's families to the destination's ride zones
  ;; (riding the stream in from a side, or walking the same route while it is off), so
  ;; a ride can strictly widen inbound but never outbound.  A family of one empty
  ;; clause is normalized to NIL, the direct/unguarded value.
  (let* ((memberships (getf arrangement :memberships))
         (families (getf arrangement :families))
         (entry-a (assoc loc-a memberships))
         (entry-b (assoc loc-b memberships))
         (connected nil)
         (base nil))
    (dolist (za (second entry-a))
      (dolist (zb (second entry-b))
        (let ((fam (gethash (list za zb) families)))
          (when fam
            (setf connected t)
            (setf base (walkability-family-union base fam))))))
    (when connected
      (let ((into-b (walkability-coordinates-ride-augmented-family
                      base (second entry-a) (third entry-b) families))
            (into-a (walkability-coordinates-ride-augmented-family
                      base (second entry-b) (third entry-a) families)))
        (if (equal into-a into-b)
          (list :sym (walkability-normalize-family into-a))
          (list :dir
                (walkability-normalize-family into-b)
                (walkability-normalize-family into-a)))))))


(defun walkability-coordinates-ride-augmented-family (base source-zones ride-zones families)
  ;; The inbound family into a location: BASE plus, when the location is some stream's
  ;; destination, the families from every source zone to each of its ride zones --
  ;; reaching a zone flanking the band's side curtains suffices, because stepping
  ;; laterally into the blowing stream carries the walker to the destination, and
  ;; walking across the stopped band covers the same trip while it is off.
  (let ((family base))
    (dolist (source-zone source-zones)
      (dolist (ride-zone ride-zones)
        (let ((fam (gethash (list source-zone ride-zone) families)))
          (when fam
            (setf family (walkability-family-union family fam))))))
    family))


;;;; STREAM BANDS ;;;;
;;;; A band is (gears swept-location destination x-lo x-hi y-lo y-hi curtains): the
;;;; stream's barred rectangle and its perimeter curtain segments, each curtain a
;;;; (:stream (gears x1 y1 x2 y2)) tagged segment.  The front curtain (at the
;;;; destination) is always first in the curtain list; the two sides follow.


(defun walkability-coordinates-stream-band (spec solids)
  ;; SPEC is (gears swept-location destination sx sy dx dy width): the gears' own
  ;; position, the AIMED-AT destination and its position, and the stream's width.  The
  ;; center line must be axis-aligned; it extends backward from the swept location, away
  ;; from the destination, to the nearest solid (the backstop).  The band spans the
  ;; center line laterally by half the width each way; its curtains are the front edge
  ;; at the destination and the two sides -- the backstop edge is the solid itself, and
  ;; any gap beside the backstop is a real walkable slit, left open.
  (destructuring-bind (gears swept-location destination sx sy dx dy width) spec
    (when (and (= sx dx) (= sy dy))
      (error "The stream of ~A has coincident swept location and destination (~A ~A)."
             gears sx sy))
    (unless (or (= sy dy) (= sx dx))
      (error "The stream of ~A from (~A ~A) to (~A ~A) is not axis-aligned."
             gears sx sy dx dy))
    (if (= sy dy)
      (let* ((backstop (walkability-coordinates-stream-backstop
                         gears sx sy :vertical (> dx sx) solids))
             (x-lo (min backstop dx))
             (x-hi (max backstop dx))
             (y-lo (- sy (/ width 2)))
             (y-hi (+ sy (/ width 2))))
        (list gears swept-location destination x-lo x-hi y-lo y-hi
              (list (list :stream (list gears dx y-lo dx y-hi))
                    (list :stream (list gears x-lo y-lo x-hi y-lo))
                    (list :stream (list gears x-lo y-hi x-hi y-hi)))))
      (let* ((backstop (walkability-coordinates-stream-backstop
                         gears sx sy :horizontal (> dy sy) solids))
             (y-lo (min backstop dy))
             (y-hi (max backstop dy))
             (x-lo (- sx (/ width 2)))
             (x-hi (+ sx (/ width 2))))
        (list gears swept-location destination x-lo x-hi y-lo y-hi
              (list (list :stream (list gears x-lo dy x-hi dy))
                    (list :stream (list gears x-lo y-lo x-lo y-hi))
                    (list :stream (list gears x-hi y-lo x-hi y-hi))))))))


(defun walkability-coordinates-stream-backstop (gears sx sy transversal-orientation destination-above-p solids)
  ;; The coordinate of the nearest solid crossing the stream's center line behind the
  ;; fan: among solids of TRANSVERSAL-ORIENTATION whose own extent contains the center
  ;; line's fixed coordinate, the closest one on the opposite side of the swept
  ;; position from the destination.
  (let ((along (if (eql transversal-orientation :vertical) sx sy))
        (fixed (if (eql transversal-orientation :vertical) sy sx))
        (best nil))
    (dolist (tagged-solid solids)
      (let ((segment (second tagged-solid)))
        (when (eql (walkability-coordinates-orientation segment) transversal-orientation)
          (let ((coordinate (if (eql transversal-orientation :vertical)
                              (second segment)
                              (third segment)))
                (range (walkability-coordinates-along-range segment transversal-orientation)))
            (when (and (<= (car range) fixed (cdr range))
                       (if destination-above-p (< coordinate along) (> coordinate along))
                       (or (null best)
                           (if destination-above-p (> coordinate best) (< coordinate best))))
              (setf best coordinate))))))
    (unless best
      (error "The stream of ~A has no solid backstop behind its fan at (~A ~A)."
             gears sx sy))
    best))


(defun walkability-coordinates-along-range (segment orientation)
  ;; SEGMENT's own extent along its line's direction, as a sorted (low . high) pair: Y
  ;; for a :vertical segment, X for a :horizontal one.
  (let ((a (if (eql orientation :vertical) (third segment) (second segment)))
        (b (if (eql orientation :vertical) (fifth segment) (fourth segment))))
    (cons (min a b) (max a b))))


;;;; LOCATION MEMBERSHIP ;;;;


(defun walkability-coordinates-memberships (positions xs ys classified zones boundary-points bands)
  ;; One (location zone-list ride-zones) entry per location: the zones the location
  ;; belongs to, and -- when it is some stream's AIMED-AT destination -- the zones from
  ;; which that stream can be ridden to it (the zones across its band's side curtains).
  ;; With a declared boundary, the unbounded corner cell's zone is the outside; a
  ;; location landing there is an authoring mistake caught here.
  (let ((outside (when boundary-points (aref zones 0 0))))
    (loop for (location x y) in positions
          collect (let ((zone-list (walkability-coordinates-resolve-location
                                     location x y xs ys classified zones bands))
                        (ride-zones (loop for band in bands
                                          when (eql location (third band))
                                            append (walkability-coordinates-band-side-zones
                                                     band xs ys classified zones))))
                    (when (and outside (member outside zone-list))
                      (error "Location ~A (~A ~A) lies outside the boundary wall."
                             location x y))
                    (list location zone-list (remove-duplicates ride-zones))))))


(defun walkability-coordinates-resolve-location (location x y xs ys classified zones bands)
  ;; A location's zone membership list: its cell's zone when strictly inside a cell (an
  ;; error for any location inside a band other than the band's own swept location);
  ;; either flanking cell's zone (they are one zone through that very interval) when on
  ;; an uncovered grid-line interval; the zone outside the band when on a stream-curtain
  ;; interval; the surrounding cells' shared zone when at a grid vertex.  Inside a
  ;; solid, inside a gate/screen doorway, or at a corner whose surrounding cells
  ;; disagree, errors -- an authoring mistake, not a case to guess at.
  (let ((xi (position x xs :test #'=))
        (yi (position y ys :test #'=))
        (col (walkability-coordinates-interval-index x xs))
        (row (walkability-coordinates-interval-index y ys)))
    (cond ((and (null xi) (null yi))
           (walkability-coordinates-resolve-in-cell
             location x y (aref zones col row) bands))
          ((null yi)
           (walkability-coordinates-resolve-on-line
             location x y :v (gethash (list :v xi row) classified)
             (aref zones xi row) (aref zones (1+ xi) row) bands))
          ((null xi)
           (walkability-coordinates-resolve-on-line
             location x y :h (gethash (list :h yi col) classified)
             (aref zones col yi) (aref zones col (1+ yi)) bands))
          (t
           (let ((corner-zones (remove-duplicates
                                 (list (aref zones xi yi) (aref zones (1+ xi) yi)
                                       (aref zones xi (1+ yi)) (aref zones (1+ xi) (1+ yi))))))
             (when (rest corner-zones)
               (error "Location ~A (~A ~A) sits at a segment corner whose surrounding ~
                       cells span ~D zones; its zone is ambiguous."
                      location x y (length corner-zones)))
             corner-zones)))))


(defun walkability-coordinates-resolve-in-cell (location x y zone bands)
  ;; Membership for a location strictly inside a cell.  Inside a stream band, only the
  ;; band's own swept location may stand, and it belongs to the band's zone alone --
  ;; every walking edge to or from it then carries the band's gears in each clause
  ;; automatically, so it is standable and enterable exactly while the stream is off.
  (let ((containing (remove-if-not
                      (lambda (band)
                        (and (< (fourth band) x (fifth band))
                             (< (sixth band) y (seventh band))))
                      bands)))
    (cond ((null containing)
           (list zone))
          ((and (null (rest containing))
                (eql location (second (first containing))))
           (list zone))
          (t (error "Location ~A (~A ~A) lies inside the air stream band of ~A."
                    location x y (first (first containing)))))))


(defun walkability-coordinates-resolve-on-line (location x y axis cover near-zone far-zone bands)
  ;; Membership for a location on a single grid-line interval of AXIS (:v or :h), given
  ;; that interval's classification and the two flanking cells' zones.  On a stream
  ;; curtain the location belongs to the zone OUTSIDE the band only -- the AIMED-AT
  ;; destination's normal situation, standing at the stream's mouth: the band side is
  ;; a place it could occupy only while the stream is off, reached by an ordinary
  ;; gears-gated crossing.  Every stream-curtain line coincides with one of its band's
  ;; four bounds, so comparing the line coordinate against the band rectangle picks the
  ;; outside flank.
  (cond ((null cover)
         (list near-zone))
        ((eql cover :solid)
         (error "Location ~A (~A ~A) lies inside a wall, window, or boundary segment."
                location x y))
        ((member (third cover) '(:gate :screen))
         (error "Location ~A (~A ~A) lies inside doorway ~A."
                location x y (second cover)))
        (t  ;a stream curtain: the outside flank only
         (let ((band (find (second cover) bands :key #'first)))
           (if (eql axis :v)
             (list (if (= x (fourth band)) near-zone far-zone))
             (list (if (= y (sixth band)) near-zone far-zone)))))))


(defun walkability-coordinates-band-side-zones (band xs ys classified zones)
  ;; Every zone lying just across one of BAND's unclipped SIDE curtain intervals -- the
  ;; zones a walker can ride BAND's stream from: stepping laterally into the flow
  ;; carries them to the destination.  The front curtain (always first in the curtain
  ;; list) never grants a ride: entering against the flow is barred.
  (let ((neighbors nil))
    (dolist (curtain (rest (eighth band)))
      (dolist (key (walkability-coordinates-segment-interval-keys (second curtain) xs ys))
        (let ((class (gethash key classified)))
          (when (and (listp class)
                     (eql (first class) :door)
                     (eql (second class) (first band)))
            (destructuring-bind (axis line cross) key
              (if (eql axis :v)
                (progn (push (aref zones line cross) neighbors)
                       (push (aref zones (1+ line) cross) neighbors))
                (progn (push (aref zones cross line) neighbors)
                       (push (aref zones cross (1+ line)) neighbors))))))))
    (remove-duplicates neighbors)))


;;;; MINIMAL DOOR-SET FAMILIES ;;;;
;;;; A family is an antichain of door-sets: no clause a superset of another.  OR over
;;;; clauses, AND within -- the same DNF convention as CONTROLS.


(defun walkability-coordinates-family-table (edges sources)
  ;; For every source zone in SOURCES, relaxes families over the door-labeled zone graph
  ;; to a fixpoint: the source starts at the family of one empty clause; each edge
  ;; extends the near side's family by its door and merges into the far side.  Families
  ;; only ever gain shorter/incomparable clauses, so the fixpoint terminates.  Returns a
  ;; hash of (source zone) -> family; a zone never reached from a source has no entry
  ;; (blocked).  A family exceeding 32 clauses signals a pathological door layout.
  (let ((table (make-hash-table :test 'equal)))
    (dolist (source sources)
      (let ((fams (make-hash-table)))
        (setf (gethash source fams) (list nil))
        (loop for changed = nil
              do (dolist (edge edges)
                   (when (walkability-coordinates-relax-edge edge fams)
                     (setf changed t)))
              while changed)
        (loop for zone being the hash-keys of fams using (hash-value family)
              do (setf (gethash (list source zone) table) family))))
    table))


(defun walkability-coordinates-relax-edge (edge fams)
  ;; Relaxes one undirected door edge (zone-a zone-b door) in both directions.  Returns
  ;; true if either endpoint's family changed.
  (let ((changed nil))
    (destructuring-bind (zone-a zone-b door) edge
      (dolist (direction (list (list zone-a zone-b) (list zone-b zone-a)))
        (let ((from-family (gethash (first direction) fams)))
          (when from-family
            (let* ((to (second direction))
                   (candidate (walkability-family-add-obstacle from-family door))
                   (merged (walkability-family-union
                             (gethash to fams) candidate)))
              (when (> (length merged) 32)
                (error "The minimal door-set family between two zones exceeds 32 ~
                        alternatives; the door layout is pathological."))
              (unless (equal merged (gethash to fams))
                (setf (gethash to fams) merged)
                (setf changed t)))))))
    changed))


;;;; ARRANGEMENT GEOMETRY ;;;;


(defun walkability-coordinates-boundary-segments (points)
  ;; The explicitly closed polygon's consecutive edges as pseudo-segments
  ;; (:boundary x1 y1 x2 y2).  BOUNDARY-WALL validation requires axis alignment;
  ;; repeat the check here as an invariant of this rectangular-cell arrangement.
  (when points
    (loop for (p1 p2) on points
          while p2
          unless (or (= (first p1) (first p2)) (= (second p1) (second p2)))
            do (error "Boundary edge ~A -> ~A is not axis-aligned." p1 p2)
          collect (list :boundary (first p1) (second p1) (first p2) (second p2)))))


(defun walkability-coordinates-orientation (segment)
  ;; :horizontal if SEGMENT's two endpoints share Y, :vertical if they share X.  A
  ;; diagonal segment is an authoring mistake to catch here, not a case to generalize
  ;; the geometry for.
  (let ((x1 (second segment)) (y1 (third segment))
        (x2 (fourth segment)) (y2 (fifth segment)))
    (cond ((= y1 y2) :horizontal)
          ((= x1 x2) :vertical)
          (t (error "Segment ~A (~A ~A ~A ~A) is not axis-aligned."
                    (first segment) x1 y1 x2 y2)))))


(defun walkability-coordinates-axis-coordinates (tagged-segments axis)
  ;; The sorted, deduplicated coordinates every segment contributes along AXIS (:x or
  ;; :y), as a vector of grid-line coordinates.  Location coordinates never contribute.
  (coerce (sort (remove-duplicates
                  (loop for (nil segment) in tagged-segments
                        append (if (eql axis :x)
                                 (list (second segment) (fourth segment))
                                 (list (third segment) (fifth segment))))
                  :test #'=)
                #'<)
          'vector))


(defun walkability-coordinates-interval-index (value coordinates)
  ;; The index of the open interval VALUE falls in: interval i spans coordinate i-1 to
  ;; coordinate i, with unbounded intervals 0 and (length COORDINATES) outside.
  (count-if (lambda (coordinate) (< coordinate value)) coordinates))


(defun walkability-coordinates-segment-interval-keys (segment xs ys)
  ;; The coverage keys of every cell edge-interval SEGMENT covers: (:v k r) is the
  ;; interval of vertical grid line k flanking row r; (:h m i) is the interval of
  ;; horizontal grid line m flanking column i.  Segment endpoints are themselves grid
  ;; coordinates, so a segment covers each interval entirely or not at all.
  (let* ((orientation (walkability-coordinates-orientation segment))
         (range (walkability-coordinates-along-range
                  segment (if (eql orientation :vertical) :vertical :horizontal))))
    (if (eql orientation :vertical)
      (let ((k (position (second segment) xs :test #'=))
            (rlo (position (car range) ys :test #'=))
            (rhi (position (cdr range) ys :test #'=)))
        (loop for r from (1+ rlo) to rhi collect (list :v k r)))
      (let ((m (position (third segment) ys :test #'=))
            (ilo (position (car range) xs :test #'=))
            (ihi (position (cdr range) xs :test #'=)))
        (loop for i from (1+ ilo) to ihi collect (list :h m i))))))


(defun walkability-coordinates-coverage-table (tagged-segments xs ys)
  ;; Marks every cell edge-interval each segment covers with the segment's (kind name).
  (let ((coverage (make-hash-table :test 'equal)))
    (dolist (tagged-segment tagged-segments)
      (destructuring-bind (kind segment) tagged-segment
        (dolist (key (walkability-coordinates-segment-interval-keys segment xs ys))
          (push (list kind (first segment)) (gethash key coverage)))))
    coverage))


(defun walkability-coordinates-classify-coverage (coverage)
  ;; Classifies each covered interval: :solid when any wall/window/boundary covers it,
  ;; or (:door name kind) for a single gate/screen/stream curtain.  A stream curtain
  ;; overlapping a solid is silently clipped -- the solid wins; a gate or screen
  ;; overlapping a solid, or two differently-named doors covering one interval, are
  ;; authoring contradictions.
  (let ((classified (make-hash-table :test 'equal)))
    (loop for key being the hash-keys of coverage using (hash-value entries)
          for solids = (remove-if-not (lambda (entry)
                                        (member (first entry) '(:wall :window :boundary)))
                                      entries)
          for doors = (remove-duplicates
                        (remove-if (lambda (entry)
                                     (member (first entry) '(:wall :window :boundary)))
                                   entries)
                        :key #'second)
          do (cond (solids
                    (let ((hard-doors (remove :stream doors :key #'first)))
                      (when hard-doors
                        (error "Door segment(s) ~A overlap solid segment(s) ~A on one ~
                                interval; a doorway cannot coincide with a solid partition."
                               (mapcar #'second hard-doors) (mapcar #'second solids))))
                    (setf (gethash key classified) :solid))
                   ((rest doors)
                    (error "Doors/stream curtains ~A cover the same interval; a ~
                            crossing there has no single door."
                           (mapcar #'second doors)))
                   (doors (setf (gethash key classified)
                                (list :door (second (first doors)) (first (first doors)))))))
    classified))


(defun walkability-coordinates-flood-fill (nx ny classified)
  ;; Unions cells across open (unclassified) intervals into zones: a 2D array of zone
  ;; ids over the (1+ NX) x (1+ NY) cell grid, unbounded outer cells included -- a
  ;; closed solid boundary isolates them on its own.
  (let ((zones (make-array (list (1+ nx) (1+ ny)) :initial-element nil))
        (zone-count 0))
    (dotimes (i (1+ nx))
      (dotimes (j (1+ ny))
        (when (null (aref zones i j))
          (setf (aref zones i j) zone-count)
          (let ((stack (list (list i j))))
            (loop while stack
                  do (destructuring-bind (ci cj) (pop stack)
                       (dolist (neighbor (walkability-coordinates-open-neighbors
                                           ci cj nx ny classified))
                         (when (null (aref zones (first neighbor) (second neighbor)))
                           (setf (aref zones (first neighbor) (second neighbor)) zone-count)
                           (push neighbor stack))))))
          (incf zone-count))))
    zones))


(defun walkability-coordinates-open-neighbors (i j nx ny classified)
  ;; The cells adjacent to cell (I J) across open intervals.
  (let ((neighbors nil))
    (when (and (< i nx) (null (gethash (list :v i j) classified)))
      (push (list (1+ i) j) neighbors))
    (when (and (>= i 1) (null (gethash (list :v (1- i) j) classified)))
      (push (list (1- i) j) neighbors))
    (when (and (< j ny) (null (gethash (list :h j i) classified)))
      (push (list i (1+ j)) neighbors))
    (when (and (>= j 1) (null (gethash (list :h (1- j) i) classified)))
      (push (list i (1- j)) neighbors))
    neighbors))


(defun walkability-coordinates-door-edges (classified zones)
  ;; The labeled zone graph: one (zone-a zone-b door-name) edge per door that joins two
  ;; distinct zones somewhere, deduplicated; a door interval interior to one zone (a
  ;; walkaround exists) contributes nothing.
  (let ((edges nil))
    (loop for key being the hash-keys of classified using (hash-value class)
          when (and (listp class) (eql (first class) :door))
            do (destructuring-bind (axis line cross) key
                 (let ((zone-a (if (eql axis :v)
                                 (aref zones line cross)
                                 (aref zones cross line)))
                       (zone-b (if (eql axis :v)
                                 (aref zones (1+ line) cross)
                                 (aref zones cross (1+ line)))))
                   (unless (= zone-a zone-b)
                     (pushnew (list (min zone-a zone-b) (max zone-a zone-b) (second class))
                              edges :test #'equal)))))
    edges))


;;;; QUERY FUNCTIONS ;;;;


(define-query walkability-coordinates-location-coords ()
  (do (assign $positions nil)
      (doall (?location location)
        (if (bind (location-coords> ?location $x $y))
          (push (list ?location $x $y) $positions)
          (error "No LOCATION-COORDS> is defined for location ~A." ?location)))
      $positions))


(define-query walkability-coordinates-stream-specs ()
  ;; Default: no air streams.  -stream-passability, nested by wall-blower, redefines
  ;; this to gather one (gears swept-location destination sx sy dx dy width) spec per
  ;; wall-gears from HAS-POSITION, AIMED-AT, LOCATION-COORDS>, and STREAM-WIDTH
  ;; facts -- so this file never references blower relations itself.
  (do (assign $specs nil)
      $specs))


;;;; INITIALIZATION ;;;;


(define-init-action derive-walk-via-from-segments
  ;; Derives WALK-VIA (and WALK-VIA> for rides into stream destinations) from the
  ;; problem's raw segment geometry -- see the file header for the region-connectivity
  ;; derivation.  Runs only when the problem has asserted WALL-SEGMENT>, EDGE-SEGMENT>,
  ;; or BOUNDARY-WALL -- inert otherwise, so a problem that hand-authors its own WALK-VIA
  ;; facts is unaffected.  Only one direction per symmetric pair is asserted: WALK-VIA
  ;; has no ">" suffix, so WW mirrors it both ways itself; a pair whose ride edges
  ;; widen a destination's inbound direction gets its two explicit WALK-VIA>
  ;; directions instead, never both kinds.
  0
  ()
  (or (exists (?wall wall)
        (bind (wall-segment> ?wall $x1 $y1 $x2 $y2)))
      (exists (?edge edge)
        (bind (edge-segment> ?edge $x1 $y1 $x2 $y2)))
      (bind (boundary-wall $trigger-boundary)))
  ()
  (assert
    (do (assign $walls (append (wall-segment-records) (edge-segment-records)))
        (assign $gates (gate-segment-records))
        (assign $windows (window-segment-records))
        (assign $screens (screen-segment-records))
        (assign $boundary (if (bind (boundary-wall $boundary-points)) $boundary-points))
        (assign $stream-specs (walkability-coordinates-stream-specs))
        (assign $positions (walkability-coordinates-location-coords))
        (assign $arrangement (walkability-coordinates-build-arrangement
                               $positions $walls $gates $windows $screens $stream-specs $boundary))
        (doall (?source location)
          (doall (?destination location)
            (if (member ?destination
                        (rest (member ?source (gethash 'location *types*))))
              (do (assign $spec (walkability-coordinates-pair-spec
                                  $arrangement ?source ?destination))
                  (if $spec
                    (if (eql (first $spec) :sym)
                      (do (assign $family (second $spec))
                          (walk-via ?source $family ?destination))
                      (do (assign $forward (second $spec))
                          (assign $backward (third $spec))
                          (walk-via> ?source $forward ?destination)
                          (walk-via> ?destination $backward ?source))))))))
        (convert-databases-to-integers))))

;;;; ==== end technology -walkability-coordinates ====
;; (include-tech -threat): already included -- skipped
;; (include-tech -mobility-action): already included -- skipped

(in-package :ww)


(define-problem-helper walking-segment-for-family
    (state agent source destination family)
  "Return a normalized WALK segment using the canonical passing DNF clause."
  (when (and (= (funcall (symbol-function 'location-elevation) state source)
                (funcall (symbol-function 'location-elevation) state destination))
             (funcall (symbol-function 'safe) state destination))
    (cond ((null family)
           (list 'walk source nil destination))
          (t
           (let ((passing
                   (remove-if-not
                     (lambda (clause)
                       (funcall (symbol-function 'all-clear) state agent clause))
                     (walkability-canonical-family family))))
             (when passing
               (list 'walk source (first passing) destination)))))))


(define-query walking-traversal-segments (?agent agent ?from location)
  (do (assign $segments nil)
      (doall (?to location)
        (do (assign $symmetric-segment nil)
            (assign $directional-segment nil)
            (if (bind (walk-via ?from $symmetric-family ?to))
              (assign $symmetric-segment
                      (walking-segment-for-family
                        state ?agent ?from ?to $symmetric-family)))
            (if (bind (walk-via> ?from $directional-family ?to))
              (assign $directional-segment
                      (walking-segment-for-family
                        state ?agent ?from ?to $directional-family)))
            (if $symmetric-segment
              (assign $segments (cons $symmetric-segment $segments)))
            (if $directional-segment
              (assign $segments (cons $directional-segment $segments)))))
      $segments))


(register-mobility-provider 'walking-traversal-segments)


(define-query one-step-walkable (?agent agent ?from location ?to location)
  (ww-loop for $segment in (walking-traversal-segments ?agent ?from)
           thereis (eql (fourth $segment) ?to)))

;;;; ==== end technology walkability ====

;;;; ==== begin technology visibility ====

;;; Filename: visibility.lisp

;;; Visibility background capability: whether a fixture or another location is in sight from
;;; a location.  LOS-TO-APPARATUS covers point apparatus (transmitter, receiver, repeater,
;;; or gun); LOS-TO-TARGET covers gate, what jammer's jam-target aims at
;;; (a gears jam target instead resolves through its HAS-POSITION location's ordinary
;;; LOS-TO-LOCATION entry -- gears hang at a location, not along a segment -- so
;;; LOS-TO-TARGET remains gate-only).
;;; A connector-to-connector pairing never consults either -- it resolves through a connector's
;;; own location via LOS-TO-LOCATION instead.  A sightline must exist in the LOS tables.  A
;;; LOS-TO-APPARATUS/LOS-TO-LOCATION occluder list may
;;; also carry location entries (-beam-los-coordinates' own location-occlusion test, within
;;; *beam-occlusion-tolerance*); VISIBLE itself always treats a location occluder as clear.
;;; VISIBLE is ordinary opaque sight; VISIBLE-FOR-OBJECT selects gate openness for an actor's
;;; playback or recording view.  POTENTIALLY-VISIBLE remains actor-independent because it
;;; recognizes structural pairing through finite barriers.  BEAM-VISIBLE is the
;;; elevation-aware sibling beam-relay's own hops use instead; BEAM-VISIBLE-FOR-OBJECT is
;;; its actor/view-aware form.
;;; Given both endpoints' live elevations, it checks every static barrier crossing and also
;;; blocks on a location occluder whose beam-blocker spans the beam's interpolated elevation
;;; (-beam-occlusion's beam-blocker-occludes-location, -beam-interpolation's live
;;; beam-elevation-at-location).  ELEVATION-VISIBLE-FOR-OBJECT applies the same static
;;; crossing rule to jammer sight without treating intervening movable objects as blockers.
;;;
;;; The los tables may be hand-authored, or -- when the problem asserts WALL-SEGMENT>,
;;; EDGE-SEGMENT>, or BOUNDARY-WALL -- derived from raw 2D segment geometry by nested
;;; -beam-los-coordinates (entirely inert otherwise), mirroring walkability's own nested
;;; -walkability-coordinates deriving
;;; WALK-VIA.  This file owns the los relations, so it owns their coordinate derivation too;
;;; beam-direct also records every authored fixed coupling's segment crossings through this
;;; interface; beam-relay and beam-crossing consume location sightlines (beam-crossing's own
;;; -beam-crossing-coordinates re-nests it only to guarantee LOS derivation splices before
;;; its crossing derivation; splicing is deduplicated, so that is never a second copy).  A
;;; hand-authored problem may list a location as an occluder exactly as it would a gate; that
;;; location, and both of the beam's own endpoints, still need LOCATION-COORDS>/APPARATUS-
;;; COORDS> asserted -- beam-visible's elevation interpolation reads them live regardless of
;;; whether the LOS fact itself was hand-authored or coordinate-derived.
;;;
;;; REQUIRES:
;;;   types     : location  --  gate, transmitter, receiver, and apparatus are declared
;;;               optional/composite here through nested -visibility
;;;   nested    : -visibility (apparatus and the null-default visible/beam-visible
;;;               interface);
;;;               -gate (gate optional type, (open gate) relation) -- shared with gate,
;;;               walkability (via -passability), reachability, beam-direct, and
;;;               beam-crossing, which all nest -gate instead of hand-declaring it;
;;;               -beam-los-coordinates (LOS-ENDPOINT type; APPARATUS-COORDS>,
;;;               WALL-SEGMENT>, EDGE-SEGMENT>, GATE-SEGMENT>, BOUNDARY-WALL;
;;;               DERIVE-LOS-FROM-SEGMENTS;
;;;               live BEAM-COORDINATES-ELEVATION-AT);
;;;               -beam-interpolation (the sloped-beam elevation hook);
;;;               -beam-occlusion (BEAM-BLOCKER-OCCLUDES-LOCATION)
;;; PROVIDES:
;;;   relations : (los-to-apparatus location $list apparatus)  -- $list items are gate or
;;;               location names,
;;;               (los-to-target location $list gate)  -- $list items are gate names only,
;;;               (los-to-location location $list location)  -- $list items are gate or
;;;               location names,
;;;               (los-barrier-crossings> los-endpoint $list visibility-object) -- oriented
;;;               static wall/edge/gate/boundary crossing records, including fixed couplings
;;;   queries   : visible, visible-for-object, and potentially-visible (override
;;;               -visibility's null defaults), beam-visible and beam-visible-for-object
;;;               (override -visibility's null defaults), elevation-visible-for-object,
;;;               visible-clear

;; (include-tech -visibility): already included -- skipped
;; (include-tech -gate): already included -- skipped

;;;; ==== begin technology -beam-los-coordinates ====

;;; Filename: -beam-los-coordinates.lisp

;;; Beam LOS coordinates substrate: derives LOS-TO-APPARATUS/LOS-TO-TARGET/LOS-TO-LOCATION
;;; from raw WALL-SEGMENT>/EDGE-SEGMENT>/GATE-SEGMENT>/BOUNDARY-WALL segment geometry, for a
;;; problem that would rather author 2D positions than hand-list sightlines.  Nested under
;;; visibility-tech (the owner of the los relations derived here) and beam-crossing-tech (via
;;; -beam-crossing-coordinates, which re-nests it only to guarantee splice order), so it is
;;; always present wherever either is included; entirely inert unless the problem actually
;;; asserts WALL-SEGMENT>, EDGE-SEGMENT>, or BOUNDARY-WALL, so a problem that hand-authors its own LOS-TO-
;;; APPARATUS/LOS-TO-TARGET/LOS-TO-LOCATION facts instead is unaffected.  No problem currently
;;; takes that hand-authored path -- corner-topo and claustro-topo both supply WALL-SEGMENT>
;;; facts and derive.  Walls, edges, gates, and boundary segments retain their static 2D
;;; crossings for runtime vertical-clearance checks.  Edges have the same finite-height
;;; model as walls for LOS, while remaining excluded from jump feature lists.
;;;
;;; Endpoint coordinates come from two relations, split by ownership: LOCATION-COORDS>
;;; (nested from -location-coordinates, shared with walkability-tech's own coordinate
;;; substrate, so a location's position is entered once even when a problem uses both
;;; capabilities) for location endpoints, and APPARATUS-COORDS> (declared here) for
;;; transmitter/receiver/repeater/gun functional points -- a problem with pure location-to-location
;;; beams and no fixtures never needs APPARATUS-COORDS> at all.  A gun's LOS-TO-
;;; APPARATUS entries are derived the same way a receiver's are (gated on a jammer
;;; being present, like LOS-TO-TARGET, since nothing but jam-target ever reads them).
;;;
;;; DERIVE-LOS-FROM-SEGMENTS tests every location<->apparatus, location<->gate, and
;;; location<->location pair against that geometry, recording every finite barrier crossing
;;; and every gate that properly intersects as an occluder.  A wall crossing counts at its own corner
;;; exactly like its interior -- so a sightline can't leak through the junction where it
;;; meets another wall, a gate, or the boundary wall -- while a gate stays strict at its own
;;; corner, since the neighboring wall already covers that point; a beam endpoint that lies
;;; exactly on a wall or gate, corner or interior, is an authoring error (see BEAM-
;;; COORDINATES-OBSTACLE-INTERSECTION-PARAMETER).  A gate has no APPARATUS-COORDS> of its
;;; own -- it is authored as an extended segment, not a point endpoint -- so its LOS-TO-TARGET
;;; entries use BEAM-COORDINATES-GATE-MIDPOINT as a single reference point instead.  When the
;;; problem also asserts BOUNDARY-WALL -- a closed polygon whose final point explicitly
;;; repeats its first -- each consecutive polygon edge contributes its own retained crossing.
;;; -walkability-coordinates.lisp's own WALK-VIA derivation folds BOUNDARY-WALL in the same way
;;; (as a solid boundary segment, alongside WALL-SEGMENT>), so a problem that asserts it gets
;;; ordinary LOS and walkability remain blocked at the map's edge automatically, while a
;;; sufficiently elevated beam or jammer sightline can clear its default height 4.
;;;
;;; The location<->apparatus and location<->location branches additionally test every other
;;; location as a candidate occluder: BEAM-COORDINATES-LOCATION-OCCLUDES-BEAM projects the
;;; candidate onto the beam's line and accepts it iff that projection falls strictly between
;;; the beam's own two endpoints (a location never occludes a beam it terminates) and its
;;; perpendicular distance from the line is within *BEAM-OCCLUSION-TOLERANCE* (declared below;
;;; default 1/2, a half-unit radius; a problem overrides it with its own DEFPARAMETER).  A
;;; qualifying location is appended to the occluder list as a bare location name, exactly like
;;; a qualifying gate; distances are compared squared throughout to stay in exact rational
;;; arithmetic.  The location<->gate (LOS-TO-TARGET) and location<->gun branches deliberately
;;; do not gain this test -- nothing but jam-target ever reads either, and a jammer's line to
;;; its target is not blocked by intervening objects, by design.
;;;
;;; Declares LOS-ENDPOINT itself, as (either transmitter receiver floor-repeater
;;; wall-repeater gun location) -- the composite every consuming query/init-action here
;;; iterates over.  A problem may also declare it identically in its own DEFINE-TYPES (as
;;; problem-corner-topo does); CHECK-TYPE-SIGNATURE-CONSISTENCY requires every declaration
;;; to resolve to the same instance list, so the duplicate is harmless.
;;;
;;; Self-contained; spliced by (include-tech -beam-los-coordinates), nested from visibility
;;; and from -beam-crossing-coordinates (itself nested from beam-crossing).  Splicing is
;;; deduplicated per problem copy, so a problem including both visibility and beam-crossing
;;; still gets this file exactly once, and always before -beam-crossing-coordinates' own
;;; ESTABLISH-BEAM-COORDINATES/DERIVE-BEAM-CROSSINGS-BEFORE-GATE, regardless of which of the two
;;; parent techs the problem lists first.
;;;
;;; REQUIRES:
;;;   types     : location  --  declared by the problem; transmitter, receiver, repeater, gun
;;;               declared optional by -visibility/-beam-substrate, sibling nested
;;;               includes of the parent techs
;;;   relations : los-to-apparatus, los-to-target, los-to-location  --  declared by
;;;               visibility-tech, this file's primary parent; a beam-crossing problem
;;;               reaching this file through -beam-crossing-coordinates must still include
;;;               visibility for these relations to exist
;;; PROVIDES:
;;;   nested    : -location-coordinates (LOCATION-COORDS>; shared with walkability, so
;;;               a location's coordinates are entered once regardless of which
;;;               capabilities the problem uses)
;;;   parameter : *beam-occlusion-tolerance*, default 1/2 -- a Talos-problem default, not a
;;;               core wouldwork setting, so it lives here rather than in ww-settings.lisp;
;;;               a problem overrides it with its own DEFPARAMETER
;;;   types     : los-endpoint (either transmitter receiver floor-repeater wall-repeater
;;;               gun location);
;;;               jammer and gun
;;;               declared optional here only to gate DERIVE-LOS-FROM-SEGMENTS's
;;;               LOS-TO-TARGET/gun LOS-TO-APPARATUS derivations below, so a problem with
;;;               no jammer never gets location<->gate or location<->gun sightlines
;;;               nothing can consume
;;;   relations : apparatus-coords> (transmitter/receiver/repeater/gun functional point),
;;;               wall-segment>, edge-segment>, gate-segment>, boundary-wall -- all default
;;;               to no facts; a problem that asserts wall-segment>, edge-segment>, or
;;;               boundary-wall gets
;;;               LOS-TO-APPARATUS/LOS-TO-TARGET/LOS-TO-LOCATION derived automatically
;;;               instead of hand-authoring them; boundary-wall additionally folds its
;;;               polygon edges into that derivation's finite-barrier crossings
;;;   functions : beam-coordinates-coupled-beams -- stable raw enumeration shared with
;;;               beam-direct and -beam-crossing-coordinates
;;;   queries   : beam-coordinates-endpoint-xy, beam-coordinates-elevation-at -- live
;;;               (query-time, not just init-time) coordinate lookup and interpolation,
;;;               read by visibility.lisp's beam-visible; consulted for a hand-authored
;;;               location occluder exactly as for a derived one, so a problem that hand-
;;;               authors LOS-TO-APPARATUS/LOS-TO-LOCATION directly (bypassing WALL-SEGMENT>
;;;               derivation) can still list a location as an occluder -- it still needs
;;;               LOCATION-COORDS>/APPARATUS-COORDS> asserted for that location and for both
;;;               of the beam's own endpoints, even though DERIVE-LOS-FROM-SEGMENTS itself
;;;               never runs; BEAM-COORDINATES-ENDPOINT-XY errors by name if one is missing
;;;   init      : derive-los-from-segments

;; (include-tech -location-coordinates): already included -- skipped
;; (include-tech -segment-geometry): already included -- skipped

(in-package :ww)


(define-optional-types jammer gun floor-repeater wall-repeater)


(defun beam-coordinates-coupled-beams ()
  ;; Fixed directional beams authored through COUPLED.  Read *STATIC-DB* directly so this
  ;; geometry helper remains usable whether or not the calling technology has a translated
  ;; query over COUPLED.  Stable endpoint ordering keeps every downstream crossing identity
  ;; reproducible across runs.
  (let ((pairs (loop for key being the hash-keys of *static-db*
                     when (and (consp key) (eq (first key) 'coupled))
                       collect (list (second key) (third key)))))
    (sort pairs (lambda (left right)
                  (if (string= (symbol-name (first left)) (symbol-name (first right)))
                    (string< (symbol-name (second left)) (symbol-name (second right)))
                    (string< (symbol-name (first left)) (symbol-name (first right))))))))


(define-types
  repeater (either floor-repeater wall-repeater)
  los-endpoint
    (either transmitter receiver floor-repeater wall-repeater gun location))


(define-static-relations
  (apparatus-coords>
    (either transmitter receiver floor-repeater wall-repeater gun)
    $rational $rational))


(defvar *beam-occlusion-tolerance* 1/2
  "Maximum perpendicular distance a location may sit off a beam's exact line and still
   count as a candidate occluder there (BEAM-COORDINATES-LOCATION-OCCLUDES-BEAM). Default is
   a half-unit radius. Problem files can override this.")


;;;; GEOMETRY HELPERS ;;;;
;;;; Plain Lisp functions operating on positions/beams passed as arguments -- no live
;;;; database access, so no WW query wrapper is needed for these.


(defun beam-coordinates-position (endpoint positions)
  (or (rest (assoc endpoint positions))
      (error "No position is defined for beam endpoint ~A." endpoint)))


(defun beam-coordinates-gate-midpoint (gate-record)
  ;; Returns GATE-RECORD's own (x y) midpoint -- a gate has no APPARATUS-COORDS> of its own,
  ;; since it is authored as an extended segment rather than a point endpoint, so its
  ;; LOS-TO-TARGET entries (DERIVE-LOS-FROM-SEGMENTS, below) use this single reference
  ;; point in its place.
  (list (/ (+ (second gate-record) (fourth gate-record)) 2)
        (/ (+ (third gate-record) (fifth gate-record)) 2)))


(defun beam-coordinates-gate-positions (gates)
  ;; Returns an alist of (gate-name x y), one per GATES record, keyed by name exactly like
  ;; BEAM-COORDINATES-ENDPOINT-POSITIONS's own entries, so it can extend that table for a
  ;; beam whose first endpoint is a gate.  Values come from BEAM-COORDINATES-GATE-MIDPOINT.
  (mapcar (lambda (gate-record)
            (cons (first gate-record) (beam-coordinates-gate-midpoint gate-record)))
          gates))


(defun beam-coordinates-boundary-segments (boundary-points)
  ;; Converts an explicitly closed BOUNDARY-WALL point list into wall-shaped
  ;; (name x1 y1 x2 y2) records, one per consecutive polygon edge.  Fed into
  ;; DERIVE-LOS-FROM-SEGMENTS below as finite barriers alongside WALL-SEGMENT>.  A plain
  ;; edge index provides stable identity within this one boundary polygon.
  (loop for (point1 point2) on boundary-points
        while point2
        for edge-index from 1
        collect (list edge-index
                      (first point1) (second point1)
                      (first point2) (second point2))))


(defun beam-coordinates-obstacle-intersection-parameter (beam positions obstacle &optional endpoints-block)
  ;; Returns BEAM's own parameter (0 < t < 1) where OBSTACLE -- an (name x1 y1 x2 y2)
  ;; wall, edge, gate, or boundary segment record -- crosses BEAM's interior, or nil if it
  ;; doesn't.  Strict on BEAM's own side always: BEAM's own
  ;; endpoint touching OBSTACLE is never itself a crossing (see the error clause below
  ;; instead).  On OBSTACLE's side, ENDPOINTS-BLOCK controls whether OBSTACLE's own
  ;; endpoint also counts: nil (the default; gates use this) keeps the strict reading,
  ;; since a gate's own corner is already covered by its neighboring wall's inclusive
  ;; endpoint, so leaving gates strict avoids a redundant conditional occluder there;
  ;; true (walls, and BOUNDARY-WALL edges folded in as walls) also blocks at OBSTACLE's
  ;; own endpoint, so a beam threading exactly through the corner where two walls (or a
  ;; wall and the boundary wall) meet can't slip through for want of either wall's
  ;; interior, read strictly, containing that point.
  ;;
  ;; Errors if BEAM's own endpoint -- a location or fixture's authored position -- lies
  ;; exactly on OBSTACLE's own segment, corner or interior: a fixture must always be
  ;; offset off every segment barrier it sits beside, never placed on one, so this is an
  ;; authoring mistake to catch, not a case to silently resolve either way.
  (let* ((position1 (beam-coordinates-position (first beam) positions))
         (position2 (beam-coordinates-position (second beam) positions))
         (x1 (first position1))
         (y1 (second position1))
         (x2 (first position2))
         (y2 (second position2))
         (x3 (second obstacle))
         (y3 (third obstacle))
         (x4 (fourth obstacle))
         (y4 (fifth obstacle))
         (dx1 (- x2 x1))
         (dy1 (- y2 y1))
         (dx2 (- x4 x3))
         (dy2 (- y4 y3))
         (offset-x (- x3 x1))
         (offset-y (- y3 y1))
         (denominator (- (* dx1 dy2) (* dy1 dx2))))
    (unless (zerop denominator)
      (let ((parameter1 (/ (- (* offset-x dy2) (* offset-y dx2))
                           denominator))
            (parameter2 (/ (- (* offset-x dy1) (* offset-y dx1))
                           denominator)))
        (when (and (<= 0 parameter2 1) (or (zerop parameter1) (= parameter1 1)))
          (error "Beam endpoint ~A lies exactly on obstacle ~A; offset the fixture or ~
                  location off the barrier segment instead of leaving it on one."
                 (if (zerop parameter1) (first beam) (second beam))
                 (first obstacle)))
        (when (and (< 0 parameter1 1)
                   (if endpoints-block (<= 0 parameter2 1) (< 0 parameter2 1)))
          parameter1)))))


(defun beam-coordinates-barrier-crossing-records
    (beam positions obstacles kind endpoints-block)
  ;; One stable record per 2D crossing: (kind identity beam-parameter x1 y1 x2 y2).
  ;; BEAM is oriented exactly like LOS-BARRIER-CROSSINGS>, so the stored parameter can be
  ;; applied directly to the caller's near and far elevations at runtime.
  (loop for obstacle in obstacles
        for endpoint-gate = (and (eql kind :gate)
                                 (member (first obstacle) beam :test #'eql))
        for parameter = (unless endpoint-gate
                          (beam-coordinates-obstacle-intersection-parameter
                            beam positions obstacle endpoints-block))
          when parameter
            collect (list kind (first obstacle) parameter
                          (second obstacle) (third obstacle)
                          (fourth obstacle) (fifth obstacle))))


(defun beam-coordinates-barrier-crossings
    (beam positions walls edges boundary-segments gates)
  ;; Retains every crossing rather than deleting the whole 2D sightline.  Wall, edge, and
  ;; boundary endpoints count as crossings; gate endpoints remain strict because their
  ;; neighboring solid segment owns the shared corner.
  (append
    (beam-coordinates-barrier-crossing-records beam positions walls :wall t)
    (beam-coordinates-barrier-crossing-records beam positions edges :edge t)
    (beam-coordinates-barrier-crossing-records
      beam positions boundary-segments :boundary t)
    (beam-coordinates-barrier-crossing-records beam positions gates :gate nil)))


(defun beam-coordinates-gate-occluders (crossings)
  (loop for crossing in crossings
        when (eql (first crossing) :gate)
          collect (second crossing)))


(defun beam-coordinates-reverse-crossings (crossings)
  ;; Used for the reverse direction of a symmetric location sightline.  Geometry and
  ;; identity remain unchanged; only the oriented beam parameter changes.
  (mapcar (lambda (crossing)
            (list (first crossing) (second crossing) (- 1 (third crossing))
                  (fourth crossing) (fifth crossing)
                  (sixth crossing) (seventh crossing)))
          crossings))


(defun beam-coordinates-location-occluders (beam positions locations tolerance)
  ;; Every other location whose position lies within TOLERANCE of BEAM's interior --
  ;; strictly between its two endpoints.  A location that is itself one of BEAM's own two
  ;; endpoints is skipped outright, the same way BEAM-COORDINATES-LOS-OCCLUDERS skips a
  ;; gate against a beam it is itself an endpoint of.
  (loop for location in locations
        unless (member location beam :test #'eql)
          append (when (beam-coordinates-location-occludes-beam
                         beam positions (beam-coordinates-position location positions)
                         tolerance)
                   (list location))))


(defun beam-coordinates-projection-parameter (x1 y1 x2 y2 x3 y3)
  ;; (x3,y3)'s own orthogonal projection parameter onto the line from (x1,y1) to (x2,y2) --
  ;; 0 at the first point, 1 at the second.  Shared by the init-time occlusion test
  ;; (BEAM-COORDINATES-LOCATION-OCCLUDES-BEAM, below) and the live elevation interpolation a
  ;; beam or sightline consumer performs at query time (BEAM-COORDINATES-ELEVATION-AT).
  (let ((dx (- x2 x1))
        (dy (- y2 y1)))
    (/ (+ (* (- x3 x1) dx) (* (- y3 y1) dy)) (+ (* dx dx) (* dy dy)))))


(defun beam-coordinates-location-occludes-beam (beam positions location-position tolerance)
  ;; True iff LOCATION-POSITION's own orthogonal projection onto BEAM's line falls strictly
  ;; between BEAM's two endpoints and its perpendicular distance from that line is within
  ;; TOLERANCE -- strict at BEAM's own endpoints exactly like BEAM-COORDINATES-OBSTACLE-
  ;; INTERSECTION-PARAMETER's own segment-barrier test: a location standing at (or beyond) either
  ;; endpoint is never its own occluder.  Coincident 2D endpoints have no interior horizontal
  ;; segment, so no location can occlude between them; this occurs legitimately when two
  ;; locations represent different elevations at the same map coordinates.  Compares squared
  ;; distances throughout to stay in exact rational arithmetic.
  (let* ((position1 (beam-coordinates-position (first beam) positions))
         (position2 (beam-coordinates-position (second beam) positions))
         (x1 (first position1))
         (y1 (second position1))
         (x2 (first position2))
         (y2 (second position2))
         (x3 (first location-position))
         (y3 (second location-position)))
    (unless (and (= x1 x2) (= y1 y2))
      (let ((parameter
              (beam-coordinates-projection-parameter x1 y1 x2 y2 x3 y3)))
        (and (< 0 parameter 1)
             (let* ((nearest-x (+ x1 (* parameter (- x2 x1))))
                    (nearest-y (+ y1 (* parameter (- y2 y1))))
                    (offset-x (- x3 nearest-x))
                    (offset-y (- y3 nearest-y))
                    (distance-squared (+ (* offset-x offset-x) (* offset-y offset-y))))
               (<= distance-squared (* tolerance tolerance))))))))


;;;; QUERY FUNCTIONS ;;;;


(define-query beam-coordinates-endpoint-positions ()
  ;; Routes each los-endpoint to its owning position relation: LOCATION-COORDS> for a
  ;; location, APPARATUS-COORDS> (transmitter/receiver/repeater/gun) for everything else.
  (do (assign $positions nil)
      (doall (?endpoint los-endpoint)
        (if (location ?endpoint)
          (if (bind (location-coords> ?endpoint $x $y))
            (push (list ?endpoint $x $y) $positions)
            (error "No LOCATION-COORDS> is defined for location ~A." ?endpoint))
          (if (bind (apparatus-coords> ?endpoint $x $y))
            (push (list ?endpoint $x $y) $positions)
            (error "No APPARATUS-COORDS> is defined for beam endpoint ~A." ?endpoint))))
      $positions))


(define-query beam-coordinates-endpoint-xy (?endpoint los-endpoint)
  ;; ?endpoint's own live coordinates, routed the same way BEAM-COORDINATES-ENDPOINT-
  ;; POSITIONS routes them at init time: LOCATION-COORDS> for a location, APPARATUS-COORDS>
  ;; for a non-location beam endpoint.  Errors by name if the fact is missing, exactly like
  ;; that init-time sibling -- a bare BIND left unguarded here would instead leave $x/$y nil
  ;; and only fail later, confusingly, inside BEAM-COORDINATES-PROJECTION-PARAMETER's
  ;; arithmetic.  A hand-authored location occluder needs coordinates for itself and both
  ;; of its beam's endpoints, not just for the LOS pair the fact itself names.
  (if (location ?endpoint)
    (do (or (bind (location-coords> ?endpoint $x $y))
            (error "No LOCATION-COORDS> is defined for location ~A." ?endpoint))
        (values $x $y))
    (do (or (bind (apparatus-coords> ?endpoint $x $y))
            (error "No APPARATUS-COORDS> is defined for beam endpoint ~A." ?endpoint))
        (values $x $y))))


(define-query beam-coordinates-elevation-at
    (?occluder location
     ?from los-endpoint
     ?near-elevation
     ?to los-endpoint
     ?far-elevation)
  ;; The occluder and endpoints are Wouldwork objects. Elevations are computed Lisp values
  ;; and therefore deliberately have no Wouldwork object type.
  ;;
  ;; The beam's own interpolated elevation at ?occluder's position along the line from ?from
  ;; to ?to -- linear between ?near-elevation (at ?from) and ?far-elevation (at ?to), weighted
  ;; by ?occluder's own live projection parameter on that line.  Read by visibility.lisp's
  ;; beam-visible for a location occluder it has already confirmed qualifies.
  (do (mv-assign ($x1 $y1) (beam-coordinates-endpoint-xy ?from))
      (mv-assign ($x2 $y2) (beam-coordinates-endpoint-xy ?to))
      (mv-assign ($x3 $y3) (beam-coordinates-endpoint-xy ?occluder))
      (assign $parameter (beam-coordinates-projection-parameter $x1 $y1 $x2 $y2 $x3 $y3))
      (+ ?near-elevation (* $parameter (- ?far-elevation ?near-elevation)))))


;;;; INITIALIZATION ;;;;


(define-init-action derive-los-from-segments
  ;; Derives LOS-TO-APPARATUS/LOS-TO-LOCATION, and LOS-TO-TARGET/gun's LOS-TO-APPARATUS
  ;; entries when a jammer is present, from wall/edge/gate/boundary raw segment
  ;; geometry, when the problem supplies it, instead of requiring them hand-authored.
  ;; LOS-TO-TARGET and gun's LOS-TO-APPARATUS entries are both gated on (exists (?j
  ;; jammer) t): nothing but jam-target ever consumes a location<->gate or location<->gun
  ;; sightline, so a problem without a jammer (like corner-topo) skips both derivations
  ;; entirely rather than asserting facts no query ever reads.  A gate's own LOS-TO-TARGET
  ;; entries use BEAM-COORDINATES-GATE-MIDPOINT as their reference point, since a gate is
  ;; authored as an extended segment rather than
  ;; a point endpoint.  When the problem also asserts BOUNDARY-WALL, each polygon edge
  ;; (BEAM-COORDINATES-BOUNDARY-SEGMENTS) is retained alongside internal wall, edge, and gate
  ;; crossings.  Ordinary sight treats solid crossings as opaque; beam and elevated-jammer
  ;; sight evaluates their vertical span at runtime.  This init-action runs before the
  ;; problem's own INITIALIZE-
  ;; DERIVED-STATE calls PROPAGATE-CHANGES!.  Runs only when the problem has asserted
  ;; WALL-SEGMENT>, EDGE-SEGMENT>, or BOUNDARY-WALL -- inert otherwise, so a problem that hand-authors its
  ;; own LOS facts instead is unaffected.  Defined here, textually before
  ;; -beam-crossing-coordinates' own ESTABLISH-BEAM-COORDINATES when that file is also
  ;; spliced: init-actions run in file/load order (see that init-action's own commentary
  ;; there on DO-INIT-ACTION-UPDATES), not by the numeric-looking argument below, and
  ;; ESTABLISH-BEAM-COORDINATES reads LOS-TO-APPARATUS/LOS-TO-LOCATION to enumerate its own
  ;; beam set.  Ends with its own CONVERT-DATABASES-TO-INTEGERS for the same reason that
  ;; init-action does -- so the facts asserted here are visible to its own later BIND calls.
  ;;
  ;; The location<->apparatus and location<->location branches additionally append every
  ;; other location that occludes the beam within *BEAM-OCCLUSION-TOLERANCE* (default 0,
  ;; exact collinearity); the location<->gate and location<->gun branches deliberately do
  ;; not, since only jam-target ever reads those two, and a jammer's line to its target is
  ;; not blocked by intervening objects.
  0
  ()
  (or (exists (?wall wall)
        (bind (wall-segment> ?wall $x1 $y1 $x2 $y2)))
      (exists (?edge edge)
        (bind (edge-segment> ?edge $x1 $y1 $x2 $y2)))
      (bind (boundary-wall $some-boundary-points)))
  ()
  (assert
    (do (assign $walls (wall-segment-records))
        (assign $edges (edge-segment-records))
        (assign $gates (gate-segment-records))
        (assign $boundary-segments
                (if (bind (boundary-wall $boundary-points))
                  (beam-coordinates-boundary-segments $boundary-points)))
        (assign $positions (beam-coordinates-endpoint-positions))
        (assign $target-positions
                (append (beam-coordinates-gate-positions $gates) $positions))
        (assign $locations (gethash 'location *types*))
        (doall (?location location)
          (doall (?transmitter transmitter)
            (do (assign $beam (list ?location ?transmitter))
                (assign $crossings
                        (beam-coordinates-barrier-crossings
                          $beam $positions $walls $edges $boundary-segments $gates))
                (assign $location-occluders
                        (beam-coordinates-location-occluders
                          $beam $positions $locations *beam-occlusion-tolerance*))
                (los-to-apparatus ?location
                                  (append (beam-coordinates-gate-occluders $crossings)
                                          $location-occluders)
                                  ?transmitter)
                (los-barrier-crossings> ?location $crossings ?transmitter))))
        (doall (?location location)
          (doall (?receiver receiver)
            (do (assign $beam (list ?location ?receiver))
                (assign $crossings
                        (beam-coordinates-barrier-crossings
                          $beam $positions $walls $edges $boundary-segments $gates))
                (assign $location-occluders
                        (beam-coordinates-location-occluders
                          $beam $positions $locations *beam-occlusion-tolerance*))
                (los-to-apparatus ?location
                                  (append (beam-coordinates-gate-occluders $crossings)
                                          $location-occluders)
                                  ?receiver)
                (los-barrier-crossings> ?location $crossings ?receiver))))
        (doall (?location location)
          (doall (?repeater repeater)
            (do (assign $beam (list ?location ?repeater))
                (assign $crossings
                        (beam-coordinates-barrier-crossings
                          $beam $positions $walls $edges $boundary-segments $gates))
                (assign $location-occluders
                        (beam-coordinates-location-occluders
                          $beam $positions $locations *beam-occlusion-tolerance*))
                (los-to-apparatus ?location
                                  (append (beam-coordinates-gate-occluders $crossings)
                                          $location-occluders)
                                  ?repeater)
                (los-barrier-crossings> ?location $crossings ?repeater))))
        (if (exists (?j jammer) t)
          (do (doall (?location location)
                (doall (?gate gate)
                  (do (assign $beam (list ?location ?gate))
                      (assign $crossings
                              (beam-coordinates-barrier-crossings
                                $beam $target-positions $walls $edges
                                $boundary-segments $gates))
                      (los-to-target ?location
                                     (beam-coordinates-gate-occluders $crossings)
                                     ?gate)
                      (los-barrier-crossings> ?location $crossings ?gate))))
              (doall (?location location)
                (doall (?gun gun)
                  (do (assign $beam (list ?location ?gun))
                      (assign $crossings
                              (beam-coordinates-barrier-crossings
                                $beam $positions $walls $edges $boundary-segments $gates))
                      (los-to-apparatus ?location
                                        (beam-coordinates-gate-occluders $crossings)
                                        ?gun)
                      (los-barrier-crossings> ?location $crossings ?gun))))))
        (doall (?source location)
          (doall (?destination location)
            (if (member ?destination
                        (rest (member ?source (gethash 'location *types*))))
              (do (assign $beam (list ?source ?destination))
                  (assign $crossings
                          (beam-coordinates-barrier-crossings
                            $beam $positions $walls $edges $boundary-segments $gates))
                  (assign $location-occluders
                          (beam-coordinates-location-occluders
                            $beam $positions $locations *beam-occlusion-tolerance*))
                  (los-to-location ?source
                                   (append (beam-coordinates-gate-occluders $crossings)
                                           $location-occluders)
                                   ?destination)
                  (los-barrier-crossings> ?source $crossings ?destination)
                  (los-barrier-crossings>
                    ?destination
                    (beam-coordinates-reverse-crossings $crossings)
                    ?source)))))
        (convert-databases-to-integers))))

;;;; ==== end technology -beam-los-coordinates ====

;;;; ==== begin technology -beam-interpolation ====

;;; Filename: -beam-interpolation.lisp

(in-package :ww)


;;; Beam interpolation substrate: include-order-independent hook for finding a sloped beam's
;;; elevation at an intervening location.  A horizontal beam needs no coordinates and keeps
;;; the default.  visibility overrides the hook with coordinate interpolation for endpoints
;;; at different elevations.  beam-direct consumes it for fixed coupled corridors.
;;;
;;; REQUIRES:
;;;   nested  : -beam-substrate (beam-node)
;;;   type    : location
;;; PROVIDES:
;;;   query   : beam-elevation-at-location -- horizontal default; visibility override

;; (include-tech -beam-substrate): already included -- skipped


(define-query beam-elevation-at-location
    (?location location
     ?from beam-node
     ?near-elevation
     ?to beam-node
     ?far-elevation)
  (do ?location ?from ?to
      (if (= ?near-elevation ?far-elevation)
        ?near-elevation
        (error "A sloped fixed beam requires visibility's coordinate interpolation."))))

;;;; ==== end technology -beam-interpolation ====

;;;; ==== begin technology -beam-occlusion ====

;;; Filename: -beam-occlusion.lisp

;;; Beam occlusion substrate: whether a beam-blocking object at a given location intersects
;;; a given beam elevation.  Factored out of beam-direct so the same elevation-aware test is
;;; available to any beam or sightline capability that needs it, not just the direct
;;; transmitter -> receiver corridor -- visibility becomes a second consumer once its own
;;; sightline occluder lists gain location entries alongside gates.
;;;
;;; REQUIRES:
;;;   types  : location, agent  --  box, jammer, connector are declared optional wherever
;;;            the including tech (beam-direct today) declares them; not redeclared here,
;;;            mirroring how -support-occupancy.lisp's own composite types work
;;;   nested : -support-elevation (occupant-elevation, chained through box/fan support;
;;;            plate support does not raise); -height (heighted-object, has-height,
;;;            declared-height); -location (mobile-object, (has-location ...));
;;;            -recording-shadow-policy (recording-side object presence)
;;; PROVIDES:
;;;   types    : beam-blocker (either agent box jammer connector)  --  what can occlude a
;;;              beam or sightline
;;;   queries  : beam-blocker-occludes-location,
;;;              beam-blocker-occludes-location-for-object, beam-blocker-spans-elevation

;; (include-tech -support-elevation): already included -- skipped
;; (include-tech -height): already included -- skipped
;; (include-tech -location): already included -- skipped
;; (include-tech -recording-shadow-policy): already included -- skipped

(in-package :ww)


(define-types
  beam-blocker (either agent box jammer connector))  ;what can block/occlude a beam or sightline


(define-query beam-blocker-occludes-location (?location location ?beam-elevation)
  ;; True iff some beam-blocker at ?location spans ?beam-elevation.
  (exists (?blocker beam-blocker)
    (and (has-location ?blocker ?location)
         (beam-blocker-spans-elevation ?blocker ?beam-elevation))))


(define-query beam-blocker-occludes-location-for-object
    (?view ?location location ?beam-elevation)
  ;; A recording view excludes mapped live blockers that were absent while the trajectory
  ;; was recorded.  Ordinary beam evaluation includes every physical playback blocker.
  (do ?view
      (exists (?blocker beam-blocker)
        (and (recording-shadow-object-present ?blocker)
             (has-location ?blocker ?location)
             (beam-blocker-spans-elevation ?blocker ?beam-elevation)))))


(define-query beam-blocker-spans-elevation (?blocker beam-blocker ?beam-elevation)
  ;; True iff ?blocker's own vertical span -- occupant-elevation up to occupant-elevation
  ;; plus its own declared-height -- covers ?beam-elevation.  Occupant-elevation (from
  ;; -support-elevation) chains through box/fan support; plate support does not raise it.
  (do (assign $base-level (occupant-elevation ?blocker))
      (and (<= $base-level ?beam-elevation)
           (<= ?beam-elevation (+ $base-level (declared-height ?blocker))))))

;;;; ==== end technology -beam-occlusion ====

(in-package :ww)


(define-types
  visibility-object
    (either gate transmitter receiver floor-repeater wall-repeater gun location))


(define-static-relations
  (los-to-apparatus location $list apparatus)  ;per-location occluders on a sightline to a connector/beam-relay apparatus
  (los-to-target location $list gate)  ;per-location occluders on a sightline to a jammer target
  (los-to-location location $list location)  ;symmetric per-pair occluders for location-to-location sightlines
  ;; Directed, oriented records: (:kind identity parameter x1 y1 x2 y2).  An empty list
  ;; marks a coordinate-derived sightline with no segment crossings; absence means the LOS
  ;; fact was hand-authored and retains its legacy gate-only behavior.
  (los-barrier-crossings> los-endpoint $list visibility-object))


(define-init-check visibility-init-check (literals)
  (check-init-list-relation-items-have-types
    literals 'los-to-apparatus '(gate location))
  (check-init-list-relation-items-have-types
    literals 'los-to-target '(gate))
  (check-init-list-relation-items-have-types
    literals 'los-to-location '(gate location)))


(define-query los-barrier-crossings
    (?from los-endpoint ?to visibility-object)
  ;; :UNRECORDED distinguishes a hand-authored LOS fact from a coordinate-derived LOS
  ;; whose crossing list is genuinely empty.
  (if (bind (los-barrier-crossings> ?from $crossings ?to))
    $crossings
    :unrecorded))


(define-query barrier-crossing-clear-for-object
    (?view ?crossing ?near-elevation ?far-elevation)
  (do (assign $kind (first ?crossing))
      (assign $barrier (second ?crossing))
      (assign $parameter (third ?crossing))
      (assign $crossing-elevation
              (+ ?near-elevation
                 (* $parameter (- ?far-elevation ?near-elevation))))
      ;; An open gate has no vertical span.  All other segment barriers use an inclusive
      ;; base-to-top blocking interval: equality with either boundary still blocks.
      (if (and (eql $kind :gate)
               (gate-open-for-object ?view $barrier))
        t
        (do (assign $base-elevation
                    (if (eql $kind :boundary)
                      0
                      (object-elevation $barrier)))
            (assign $height
                    (if (eql $kind :boundary)
                      6
                      (declared-height $barrier)))
            (or (< $crossing-elevation $base-elevation)
                (> $crossing-elevation (+ $base-elevation $height)))))))


(define-query recorded-barriers-clear-for-object
    (?view ?crossings ?near-elevation ?far-elevation)
  (ww-loop for $crossing in ?crossings
           always (barrier-crossing-clear-for-object
                    ?view $crossing ?near-elevation ?far-elevation)))


(define-query visible
    (?location location ?object visibility-object)
  (visible-for-object nil ?location ?object))


(define-query visible-for-object
    (?view ?location location ?object visibility-object)
  ;; A sightline must exist (an empty occluder list is a direct, always-clear line); it is
  ;; clear iff every occluder gate is open in ?view's environmental layer and no retained
  ;; solid segment crosses it.  The NIL view used by VISIBLE reads ordinary playback state.
  ;; Endpoint-elevation-blind: a location occluder is always clear here.  ?object is an
  ;; apparatus (los-to-apparatus), a jammer
  ;; target (los-to-target), or another location (los-to-location); at most one matches,
  ;; so try all three in turn.  BEAM-VISIBLE-FOR-OBJECT is the elevation-aware sibling that
  ;; additionally tests a location occluder, for consuming roles that carry both endpoints'
  ;; live elevations.
  (and (or (bind (los-to-apparatus ?location $occluders ?object))
           (bind (los-to-target ?location $occluders ?object))
           (bind (los-to-location ?location $occluders ?object)))
       (assign $crossings (los-barrier-crossings ?location ?object))
       ;; Ordinary sight never clears a wall, edge, or boundary by height.  Coordinate-
       ;; derived gate crossings continue to be governed by the familiar occluder list.
       (or (eql $crossings :unrecorded)
           (ww-loop for $crossing in $crossings
                    always (eql (first $crossing) :gate)))
       (ww-loop for $o in $occluders
                always (if (gate $o)
                         (gate-open-for-object ?view $o)
                         t))))


(define-query beam-visible
    (?location location
     ?near-elevation
     ?object (either transmitter receiver floor-repeater wall-repeater gun location)
     ?far-elevation)
  ;; Locations/apparatus are Wouldwork objects. Elevations are computed Lisp values and
  ;; therefore deliberately have no Wouldwork object type.
  ;;
  ;; Elevation-aware sibling of visible, for a relay hop whose two live endpoint elevations
  ;; the caller already knows.  No los-to-target branch here: a jammer
  ;; target never carries a location occluder to test in the first place, so jammer uses
  ;; ELEVATION-VISIBLE-FOR-OBJECT.  A location occluder blocks iff some beam-blocker there
  ;; spans the beam's own interpolated elevation at that point.
  (beam-visible-for-object
    nil ?location ?near-elevation ?object ?far-elevation))


(define-query beam-visible-for-object
    (?view
     ?location location
     ?near-elevation
     ?object (either transmitter receiver floor-repeater wall-repeater gun location)
     ?far-elevation)
  ;; A beam's recording view uses recording-side gate transparency and excludes mapped
  ;; live blockers.  The ordinary NIL view retains the shared playback environment.
  (and
       (or (bind (los-to-apparatus ?location $occluders ?object))
           (bind (los-to-location ?location $occluders ?object)))
       (assign $crossings (los-barrier-crossings ?location ?object))
       (or (eql $crossings :unrecorded)
           (recorded-barriers-clear-for-object
             ?view $crossings ?near-elevation ?far-elevation))
       (ww-loop for $o in $occluders
                always
                  (if (gate $o)
                    ;; Coordinate-derived gate crossings were already evaluated at their
                    ;; exact parameter above.  A hand-authored gate still has no crossing
                    ;; geometry and therefore retains the legacy open-only rule.
                    (if (eql $crossings :unrecorded)
                      (gate-open-for-object ?view $o)
                      t)
                    (not (if (recording-shadow-object ?view)
                           (beam-blocker-occludes-location-for-object
                             ?view $o
                             (beam-elevation-at-location
                               $o ?location ?near-elevation ?object ?far-elevation))
                           (beam-blocker-occludes-location
                             $o
                             (beam-elevation-at-location
                               $o ?location ?near-elevation ?object ?far-elevation))))))))


(define-query elevation-visible-for-object
    (?view
     ?location location
     ?near-elevation
     ?object visibility-object
     ?far-elevation)
  ;; Height-aware visual sight for a source and target whose viewing elevations are known.
  ;; Unlike beam visibility, intervening movable occupants do not block this sightline.
  (and (or (bind (los-to-apparatus ?location $occluders ?object))
           (bind (los-to-target ?location $occluders ?object))
           (bind (los-to-location ?location $occluders ?object)))
       (assign $crossings (los-barrier-crossings ?location ?object))
       (if (eql $crossings :unrecorded)
         (ww-loop for $o in $occluders
                  always (if (gate $o)
                           (gate-open-for-object ?view $o)
                           t))
         (recorded-barriers-clear-for-object
           ?view $crossings ?near-elevation ?far-elevation))))


(define-query beam-elevation-at-location
    (?location location
     ?from beam-node
     ?near-elevation
     ?to beam-node
     ?far-elevation)
  (if (= ?near-elevation ?far-elevation)
    ?near-elevation
    (beam-coordinates-elevation-at
      ?location ?from ?near-elevation ?to ?far-elevation)))


(define-query potentially-visible
    (?location location ?object visibility-object)
  ;; Structural LOS ignores whether its authored gate occluders are currently open.  Relay
  ;; pairing selection uses this query; operational sight checks use the appropriate ordinary
  ;; or elevation-aware query instead.
  (or (bind (los-to-apparatus ?location $occluders ?object))
      (bind (los-to-target ?location $occluders ?object))
      (bind (los-to-location ?location $occluders ?object))))


(define-query visible-clear (?occluder gate)
  ;; Ordinary playback transparency for one gate occluder.  Actor-aware consumers use
  ;; GATE-OPEN-FOR-OBJECT directly because this query's single-occluder signature has no
  ;; view parameter.
  (and (gate ?occluder)
       (open ?occluder)))

;;;; ==== end technology visibility ====

;;;; ==== begin technology reachability ====

;;; Filename: reachability.lisp

;;; Reachability background capability: whether one location is within placing/picking reach
;;; of another.  Two locations are in reach iff identical, or a reach edge joins them with
;;; every barrier gate open.
;;;
;;; REQUIRES:
;;;   types     : location
;;;   nested    : -reachability (identity-default reachable query overridden here);
;;;               -gate (gate optional type, (open gate) relation) -- shared with gate,
;;;               walkability (via -passability), visibility, beam-direct, and
;;;               beam-crossing, which all nest -gate instead of hand-declaring it
;;; PROVIDES:
;;;   relations : (reach-via location $list location)
;;;   queries   : reachable (overrides -reachability), reachable-clear

;; (include-tech -reachability): already included -- skipped
;; (include-tech -gate): already included -- skipped

(in-package :ww)


(define-static-relations
  (reach-via location $list location))  ;reach edge (eg through a wall opening); $list = barrier gates that must be open


(define-init-check reachability-init-check (literals)
  (:consumes gate)
  (check-init-list-relation-items-have-types
    literals 'reach-via '(gate)))


(define-query reachable (?location1 location ?location2 location)
  ;; Within reach iff the same location, or a reach edge joins them with every barrier open.
  ;; Agent-independent; reach-via is symmetric (both endpoints are locations).
  (or (eql ?location1 ?location2)
      (and (bind (reach-via ?location1 $barriers ?location2))
           (ww-loop for $b in $barriers
                    always (reachable-clear $b)))))


(define-query reachable-clear (?barrier gate)
  ;; A reach barrier clears only as an open gate; a closed gate or any non-gate barrier blocks.
  (and (gate ?barrier)
       (open ?barrier)))

;;;; ==== end technology reachability ====

;;;; INITIALIZATION ;;;;


(define-init
  ;; Movable objects.  Ghosts (agent1*, connector1*, connector2*, box1*, tray1*) have no
  ;; initial location: START-RECORDER forks each one from its live counterpart's current
  ;; state when the search finds it, per rule 5 -- a ghost does not exist beforehand.
  (has-location agent1 location3)
  (has-location connector1 location13)
  (has-location connector2 location10)
  (has-location box1 location7)
  (has-location tray1 location13)

  ;; Ghost definitions
  (recording-copy> agent1 agent1*)
  (recording-copy> connector1 connector1*)
  (recording-copy> connector2 connector2*)
  (recording-copy> box1 box1*)
  (recording-copy> tray1 tray1*)

  ;; Fixed-position objects and initial support occupancy
  (has-position pplate1 location6)
  (has-position pplate2 location9)
  (has-position pplate3 location12)
  (has-position pplate4 location15)
  (has-position ladder1 location5)
  (has-position ladder2 location14)
  (has-position recorder1 location3)

  ;; Representative location coordinates
  (location-coords> location1 21 10)
  (location-coords> location2 6 9)
  (location-coords> location3 6 5)
  (location-coords> location4 8 10)
  (location-coords> location5 17 151/10)
  (location-coords> location6 22 16)
  (location-coords> location7 25 16)
  (location-coords> location8 241/10 6)
  (location-coords> location9 23 6)
  (location-coords> location10 20 5)
  (location-coords> location11 31 10)
  (location-coords> location12 32 5)
  (location-coords> location13 11 9)
  (location-coords> location14 349/10 9)
  (location-coords> location15 34 2)
  (location-coords> location16 31 2)

  ;; Exact beam-fixture coordinates.  The 1/10 offsets place each fixture
  ;; unambiguously on the intended side of its adjacent boundary.
  (apparatus-coords> transmitter1 69/10 17)
  (apparatus-coords> transmitter2 69/10 2)
  (apparatus-coords> receiver1 13 149/10)
  (apparatus-coords> receiver2 31 41/10)

  ;; Nondefault elevations.  Other locations, gates, and screens default to 0.
  ;; Transmitters and receivers default to elevation 1.
  (has-elevation location4 3/2)
  (has-elevation location9 3/2)
  ;(has-elevation location10 3/2)
  (has-elevation location13 3/2)
  (has-elevation gate4 3/2)
  (has-elevation receiver1 3/2)
  (has-elevation transmitter1 3/2)
  (has-elevation transmitter2 3/2)

  ;; Nondefault heights.
  (has-height wall10 3/2)
  (has-height wall11 3/2)
  (has-height wall12 3/2)
  (has-height wall13 3/2)

  ;; Gate controllers
  (controls ((receiver1)) gate1 normal)
  (controls ((receiver1)) gate2 inverted)
  (controls ((pplate1)) gate3 normal)
  (controls ((pplate2)) gate4 normal)
  (controls ((receiver2 pplate3)) gate5 normal)
  (controls ((pplate4)) gate6 normal)

  ;; Apparatus properties
  (has-chroma transmitter1 blue)
  (has-chroma transmitter2 red)
  (has-chroma receiver1 blue)
  (has-chroma receiver2 red)

  ;; Boundary wall.  The repeated final point explicitly closes the polygon.
  (boundary-wall
    ((0 19) (7 19) (7 15) (16 15) (16 18) (26 18) (26 15) (33 15)
     (33 11) (38 11) (38 1) (30 1) (30 6) (27 6) (27 4) (7 4) (7 0) (0 0) (0 19)))

  ;; Opaque internal wall/edge
  (wall-segment> wall1 7 11 7 13)
  (wall-segment> wall2 7 4 7 8)
  (wall-segment> wall3 10 11 10 15)
  (wall-segment> wall4 16 15 19 15)
  (wall-segment> wall5 19 12 19 15)
  ;(wall-segment> wall6 19 4 19 7)
  (wall-segment> wall7 19 7 24 7)
  (wall-segment> wall8 23 12 23 15)
  (wall-segment> wall9 23 15 26 15)
  (wall-segment> wall10 6 16 7 16)
  (wall-segment> wall11 6 16 6 18)
  (wall-segment> wall12 6 3 7 3)
  (wall-segment> wall13 6 0 6 3)
  (wall-segment> wall14 33 8 35 8)
  (wall-segment> wall15 33 4 33 8)
  (wall-segment> wall16 30 4 33 4)
  (edge-segment> edge1 7 8 7 11)
  (edge-segment> edge2 10 11 12 11)
  (edge-segment> edge3 7 8 12 8)
  (edge-segment> edge4 24 4 24 7)
  (edge-segment> edge5 35 8 35 11)

  ;; Gate geometry
  (gate-segment> gate1 19 7 19 12)
  (gate-segment> gate2 19 12 23 12)
  (gate-segment> gate3 23 15 23 18)
  (gate-segment> gate4 22 4 22 7)
  (gate-segment> gate5 33 8 33 11)
  (gate-segment> gate6 33 1 33 4)

  (window-segment> window1 19 4 19 7)

  ;; Authorized elevation changes
  (jump-via location8 () location9)
  (jump-via location2 () location4)
  (stairs-via location2 () location4)
  (stairs-via location9 () location10)
  (climb-via> location5 (ladder1) location13)
  (climb-via> location14 (ladder2) location15)

  ;; Nearby manipulation across boundaries
  (reach-via location4 () location2)
)


(define-init-action initialize-derived-state
  0
  ()
  (always-true)
  ()
  (assert (propagate-changes!))
)


;;;; GOAL ;;;;


(define-goal
  (and (open gate5)  ;(holding agent1 connector2)
       ;(ghost-stops-recorder)
  )
)
