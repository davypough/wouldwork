;;; Filename: ww-packages.lisp


(in-package :cl-user)


(defpackage :utilities
  (:use :cl)
  (:nicknames :ut))


(defpackage :hstack
  (:use :cl)
  (:nicknames :hs))


(defpackage :wouldwork
  (:use :cl :iterate :sb-ext)
  (:nicknames :ww)
  (:shadowing-import-from :iterate)
  (:export #:main
           #:help
           #:run-test-problems
           #:run-all
           #:list-all
           #:run
          ;#:*test-problem-names*
           #:*problem-folder-paths*
	   #:get-src-folder-path
	   #:get-probs-folder-path
	   #:get-test-folder-path
	   #:add-problem-folder
           #:remove-problem-folder
           #:save-globals
           #:read-globals
           #:*globals-file*
           #:*keep-globals-p*
           #:toggle-globals
           #:set-globals
           #:display-globals))


(defun ww-reset ()
  "Discard generated problem and saved settings, then reload the default problem.
   Allows recovery if wouldwork loading fails with error in problem file."
  (format t "~%Loading wouldwork defaults...~2%")
  (let* ((root (asdf:system-source-directory :wouldwork))
         (problem-file (merge-pathnames
                          (concatenate 'string "src/problem" cl-user::*ww-instance-suffix* ".lisp")
                          root))
         (vals-file (merge-pathnames
                       (concatenate 'string "vals" cl-user::*ww-instance-suffix* ".lisp")
                       root))
         (ww-pkg (find-package :ww))
         (refreshing-sym (and ww-pkg (find-symbol "*REFRESHING*" ww-pkg))))
    (when (and refreshing-sym (boundp refreshing-sym))
      (setf (symbol-value refreshing-sym) nil))
    (when (probe-file problem-file) (delete-file problem-file))
    (when (probe-file vals-file) (delete-file vals-file)))
  (asdf:clear-system :wouldwork)
  (handler-bind ((warning #'muffle-warning))
    (let ((*compile-verbose* nil)
          (*compile-print* nil))
      (asdf:load-system :wouldwork :force t)))
  (setf *package* (find-package :ww)))


(defun refresh ()
  "Reload the current problem file after editing. Works even after load errors.
   Preserves current parameter settings. This recovery version works from
   CL-USER package when ww::refresh is unavailable."
  (let* ((ww-pkg (find-package :ww))
         (problem-name-sym (and ww-pkg (find-symbol "*PROBLEM-NAME*" ww-pkg)))
         (problem-name (and problem-name-sym 
                            (boundp problem-name-sym)
                            (symbol-value problem-name-sym)))
         (goal-sym (and ww-pkg (find-symbol "*GOAL*" ww-pkg)))
         (final-goal-sym (and ww-pkg (find-symbol "*FINAL-GOAL*" ww-pkg)))
         (refreshing-sym (and ww-pkg (find-symbol "*REFRESHING*" ww-pkg))))
    ;; Check we have a problem to refresh
    (unless (and problem-name (not (eq problem-name 'ww::unspecified)))
      (format t "~%No problem currently loaded. Use (run <problem-name>) or (stage <problem-name>) instead.~%")
      (return-from refresh nil))
    (format t "~%Refreshing problem ~A...~2%" problem-name)
    ;; Clear goal if bound
    (when (and goal-sym (boundp goal-sym))
      (setf (symbol-value goal-sym) nil))
    ;; Clear final-goal if bound
    (when (and final-goal-sym (boundp final-goal-sym))
      (setf (symbol-value final-goal-sym) nil))
    ;; Warn about undo checkpoint if set
    ;; Set refreshing flag to preserve current parameter settings
    (when (and refreshing-sym (boundp refreshing-sym))
      (setf (symbol-value refreshing-sym) t))
    ;; Locate and splice problem file via the shared staging decision (idempotent)
    (unless (ww::ensure-problem-staged (string-downcase problem-name))
      (format t "~%Source file not found for problem: ~A~%" problem-name)
      (when (and refreshing-sym (boundp refreshing-sym))
        (setf (symbol-value refreshing-sym) nil))
      (return-from refresh nil))
    ;; Clear and reload
    (asdf:clear-system :wouldwork)
    (unwind-protect
        (let ((*compile-verbose* nil)
              (*compile-print* nil))
          (asdf:load-system :wouldwork :force t))
      ;; Cleanup: reset refreshing flag (look up fresh after reload)
      (let* ((new-ww-pkg (find-package :ww))
             (new-refreshing-sym (and new-ww-pkg 
                                      (find-symbol "*REFRESHING*" new-ww-pkg))))
        (when (and new-refreshing-sym (boundp new-refreshing-sym))
          (setf (symbol-value new-refreshing-sym) nil))))
    (setf *package* (find-package :ww))))
