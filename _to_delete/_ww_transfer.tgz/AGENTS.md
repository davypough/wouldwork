# Project Overview

**Wouldwork** is a Common Lisp AI planning and search system. It solves combinatorial problems by searching for action sequences that transform an initial state into a goal state.

**Language:** Common Lisp, loaded via Quicklisp.

**Layout:**
* `src/ww-*.lisp` — planning engine: search, backtracking, structures, translation, initialization, symmetry, parallelism, and utilities.
* `probs/problem-*.lisp` — individual problem definitions (Towers of Hanoi, N-queens, sliding tiles, beam-routing puzzles, etc.). Each file is a self-contained problem spec consumed by the engine.
* `test/problem-*.lisp` — test problems exercising individual technologies (e.g. floor-blower).
* `doc/` — supporting data, notes, and solution analyses.
* ignore CLAUDE.md.

**Entry point:** Load, stage, and test Wouldwork through the SBCL workflow described below.

---

# Collaboration Preferences

## Response Style

* Generally, keep the discussion perspective from the user's (not a developer's) point of view.
* Keep responses concise but clear.
* Prefer plain language and direct answers.
* If a technical term of art is genuinely more precise, use it and gloss it briefly on first use; otherwise use ordinary language.
* Avoid unnecessary background unless requested.
* If my request is ambiguous, ask for clarification rather than guessing.

---

# Coding Workflow

## General Philosophy

* Don't program defensively; inconsistencies should surface as errors during development.
* If multiple fixes are possible, prefer the one that improves the long-term clarity of the codebase rather than the one with the smallest diff.
* This codebase is not a public library; it is maintained and used by a single developer.
* Backward compatibility is not required unless explicitly stated.
* Keep documentation up to date with changes made.
* Before starting on a new analysis or refactoring, suggest committing existing work.
* Avoid large functions and macros.
* Avoid deeply nested expressions.
* When you're nearly out of context, present a prompt that we can use to continue in a new session. 

---

## Editing Workflow

Before editing files:

* Present the recommended code changes and explain why.
* Wait for approval before editing.
* Always read the current version of each file before composing changes, and preserve any interim user edits. Do not overwrite or revert changes you did not make unless explicitly asked.

After edits:

* Briefly explain what you changed.

---

## Testing

After I approve a proposed revision, you may run limited local tests without requesting separate approval.

Allowed testing:

* Load or compile the files affected by the revision using SBCL, Quicklisp, or ASDF.
* Run focused tests or small problem cases that directly exercise the changed behavior.
* Reproduce the reported failure before the fix when practical, then rerun the same case afterward.
* Run closely related regression tests when they are quick and have no external effects.

Testing limits:

* Do not run the complete test suite, long searches, benchmarks, large problem instances, or parallel stress tests without explicit approval.
* Do not install or update dependencies, access external services, or change machine configuration.
* Stop a test if it appears unexpectedly resource-intensive, interactive, or unable to terminate normally.
* Test-generated build artifacts and temporary files are acceptable, but do not modify project source files as part of testing.
* Cancel any test that runs more than 3 minutes.

After testing, report:

* The exact commands or Lisp forms run.
* Whether each test passed or failed.
* Any warnings, unexpected output, or testing limitations.

If an appropriate test cannot be run safely within these limits, tell me exactly what I should run locally.

### Wouldwork REPL workflow

Run SBCL from PowerShell in the project directory:

```powershell
sbcl --dynamic-space-size 4096
```

This loads the user's `.sbclrc` initialization file. At the SBCL prompt, load Wouldwork and enter its package:

```lisp
(progn (ql:quickload :wouldwork) (in-package :ww))
```

To stage a problem, use its truncated name. For example, `probs/problem-blocks3.lisp` is staged with:

```lisp
(stage blocks3)
```

To solve the staged problem:

```lisp
(solve)
```

Keep the interactive SBCL session running while performing related tests when practical. Staging and solving small, focused problems are allowed under the testing rules above. Obtain explicit approval before solving a problem whose runtime or resource requirements may be substantial.

---

## Bug Fix Policy

When fixing bugs:

* Prefer fixing the **root cause** rather than applying a superficial patch.
* Small refactors are encouraged if they improve clarity or remove structural problems.
* If multiple fixes are possible, prefer the one that **reduces long-term complexity**.

Refactor as part of a bug fix if the minimal patch would:

* Add another special-case conditional
* Duplicate existing logic
* Increase nesting or complexity
* Rely on subtle ordering or hidden assumptions
* Obscure the real invariant being enforced

Avoid fixes that introduce:

* Extra wrapper functions
* Compatibility layers
* Duplicated validation logic
* Additional special-case branching

---

## Code Structure

Function invariants and input validation should live **inside the function** rather than in wrapper functions.

Prefer:

```
(process-data x)
  -> validates x internally
```

Avoid:

```
safe-process-data -> wrapper
process-data      -> real logic
```

Wrappers are acceptable only for: logging/instrumentation, caching, retries/timeouts, or clearly defined policy layers.

Prefer:

* Direct fixes to the underlying function
* Guard clauses and early returns
* Simple data flow and clear invariants
* Smaller focused functions

Avoid:

* Unnecessary abstraction layers and wrapper chains
* Deeply nested control flow
* Labels and flet expressions
* Nesting beyond three levels — extract a helper instead

Keep changes tightly scoped to the problem being solved. If a larger architectural change seems appropriate, propose it first instead of implementing immediately.

---

## API Changes

Interface changes are allowed. You may:

* Modify function signatures
* Consolidate redundant APIs
* Remove unused functions
* Simplify call graphs

When changing an interface:

* Update all call sites in the repository
* Update related documentation
* Ensure behavior remains clear and testable.

---

## Tests

When fixing a bug:

* Identify how the bug can be reproduced.
* Suggest a test that demonstrates the failure.
* After the fix, confirm the test should pass.

If existing behavior is unclear, suggest adding debug prints or creating a **characterization test** before refactoring.
