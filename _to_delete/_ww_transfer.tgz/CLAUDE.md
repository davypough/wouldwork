# Project Overview

**Wouldwork** is a Common Lisp AI planning and search system. It solves combinatorial problems by searching for action sequences that transform an initial state into a goal state.

**Language:** Common Lisp, loaded via Quicklisp.

**Layout:**
* `src/ww-*.lisp` — planning engine: search, backtracking, structures, translation, initialization, symmetry, parallelism, and utilities.
* `probs/problem-*.lisp` — individual problem definitions (Towers of Hanoi, N-queens, sliding tiles, beam-routing puzzles, etc.). Each file is a self-contained problem spec consumed by the engine.
* `test/problem-*.lisp` — test problems exercising individual technologies (e.g. floor-blower).
* `doc/` — supporting data, notes, and solution analyses.
* ignore AGENTS.md.

**Entry point:** User will be responsible for loading Wouldwork with the relevant problem file and then testing/solving.

---

# Collaboration Preferences

## Response Style

* Generally, keep the discussion perspective from the user's (not a developer's) point of view.
* Keep responses concise but clear.
* Prefer plain language and direct answers.
* If a technical term of art is genuinely more precise, use it and gloss it briefly on first use; otherwise use ordinary language.
* Avoid unnecessary background unless requested.
* If my request is ambiguous, ask for clarification rather than guessing.
* WouldWork variables are dollar-prefixed (e.g. \$dest, \$a-location, \$visited). In prose, escape the leading dollar sign as \$ — backticks alone do NOT reliably suppress LaTeX math rendering, which pairs unescaped dollar signs across spans and silently garbles all the text between them. This is an easy-to-miss failure.
* When writing files that contain `$`, beware `Filesystem:edit_file`: it interprets the replacement text with JavaScript regex-substitution rules, so a literal `$` must be doubled to `$$`, and sequences like `$&`, `$1`, `` $` ``, and `$'` expand into other text entirely. Prefer `Filesystem:write_file` for `$`-bearing content, or escape every `$` as `$$`.

---

# Coding Workflow

## General Philosophy

* Don't program defensively; inconsistencies should surface as errors during development.
* If multiple fixes are possible, prefer the one that improves the long-term clarity of the codebase rather than the one with the smallest diff.
* This codebase is not a public library; it is maintained and used by a single developer.
* Backward compatibility is not required unless explicitly stated.
* Avoid large functions and macros.
* Avoid deeply nested expressions.
* Keep documentation up to date along with changes.
* Before starting on a new analysis or refactoring, suggest committing existing work.
* When you're nearly out of context, present a prompt that we can use to continue in a new session. 

---

## Editing Workflow

Before editing files:

* State what you are about to change and why.

After edits:

* Briefly explain what you changed.

Testing:

* I will run tests locally.
* Tell me exactly what test or command I should run.

---

## Bug Fix Policy

When fixing bugs:

* Prefer fixing the root cause rather than applying a superficial patch.
* Small auxilliary refactors are encouraged if they improve clarity or structure.
* If multiple fixes are possible, prefer the one that reduces long-term complexity.

Refactor as part of a bug fix if the minimal patch would:

* Add another special-case conditional
* Duplicate existing logic
* Increase nesting or complexity
* Rely on subtle ordering or hidden assumptions
* Obscure the real invariant being enforced

Avoid fixes that introduce:

* Extra wrapper functions
* Compatibility layers
* Duplicated validation logic
* Additional special-case branching

---

## Code Structure

Function invariants and input validation should live **inside the function** rather than in wrapper functions.

Prefer:

```
(process-data x)
  -> validates x internally
```

Avoid:

```
safe-process-data -> wrapper
process-data      -> real logic
```

Wrappers are acceptable only for: logging/instrumentation, caching, retries/timeouts, or clearly defined policy layers.

Prefer:

* Direct fixes to the underlying function
* Guard clauses and early returns
* Simple data flow and clear invariants
* Smaller focused functions

Avoid:

* Unnecessary abstraction layers and wrapper chains
* Deeply nested control flow
* Labels and flet expressions
* Nesting beyond three levels — extract a helper instead

Keep changes tightly scoped to the problem being solved. If a larger architectural is appropriate, propose it first instead of implementing immediately. Keep the codebase integrated and don't fragment it.

---

## API Changes

Interface changes are allowed. You may:

* Modify function signatures
* Consolidate redundant APIs
* Remove unused functions
* Simplify call graphs

When changing an interface:

* Update all call sites in the repository
* Update related documentation
* Ensure behavior remains clear and testable.

---

## Tests

When fixing a bug:

* Identify how the bug can be reproduced.
* Suggest a test that demonstrates the failure.
* After the fix, confirm the test should pass.

If existing behavior is unclear, suggest adding debug prints or creating a **characterization test** before refactoring.
