;;; Filename: problem-recorder-isolation-test.lisp

;;; Zero-action characterization of recorder cross-layer isolation.  It exercises the
;;; installed generic pickup and connector actions in the initial state, inspects exact
;;; placement, jump-support, and physical-landing choices, and probes malformed initial
;;; HOLDING, ON, and PAIRED facts.  Recorder's private shadow components are included first
;;; to verify that nested-hook deduplication keeps their overrides in force when the shared
;;; action technologies are spliced later.
;;; Expected minimum path length: zero.

(in-package :ww)


(ww-set *problem-name* recorder-isolation-test)

(ww-set *problem-type* planning)

(ww-set *solution-type* min-length)

(ww-set *tree-or-graph* graph)

(ww-set *depth-cutoff* 1)

(setf *expected-min-length* 0)


;;;; TYPES ;;;;


(define-types
  agent (live-pickup-agent ghost-pickup-agent
         live-place-agent ghost-place-agent
         live-pair-agent ghost-pair-agent
         live-tray-holder ghost-tray-holder)
  box (live-pickup-box ghost-pickup-box
       live-support-box ghost-support-box
       live-landing-box ghost-landing-box)
  connector (live-place-connector ghost-place-connector
             live-pair-connector ghost-pair-connector
             live-target-connector ghost-target-connector
             live-lit-blocker-connector ghost-lit-blocker-connector)
  tray (live-held-tray ghost-held-tray
        live-ground-tray ghost-ground-tray)
  recorder (recorder1)
  pressure-plate (shared-plate)
  transmitter (shared-transmitter)
  location (pickup-site place-site pair-origin
            live-target-site ghost-target-site landing-site
            live-lit-site ghost-lit-site)
  edge (pickup-edge))


;;;; TECHNOLOGY INCLUDES ;;;;


(include-tech -recorder-gate-shadow)
(include-tech -recorder-blower-shadow)
(include-tech -recorder-init-checks)
(include-tech plate)
(include-tech box)
(include-tech jump)
(include-tech -gears-fan)
(include-tech beam-relay)
(include-tech visibility)


;;;; INITIALIZATION ;;;;


(define-init
  ;; Explicit recording identity.
  (recording-copy> live-pickup-agent ghost-pickup-agent)
  (recording-copy> live-place-agent ghost-place-agent)
  (recording-copy> live-pair-agent ghost-pair-agent)
  (recording-copy> live-tray-holder ghost-tray-holder)
  (recording-copy> live-pickup-box ghost-pickup-box)
  (recording-copy> live-support-box ghost-support-box)
  (recording-copy> live-landing-box ghost-landing-box)
  (recording-copy> live-place-connector ghost-place-connector)
  (recording-copy> live-pair-connector ghost-pair-connector)
  (recording-copy> live-target-connector ghost-target-connector)
  (recording-copy> live-lit-blocker-connector ghost-lit-blocker-connector)
  (recording-copy> live-held-tray ghost-held-tray)
  (recording-copy> live-ground-tray ghost-ground-tray)

  ;; The ghost-side pickup/placement/pairing characterizations below require an open
  ;; session: OBJECT-MANIPULATION-ALLOWED gates ghost action on this flag.
  (recording-in-progress)

  ;; Recorder and shared support apparatus.
  (has-position recorder1 place-site)
  (has-position shared-plate place-site)

  ;; Pickup matrix: both agents can reach both boxes, leaving layer policy as the
  ;; distinguishing precondition.
  (has-location live-pickup-agent pickup-site)
  (has-location ghost-pickup-agent pickup-site)
  (has-location live-pickup-box pickup-site)
  (has-location ghost-pickup-box pickup-site)

  ;; Placement matrix: each correctly held connector sees shared ground/plate and both
  ;; mobile support layers at one location.
  (has-location live-place-agent place-site)
  (has-location ghost-place-agent place-site)
  (holding live-place-agent live-place-connector)
  (holding ghost-place-agent ghost-place-connector)
  (has-location live-support-box place-site)
  (has-location ghost-support-box place-site)
  (has-location live-tray-holder place-site)
  (has-location ghost-tray-holder place-site)
  ;; Unit-height holders keep their held trays exactly at the fixed reach boundary.
  (has-height live-tray-holder 1)
  (has-height ghost-tray-holder 1)
  (holding live-tray-holder live-held-tray)
  (holding ghost-tray-holder ghost-held-tray)
  (has-location live-held-tray place-site)
  (has-location ghost-held-tray place-site)
  (has-location live-ground-tray place-site)
  (has-location ghost-ground-tray place-site)
  ;; The pair is at one level, so the clause names an edge to make it a jump: a walk
  ;; offers no remote support landing.
  (traverse-via pickup-site ((pickup-edge)) place-site)

  ;; Physical landing matrix used by -gears-fan's shared landing-support query.
  (has-location live-landing-box landing-site)
  (has-location ghost-landing-box landing-site)

  ;; Pairing matrix: fixed apparatus is shared, live-target and ghost-target locations
  ;; are both structurally visible from the pairing origin.
  (has-location live-pair-agent pair-origin)
  (has-location ghost-pair-agent pair-origin)
  (holding live-pair-agent live-pair-connector)
  (holding ghost-pair-agent ghost-pair-connector)
  (has-location live-target-connector live-target-site)
  (has-location ghost-target-connector ghost-target-site)
  (los-via pair-origin () live-target-site)
  (los-via pair-origin () ghost-target-site)
  (los-via pair-origin () shared-transmitter)

  ;; Lit connector occupancy conflicts only within its own recorder layer.
  (has-location live-lit-blocker-connector live-lit-site)
  (has-location ghost-lit-blocker-connector ghost-lit-site))


;;;; CHARACTERIZATION HELPERS ;;;;


(define-test-helper recorder-isolation-action-applicable-p (state action-name args)
  (let ((action (find action-name *actions* :key #'action.name)))
    (and (member args (get-precondition-args action state) :test #'equal)
         (apply (action.pre-defun-name action) state args))))


(define-test-helper recorder-isolation-mappings ()
  '((recording-copy> live-pickup-agent ghost-pickup-agent)
    (recording-copy> live-place-agent ghost-place-agent)
    (recording-copy> live-pair-agent ghost-pair-agent)
    (recording-copy> live-tray-holder ghost-tray-holder)
    (recording-copy> live-pickup-box ghost-pickup-box)
    (recording-copy> live-support-box ghost-support-box)
    (recording-copy> live-landing-box ghost-landing-box)
    (recording-copy> live-place-connector ghost-place-connector)
    (recording-copy> live-pair-connector ghost-pair-connector)
    (recording-copy> live-target-connector ghost-target-connector)
    (recording-copy> live-lit-blocker-connector ghost-lit-blocker-connector)
    (recording-copy> live-held-tray ghost-held-tray)
    (recording-copy> live-ground-tray ghost-ground-tray)))


(define-test-claim beam-relay-default-pairing-limit
  (= *max-connector-pairings* 3))


(define-test-claim recorder-isolation-connector-location-layering
  (let ((probe-state (copy-problem-state *start-state*)))
    (add-proposition
      '(color live-lit-blocker-connector blue)
      (problem-state.idb probe-state))
    (add-proposition
      '(color ghost-lit-blocker-connector blue)
      (problem-state.idb probe-state))
    (and
      (not (connectable-location
             probe-state 'live-pair-connector 'live-lit-site))
      (connectable-location
        probe-state 'ghost-pair-connector 'live-lit-site)
      (connectable-location
        probe-state 'live-pair-connector 'ghost-lit-site)
      (not (connectable-location
             probe-state 'ghost-pair-connector 'ghost-lit-site)))))


(define-test-claim recorder-isolation-validation
  (expect-condition
    (lambda ()
      (validate-init-literals
        (append (recorder-isolation-mappings)
                '((holding live-pickup-agent ghost-pickup-box)))
        :checks '(recorder-init-check)))
    'init-check-failure
    :containing "HOLDING crosses recording layers"
    :check 'recorder-init-check)
  (expect-condition
    (lambda ()
      (validate-init-literals
        (append (recorder-isolation-mappings)
                '((on live-pickup-box ghost-support-box)))
        :checks '(recorder-init-check)))
    'init-check-failure
    :containing "ON crosses recording layers"
    :check 'recorder-init-check)
  (expect-condition
    (lambda ()
      (validate-init-literals
        (append (recorder-isolation-mappings)
                '((paired ghost-pair-connector live-target-connector)))
        :checks '(recorder-init-check)))
    'init-check-failure
    :containing "PAIRED violates recorder connector isolation"
    :check 'recorder-init-check)
  (null
    (validate-init-literals
      (append (recorder-isolation-mappings)
              '((paired live-pair-connector ghost-target-connector)))
      :checks '(recorder-init-check))))


;;;; CHARACTERIZATION QUERY AND GOAL ;;;;


;;;; One named query per theme rather than a single conjunction, so a regression narrows to
;;;; a handful of clauses and each theme can be exercised on its own at the repl, eg
;;;; (funcall 'recorder-isolation-placement-valid *start-state*).


(define-query recorder-isolation-pickup-valid ()
  ;; Generic pickup action: same-side legal, both cross-layer directions illegal.
  (and (recorder-isolation-action-applicable-p
         state 'pickup-box '(live-pickup-agent live-pickup-box))
       (not (recorder-isolation-action-applicable-p
              state 'pickup-box '(live-pickup-agent ghost-pickup-box)))
       (recorder-isolation-action-applicable-p
         state 'pickup-box '(ghost-pickup-agent ghost-pickup-box))
       (not (recorder-isolation-action-applicable-p
              state 'pickup-box '(ghost-pickup-agent live-pickup-box)))))


(define-query recorder-isolation-placement-valid ()
  ;; Placement retains shared ground/plate and same-side mobile supports.  Rule 19 also
  ;; exposes a ghost-held tray to the live connector, but not a grounded ghost tray or a
  ;; live-held tray to the ghost connector.
  (do (assign $live-places
        (placement-options live-place-agent place-site live-place-connector))
      (assign $ghost-places
        (placement-options ghost-place-agent place-site ghost-place-connector))
      (and (member 'ground $live-places)
           (member 'shared-plate $live-places)
           (member 'live-support-box $live-places)
           (not (member 'ghost-support-box $live-places))
           (member 'live-held-tray $live-places)
           (member 'ghost-held-tray $live-places)
           (not (member 'ghost-ground-tray $live-places))
           (member 'ground $ghost-places)
           (member 'shared-plate $ghost-places)
           (member 'ghost-support-box $ghost-places)
           (not (member 'live-support-box $ghost-places))
           (member 'ghost-held-tray $ghost-places)
           (not (member 'live-held-tray $ghost-places)))))


(define-query recorder-isolation-landing-valid ()
  ;; Environmental and jump landings use the same mobile-support isolation.  Rule 19 lets
  ;; the live agent land on the ghost-held tray, but not a grounded ghost tray; the ghost
  ;; agent may use only its own held tray.
  (do (assign $live-transitions
        (configuration-transition-results live-pickup-agent))
      (assign $ghost-transitions
        (configuration-transition-results ghost-pickup-agent))
      (and (eql (landing-support landing-site live-pickup-box nil)
                'live-landing-box)
           (eql (landing-support landing-site ghost-pickup-box nil)
                'ghost-landing-box)
           (member '(jump (pickup-site ground) (pickup-edge)
                           (place-site live-held-tray))
                   $live-transitions :test #'equal)
           (member '(jump (pickup-site ground) (pickup-edge)
                           (place-site ghost-held-tray))
                   $live-transitions :test #'equal)
           (not (member '(jump (pickup-site ground) (pickup-edge)
                                (place-site ghost-ground-tray))
                        $live-transitions :test #'equal))
           (member '(jump (pickup-site ground) (pickup-edge)
                           (place-site ghost-held-tray))
                   $ghost-transitions :test #'equal)
           (not (member '(jump (pickup-site ground) (pickup-edge)
                                (place-site live-held-tray))
                        $ghost-transitions :test #'equal)))))


(define-query recorder-isolation-pairing-valid ()
  ;; Live playback may use either connector layer.  Ghost recording may use only ghost
  ;; movable connectors.  Fixed transmitter apparatus is shared.
  (and (connectable-terminus
         live-pair-agent '(pair-origin) pair-origin
         live-pair-connector live-target-connector)
       (connectable-terminus
         live-pair-agent '(pair-origin) pair-origin
         live-pair-connector ghost-target-connector)
       (connectable-terminus
         ghost-pair-agent '(pair-origin) pair-origin
         ghost-pair-connector ghost-target-connector)
       (not (connectable-terminus
              ghost-pair-agent '(pair-origin) pair-origin
              ghost-pair-connector live-target-connector))
       (connectable-terminus
         live-pair-agent '(pair-origin) pair-origin
         live-pair-connector shared-transmitter)
       (connectable-terminus
         ghost-pair-agent '(pair-origin) pair-origin
         ghost-pair-connector shared-transmitter)
       (recorder-isolation-action-applicable-p
         state 'connect-connector '(live-pair-agent pair-origin))
       (recorder-isolation-action-applicable-p
         state 'connect-connector '(ghost-pair-agent pair-origin))))


(define-goal
  (and (recorder-isolation-pickup-valid)
       (recorder-isolation-placement-valid)
       (recorder-isolation-landing-valid)
       (recorder-isolation-pairing-valid)))
