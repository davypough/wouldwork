;;; Filename: problem-recorder-core-test.lisp

;;; Zero-action characterization of the private recorder core.  Identity, recording-side
;;; object presence, and both cross-layer policy hooks -- who may use a support, and which
;;; pairs of occupants contend for one -- are active, while every
;;; capability-specific shadow relation, query, and update remains absent.  This keeps the
;;; public recorder assembly extensible without letting apparatus state drift back into its
;;; identity layer.  Expected minimum path length: zero.

(in-package :ww)


(ww-set *problem-name* recorder-core-test)
(ww-set *problem-type* planning)
(ww-set *solution-type* min-length)
(ww-set *tree-or-graph* graph)
(ww-set *depth-cutoff* 1)

(setf *expected-min-length* 0)


;;;; TYPES ;;;;


(define-types
  agent (live-agent ghost-agent)
  connector (live-connector ghost-connector)
  fan (unmapped-fan)
  tray (live-held-tray ghost-held-tray live-ground-tray ghost-ground-tray)
  recorder (recorder1)
  location (recorder-site))


;;;; TECHNOLOGY INCLUDE ;;;;


(include-tech -recorder-core)


;;;; INITIALIZATION ;;;;


(define-init
  (recording-copy> live-agent ghost-agent)
  (recording-copy> live-connector ghost-connector)
  (recording-copy> live-held-tray ghost-held-tray)
  (recording-copy> live-ground-tray ghost-ground-tray)
  (has-location live-agent recorder-site)
  (has-location ghost-agent recorder-site)
  (holding live-agent live-held-tray)
  (holding ghost-agent ghost-held-tray)
  (has-location live-connector recorder-site)
  (has-location unmapped-fan recorder-site)
  (has-location live-held-tray recorder-site)
  (has-location ghost-held-tray recorder-site)
  (has-location live-ground-tray recorder-site)
  ;; OBJECT-MANIPULATION-ALLOWED and CONNECTOR-PAIRING-ALLOWED gate ghost action on this
  ;; flag; the characterization below expects both to be true for the ghost side.
  (recording-in-progress)
  (has-position recorder1 recorder-site))


;;;; SCHEMA BOUNDARY ;;;;


(define-test-claim recorder-core-schema
  (expect-relation-schema
    'recording-copy> :static '(mobile-object mobile-object)
    :fluent-indices '(1 2))
  (expect-relation-schema
    'recording-copy>1 :static '(mobile-object mobile-object)
    :fluent-indices '(2))
  (expect-relation-schema
    'recording-copy>2 :static '(mobile-object mobile-object)
    :fluent-indices '(1))
  (or (equal (gethash 'recording-copy> *bijective-relations*)
             '(recording-copy>1 recording-copy>2))
      (fail-test-claim "RECORDING-COPY> does not own both static lookup indexes."))
  (expect-registered :query 'live-recording-object)
  (expect-registered :query 'ghost-recording-object)
  (expect-registered :query 'recording-shadow-view-object)
  (expect-registered :query 'same-recording-side)
  (expect-registered :query 'recording-shadow-object)
  (expect-registered :query 'recording-shadow-object-present)
  (expect-registered :query 'support-occupancy-conflict-p)

  (expect-relation-absent 'recording-depressed :dynamic)
  (expect-relation-absent 'recording-latched :dynamic)
  (expect-relation-absent 'recording-active :dynamic)
  (expect-relation-absent 'recording-open :dynamic)
  (expect-relation-absent 'recording-turning :dynamic)
  (expect-not-registered :query 'recording-plate-occupied)
  (expect-not-registered :query 'recording-controller-energized)
  (expect-not-registered :query 'recording-control-on)
  (expect-not-registered :query 'recording-jammed)
  (expect-not-registered :update 'update-recording-plate-status!)
  (expect-not-registered :update 'update-recording-receiver-status!)
  (expect-not-registered :update 'update-recording-gate-status!)
  (expect-not-registered :update 'update-recording-blower-status!)
  (expect-registrations :solution-validator nil)
  (expect-registrations :solution-printer nil))


;;;; CHARACTERIZATION QUERY AND GOAL ;;;;


(define-query recorder-core-scenarios-valid ()
  (and
    (recording-copy> live-agent ghost-agent)
    (recording-copy> live-connector ghost-connector)
    (live-recording-object live-agent)
    (ghost-recording-object ghost-agent)
    (ghost-recording-object (recording-shadow-view-object))
    (not (recording-shadow-object live-agent))
    (recording-shadow-object ghost-agent)
    (not (recording-shadow-object unmapped-fan))

    (not (recording-shadow-object-present live-agent))
    (recording-shadow-object-present ghost-agent)
    (recording-shadow-object-present unmapped-fan)
    (recording-shadow-object-present recorder1)

    (object-manipulation-allowed live-agent live-connector)
    (object-manipulation-allowed ghost-agent ghost-connector)
    (not (object-manipulation-allowed live-agent ghost-connector))
    (not (object-manipulation-allowed live-agent unmapped-fan))

    (support-use-allowed live-agent recorder1)
    (support-use-allowed live-agent live-connector)
    ;; Rule 19 is directional and applies only while the ghost is holding the tray.
    (support-use-allowed live-connector ghost-held-tray)
    (not (support-use-allowed live-connector ghost-ground-tray))
    (not (support-use-allowed ghost-connector live-held-tray))
    (not (support-use-allowed ghost-agent live-connector))
    (not (support-use-allowed live-agent unmapped-fan))

    ;; Occupancy contention is the capacity question, and is separate from the
    ;; SUPPORT-USE-ALLOWED policy above: it asks whether two occupants can share one
    ;; support top rather than whether either may use the support at all.  Playback
    ;; superimposes the layers, so a live and a ghost object share a top; same-layer pairs
    ;; do not, and anything unmapped contends with everything.
    (not (support-occupancy-conflict-p live-agent ghost-connector))
    (not (support-occupancy-conflict-p ghost-connector live-agent))
    (support-occupancy-conflict-p live-agent live-connector)
    (support-occupancy-conflict-p ghost-agent ghost-connector)
    (support-occupancy-conflict-p live-agent unmapped-fan)
    (support-occupancy-conflict-p unmapped-fan ghost-agent)

    (connector-pairing-allowed live-agent live-connector ghost-connector)
    (connector-pairing-allowed ghost-agent ghost-connector ghost-connector)
    (not (connector-pairing-allowed
           ghost-agent ghost-connector live-connector))
    (has-position recorder1 recorder-site)))


(define-goal
  (recorder-core-scenarios-valid))
