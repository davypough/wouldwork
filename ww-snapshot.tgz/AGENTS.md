# Project Overview

**Wouldwork** is a Common Lisp AI planning and search system. It solves combinatorial problems by searching for action sequences that transform an initial state into a goal state.

**Language:** Common Lisp, loaded via Quicklisp.

**Layout:**
* `src/ww-*.lisp` — planning engine: search, backtracking, structures, translation, initialization, symmetry, parallelism, and utilities.
* `tech/*.lisp` — the Talos technology capabilities and operations (gates, plates, beams, boxes, trays, ladders, the recorder, reachability, visibility). Files beginning `-` are internal substrate spliced in by `include-tech`; the undashed ones are the public assemblies a problem includes. Most real Talos problem work happens here.
* `probs/problem-*.lisp` — individual problem definitions (Towers of Hanoi, N-queens, sliding tiles, beam-routing puzzles, etc.). Each file is a self-contained problem spec consumed by the engine.
* `test/talos/problem-*.lisp` — Talos test problems exercising individual technologies (e.g. floor-blower).
* `test/engine/`, `test/goal-chaining/`, `test/search/` — engine, goal-chaining and search test problems,
  each with any explicitly loaded check scripts that drive them. Tech may be included as test material when
  the subject under test is the engine (e.g. the propagation and reaction-order tests); problems that
  test a technology itself go in `test/talos/`. Problem lookup and `(test-talos)` cover `test/` and every
  folder directly below it, so problem names must stay unique across these folders.
* `test/parallel/*.lisp` — explicitly loaded checks and diagnostics for parallel search (worker read
  snapshots, generated reads, root task generation, thread scaling). Not in `wouldwork.asd`; no problem files.
* `test/test-solutions.lisp`, `test/test-bt-solutions.lisp`, `test/talos/test-topo-solutions.lisp` — recorded
  expectations for `(test)`, `(test-bt)` and `(test-topo)`.
* `doc/` — supporting data, notes, and solution analyses.

**Who runs the code:** verify what you can yourself in whatever environment you have, and
report measurements rather than assertions (Claude in a cloud session: see *Running
Wouldwork in a Claude cloud session* below). Ask before starting anything long-running.
Leave to me, with the exact expression to run: anything interactive, and anything that must
be confirmed on the Windows / Quicklisp setup rather than on Linux.

---

# Problem Modelling: What Is Given and What Is Ours to Choose

In a `probs/problem-*.lisp` spec these are **given** and must not be invented or removed:

* every object in `define-types` — agents, connectors, boxes, trays, gates, plates,
  transmitters, receivers, walls, ladders, and so on
* the wall / edge / gate / window / boundary geometry, and the apparatus coordinates
* the controller wiring in `(controls ...)`, the chromas, elevations, and heights

**Locations are different, but only for Talos -topo problems.** They are the user's guesses at which standing spots might
matter for a solution, not part of the puzzle. A location is just a representative
coordinate; walkability and line-of-sight are derived from it. So when a solution stalls
because the geometry has no relay point or no foothold where one is needed, proposing an
**additional location** is a legitimate and often decisive move — where proposing an extra
box or connector would not be.

Adding one costs two lines: a name in the `location` type list and a
`(location-coords> <name> <x> <y>)` in `define-init`. Everything downstream re-derives
automatically — `one-step-walkable`, `traversal-segments`, `mobility-results`, `los-via`,
`beam-visible`, and the reachability queries.

Worked example (rumin-topo): every walking route east from loc2 crossed gate1, which opens
only while the blue beam reaches receiver1 — and the only anchor high enough to see a
transmitter sits at loc2 itself, so the beam and the passage competed for the same slot.
Adding `location17` at (18 5), in front of window1, broke the deadlock on two counts, both
measured rather than assumed:

* `loc17 <-> loc2` and `loc17 <-> loc3` are `(WALK ... NIL ...)` — no barrier at all. For
  walking, loc17 is on the *west* side of gate1; it reads as a gate1 crossing only when
  approached from loc1/loc8/loc11/loc12.
* the `loc17 -> loc9` beam crosses x=19 at y≈5.2, which is inside `window1` (y 4..7)
  rather than `gate1` (y 7..12), so the relay hop is not hostage to the gate it is trying
  to open.

Nothing else about the problem changed.

When a search fails or a hand-built chain comes up one hop short, ask early: is there a
coordinate where a location would unblock this? Check it with `beam-visible` (and
`traversal-segments` for the walking half) before proposing it.

---

# Collaboration Preferences

## Response Style

* Generally, keep the discussion perspective from the user's (not a developer's) point of view.
* Keep responses concise but clear.
* Prefer plain language and direct answers.
* If a technical term of art is genuinely more precise, use it and gloss it briefly on first use; otherwise use ordinary language.
* Avoid unnecessary background unless requested.
* If my request is ambiguous, ask for clarification rather than guessing.
* At the end of each turn, check the current account-wide five-hour usage allowance using the usage-limits tool, when available. If less than 5% remains, append a brief notice to the final response with the remaining percentage and reset time in my local timezone. Repeat the notice on each turn while below 5%; omit it when 5% or more remains. Calculate remaining usage as 100 minus the reported used percentage for the 300-minute window. Do not substitute weekly usage or infer a value when the tool is unavailable or the data is missing.
* Some WouldWork variables are dollar-prefixed (e.g. \$dest, \$a-location, \$visited). In prose, escape the leading dollar sign as \$ — backticks alone do NOT reliably suppress LaTeX math rendering, which pairs unescaped dollar signs across spans and silently garbles all the text between them. This is an easy-to-miss failure.
* When writing files that contain `$`, beware any edit tool that applies **regex-substitution rules** to its replacement text — `Filesystem:edit_file` is one, and string-replacement editors in other harnesses often are too. In those, a literal `$` must be doubled to `$$`, and `$&`, `$1`, `` $` `` and `$'` expand into other text entirely. Prefer a whole-file write, or a heredoc with a quoted delimiter, for `$`-bearing content.

---

# Coding Workflow

## General Philosophy

* Don't program defensively; inconsistencies should surface as errors during development.
* If multiple fixes are possible, prefer the one that improves the long-term clarity of the codebase and reduces its complexity, rather than the one with the smallest diff.
* This codebase is not a public library; it is maintained and used by a single developer.
* Backward compatibility is not required unless explicitly stated.
* Keep documentation up to date along with changes.

---

## Editing Workflow

Before editing files:

* After receiving a prompt, first concisely explain your intended response or fix in plain
  English, or ask for clarification.
* State what you are about to change and why, and wait for approval before implementing.

After edits:

* Briefly explain what you changed and present the current status of the implementation.
* Recommend the next step, and wait for approval before proceeding.
* When a feature change is finished, remove any of your temporary files and directories.

## Files and Folders

* Do not create new folders anywhere in the wouldwork directory without my permission.
  This includes caches, scratch, staging and transfer folders (e.g. never point ASDF's
  output translations or `XDG_CACHE_HOME` into the project). Keep temporary files outside
  the wouldwork directory.
* Permission to delete files in the wouldwork directory is granted. Name what you delete,
  and say so first when a file is untracked or ignored by git, since it cannot be recovered.

---

## REPL vocabulary

On my machine, SBCL is started from PowerShell in the project directory with
`sbcl --dynamic-space-size 4096`, which loads my `.sbclrc`. Keep the interactive session
running across related tests when practical. Staging and solving small, focused problems
is allowed; obtain explicit approval before solving a problem whose runtime or resource
requirements may be substantial.

Assume Wouldwork is already loaded when you want me to run a test. 

```lisp
(stage blocks3)             ; stage probs/problem-blocks3.lisp -- truncated name
(solve)                     ; solve the staged problem
(solve-subgoal <form>)      ; solve one intermediate goal, chaining from the last solution
(ww-set *depth-cutoff* 25)  ; settings; (ww-set) alone prints them all
(ww-undo)                   ; restore the session preceding the last chained solve
(test)                      ; test wouldwork's default solving of a variety of problems -- ~1 minute
(test-bt)                   ; test wouldwork's solving using backtracking algorithm
(test-topo)                 ; derived geometry of probs/problem-*-topo, no search -- under a minute
(test-talos)                ; solve every problem in test/ and its subfolders, then mutation checks
                            ;   (excludes the -topo problems) -- ~12 minutes
```

`validate-solution` is the highest-value tool here for checked-by-hand work: it replays a
literal action list from `*start-state*` and reports the exact failing action and the
reason, running no search at all.

```lisp
(validate-solution
  (START-RECORDER AGENT1)
  (MOVE AGENT1 ((WALK LOCATION3 NIL LOCATION2))))
```

---

## Running Wouldwork in a Claude cloud session

*This section is for Claude working in a claude.ai cloud session: a Linux container linked to
my Windows machine through the Claude desktop app. Other agents and environments should
skip it.*

Building and running Wouldwork in the container turns claims about geometry, action
legality and validation into measurements. The recipe below was last verified end to end on
2026-10-10 (SBCL 2.2.9, Ubuntu 24.04). The container is reclaimed when the session ends, so
expect to repeat the setup in each new session.

**Setup**

1. **SBCL and the three dependencies.** Quicklisp's site is blocked from the container, but
   the Ubuntu archive carries everything needed. A fresh container has empty package lists,
   so update first:

   ```
   apt-get update
   apt-get install -y sbcl cl-alexandria cl-iterate cl-lparallel
   ```

2. **Copy the checkout into the container.** With the linked computer's shell, `tar czf` the
   checkout into a tarball inside the wouldwork folder, excluding `.git`, `*.png`, `*.docx`,
   `*.fasl`, `.asdf-cache`, `.codex-fasl`, `_to_delete`, `tmp`, `artifacts` and the tarball
   itself (about 3.5 MB remains). Bring it across with the stage-files tool, unpack it under
   `/root/ww/`, and delete the tarball from my folder (if `rm` is refused, request delete
   permission once).

3. **Point ASDF at the libraries and the copy.** Write
   `~/.config/common-lisp/source-registry.conf` (`$HOME` is `/root`):

   ```
   (:source-registry
     (:tree #p"/usr/share/common-lisp/source/")
     (:tree #p"/root/ww/")
     :inherit-configuration)
   ```

4. **Load through a `boot.lisp`** kept outside the copy:

   ```lisp
   (require :asdf)
   (setf uiop:*compile-file-failure-behaviour* :ignore
         uiop:*compile-file-warnings-behaviour* :ignore)
   (asdf:load-system :wouldwork)
   ```

   SBCL raises `caught WARNING` on the `ww-set` expansions (`Constant <PROBLEM> conflicts
   with its asserted type REAL`), which ASDF escalates to a load failure even though
   `wouldwork.asd` muffles warnings. This suppresses the escalation, not the warnings.
   Using a file also avoids putting `(require :asdf)` and an `asdf:` form in one `--eval`,
   which fails because the reader sees the whole form first.

**Running**

```
sbcl --dynamic-space-size 4096 --non-interactive --load boot.lisp --load script.lisp > run.log 2>&1
```

`script.lisp` starts with `(in-package :ww)`, then `(stage <problem>)` and whatever is being
measured. Logs are long (`(test-topo)` writes about 5000 lines), so grep them rather than
printing them whole. Commands are capped at 600 s, so run `(test-talos)` (~12 minutes) or
any real search with `nohup ... &` and poll the log.

`(test-topo)` takes about 40 s including the load. Run it after every change to `tech/`: the
topo problems are in no other suite.

**The copy is a snapshot.** Edits go to my checkout, as usual; re-copy (or apply the same
edit to the copy) before measuring, and never treat the copy as the source of truth.

**Stale staged problems.** Loading compiles *and initializes* `src/problem.lisp`, so a stale
one that no longer loads aborts the load before the script runs, with a backtrace naming the
stale problem's objects. After changing `tech/` in the copy, delete `src/problem.lisp` and
`vals.lisp`; the `.asd` bootstrap recreates them from `problem-blocks3.lisp`. A leftover
that still loads cleanly is harmless, since `(stage ...)` re-splices over it.

**SBCL version.** Under SBCL 2.2.9 the derived geometry matches recordings made on my
Windows/Quicklisp setup exactly (counts and digests), and `(test-topo)` passes against
`test/talos/test-topo-solutions.lisp`. SBCL 2.1.11 diverges on most topo problems. If the
container ever ships a different SBCL, treat a wholesale `test-topo` failure as an
environment difference before chasing it as a regression.

**Alternative: the Linux machine on my PC.** When the session is linked to my computer, its
shell (`device_bash`) runs in a small Linux VM on my PC that sees only the folders I connect,
mounted under `$HOME/mnt/`. Wouldwork can run there instead, on my CPU, with no tarball
transfer. Verified 2026-10-15 (SBCL 2.6.9, Ubuntu 22.04): it reproduced my sentry counts
exactly. The VM is reclaimed with the session, so repeat the setup in each new session.

1. **Folders.** Request access to `D:\quicklisp\local-projects\wouldwork` and `D:\quicklisp`
   (the second only to copy libraries from; change nothing in it).
2. **SBCL.** The VM has no root and no SBCL package, but GitHub is reachable:

   ```
   cd $HOME
   curl -sL -o sbcl.tar.bz2 https://github.com/roswell/sbcl_bin/releases/download/2.6.9/sbcl-2.6.9-x86-64-linux-glibc2.31-binary.tar.bz2
   tar xjf sbcl.tar.bz2
   cd sbcl-2.6.9-x86-64-linux-glibc2.31 && INSTALL_ROOT=$HOME/sbcl sh install.sh
   ```

   Run it as `SBCL_HOME=$HOME/sbcl/lib/sbcl $HOME/sbcl/bin/sbcl`.
3. **Libraries** from my Quicklisp: copy `alexandria-20241012-git`,
   `bordeaux-threads-v0.9.4`, `global-vars-20141106-git`, `iterate-release-b0f9a9c6-git`,
   `lparallel-20160825-git`, `trivial-features-20230618-git` and
   `trivial-garbage-20231021-git` from `$HOME/mnt/quicklisp/dists/quicklisp/software/` to
   `$HOME/cl-libs/`.
4. **Copy the checkout** to a private copy, so staging never touches my `src/problem.lisp`
   or `vals.lisp`:
   `mkdir -p $HOME/ww && cd $HOME/mnt/wouldwork && tar cf - --exclude=.git . | (cd $HOME/ww && tar xf -)`
5. **Load through a boot file** in `$HOME`:

   ```lisp
   (require :asdf)
   (asdf:initialize-source-registry
     `(:source-registry (:tree ,(merge-pathnames "cl-libs/" (user-homedir-pathname)))
                        (:directory ,(merge-pathnames "ww/" (user-homedir-pathname)))
                        :inherit-configuration))
   (handler-bind ((warning #'muffle-warning))
     (asdf:load-system :wouldwork))
   ```

   Then run `sbcl --dynamic-space-size 4096 --non-interactive --load boot.lisp --load
   script.lisp` as above. Each `device_bash` call is capped at 180 s, and every process it
   started, including `nohup`, `setsid` and double-forked jobs, is killed when the call ends
   (checked 2026-10-15), so a run longer than 3 minutes cannot be done here: use the cloud
   container route above, where background jobs survive between calls. Re-copy the checkout (step 4) after every edit before
   measuring.

**SBCL version on the PC route.** 2.6.9 has not been checked against the topo recordings.
Until `(test-topo)` passes there, check topo and other geometry results on the 2.2.9 cloud
route.

**Calling queries directly.** Beyond `validate-solution`, `define-query` bodies compile to
ordinary functions taking the state first, so `(funcall (symbol-function 'beam-visible)
state loc anchor apparatus elev)`, `placement-options`, `movement-results`,
`traversal-segments` and `connectable-terminus` can all be called against a state built by
`validate-action-sequence`. That is how anchor-height and line-of-sight tables get measured
rather than guessed.

---

## Bug Fix Policy

When fixing bugs:

* Prefer fixing the root cause rather than applying a superficial patch.
* Reasonable auxiliary refactors are encouraged if they improve clarity or structure.

Refactor as part of a bug fix if the minimal patch would:

* Add another special-case conditional
* Duplicate existing logic
* Increase nesting or complexity
* Rely on subtle ordering or hidden assumptions
* Obscure the real invariant being enforced

Avoid fixes that introduce:

* Compatibility layers
* Duplicated validation logic

---

## Code Structure

Function invariants and input validation should live **inside the function** rather than in wrapper functions.

Prefer:

```
(process-data x)
  -> validates x internally
```

Avoid:

```
safe-process-data -> wrapper
process-data      -> real logic
```

Wrappers are acceptable only for: logging/instrumentation, caching, retries/timeouts, or clearly defined policy layers.

Prefer:

* Direct fixes to the underlying function
* Guard clauses and early returns
* Simple data flow and clear invariants
* Smaller focused functions

Avoid:

* Unnecessary abstraction layers and wrapper chains
* Large functions and macros
* Reaching for `labels` and `flet` by default — prefer a named top-level helper. Existing
  ones in the codebase are not defects; don't propose churn to remove them.
* Nesting beyond three levels — extract a helper instead

Keep changes tightly scoped to the problem being solved. If a larger architectural change is appropriate, propose it first instead of implementing immediately. Keep the codebase integrated and don't fragment it.

---

## API Changes

Interface changes are allowed. You may:

* Modify function signatures
* Consolidate redundant APIs
* Remove unused functions
* Simplify call graphs

When changing an interface:

* Update all call sites in the repository
* Update related documentation
* Ensure behavior remains clear and testable.
