(FOX-GEESE-GEESE-CHECK 65 DEPTH-FIRST GRAPH PLANNING MIN-LENGTH NIL NIL 0 NIL NIL 0
 (:WOULDWORK-GOAL-V1
  (:CONS (:VALUE AND)
   (:CONS (:CONS (:VALUE BIND) (:CONS (:CONS (:VALUE FOX-AT) (:CONS (:VALUE $FOX) (:VALUE NIL))) (:VALUE NIL)))
    (:CONS
     (:CONS (:VALUE BIND)
      (:CONS (:CONS (:VALUE SQUARE-POSITION>) (:CONS (:VALUE $FOX) (:CONS (:VALUE $ROW) (:CONS (:VALUE $COL) (:VALUE NIL)))))
       (:VALUE NIL)))
     (:CONS
      (:CONS (:VALUE OR)
       (:CONS (:CONS (:VALUE =) (:CONS (:VALUE $ROW) (:CONS (:VALUE 1) (:VALUE NIL))))
        (:CONS
         (:CONS (:VALUE FORALL)
          (:CONS (:CONS (:VALUE ?SQUARE) (:CONS (:VALUE SQUARE) (:VALUE NIL)))
           (:CONS
            (:CONS (:VALUE OR)
             (:CONS (:CONS (:VALUE NOT) (:CONS (:CONS (:VALUE GOOSE-ON) (:CONS (:VALUE ?SQUARE) (:VALUE NIL))) (:VALUE NIL)))
              (:CONS
               (:CONS (:VALUE AND)
                (:CONS
                 (:CONS (:VALUE BIND)
                  (:CONS
                   (:CONS (:VALUE SQUARE-POSITION>)
                    (:CONS (:VALUE ?SQUARE) (:CONS (:VALUE $GOOSE-ROW) (:CONS (:VALUE $GOOSE-COL) (:VALUE NIL)))))
                   (:VALUE NIL)))
                 (:CONS (:CONS (:VALUE >) (:CONS (:VALUE $GOOSE-ROW) (:CONS (:VALUE $ROW) (:VALUE NIL)))) (:VALUE NIL))))
               (:VALUE NIL))))
            (:VALUE NIL))))
         (:CONS
          (:CONS (:VALUE FORALL)
           (:CONS (:CONS (:VALUE ?SQUARE) (:CONS (:VALUE SQUARE) (:VALUE NIL)))
            (:CONS
             (:CONS (:VALUE OR)
              (:CONS (:CONS (:VALUE NOT) (:CONS (:CONS (:VALUE GOOSE-ON) (:CONS (:VALUE ?SQUARE) (:VALUE NIL))) (:VALUE NIL)))
               (:CONS
                (:CONS (:VALUE AND)
                 (:CONS
                  (:CONS (:VALUE BIND)
                   (:CONS (:CONS (:VALUE GOOSE-STEPS) (:CONS (:VALUE ?SQUARE) (:CONS (:VALUE $STEPS) (:VALUE NIL)))) (:VALUE NIL)))
                  (:CONS
                   (:CONS (:VALUE FORALL)
                    (:CONS (:CONS (:VALUE ?NEXT) (:CONS (:VALUE $STEPS) (:VALUE NIL)))
                     (:CONS (:CONS (:VALUE GOOSE-ON) (:CONS (:VALUE ?NEXT) (:VALUE NIL))) (:VALUE NIL))))
                   (:VALUE NIL))))
                (:VALUE NIL))))
             (:VALUE NIL))))
          (:VALUE NIL)))))
      (:VALUE NIL))))))
 16 1 NIL NIL)