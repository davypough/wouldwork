;;;; Filename: problem-windtunnel.lisp

;;; Talos Principle problem in Purgatory workshop


(in-package :ww)


(ww-set *problem-name* windtunnel)

(ww-set *problem-type* planning)

(ww-set *solution-type* min-length)

(ww-set *tree-or-graph* graph)

(ww-set *depth-cutoff* 13)

(ww-set *progress-reporting-interval* 3000000)


(define-types
  real-agent      (agent1)  ;the name of the main agent performing actions
  ghost-agent     (agent1*)  ;ghost objects are starred
  agent           (either real-agent ghost-agent)
  recorder        (recorder1)
  gate            (gate1 gate2)
  wall            (wall1 wall2 wall3 wall4 wall5 wall6 wall7 wall8 wall9 wall10)
  real-connector  (connector1)
  ghost-connector (connector1*)
  connector       (either real-connector ghost-connector)
  floor-repeater  (repeater1)
  wall-repeater   ()
  repeater        (either floor-repeater wall-repeater)
  relay           (either connector repeater)
  transmitter     (transmitter1)
  receiver        (receiver1)
  plate           (plate1)
  blower          (blower1)
  hue             (blue)  ;the hue of a transmitter, receiver, repeater, or active connector
  area            (area1 area2 area3 area4 area5)  ;position points
  real-cargo      (either real-connector)
  ghost-cargo     (either ghost-connector)
  cargo           (either connector)  ;what the player can pickup & carry
  terminus        (either transmitter receiver connector repeater)  ;what a connector can connect to
  source          (either transmitter connector repeater)  ;beam source
  occluder        (either cargo agent gate wall)  ;objects that can occlude a beam
  target          (either connector receiver repeater)  ;beam target
  beam            (compute (loop for i from 1 to (loop for src in (gethash 'source *types*)
                                                   sum (count-if (lambda (tgt) (not (eql tgt src)))
                                                                 (gethash 'target *types*)))
                                 collect (intern (format nil "BEAM~D" i) :ww)))  ;beam pool, one per distinct source-target pair
  focus           (either transmitter receiver repeater)  ;los object of interest
  fixture         (either transmitter receiver recorder repeater plate blower)
  zone            (either gate area)
  access-obstacle (either gate blower)
)


(define-dynamic-relations  ;relations with fluents can be bound in rules--eg (bind (holds agent1 $any-cargo))
  (holds agent $cargo)  ;fluent because we may need to lookup what is currently being held
  (loc (either agent cargo) $area)  ;a location in an area
  (open gate)  ;a gate can be open or not open, default is not open
  (active (either plate blower receiver))
  (paired terminus terminus)  ;potential beam between two terminus
  (color relay $hue)  ;having a color means it is active
  (beam-segment> beam $source $target $rational $rational)  ;endpoint-x endpoint-y
  (current-beams $list)
  (ghost-toggled-active plate)  ;used to track ghost plate activations during playback to catch illegal moves
  (moves-pending-validation $list)
)


(define-static-relations
  (coords> (either area fixture) $fixnum $fixnum)  ;the (x,y) position
  (apparatus-coords> repeater $fixnum $fixnum)  ;repeater functional-point coordinates
  (controls (either receiver plate) (either gate blower))
  (blows> blower $area $area)
  (gate-segment> gate $fixnum $fixnum $fixnum $fixnum)
  (wall-segment> wall $fixnum $fixnum $fixnum $fixnum)
  (toggles plate (either gate blower))
  (chroma (either transmitter receiver) $hue)  ;fixed color
  ;potential clear los from an area to a focus
  (los0 area focus)  
  (los1 area zone focus)  ;los can be blocked either by a closed gate or object in an area
  ;potential visibility from an area to another area
  (visible0 area area)  
  (visible1 area zone area)
  ;potential accesibility to move from an area to another area
  (accessible0 area area)
  (accessible1 area access-obstacle area)
)


;;;; QUERY FUNCTIONS ;;;;


(define-query heuristic? ()
  ;; Estimates minimum actions to reach goal (agent1 in area5)
  (do (bind (loc agent1 $area))
      ;; Base distance considering topology
      (assign $base-distance
        (cond ((eql $area 'area5) 0)    ; At goal
              ((eql $area 'area4) 1)    ; One move (through gate2)
              ((eql $area 'area3) 2)    ; area3 -> area4 -> area5
              ;; From area1/area2: can reach area4 directly if blower off
              ((or (eql $area 'area1) (eql $area 'area2)) 2)
              (t 10)))                   ; Should not occur
      ;; Penalties for obstacles on path to goal
      (assign $penalty 0)
      ;; blower blocks area1/area2 -> area3/area4 passage
      (if (and (or (eql $area 'area1) (eql $area 'area2))
               (active blower1))
        (assign $penalty (+ $penalty 1)))  ; Need to toggle plate1
      ;; Gate2 blocks area4 -> area5 passage
      (if (and (not (eql $area 'area5))
               (not (open gate2)))
        (assign $penalty (+ $penalty 1)))  ; Need to activate receiver1
      ;; Return total heuristic value
      (+ $base-distance $penalty)))


(define-query get-current-beams ()
  (do (bind (current-beams $beams))
      (remove nil $beams)))  ; Filter out placeholders


(define-query get-hue-if-source (?terminus)
  ;gets the hue of ?terminus if it is a source, else nil
  (or (and (transmitter ?terminus)
           (bind (chroma ?terminus $hue))
           $hue)
      (and (connector ?terminus)
           (bind (color ?terminus $hue))
           $hue)
      (and (repeater ?terminus)
           (bind (color ?terminus $hue))
           $hue)))


(define-query get-fixed-coordinates (?area/fixture)
  ;; Efficiently get coordinates for fixed objects
  (do (bind (coords> ?area/fixture $x $y))
      (values $x $y)))


(define-query get-coordinates (?object)
  ;; Finds coordinates for any arbitrary object
  (cond 
    ((or (area ?object) (fixture ?object))
     (bind (coords> ?object $x $y))
     (values $x $y))
    ((or (agent ?object) (and (cargo ?object) (not (holds agent1 ?object))))
     (bind (loc ?object $area))
     (bind (coords> $area $x $y))
     (values $x $y))
    (t (error "~%No coordinates found for ~A~%" ?object))))


(define-query beam-exists-p (?source ?target)
  ; Returns t if a beam already exists from ?source to ?target
  (exists (?b (get-current-beams))
    (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
         (eql $src ?source)
         (eql $tgt ?target))))


(define-query beam-reaches-target (?source ?target)
  ; Returns t if a beam from ?source to ?target reaches ?target's coordinates
  (do (mv-assign ($target-x $target-y) (get-coordinates ?target))
      (exists (?b (get-current-beams))
        (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
             (eql $src ?source)
             (eql $tgt ?target)
             (= $end-x $target-x)
             (= $end-y $target-y)))))


(define-query los (?agent ?area ?fixture)
  ;; For player: respects gate open states and area occupancy
  ;; For ghost: ignores environmental states (recorded when different)
  (or (los0 ?area ?fixture)
      (exists (?zone zone)
        (and (los1 ?area ?zone ?fixture)
             (or (ghost-agent ?agent)
                 (and (gate ?zone)
                      (open ?zone))
                 (and (area ?zone)
                      (not (exists (?obj (either agent cargo))
                             (loc ?obj ?zone)))))))))


(define-query visible (?agent ?area1 ?area2)
  ;; For player: respects gate open states and area occupancy to connect connectors
  ;; For ghost: ignores environmental states (recorded when different)
  (or (visible0 ?area1 ?area2)
      (exists (?zone zone)
        (and (visible1 ?area1 ?zone ?area2)
             (or (ghost-agent ?agent)
                 (and (gate ?zone)
                      (open ?zone))
                 (and (area ?zone)
                      (not (exists (?obj (either agent cargo))
                             (loc ?obj ?zone)))))))))


(define-query observable (?area ?terminus)
  ;; Static observability check - ignores gate state and area occupancy
  ;; Returns t if terminus could potentially be seen from ?area
  (or
    ;; Case 1: Fixture terminus - check los relationships exist
    (and (fixture ?terminus)
         (or (los0 ?area ?terminus)
             (exists (?zone zone)
               (los1 ?area ?zone ?terminus))))
    ;; Case 2: Connector terminus - check visible relationships to connector's area
    (and (connector ?terminus)
         (bind (loc ?terminus $target-area))
         (or (visible0 ?area $target-area)
             (exists (?zone zone)
               (visible1 ?area ?zone $target-area))))))


(define-query selectable (?agent ?area ?terminus)
  ;; Agent can select terminus if observable from ?area or accessible adjacent area
  (or (observable ?area ?terminus)
      (exists (?adj-area area)
        (and (accessible ?agent ?area ?adj-area)
             (observable ?adj-area ?terminus)))))


(define-query accessible (?agent ?area1 ?area2)
  ;; For real agent: respects gate and blower environmental states
  ;; For ghost: respects states it caused (recording phase),
  ;;            ignores states caused by real agent (playback phase)
  (or (accessible0 ?area1 ?area2)
      (exists (?g gate)
        (and (accessible1 ?area1 ?g ?area2)
             (or (ghost-agent ?agent)
                 (open ?g))))
      (exists (?b blower)
        (and (accessible1 ?area1 ?b ?area2)
             (or (not (active ?b))                                 ;; blower off: anyone can pass
                 (and (ghost-agent ?agent)                         ;; blower on + ghost:
                      (not (blower-activated-by-ghost ?b))))))))  ;;   only if ghost didn't cause it


(define-query placeable (?cargo ?area)
  ;; Area can hold multiple cargos; coordinate reference used for calculations;
  ;; can be extended if future domains require area capacity constraints.
  (and (cargo ?cargo) (area ?area)))


(define-query same-type (?agent ?cargo)
  ; Agent type and cargo type are the same (real or ghost).
  (if (real-agent ?agent)
    (real-cargo ?cargo)
    (ghost-cargo ?cargo)))


(define-query resolve-consensus-hue (?hue-list)
  ; Returns consensus hue from list of available hues, nil if no consensus
  (do (assign $unique-hues (remove-duplicates (remove nil ?hue-list)))
      (if (= (length $unique-hues) 1)
        (first $unique-hues)  ; Single unique hue (consensus achieved)
        nil)))               ; Multiple different hues or no hues (no consensus)


(define-query beam-segment-interference
    (?source-x ?source-y ?end-x ?end-y ?cross-x1 ?cross-y1 ?cross-x2 ?cross-y2)
  ; Determines if a cross segment (beam, gate, etc) interferes with the main beam-segment
  ; Returns the interference endpoint, or nil
  ; Step 1: Calculate direction vectors and displacement
  (do (assign $dx1 (- ?end-x ?source-x))    ; Beam direction x
      (assign $dy1 (- ?end-y ?source-y))    ; Beam direction y
      (assign $dx2 (- ?cross-x2 ?cross-x1)) ; Obstacle direction x
      (assign $dy2 (- ?cross-y2 ?cross-y1)) ; Obstacle direction y
      (assign $dx3 (- ?cross-x1 ?source-x)) ; Displacement x
      (assign $dy3 (- ?cross-y1 ?source-y)) ; Displacement y
      ;; Step 2: Calculate determinant for parallel line detection
      (assign $det (- (* $dy1 $dx2) (* $dx1 $dy2)))
      ;; Step 3: Handle parallel lines case
      (if (< (abs $det) 1e-10)
        (values nil nil nil)
        ;; Step 4: Solve for intersection parameters using Cramer's rule
        (do (assign $t (/ (- (* $dy3 $dx2) (* $dx3 $dy2)) $det))
            (assign $s (/ (- (* $dx1 $dy3) (* $dy1 $dx3)) $det))
            ;; Treat hits within 2% of either endpoint as "at the endpoint" => no interference
            (assign $eps 2e-2)  ; parameter-space epsilon (2%)
            ;; Step 5: Validate intersection lies well inside both segments
            (if (and (> $t $eps) (< $t (- 1.0 $eps))      ; main beam interior only
                     (> $s $eps) (< $s (- 1.0 $eps)))     ; cross segment interior only
              ;; Step 6: Calculate and return intersection coordinates
              (do (assign $int-x (+ ?source-x (* $t $dx1)))
                  (assign $int-y (+ ?source-y (* $t $dy1)))
                  (values $t $int-x $int-y))
              ;; No valid intersection within (epsilon-trimmed) interiors
              (values nil nil nil))))))


(define-query beam-segment-occlusion (?source-x ?source-y ?end-x ?end-y ?px ?py)
  ; Determines if an object in an area at (?px,?py) occludes a beam-segment with tolerance < 1.0
  ; Step 1: Calculate beam direction and length
  (do (assign $dx (- ?end-x ?source-x))
      (assign $dy (- ?end-y ?source-y))
      (assign $length-squared (+ (* $dx $dx) (* $dy $dy)))
      ;; Step 2: Handle degenerate case (zero-length beam)
      (if (< $length-squared 1e-10)
        ;; Check if point coincides with source/target
        (if (and (< (abs (- ?px ?source-x)) 1e-6)
                 (< (abs (- ?py ?source-y)) 1e-6))
          (values 0.0 ?source-x ?source-y)      ; Point at source
          (values nil nil nil))     ; Point not at degenerate beam
        ;; Step 3: Calculate projection parameter
        (do (assign $vx (- ?px ?source-x))   ; Vector from source to point
            (assign $vy (- ?py ?source-y))
            (assign $dot-product (+ (* $vx $dx) (* $vy $dy)))
            (assign $t (/ $dot-product $length-squared))
            ;; Step 4: Validate parameter within segment bounds
            (if (and (> $t 0.0) (< $t 1.0))
              ;; Step 5: Calculate closest point on beam to given point
              (do (assign $closest-x (+ ?source-x (* $t $dx)))
                  (assign $closest-y (+ ?source-y (* $t $dy)))
                  ;; Step 6: Calculate distance from point to beam
                  (assign $dist-x (- ?px $closest-x))
                  (assign $dist-y (- ?py $closest-y))
                  (assign $distance (sqrt (+ (* $dist-x $dist-x) 
                                          (* $dist-y $dist-y))))
                  ;; Step 7: Check if point is within intersection tolerance
                  (if (< $distance (+ 0.25d0 1d-6))  ; Tolerance for blocking the beam with epsilon
                    (values $t $closest-x $closest-y)  ; Point blocks beam
                    (values nil nil nil)))             ; Point too far from beam
              ;; Projection falls outside segment bounds
              (values nil nil nil))))))


(define-query find-first-obstacle-intersection (?source-x ?source-y ?target-x ?target-y)
  ; Establishes each beam's intended full path by finding intersections with static obstacles only
  ; Returns the endpoint coordinates where the beam terminates and what blocks it
  (do
    ;; Initialize closest intersection tracking
    (assign $closest-t 1.0)  ; Default to target if no intersections
    (assign $result-x ?target-x)   
    (assign $result-y ?target-y)
    ;; Check static obstacles only - exclude beams
    (doall (?obj occluder)
      (if (and ;; Type-specific coordinate binding and conditions
               (or (and (gate ?obj) 
                        (not (open ?obj))  ; Block UNLESS explicitly open
                        (bind (gate-segment> ?obj $x1 $y1 $x2 $y2)))
                   (and (wall ?obj)
                        (bind (wall-segment> ?obj $x1 $y1 $x2 $y2)))
                   (and (or (cargo ?obj) (agent ?obj))
                        (bind (loc ?obj $area))
                        (bind (coords> $area $x1 $y1))
                        (assign $x2 $x1) (assign $y2 $y1)))
               ;; Endpoint exclusion logic for all obstacle types
               (not (or (and (= $x1 ?source-x) (= $y1 ?source-y))
                        (and (= $x2 ?source-x) (= $y2 ?source-y))
                        (and (= $x1 ?target-x) (= $y1 ?target-y))
                        (and (= $x2 ?target-x) (= $y2 ?target-y)))))
        ;; Calculate intersection with obstacle
        (do (mv-assign ($int-t $int-x $int-y)
              (if (and (= $x1 $x2) (= $y1 $y2))
                ;; Point occlusion (cargo)
                (beam-segment-occlusion ?source-x ?source-y ?target-x ?target-y $x1 $y1)
                ;; Line segment interference (gates)
                (beam-segment-interference ?source-x ?source-y ?target-x ?target-y $x1 $y1 $x2 $y2)))
            (if (and $int-t (< $int-t $closest-t))
              (do (assign $closest-t $int-t)
                  (assign $result-x $int-x)
                  (assign $result-y $int-y))))))
    ;; Return closest intersection coordinates
    (values $result-x $result-y)))


(define-query collect-all-beam-intersections ()
  ; Use current endpoints (actual segments), not intended targets
  ; Returns list of intersection records: ((beam1 beam2 intersection-x intersection-y t1 t2) ...)
  (do 
      ;; Build coordinate cache for all beam sources
      (assign $coord-cache (make-hash-table :test 'eq))
      (doall (?b (get-current-beams))
        (do (bind (beam-segment> ?b $src $tgt $end-x $end-y))
            ;; Cache source coordinates if not already cached
            (if (not (gethash $src $coord-cache))
              (do (mv-assign ($x $y) (get-coordinates $src))
                  (setf (gethash $src $coord-cache) (list $x $y))))))
      ;; Detect intersections using cached coordinates
      (doall (?b1 (get-current-beams))
        (doall (?b2 (get-current-beams))
          (if (and (different ?b1 ?b2)
                   (string< (symbol-name ?b1) (symbol-name ?b2))) ; Avoid duplicate pairs
            (do (bind (beam-segment> ?b1 $src1 $tgt1 $end1-x $end1-y))
                (bind (beam-segment> ?b2 $src2 $tgt2 $end2-x $end2-y))
                (assign $src1-coords (gethash $src1 $coord-cache))
                (assign $src1-x (first $src1-coords))
                (assign $src1-y (second $src1-coords))
                (assign $tgt1-x $end1-x)
                (assign $tgt1-y $end1-y)
                (assign $src2-coords (gethash $src2 $coord-cache))
                (assign $src2-x (first $src2-coords))
                (assign $src2-y (second $src2-coords))
                (assign $tgt2-x $end2-x)
                (assign $tgt2-y $end2-y)
                ;; Check intersection between current segments (not intended paths)
                (mv-assign ($t1 $int-x $int-y)
                  (beam-segment-interference
                    $src1-x $src1-y $tgt1-x $tgt1-y
                    $src2-x $src2-y $tgt2-x $tgt2-y))
                (if $t1
                  (do
                    ;; Get t2 parameter by checking beam2 vs beam1
                    (mv-assign ($t2 $int-x2 $int-y2)
                      (beam-segment-interference
                        $src2-x $src2-y $tgt2-x $tgt2-y
                        $src1-x $src1-y $tgt1-x $tgt1-y))
                    ;; Only push if both intersections valid
                    (if $t2
                      (push (list ?b1 ?b2 $int-x $int-y $t1 $t2) $intersections))))))))
      $intersections))


(define-query beam-reaches-receiver (?receiver)
  ; Returns t if a color-matching beam reaches the receiver
  (do
    (mv-assign ($r-x $r-y) (get-fixed-coordinates ?receiver))
    (bind (chroma ?receiver $required-hue))
    (exists (?b (get-current-beams))
      (and (bind (beam-segment> ?b $source $target $end-x $end-y))
           (= $end-x $r-x)
           (= $end-y $r-y)
           ;; Get hue from source
           (or (bind (chroma $source $source-hue))
               (bind (color $source $source-hue)))
           (eql $source-hue $required-hue)))))


(define-query connector-has-beam-power (?connector ?hue)
  ; Returns t if a beam with matching hue reaches the connector at its current coordinates
  (do
    (mv-assign ($c-x $c-y) (get-coordinates ?connector))
    (exists (?b (get-current-beams))
      (and (bind (beam-segment> ?b $source $target $end-x $end-y))
           (eql $target ?connector)  ; Beam must target this connector
           (= $end-x $c-x)            ; Beam must reach connector coordinates
           (= $end-y $c-y)
           ;; Verify source has matching hue
           (or (bind (chroma $source $source-hue))
               (bind (color $source $source-hue)))
           (eql $source-hue ?hue)))))


(define-query relay-is-powered-by (?relay ?potential-source)
  ;; Returns t if ?relay is currently receiving power from ?potential-source
  ;; This prevents creating reciprocal beams back to the power source
  (and (bind (color ?relay $conn-hue))  ; Relay must be active
       ;; Check if a beam exists from ?potential-source to ?relay
       (exists (?b (get-current-beams))
         (and (bind (beam-segment> ?b $src $tgt $end-x $end-y))
              (eql $src ?potential-source)
              (eql $tgt ?relay)
              ;; Verify beam actually reaches relay's coordinates
              (mv-assign ($conn-x $conn-y) (get-coordinates ?relay))
              (= $end-x $conn-x)
              (= $end-y $conn-y)
              ;; Verify source has matching hue (confirming power flow)
              (or (bind (chroma $src $src-hue))     ; Transmitter
                  (bind (color $src $src-hue)))     ; Active relay
              (eql $src-hue $conn-hue)))))


(define-query collect-transmitter-powered-relays ()
  ;; BFS from all transmitters, returning list of relays reachable via beam chains
  (do
    ;; Initialize frontier with all transmitters
    (assign $frontier nil)
    (doall (?t transmitter)
      (push ?t $frontier))
    ;; Initialize result set
    (assign $powered-relays nil)
    ;; BFS loop - continue while frontier has sources to process
    (ww-loop while $frontier do
      (assign $next-frontier nil)
      ;; Process each source in current frontier
      (ww-loop for $source in $frontier do
        ;; Check all beams originating from this source
        (doall (?b (get-current-beams))
          (do (bind (beam-segment> ?b $src $tgt $end-x $end-y))
              (if (eql $src $source)
                ;; Beam originates from current source - check if target is a relay
                (if (relay $tgt)
                  ;; Verify beam actually reaches target coordinates
                  (do (mv-assign ($tgt-x $tgt-y) (get-coordinates $tgt))
                      (if (and (= $end-x $tgt-x)
                               (= $end-y $tgt-y)
                               (not (member $tgt $powered-relays)))
                        ;; Target is newly discovered powered relay
                        (do (push $tgt $powered-relays)
                            (push $tgt $next-frontier)))))))))
      ;; Advance to next frontier
      (assign $frontier $next-frontier))
    $powered-relays))


(define-query find-blower-on-path (?area1 ?area2)
  ;; Returns the blower controlling path from ?area1 to ?area2, or nil if none.
  (ww-loop for ?b in (gethash 'blower *types*)
           do (if (accessible1 ?area1 ?b ?area2)
                (return ?b))))


(define-query playback-blower-active (?blower)
  ;; Returns t if blower will be active when playback begins.
  ;; This occurs when any controlling plate has been ghost-toggled to active.
  (exists (?p plate)
    (and (controls ?p ?blower)
         (ghost-toggled-active ?p))))


(define-query blower-activated-by-ghost (?blower)
  ;; Returns t if blower is currently active due to ghost plate toggle.
  ;; Used to enforce recording-phase physics on ghost agent.
  (and (active ?blower)
       (exists (?p plate)
         (and (controls ?p ?blower)
              (ghost-toggled-active ?p)))))


(define-query recording-playback-valid? ()
  ;; Validates that all real agent moves through blower-controlled paths
  ;; were legal given the recording-final blower states.
  ;; Returns t if valid, nil if any move was illegal.
  (do (bind (moves-pending-validation $moves))
      (not (ww-loop for $move in $moves
                    thereis (playback-blower-active (third $move))))))


;;;; UPDATE FUNCTIONS ;;;;


(define-update propagate-changes! ()
  (ww-loop for $iteration from 1 to 10
           do (if (not (propagate-consequences!))
                (return))  ;convergence achieved
           finally (inconsistent-state)))  ;no convergence, mark state inconsistent for pruning


(define-update propagate-consequences! ()
  ;; All functions must execute in order; returns t if any change occurred
  (some #'identity
        (mapcar (lambda (fn) (funcall fn state))
                (list #'update-plate-controlled-devices!
                      #'blow-objects-if-active!
                      #'create-missing-beams!
                      #'remove-orphaned-beams!
                      #'recalculate-all-beams!          ;always returns nil
                      #'update-beams-if-interference!   ;always returns nil
                      #'deactivate-receivers-that-lost-power!
                      #'deactivate-unpowered-relays!
                      #'activate-receivers-that-gained-power!
                      #'activate-reachable-relays!))))


(define-update update-plate-controlled-devices! ()
  ;; Propagates plate activation state to controlled gates and blowers
  ;; Returns t if any change occurred, nil otherwise
  (do
    (doall (?p plate)
      (if (active ?p)
        ;; Plate is active: open controlled gates, activate controlled blowers
        (do (doall (?g gate)
              (if (and (controls ?p ?g) (not (open ?g)))
                (do (open ?g)
                    (assign $changed t))))
            (doall (?b blower)
              (if (and (controls ?p ?b) (not (active ?b)))
                (do (active ?b)
                    (assign $changed t)))))
        ;; Plate is inactive: close controlled gates, deactivate controlled blowers
        (do (doall (?g gate)
              (if (and (controls ?p ?g) (open ?g))
                (do (not (open ?g))
                    (assign $changed t))))
            (doall (?b blower)
              (if (and (controls ?p ?b) (active ?b))
                (do (not (active ?b))
                    (assign $changed t)))))))
    $changed))


(define-update blow-objects-if-active! ()
  ;; Blows objects according to blows> relation when blower is active.
  ;; Real agents/cargo: always subject to active blowers.
  ;; Ghost agents/cargo: only subject if ghost activated the blower
  ;;   (recording-phase physics); immune if real agent activated it
  ;;   (playback-phase, ghost follows pre-recorded trajectory).
  ;; Returns t if any object was moved, nil otherwise.
  (do
    (doall (?b blower)
      (if (and (active ?b)
               (bind (blows> ?b $from $to)))
        (do ;; Real objects always affected
            (doall (?a real-agent)
              (if (loc ?a $from)
                (do (loc ?a $to)
                    (assign $moved-any t))))
            (doall (?c real-cargo)
              (if (loc ?c $from)
                (do (loc ?c $to)
                    (assign $moved-any t))))
            ;; Ghost objects only affected if ghost activated blower
            (if (blower-activated-by-ghost ?b)
              (do (doall (?a ghost-agent)
                    (if (loc ?a $from)
                      (do (loc ?a $to)
                          (assign $moved-any t))))
                  (doall (?c ghost-cargo)
                    (if (loc ?c $from)
                      (do (loc ?c $to)
                          (assign $moved-any t)))))))))
    $moved-any))


(define-update create-missing-beams! ()
  ;; Creates beams for active sources paired with targets where no beam exists yet
  ;; Returns t if any beams were created, nil otherwise
  (do
    (doall (?src terminus)
      (doall (?tgt terminus)
        (if (and (different ?src ?tgt)
                 (or (paired ?src ?tgt) (paired ?tgt ?src)))  ; Pairing exists (bidirectional)
          ;; Have a pairing - check if source can emit and beam should exist
          (do (assign $source-hue (get-hue-if-source ?src))
              (if (and $source-hue                              ; Source is active
                       (target ?tgt)
                       (not (beam-exists-p ?src ?tgt))          ; Beam doesn't exist yet
                       (not (relay-is-powered-by ?src ?tgt)))  ; ?tgt is not powering ?src
                ;; Create beam: source is transmitter (always active) or powered connector
                (do (create-beam-segment-p! ?src ?tgt)
                    (assign $created-any t)))))))
    $created-any))


(define-update remove-orphaned-beams! ()
  ;; Removes beams whose pairing no longer exists or whose source lost power
  ;; Returns t if any beams were removed, nil otherwise
  (do
    (doall (?b (get-current-beams))
      (do (bind (beam-segment> ?b $src $tgt $end-x $end-y))
          ;; Determine if beam should be removed
          (assign $should-remove nil)
          ;; Reason 1: Pairing no longer exists (check bidirectional)
          (if (not (or (paired $src $tgt) (paired $tgt $src)))
            (assign $should-remove t))
          ;; Reason 2: Source is a relay that lost power (no color binding)
          (if (and (relay $src)
                   (not (bind (color $src $hue))))
            (assign $should-remove t))
          ;; Execute removal if needed
          (if $should-remove
            (do (remove-beam-segment-p! ?b)
                (assign $removed-any t)))))
    $removed-any))


(define-update recalculate-all-beams! ()
  (do (doall (?b (get-current-beams))
        (do (bind (beam-segment> ?b $source $target $old-end-x $old-end-y))
            ;; Get source coordinates
            (mv-assign ($source-x $source-y) (get-coordinates $source))
            ;; Get target coordinates  
            (mv-assign ($target-x $target-y) (get-coordinates $target))
            ;; Recalculate endpoint using current gate/beam states
            (mv-assign ($new-end-x $new-end-y)
                    (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
            ;; Update beam segment if endpoint changed
            (if (or (/= $new-end-x $old-end-x)
                    (/= $new-end-y $old-end-y))
              (beam-segment> ?b $source $target $new-end-x $new-end-y))))
      nil))  ;must return nil


(define-update update-beams-if-interference! ()
  ;; Resolves all beam-beam intersections using iterative fixed-point computation.
  ;; Each iteration validates intersections against current effective endpoints,
  ;; converging when no beam's effective endpoint changes.  This avoids the
  ;; cascading phantom problem where a single-pass approach uses an invalid
  ;; (phantom) intersection to deflate a beam's effective-t.
  ;; Detects period-2 oscillation (mutual blocking cycles) and resolves by
  ;; taking element-wise min of the two alternating states.
  (do
    ;; Phase 1: Collect all geometric intersections
    (assign $all-intersections (collect-all-beam-intersections))
    ;; Phase 2: Build per-beam geometry cache and obstacle-only t parameters
    (assign $obstacle-t (make-hash-table :test 'eq))
    (assign $effective-t (make-hash-table :test 'eq))
    (assign $beam-geometry (make-hash-table :test 'eq))  ;beam -> (src-x src-y dx dy)
    (doall (?b (get-current-beams))
      (do (bind (beam-segment> ?b $src $tgt $old-end-x $old-end-y))
          (mv-assign ($src-x $src-y $src-z) (get-coordinates $src))
          (mv-assign ($tgt-x $tgt-y $tgt-z) (get-coordinates $tgt))
          (assign $dx (- $tgt-x $src-x))
          (assign $dy (- $tgt-y $src-y))
          (setf (gethash ?b $beam-geometry) (list $src-x $src-y $dx $dy))
          (assign $length-sq (+ (* $dx $dx) (* $dy $dy)))
          (if (< $length-sq 1e-20)
            (assign $t0 0)
            (do (assign $curr-dx (- $old-end-x $src-x))
                (assign $curr-dy (- $old-end-y $src-y))
                (assign $dot (+ (* $curr-dx $dx) (* $curr-dy $dy)))
                (assign $t0 (/ $dot $length-sq))))
          (setf (gethash ?b $obstacle-t) $t0)
          (setf (gethash ?b $effective-t) $t0)))
    ;; Phase 3: Iterative fixed-point resolution of beam-beam interference
    (assign $prev1-t (make-hash-table :test 'eq))  ;values from 1 iteration ago
    (assign $prev2-t (make-hash-table :test 'eq))  ;values from 2 iterations ago
    (ww-loop for $iteration from 1 to 10 do  ;bounded; converges in <= num-beams iterations
      (assign $changed nil)
      (doall (?b (get-current-beams))
        (do (assign $new-t (gethash ?b $obstacle-t))  ;start from obstacle upper bound
            (ww-loop for $intersection in $all-intersections do
              (assign $beam1 (first $intersection))
              (assign $beam2 (second $intersection))
              (assign $int-x (third $intersection))
              (assign $int-y (fourth $intersection))
              ;; Recompute full-path t parameters from intersection point so all
              ;; comparisons are in the same parameter space even when beams were
              ;; obstacle-truncated before interference resolution.
              (assign $geom1 (gethash $beam1 $beam-geometry))
              (assign $geom2 (gethash $beam2 $beam-geometry))
              (assign $src1-x (first $geom1))
              (assign $src1-y (second $geom1))
              (assign $dx1 (third $geom1))
              (assign $dy1 (fourth $geom1))
              (assign $src2-x (first $geom2))
              (assign $src2-y (second $geom2))
              (assign $dx2 (third $geom2))
              (assign $dy2 (fourth $geom2))
              (assign $len1-sq (+ (* $dx1 $dx1) (* $dy1 $dy1)))
              (assign $len2-sq (+ (* $dx2 $dx2) (* $dy2 $dy2)))
              (if (< $len1-sq 1e-20)
                (assign $t1-full nil)
                (do (assign $vx1 (- $int-x $src1-x))
                    (assign $vy1 (- $int-y $src1-y))
                    (assign $t1-full (/ (+ (* $vx1 $dx1) (* $vy1 $dy1)) $len1-sq))))
              (if (< $len2-sq 1e-20)
                (assign $t2-full nil)
                (do (assign $vx2 (- $int-x $src2-x))
                    (assign $vy2 (- $int-y $src2-y))
                    (assign $t2-full (/ (+ (* $vx2 $dx2) (* $vy2 $dy2)) $len2-sq))))
              (if (eql ?b $beam1)
                (do (assign $t-param $t1-full)
                    (assign $blocker $beam2)
                    (assign $blocker-t $t2-full))
                (if (eql ?b $beam2)
                  (do (assign $t-param $t2-full)
                      (assign $blocker $beam1)
                      (assign $blocker-t $t1-full))
                  (assign $t-param nil)))
              ;; Valid only if blocker's effective endpoint reaches the crossing
              (if (and $t-param
                       (>= (gethash $blocker $effective-t) $blocker-t)
                       (< $t-param $new-t))
                (assign $new-t $t-param)))
            (if (/= $new-t (gethash ?b $effective-t))
              (do (setf (gethash ?b $effective-t) $new-t)
                  (assign $changed t)))))
      (if (not $changed)
        (return))
      ;; Detect period-2 oscillation: current state matches state from 2 iterations ago
      (if (and (> $iteration 2)
               (not (exists (?b (get-current-beams))
                      (/= (gethash ?b $effective-t)
                          (gethash ?b $prev2-t -1)))))
        ;; Oscillation detected: resolve by element-wise min of the two alternating
        ;; states (current = state A, prev1-t = state B).  Crossing beams that
        ;; appear truncated in either state are truly intersecting, so min is correct.
        (do (doall (?b (get-current-beams))
              (do (assign $alt-val (gethash ?b $prev1-t))
                  (if (< $alt-val (gethash ?b $effective-t))
                    (setf (gethash ?b $effective-t) $alt-val))))
            (return)))
      ;; Rotate saved states: prev2 <- prev1, prev1 <- current
      (doall (?b (get-current-beams))
        (do (setf (gethash ?b $prev2-t) (gethash ?b $prev1-t))
            (setf (gethash ?b $prev1-t) (gethash ?b $effective-t)))))
    ;; Phase 4: Apply converged effective-t values to update beam endpoints
    (doall (?b (get-current-beams))
      (do (bind (beam-segment> ?b $src $tgt $old-end-x $old-end-y))
          (assign $geom (gethash ?b $beam-geometry))
          (assign $src-x (first $geom))
          (assign $src-y (second $geom))
          (assign $dx (third $geom))
          (assign $dy (fourth $geom))
          (assign $new-end-x (+ $src-x (* (gethash ?b $effective-t) $dx)))
          (assign $new-end-y (+ $src-y (* (gethash ?b $effective-t) $dy)))
          (if (or (/= $new-end-x $old-end-x)
                  (/= $new-end-y $old-end-y))
            (beam-segment> ?b $src $tgt $new-end-x $new-end-y))))
    nil))  ;must return nil


(define-update deactivate-receivers-that-lost-power! ()
  ;; Returns t if any receiver was deactivated, nil otherwise
  (do
    (doall (?r receiver)
      (if (and (active ?r)
               (not (beam-reaches-receiver ?r)))
        (do (deactivate-receiver! ?r)
            (assign $any-deactivated t))))
    $any-deactivated))


(define-update deactivate-unpowered-relays! ()
  ;; Returns t if any relay was deactivated, nil otherwise
  ;; Uses forward reachability from transmitters to detect true power
  (do
    ;; Get set of relays with valid transmitter power
    (assign $powered-relays (collect-transmitter-powered-relays))
    (doall (?r relay)
      (if (bind (color ?r $c-hue))
        ;; Relay is currently active - verify it has transmitter power
        (if (not (member ?r $powered-relays))
          ;; No path to transmitter - deactivate
          (do
            (not (color ?r $c-hue))
            (assign $deactivated-any t)))))
    $deactivated-any))


(define-update activate-receivers-that-gained-power! ()
  ;; Returns t if any receiver was activated, nil otherwise
  (do
    (doall (?r receiver)
      (if (and (not (active ?r))
               (beam-reaches-receiver ?r))
        (do (active ?r)
            (doall (?g gate)
              (if (controls ?r ?g)
                (open ?g)))
            (assign $any-activated t))))
    $any-activated))


(define-update activate-reachable-relays! ()
  ;; Returns t if any connector was activated, nil otherwise
  ;; Now uses consensus logic: connector only activates if ALL reaching beams have same hue
  (do
    (doall (?r relay)
      (if (not (bind (color ?r $existing-hue)))
        (do
          ;; Collect all hues from beams that reach this connector
          (assign $reaching-hues nil)
          ;; Check all paired termini that could be sources
          (doall (?src terminus)
            (if (or (paired ?r ?src) (paired ?src ?r))  ; Pairing exists (bidirectional)
              (do
                ;; Get source hue if it's an active source (transmitter or powered connector)
                (assign $src-hue (get-hue-if-source ?src))
                ;; If source has hue AND beam reaches connector, collect hue
                (if (and $src-hue
                         (beam-reaches-target ?src ?r))
                  (push $src-hue $reaching-hues)))))
          ;; Check for consensus among all reaching hues
          (assign $consensus-hue (resolve-consensus-hue $reaching-hues))
          ;; Only activate if consensus achieved (all hues identical)
          (if $consensus-hue
            (do (color ?r $consensus-hue)
                (assign $activated-any t))))))
    $activated-any))


(define-update deactivate-receiver! (?receiver)
  (do (not (active ?receiver))
      (doall (?g gate)
        (if (controls ?receiver ?g)
          (not (open ?g))))))


(define-update disconnect-connector! (?cargo)
  ;; Clears all pairings and deactivates connector when picked up
  (do (doall (?t terminus)
        (if (paired ?cargo ?t)
          (not (paired ?cargo ?t))))
      (if (bind (color ?cargo $hue))
        (not (color ?cargo $hue)))))


(define-update create-beam-segment-p! (?source ?target)
  ; Create a beam segment from source using the first free pooled beam, and return its name.
  (do
    ;; Select the first pooled beam not currently in use
    (bind (current-beams $current-beams))
    (doall (?b beam)
      (if (and (not $new-beam)
               (not (member ?b $current-beams)))
        (assign $new-beam ?b)))
    ;; Calculate beam path and intersection
    (mv-assign ($source-x $source-y) (get-coordinates ?source))
    (mv-assign ($target-x $target-y) (get-coordinates ?target))
    (mv-assign ($end-x $end-y) (find-first-obstacle-intersection $source-x $source-y $target-x $target-y))
    ;; Create beam relations
    (beam-segment> $new-beam ?source ?target $end-x $end-y)
    (current-beams (cons $new-beam $current-beams))
    $new-beam))


(define-update remove-beam-segment-p! (?beam)
  (if (bind (beam-segment> ?beam $source $target $end-x $end-y))
    (do (not (beam-segment> ?beam $source $target $end-x $end-y))
        (bind (current-beams $beams))
        (current-beams (substitute nil ?beam $beams))
        t)
    nil))


(define-update record-move-for-playback-validation! (?agent ?area1 ?area2)
  ;; Records blower-path moves by real agents for playback validation.
  ;; Only records if agent is real and path is blower-controlled.
  (if (real-agent ?agent)
    (do (assign $blower (find-blower-on-path ?area1 ?area2))
        (if $blower
          (do (bind (moves-pending-validation $moves))
              (moves-pending-validation (cons (list ?area1 ?area2 $blower) $moves)))))))


(define-update log-if-ghost-toggle! (?agent ?plate)
  ;; Track ghost toggle parity for playback validation.
  ;; Only affects state when agent is a ghost-agent.
  (if (ghost-agent ?agent)
    (if (ghost-toggled-active ?plate)
      (not (ghost-toggled-active ?plate))
      (ghost-toggled-active ?plate))))


;;;; ACTIONS ;;;;


(define-action connect-to-1-terminus
    1
  (?agent agent ?terminus terminus)
  (and (bind (holds ?agent $cargo))
       (same-type ?agent $cargo)
       (different $cargo ?terminus)
       (bind (loc ?agent $area))
       (placeable $cargo $area)
       (selectable ?agent $area ?terminus))
  (?agent $cargo ?terminus $area)
  (assert (not (holds ?agent $cargo))
          (loc $cargo $area)
          (paired $cargo ?terminus)
          (propagate-changes!)))


(define-action connect-to-2-terminus
    1
  (?agent agent (combination (?t1 ?t2) terminus))
  (and (bind (holds ?agent $cargo))
       (same-type ?agent $cargo)
       (different $cargo ?t1)
       (different $cargo ?t2)
       (bind (loc ?agent $area))
       (placeable $cargo $area)
       (selectable ?agent $area ?t1)
       (selectable ?agent $area ?t2))
  (?agent $cargo ?t1 ?t2 $area)
  (assert (not (holds ?agent $cargo))
          (loc $cargo $area)
          (paired $cargo ?t1)
          (paired $cargo ?t2)
          (propagate-changes!)))


(define-action connect-to-3-terminus
    1
  (?agent agent (combination (?t1 ?t2 ?t3) terminus))
  (and (bind (holds ?agent $cargo))
       (same-type ?agent $cargo)
       (different $cargo ?t1)
       (different $cargo ?t2)
       (different $cargo ?t3)
       (bind (loc ?agent $area))
       (placeable $cargo $area)
       (selectable ?agent $area ?t1)
       (selectable ?agent $area ?t2)
       (selectable ?agent $area ?t3))
  (?agent $cargo ?t1 ?t2 ?t3 $area)
  (assert (not (holds ?agent $cargo))
          (loc $cargo $area)
          (paired $cargo ?t1)
          (paired $cargo ?t2)
          (paired $cargo ?t3)
          (propagate-changes!)))


(define-action pickup-connector
    1
  (?agent agent ?cargo cargo)
  (and (same-type ?agent ?cargo)
       (not (bind (holds ?agent $held)))
       (bind (loc ?agent $area))
       (loc ?cargo $area))
  (?agent ?cargo $area)
  (assert (holds ?agent ?cargo)
          (not (loc ?cargo $area))
          (disconnect-connector! ?cargo)
          (propagate-changes!)))


(define-action drop
    1
  (?agent agent)
  (and (bind (holds ?agent $cargo))
       (bind (loc ?agent $area))
       (placeable $cargo $area))
  (?agent $cargo $area)
  (assert (not (holds ?agent $cargo))
          (loc $cargo $area)
          (propagate-changes!)))


(define-action toggle-plate
  1
  (?agent agent ?plate plate)
  (and (bind (loc ?agent $area))
       (bind (coords> $area $agent-x $agent-y))
       (bind (coords> ?plate $plate-x $plate-y))
       (= $agent-x $plate-x)
       (= $agent-y $plate-y))
  (?agent ?plate)
  (assert (if (active ?plate)
            (not (active ?plate))
            (active ?plate))
          (log-if-ghost-toggle! ?agent ?plate)  ;tracks ghost toggling for playback validation
          (propagate-changes!)))


(define-action move
    1
  (?agent agent ?area2 area)
  (and (bind (loc ?agent $area1))
       (different $area1 ?area2)
       (accessible ?agent $area1 ?area2))
  (?agent $area1 ?area2)
  (assert (loc ?agent ?area2)
          (record-move-for-playback-validation! ?agent $area1 ?area2)
          (propagate-changes!)))


;;;; INITIALIZATION ;;;;


(define-init
  ;; Dynamic state (agent-manipulable or derived)
  (loc agent1 area1)
  (loc agent1* area1)
  (loc connector1 area1)
  (loc connector1* area1)
  (current-beams ())  ; Empty - can be populated by init-action, if exist initially
  (moves-pending-validation ())  ;empty list of recorded blower-path moves

  ;; Static spatial configuration
  (coords> area1  4 20)
  (coords> area2 11 14)
  (coords> area3 21 8)
  (coords> area4 22 3)
  (coords> area5 14 3)
  (accessible0 area1 area2)  ;chain moves between areas to lower search branching
  (accessible1 area2 blower1 area3)
  (accessible0 area3 area4)
  (accessible1 area4 gate2 area5)

  ;; Static fixture configuration
  (coords> recorder1 4 20)
  (coords> transmitter1 19 19)
  (coords> plate1 11 14)
  (coords> repeater1 3 8)
  (apparatus-coords> repeater1 3 8)
  (coords> blower1 23 8)
  (coords> receiver1 21 0)
  (controls plate1 gate1)
  (controls plate1 blower1)
  (controls receiver1 gate2)
  (blows> blower1 area3 area1)
  (gate-segment> gate1 12 21 12 17)
  (gate-segment> gate2 17 6 17 0)
  (wall-segment> wall1 19 21 19 17)
  (wall-segment> wall2 19 17 12 17)
  (wall-segment> wall3 12 17 12 10)
  (wall-segment> wall4 12 10 23 10)
  (wall-segment> wall5 23 10 23 0)
  (wall-segment> wall6 23 0 0 0)
  (wall-segment> wall7 0 0 0 21)
  (wall-segment> wall8 0 21 19 21)
  (wall-segment> wall9 12 0 12 6)
  (wall-segment> wall10 12 6 19 6)
  (chroma transmitter1 blue)
  (chroma receiver1 blue)
  
  ;; Line-of-sight relationships (connector area to fixture)
  (los1 area1 gate1 transmitter1)  ;include only necessary los relations
  (los0 area1 repeater1)
  (los0 area3 repeater1)
  (los0 area3 receiver1)
  
  ;; Visibility relationships (connector area to area)
  (visible0 area1 area2)
  (visible0 area3 area4)
  (visible1 area4 gate2 area5)
)


;;;; GOAL ;;;;


(define-goal
  (and (loc agent1 area5)
       (recording-playback-valid?)))  ;if invalid state, return nil, continue searching


#|  NOTES:
Role of recording-playback-valid?
This query function serves as a deferred constraint validator for Talos Principle ghost-agent mechanics. It enforces a critical rule: the real agent's moves through blower-controlled paths must remain legal when the ghost replays its recorded sequence.
The Problem It Solves
In the game mechanics:

The ghost agent (agent1*) records a sequence of actions first
Those actions are later played back while the real agent (agent1) acts simultaneously
During recording, the ghost might toggle plates that control blowers
When playback begins, the environment reflects the final state the ghost left it in

The issue: The real agent may traverse a blower-controlled path (e.g., area2 → area3 via blower1) before the ghost has toggled the plate. At that moment, the blower is off, so the move succeeds. However, if the ghost eventually toggles that plate ON, then during actual playback the blower would be active from the start—making that same move impossible (the agent would be blown back).
How It Works

During search: Every time the real agent moves through a blower-controlled path, record-move-for-playback-validation! logs it to moves-pending-validation
Meanwhile: log-if-ghost-toggle! tracks which plates the ghost has toggled (via ghost-toggled-active)
At goal check: recording-playback-valid? examines all logged moves and verifies that none of them pass through blowers that would be active at playback start (i.e., via playback-blower-active)
If any recorded real-agent move would be blocked by a ghost-activated blower, the goal returns nil, forcing the planner to continue searching for a valid solution sequence.

In Essence
It ensures temporal consistency—the solution found during planning must actually be executable when the recording is replayed with both agents acting simultaneously.
|#
