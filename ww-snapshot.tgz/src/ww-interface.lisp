;;; Filename: ww-interface.lisp

;;; Misc file handling & test managment functions


(in-package :wouldwork)


(defparameter *globals-file*
  (instance-vals-file (asdf:system-source-directory :wouldwork))
  "In the vals.lisp file of this package the values of parameters
     are stored as a list.  The filename carries CL-USER::*WW-INSTANCE-SUFFIX* when the
     WOULDWORK_INSTANCE environment variable is set, so a concurrently-run SBCL process
     keeps its own settings file.
   This should preserve when reloading the package for problems
   the values of these global variables.")


(defvar *refreshing* nil
  "Flag indicating refresh is reloading definitions while preserving current settings.")


(defun help ()  ;;; text which appears if user enters (help)
  (format t "~%
THE LIST OF WOULDWORK COMMANDS RECOGNIZED IN THE REPL:

(run <problem-name>) eg, (run \"blocks3\") or (run blocks3)
   -- load and solve a problem 

(run-test-problems) alias (test)
   -- solve all test problems

(test-commands)
  -- run a series of tests to exercise potential user REPL commands

(list-all-problems), or (probs) for the bare list
   -- lists all currently specified problems in the probs and test
      directories (use these names with run or stage)

(stage <problem-name>) eg, (stage \"blocks3\") or (stage blocks3)
  -- loads a problem into wouldwork in preparation for solving or debugging,
     reinitializing settings from the problem specification without attempting
     to solve it

(solve)
  -- attempts to solve the currently staged problem

(solve-subgoal <goal>)
  -- searches for and retains the next ordered milestone in single-threaded mode

(solve-subgoal <start-state> <goal>)
  -- one-off search (serial or parallel) for <goal> from <start-state> (a problem-state
     form, an unquoted list of all dynamic facts, or a saved search-checkpoint);
     discards any active goal chain. With a search-checkpoint, returns the next
     checkpoint on success or the unchanged checkpoint on exhaustion.

(capture-search-checkpoint)
  -- captures a live milestone chain or a freshly staged initial state

(export-search-checkpoint <checkpoint> <txt-file>)
  -- saves the exact endpoint signatures and accumulated action history

(import-search-checkpoint <txt-file>)
  -- returns a checkpoint by replay, with no search; stage and set threads first

(validate-search-checkpoint <checkpoint>)
  -- replays the accumulated path from its origin and checks the original goal

(solve-subgoal <goal>) continuation caution:
     A milestone search the depth cutoff truncated proves nothing: it rejects no
     checkpoint and leaves the preceding chain untouched, so raise *depth-cutoff*
     and reissue the same command

(export-subgoal-progress <txt-file>)
  -- writes the active accepted milestone chain as readable, replayable text

(import-subgoal-progress <txt-file>)
  -- replays and restores exported milestones into a freshly staged problem

(ww-undo)
  -- reverses the last goal-chaining command or imported checkpoint chain

(get-probs-folder-path)
   -- the location where all problem specification files should appear
      (test problems live in category subfolders of the test folder, per (get-test-folder-path),
       with Talos test problems in its talos subfolder, per (get-talos-test-folder-path))

(profile)
   -- employs a basic profiler on the currently staged problem,
      for analyzing the efficiency of action rules in the problem specification

(display-current-parameters) alias (params)
   -- displays all parameters associated with the currently staged problem

(refresh)
  -- reloads the current problem specification file after editing it, while
     preserving the current parameter settings

(ww-reset)
  -- discards generated problem and saved settings, then reloads the default problem


(ww-set <problem-parameter> <new-value>)
   -- set a problem parameter to a new value
   eg, (ww-set *solution-type* <one of first, every, all-paths, min-length, min-time,
                                       min-value, max-value, or a positive integer N
                                       to find exactly N solutions;
                                       all-paths requires depth-first + graph + depth-cutoff>0>)
       (ww-set *tree-or-graph* <one of tree or graph>)
       (ww-set *bt-cycle-check* <nil (default, immediate inverse checking) or t (full-path checking)>)
       (ww-set *depth-cutoff* <positive integer (search to specified depth) or
                                                 0 (no depth limit)>)
       (ww-set *progress-reporting-interval* <nil (default: report on a time schedule whose gaps
                                                   double) or a positive integer N (report
                                                   every N states)>)
       (ww-set *progress-first-report* <seconds before the first adaptive report; default 10>)
       (ww-set *randomize-search* <t (random depth-first search) or
                                   nil (standard depth-first search)>)
       (ww-set *branch* <number (eg, search only branch 1 (first) of 10 initial branches) or
                         0 (search all branches)>)
       (ww-set *time-limit* <seconds after which a search stops, leaving it inconclusive, or
                             0 (no time limit)>)
       (ww-set *debug* <one of 0 (no debugging), 1-4 (increasing debugging info),
                               5 (step through search)>)
       (ww-set *symmetry-pruning* <t (prune symmetric states) or
                                    nil (don't prune symmetric states>)
       (ww-set *max-recorder-cycles* <positive integer limiting recorder starts per path,
                                      or nil for no limit>)
       (ww-set *recorder-prefix-pruning* <t (also prune unplayable open recording prefixes) or
                                          nil (validate only completed recorder cycles)>)
       (ww-set *max-connector-pairings* <positive integer limiting pairings per connector>)
       (ww-set *probe* (<action name> <instantiations> <depth> &optional <count>))
           -- probe enables debugging when a state is reached during search
              see ww-settings.lisp and User Manual for probe format examples

Note that setting problem parameters at the REPL with ww-set will override
any such settings appearing in the problem specification file until the problem
is staged again.
"))

(defun lookup (key plist &key (test #'string-equal) (default))
  "Key value lookup in plist with #'string= or any other function as test.
   The plist-related getf can only handle eql."
  (let ((res nil)
	(foundp nil))
    (loop for (k v) on plist by #'cddr
	  when (funcall test k key)
	    do (setf res v
		     foundp t)
	  finally (return (values (if res res default) foundp)))))


;; -------------------- pathname handling ---------------------------- ;;

  
(Defun get-src-folder-path ()
  (add-dir (asdf:system-source-directory :wouldwork) "src"))


(defun get-probs-folder-path ()
  (add-dir (asdf:system-source-directory :wouldwork) "probs"))


(defun get-test-folder-path ()
  (add-dir (asdf:system-source-directory :wouldwork) "test"))


(defun get-talos-test-folder-path ()
  (add-dir (get-test-folder-path) "talos"))

   
(defun add-dir (root dir)
  "Add to absolute path an additional directory"
  (merge-pathnames (make-pathname :directory `(:relative ,dir)) root))
  
(defun add-file (root file)
  "Add to absolute path a filename"
  (merge-pathnames (pathname file) root))
  
(defun directory-exists-p (directory)
  "Returns pathname if the directory exists and is a directory.
   Currently only works with SBCL - but not CLISP!"
  (let ((path (pathname directory)))
    (and (probe-file path)
         (string-suffix-p "/" (format nil "~a" (probe-file path))))))
  
(defun in-src (filename)
  "Shortcut to add filename to current package directory's src folder"   
  (add-file (get-src-folder-path) filename))


;; --------------------- file handling ------------------------------- ;;


(defun copy-file-content (source-file target-file)
  "Replace the content of target-file by the content of source-file."
  (with-open-file (in source-file :direction :input)
    (with-open-file (out target-file :direction :output :if-exists :supersede)
      (loop for line = (read-line in nil nil)
	    while line
	    do (write-line line out)))))


(defun save-to-file (list filename)
  (with-open-file (out filename :direction :output :if-exists :supersede :if-does-not-exist :create)
    (format out "~S" list)))


(defun read-from-file (filename &optional (default '()))
  (if (probe-file filename)  ; Check if the file exists
      (with-open-file (stream filename :direction :input)
        (read stream))
      ;; If file doesn't exist, create it with the default values
      (progn
        (save-to-file default filename)
        default)))


(defun display-globals ()
  (format t "~&*problem-name* ~A~% 
               *depth-cutoff* ~A~%
               *algorithm* ~A~%
               *bt-cycle-check* ~A~%
               *tree-or-graph* ~A~%
               *problem-type* ~A~%
               *solution-type* ~A~%
               *progress-reporting-interval* ~A~%
               *randomize-search* ~A~%
               *branch* ~A~%
               *probe* ~A~%
               *symmetry-pruning* ~A~%
               *max-recorder-cycles* ~A~%
               *recorder-prefix-pruning* ~A~%
               *debug* ~A~2%"
            *problem-name* *depth-cutoff* *algorithm* *bt-cycle-check* *tree-or-graph* *problem-type*
            *solution-type* *progress-reporting-interval* *randomize-search* *branch* 
            *probe* *symmetry-pruning* *max-recorder-cycles* *recorder-prefix-pruning*
            *debug*))


(defun refresh ()
  "Refreshes the current problem.lisp file--eg, after editing it.
   Preserves the current parameter settings instead of reapplying problem-file settings."
  (reject-worker-read-write 'refresh)
  (save-globals)
  (setf *goal* nil
        *final-goal* nil)
  (setf *refreshing* t)
  (unwind-protect
      (with-silenced-compilation
        (load-problem (string *problem-name*)))
    (setf *refreshing* nil)))                            ; cleanup
  

(defun reset-parameters ()
  "Reset every managed problem parameter to its authoritative default."
  (reset-problem-parameters-to-defaults))


(defun encode-parameter-value (value)
  "Encode finite parameter trees, including hash-table goal fluents, as data."
  (typecase value
    (cons (list :cons (encode-parameter-value (car value))
                      (encode-parameter-value (cdr value))))
    (hash-table
     (list :hash-table (hash-table-test value) (hash-table-size value)
           (hash-table-rehash-size value) (hash-table-rehash-threshold value)
           (sb-ext:hash-table-synchronized-p value)
           (loop for key being the hash-keys of value using (hash-value item)
                 collect (cons (encode-parameter-value key)
                               (encode-parameter-value item)))))
    (t (list :value value))))


(defun decode-parameter-table (encoded)
  (destructuring-bind (tag test size rehash-size threshold synchronized entries) encoded
    (declare (ignore tag))
    (let ((table (make-hash-table :test test :size size :rehash-size rehash-size
                                 :rehash-threshold threshold :synchronized synchronized)))
      (dolist (entry entries)
        (setf (gethash (decode-parameter-value (car entry)) table)
              (decode-parameter-value (cdr entry))))
      table)))


(defun decode-parameter-value (encoded)
  (ecase (first encoded)
    (:cons (cons (decode-parameter-value (second encoded))
                 (decode-parameter-value (third encoded))))
    (:hash-table (decode-parameter-table encoded))
    (:value (second encoded))))


(defun save-globals ()
  "Save parameter data without printing unreadable hash-table goal objects."
  (let ((*print-readably* t) (*print-circle* t))
    (save-to-file
      (mapcar (lambda (name)
                (if (eq name '*goal*)
                    (list :wouldwork-goal-v1 (encode-parameter-value *goal*))
                    (symbol-value name)))
              *persisted-problem-parameters*)
      *globals-file*)))


(defun migrate-retired-recorder-settings (params)
  "Remove retired recorder settings while preserving a saved cycle maximum."
  (cond
    ((and (>= (length params) 16)
          (member (nth 14 params) '(nil t))
          (typep (nth 15 params) '(integer 1 *)))
      (append (subseq params 0 14)
              (list (nth 15 params))
              (nthcdr 15 *default-parameters*)))
    ((and (= (length params) 15)
          (member (nth 14 params) '(nil t)))
      (append (subseq params 0 14)
              (nthcdr 14 *default-parameters*)))
    (t params)))


(defun normalize-persisted-problem-parameters (params)
  "Migrate old layouts, fill missing defaults, and ignore retired trailing values."
  (let* ((migrated (migrate-retired-recorder-settings params))
         (padded (if (< (length migrated) (length *default-parameters*))
                   (append migrated
                           (nthcdr (length migrated) *default-parameters*))
                   migrated)))
    (subseq padded 0 (length *default-parameters*))))


(defun read-globals ()
  "Read and setf values for global variables from vals.lisp file."
  (let* ((saved-params (read-from-file *globals-file* *default-parameters*))
         (current-params
           (normalize-persisted-problem-parameters saved-params)))
    (loop for parameter in *persisted-problem-parameters*
          for value in current-params
          do (set parameter
                  (if (and (eq parameter '*goal*) (consp value)
                           (eq (first value) :wouldwork-goal-v1))
                      (decode-parameter-value (second value))
                      value)))))


;; -------------------- problem.lisp file handling ------------------------ ;;


(defparameter *problem-folder-paths* (cons (get-probs-folder-path)
                                           (test-folder-paths (asdf:system-source-directory :wouldwork)))
"This variable holds all folder pathnames which can hold problems in this system.
   The user cann add custom folder pathnames to this folder using the function
   `add-problem-folder` and remove by `remove-problem-folder`.
   The Package directory's `probs` and `test` folders, and every folder directly below `test`,
   however, are always present at startup.")


(defun add-problem-folder (folder-path)
  "Adds an additional path to a folder containing problem-*.lisp files to the
   global list `*problem-folder-paths*`."
  (let ((path (pathname folder-path)))
    (if (directory-exists-p path)
        (push (probe-file path) *problem-folder-paths*)
        (format t "\"~a\" is either not a path to a folder or there are other problems."
                path))))


(defun remove-problem-folder (folder-path)
  "Removes folder-path from global `*problem-folder-paths*` list.
   It always leaves at least one folder present!"
  (let ((path (probe-file (pathname folder-path))))
    (cond ((<= (length *problem-folder-paths*) 1)
           (Format t "Not removing anything, because *problem-folder-paths* contains only the src folder")
           *problem-folder-paths*)
          (t
           (setf *problem-folder-paths* (remove-if (lambda (p) (string= (format nil "~a" p)
                                                                        (format nil "~a" path)))
                                                   *problem-folder-paths*))
           *problem-folder-paths*))))


(defun list-problem-files-plist (&optional (prefix "problem-") (suffix "lisp"))
  "Return a plist of files in the problem folders that start with 'problem-'.
   The key is the filename without 'problem-' and '.lisp'.
   The value is the full path of the file. Uses the root directory of the 'wouldwork' system."
  (let ((files)
        (result))
    (loop for dir in *problem-folder-paths*
          do (let ((path (format nil "~A~A*.~A" (namestring dir) prefix suffix)))
               (setf files (append (directory path) files))))
    (dolist (file files)
      (let* ((filename (file-namestring file))
             (name (strip-name filename prefix suffix)))
        (when (and (string-prefix-p prefix filename)
                   (string-suffix-p (concatenate 'string "." suffix) filename))
          (push name result)
          (push file result))))
    (nreverse result)))


(defun list-problem-names ()
  (let* ((plist (list-problem-files-plist)))
    (loop for (k nil) on plist by #'cddr
	  collect k)))

(setf (fdefinition 'probs) #'list-problem-names)


(defun project-relative-problem-p (problem-name-str)
  "Whether PROBLEM-NAME-STR names a file below the Wouldwork root."
  (or (find #\/ problem-name-str)
      (find #\\ problem-name-str)))


(defun project-relative-problem-file (problem-name-str)
  "Resolve a project-relative problem path, adding the Lisp extension if absent."
  (let* ((portable-name (substitute #\/ #\\ problem-name-str))
         (relative-path (pathname portable-name))
         (lisp-path (if (pathname-type relative-path)
                      relative-path
                      (make-pathname :type "lisp" :defaults relative-path)))
         (root (asdf:system-source-directory :wouldwork)))
    (probe-file (merge-pathnames lisp-path root))))


(defun resolve-problem-file (problem-name-str)
  "Resolve either a registered problem name or a path below the Wouldwork root."
  (if (project-relative-problem-p problem-name-str)
    (project-relative-problem-file problem-name-str)
    (lookup problem-name-str (list-problem-files-plist))))


(defun load-problem (problem-name-str)
  "Stage a named or project-relative problem file, then reload Wouldwork once.
   The prescan in ww-preliminaries sets *threads* from the problem's top-level
   declaration before the system compiles, so no rebuild is needed afterward.
   Signals an error if the problem load changed the compilation mode anyway.
   Returns T once the problem is loaded, NIL if it could not be staged."
  (reject-worker-read-write 'load-problem)
  (when (ensure-problem-staged problem-name-str)
    (asdf:load-system :wouldwork :force t)
    (unless (eq *load-read-mode* (current-generated-read-mode))
      (error "*threads* changed during problem load; declare (ww-set *threads* N) as a top-level form."))
    t))


(declaim (ftype (function () t) solve))  ;function ww-solve located in searcher.lisp


(defmacro run (problem-name)
  "Stages and solves a user specified problem."
  `(%run ,(if (stringp problem-name)
            problem-name
            (string-downcase (string problem-name)))))


(defun %run (problem-name-str)
  "Stages and solves a user specified problem with default parameters."
  (when (%stage problem-name-str)
    (ww-solve)))


(defmacro stage (problem-name)
  "Loads a specified problem to be subsequently solved, reinitializing settings from its problem spec.
   This allows the user to verify/debug their problem specification, and check the current parameters,
   without asking wouldwork to solve it as run does.
   Once the problem loads correctly, it can then be solved with a follow-up (solve) command."
  `(%stage ,(if (stringp problem-name)
              problem-name
              (string-downcase (string problem-name)))))


(defun %stage (problem-name-str)
  "Loads a specified problem to be subsequently solved, reinitializing settings from its problem spec.
   This allows the user to verify/debug their problem specification, and check the current parameters,
   without asking wouldwork to solve it as run does.
   Once the problem loads correctly, it can then be solved with a follow-up (solve) command."
  (reject-worker-read-write '%stage)
  (let ((problem-file (resolve-problem-file problem-name-str)))
    (unless problem-file
    (format t "The problem ~A was not found." problem-name-str)
    (format t "~&Enter (list-all-problems) for a complete list of problems." )
      (return-from %stage))
    (uiop:delete-file-if-exists *globals-file*)
    (reset-problem-parameters-to-defaults
      (intern (string-upcase (pathname-name problem-file))))
    (with-silenced-compilation
      (load-problem problem-name-str))))


(defun solve ()
  "Solve the current problem, or finish an active goal chain through its policy."
  (reject-worker-read-write 'solve)
  (validate-bt-path-mode)
  (cond
    ((null *final-goal*)
     (ww-solve))
    (*goal-chaining-policy*
     (funcall
       (symbol-function
         (goal-chaining-policy-final-solver *goal-chaining-policy*))))
    (*goal-chain-session*
     (solve-generic-final))
    (t
      ;; Mid-chain: consume the last subgoal result and reinstate the original goal.
      (continue-from-solution *final-goal*)
      (ww-solve)
      (when *solutions-valid*
        (setf *final-goal* nil))
      *solution-paths*)))


(defun solve-restarts (runs seconds &optional (first-seed (random 1000000 (make-random-state t))))  ;CHANGED
  "Solves the staged problem up to RUNS times, each a randomized search stopped after
   SECONDS, the runs seeded FIRST-SEED, FIRST-SEED + 1, and so on.  A problem with a goal
   stops at the first run that finds a solution; a best-value problem keeps the best run's
   states in *best-states*.  Every run is inconclusive: a series that finds nothing proves
   nothing."
  (check-type runs (integer 1))  ;CHANGED
  (check-type seconds (real (0)))  ;CHANGED
  (unless *randomize-search*  ;CHANGED
    (error "SOLVE-RESTARTS needs (ww-set *randomize-search* t)."))  ;CHANGED
  (when (fboundp 'heuristic?)  ;CHANGED
    (error "SOLVE-RESTARTS: heuristic? overrides *randomize-search*, so the runs would repeat each other."))  ;CHANGED
  (let ((*time-limit* seconds)  ;CHANGED
        (results nil)  ;CHANGED
        (best-states nil))  ;CHANGED
    (loop for seed from first-seed below (+ first-seed runs)  ;CHANGED
          do (push (solve-restart-run seed) results)  ;CHANGED
          unless (boundp 'goal-fn)  ;CHANGED
            do (setf best-states (restart-best-states best-states))  ;CHANGED
          until (and (boundp 'goal-fn) *solution-paths*))  ;CHANGED
    (when best-states  ;CHANGED
      (setf *best-states* best-states))  ;CHANGED
    (format t "~2%Restarts: ~D run~:P of ~A sec each~%" (length results) seconds)  ;CHANGED
    (loop for (seed result) in (reverse results)  ;CHANGED
          for run from 1  ;CHANGED
          do (format t "~&  run ~D  seed ~D  ~A~%" run seed result))  ;CHANGED
    (format t "~&~A~%" (if (boundp 'goal-fn)  ;CHANGED
                         "Restarts stop at the first run with a solution."  ;CHANGED
                         "The best run's states are in *best-states*."))  ;CHANGED
    (values)))  ;CHANGED


(defun solve-restart-run (seed)  ;CHANGED
  "Solves once from a random state seeded by SEED; returns (SEED result-description)."
  (setf *random-state* (sb-ext:seed-random-state seed))  ;CHANGED
  (solve)  ;CHANGED
  (list seed  ;CHANGED
        (cond ((not (boundp 'goal-fn))  ;CHANGED
               (format nil "best value ~A" (problem-state.value (first *best-states*))))  ;CHANGED
              (*solution-paths*  ;CHANGED
               (format nil "solution of ~D steps"  ;CHANGED
                       (reduce #'min *solution-paths* :key #'solution.depth)))  ;CHANGED
              (t "no solution"))))  ;CHANGED


(defun restart-best-states (best-states)  ;CHANGED
  "Returns the last run's *best-states* if its best state beats that of BEST-STATES (nil at
   the start), otherwise BEST-STATES."
  (if (or (null best-states)  ;CHANGED
          (funcall (ecase *solution-type* (max-value #'>) (min-value #'<))  ;CHANGED
                   (problem-state.value (first *best-states*))  ;CHANGED
                   (problem-state.value (first best-states))))  ;CHANGED
    *best-states*  ;CHANGED
    best-states))  ;CHANGED


(defun list-all-problems (&optional (prettyp nil))
  "List all problem names in the problem folder.
   One-per-line: (list-all t) or (list-all :pretty)"
  (if prettyp
      (loop for name in (list-problem-names)
            do (format t "~a~%" name))
      (list-problem-names)))
