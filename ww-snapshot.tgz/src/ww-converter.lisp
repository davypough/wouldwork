;;; Filename:  ww-converter.lisp

;;; Procedures for converting database hashtable lookups from symbols to integers


(in-package :ww)


(defun convert-databases-to-integers ()
  "Convert propositions in databases to integer keys and store in integer databases.
   This can be called multiple times to convert newly-added propositions."
  ;; Convert type propositions
  (reject-worker-read-write 'convert-databases-to-integers)
  (iter (for (type constants) in-hashtable *types*)
    (iter (for constant in constants)
      (when (or (symbolp constant) (realp constant) (characterp constant))
        (setf (gethash (convert-to-integer-memoized (list type constant)) *static-idb*) t))))
  ;; Convert dynamic database propositions
  (iter (for (prop-key value) in-hashtable *db*)
        (for iproposition = (convert-to-integer-memoized prop-key))
        (setf (gethash iproposition *idb*) value)
        (setf (gethash iproposition (problem-state.idb *start-state*)) value))
  ;; Convert hash dynamic database propositions
  (iter (for (prop-key value) in-hashtable *hdb*)
        (for iproposition = (convert-to-integer-memoized prop-key))
        (setf (gethash iproposition *hidb*) value)
        (setf (gethash iproposition (problem-state.hidb *start-state*)) value))
  ;; Convert static database propositions
  (iter (for (prop-key value) in-hashtable *static-db*)
        (for iproposition = (convert-to-integer-memoized prop-key))
        (setf (gethash iproposition *static-idb*) value))
  ;; Convert happenings database propositions
  (iter (for (prop-key value) in-hashtable *hap-db*)
        (for iproposition = (convert-to-integer-memoized prop-key))
        (setf (gethash iproposition *hap-idb*) value)
        (setf (gethash iproposition (problem-state.hidb *start-state*)) value)))


(defun compile-generated-function (name form)
  "Translate and compile one generated function; failed compilation closes admission."
  (reject-worker-read-write 'compile-generated-function)
  (handler-case
      (multiple-value-bind (function warnings failure)
          (compile name (subst-int-code form))
        (declare (ignore warnings))
        (when failure (error "Generated function compilation failed: ~S." name))
        function)
    (error (condition)
      (setf *generated-read-mode* nil)
      (error condition))))

(defun compile-all-functions ()
  "Publish the read mode only after the complete generated pass succeeds."
  (reject-worker-read-write 'compile-all-functions)
  (setf *generated-read-mode* nil)
  (compile-problem-functions)
  (setf *generated-read-mode* (current-generated-read-mode)))

(defun compile-problem-functions ()
  "Compile all action preconditions/effects, queries, updates, goal, and constraint functions.
   Should only be called once during initialization.
   Optimization notes are muffled across the whole pass.  Every lambda compiled here was
   generated rather than authored -- spliced in from the tech files, then specialized by the
   translator against this problem's own type declarations -- so a note about one describes
   that machinery working as designed and names nothing an author can act on.  A problem
   declaring no TRAY, for instance, reduces PLACE-HELD-OBJECT!'s tray branch to dead code,
   and SBCL reports each dropped form as \"deleting unreachable code\" on every (stage ...).
   Warnings and errors are deliberately left alone: only notes are suppressed, and only over
   generated code -- the hand-written sources in src/ and tech/ still report theirs."
  (reject-worker-read-write 'compile-problem-functions)
  (setf *generated-read-mode* nil)
  (handler-bind (#+sbcl (sb-ext:compiler-note #'muffle-warning))
    (format t "~&Optimizing lambda expressions and compiling...")
    ;; Compile action preconditions and effects
    (iter (for action in *actions*)
          (format t "~&  ~A...~%" (action.name action))
          (finish-output)
          (with-slots (pre-defun-name eff-defun-name precondition-lambda effect-lambda) action
            (compile-generated-function pre-defun-name precondition-lambda)
            (compile-generated-function eff-defun-name effect-lambda)))
    ;; Compile query and update functions
    (iter (for fname in (append *query-names* *update-names*))
          (format t "~&  ~A...~%" fname)
          (finish-output)
          (compile-generated-function fname (symbol-value fname)))
    ;; Compile base filter if present
    (if *enumerator-base-filter-form*
        (progn
          (format t "~&  ~A (base-filter)...~%" *enumerator-base-filter-name*)
          (finish-output)
          (setf *enumerator-prefilter*
                (compile-generated-function nil *enumerator-base-filter-form*)))
        ;; Ensure old filter state does not leak when a problem defines no base filter.
        (setf *enumerator-prefilter* nil))
    ;; Compile enum :REQUIRES predicates if the enumerator module is loaded.
    (when (fboundp 'compile-enum-relation-requires-predicates)
      (format t "~&  enum relation requires predicates...~%")
      (finish-output)
      (compile-enum-relation-requires-predicates))
    ;; Compile happening interrupt functions
    (iter (for obj in *happening-names*)
          (format t "~&  ~A...~%" obj)
          (finish-output)
          (when (get obj :interrupt)
            (setf (get obj :interrupt)
                  (compile-generated-function nil (get obj :interrupt-lambda)))))
    ;; Compile happening rebound functions
    (iter (for obj in *happening-names*)
          (when (get obj :rebound-lambda)
            (format t "~&  ~A rebound...~%" obj)
            (finish-output)
            (setf (get obj :rebound)
                  (compile-generated-function nil (get obj :rebound-lambda)))))
    ;; Compile happening kill functions
    (iter (for obj in *happening-names*)
          (when (get obj :kill-lambda)
            (format t "~&  ~A kill...~%" obj)
            (finish-output)
            (setf (get obj :kill)
                  (compile-generated-function nil (get obj :kill-lambda)))))
    ;; Compile happening aftereffect functions
    (iter (for obj in *happening-names*)
          (when (get obj :aftereffect-lambda)
            (format t "~&  ~A aftereffect...~%" obj)
            (finish-output)
            (setf (get obj :aftereffect)
                  (compile-generated-function nil (get obj :aftereffect-lambda)))))
    ;; Compile goal function
    (when (boundp 'goal-fn)
      (format t "~&  ~A...~%" 'goal-fn)
      (finish-output)
      (compile-generated-function 'goal-fn (symbol-value 'goal-fn)))
    ;; Compile constraint function
    (when (boundp 'constraint-fn)
      (format t "~&  ~A...~%" 'constraint-fn)
      (finish-output)
      (compile-generated-function 'constraint-fn (symbol-value 'constraint-fn)))))


(defun do-integer-conversion ()
  "Convert all objects to integers, populate integer databases, and compile all functions.
   This is the main initialization function called during problem loading."
  (reject-worker-read-write 'do-integer-conversion)
  (setf *generated-read-mode* nil)
  (clrhash *prop-key-cache*)
  (associate-objects-with-integers)
  (convert-databases-to-integers)
  (compile-all-functions))


(defun associate-objects-with-integers ()
  "Build list of all object constants requiring conversion."
  (reject-worker-read-write 'associate-objects-with-integers)
  (let (objects)    
    (push 'always-true objects)
    (push 'waiting objects)
    (push nil objects)
    (iter (with flat-codes = (append (alexandria:flatten (when (boundp 'goal-fn)
                                                           (symbol-value 'goal-fn)))
                                     (alexandria:flatten (when (boundp 'constraint-fn)
                                                           (symbol-value 'constraint-fn)))))
          (for item in flat-codes)
          (when (numberp item)
            (collecting item into numbers))
          (finally (alexandria:appendf objects numbers)))
    (iter (for (prop nil) in-hashtable *db*)
          (appending (remove-if-not #'numberp prop) into numbers)
          (finally (alexandria:appendf objects numbers))) 
    (iter (for (prop nil) in-hashtable *static-db*)
          (appending (remove-if-not #'numberp prop) into numbers)
          (finally (alexandria:appendf objects numbers)))
    (alexandria:appendf objects (iter (for (type constants) in-hashtable *types*)
                                      ;(when (symbolp (first constants))
                                        (collecting type)
                                        (appending constants)))
    (alexandria:appendf objects (iter (for (predicate nil) in-hashtable *relations*)
                                      (collecting predicate)))
    (alexandria:appendf objects (iter (for (predicate nil) in-hashtable *static-relations*)
                                      (collecting predicate)))
    (setf objects (delete-duplicates objects))
    (iter (for obj in objects)
          (when (or (listp obj) (vectorp obj))
            (setf *constant-integers*
                  (make-hash-table :test #'equal :size 2003 :rehash-threshold 1.0))  ;; was :synchronized (> *threads* 0)
            (leave)))
    (iter (for obj in objects)
          (for i from 100)
          (setf (gethash obj *constant-integers*) i)
          (setf (gethash i *integer-constants*) obj)
          (finally (setf *last-object-index* i)))))


#+ignore (defun associate-objects-with-integers ()
  "Build list of all object constants requiring conversion."
  (let (objects)    
    (push 'always-true objects)
    (push 'waiting objects)
    (push nil objects)
    (iter (with flat-codes = (append (alexandria:flatten (when (boundp 'goal-fn)
                                                           (symbol-value 'goal-fn)))
                                     (alexandria:flatten (when (boundp 'constraint-fn)
                                                           (symbol-value 'constraint-fn)))))
          (for item in flat-codes)
          (when (numberp item)
            (collecting item into numbers))
          (finally (alexandria:appendf objects numbers)))
    (iter (for (prop nil) in-hashtable *db*)
          (appending (remove-if-not #'numberp prop) into numbers)
          (finally (alexandria:appendf objects numbers))) 
    (iter (for (prop nil) in-hashtable *static-db*)
          (appending (remove-if-not #'numberp prop) into numbers)
          (finally (alexandria:appendf objects numbers)))
    (alexandria:appendf objects (iter (for (type constants) in-hashtable *types*)
                                      ;(when (symbolp (first constants))
                                        (collecting type)
                                        (appending constants)))
    (alexandria:appendf objects (iter (for (predicate nil) in-hashtable *relations*)
                                      (collecting predicate)))
    (alexandria:appendf objects (iter (for (predicate nil) in-hashtable *static-relations*)
                                      (collecting predicate)))
    (setf objects (delete-duplicates objects))
    (iter (for obj in objects)
          (when (or (listp obj) (vectorp obj))
            (setf *constant-integers* (make-hash-table :test #'equal :synchronized (> *threads* 0)))
            (leave)))
    (iter (for obj in objects)
          (for i from 100)
          (setf (gethash obj *constant-integers*) i)
          (setf (gethash i *integer-constants*) obj)
          (finally (setf *last-object-index* i)))))


(defun register-dynamic-object (object type-name)
  "Registers a dynamically-created object in the integer constants system
   and adds the type proposition to the static database.
   This function MUST be called immediately after creating any dynamic object
   (via intern, gensym, etc.) and BEFORE using it in any propositions.
   Purpose:
   - Assigns an integer code enabling database lookups for the new object
   - Creates type proposition (type-name object) in *static-idb*
   - Makes the object discoverable via type queries (e.g., (beam ?b))
   - Serializes allocation of object codes with the integer lock
   - Rejects registration while parallel worker read snapshots are published
   Problems registering objects during search must declare
   their object types, e.g. (ww-set *search-registers-dynamic-objects* (beam)).
   Initialization-only registration before worker snapshot publication is allowed.
   Parameters:
   - object: The dynamically-created symbol (e.g., BEAM3)
   - type-name: The type it belongs to (e.g., BEAM)
   Returns: The registered object (for convenient chaining)
   Example Usage:
   (setq $new-beam (intern (format nil \"BEAM~D\" $index)))
   (register-dynamic-object $new-beam 'beam)
   ;; Now $new-beam can be safely used in propositions like:
   ;; (beam-segment $new-beam ?source ?target $x $y)"
  (declare (type symbol object type-name))
  ;; Input validation
  (reject-worker-read-write 'register-dynamic-object)
  (check-type object symbol "a symbol")
  (check-type type-name symbol "a symbol")
  ;; Register object in integer constants system
  ;; This enables convert-to-integer to process propositions containing this object
  (unless (gethash object *constant-integers*)
    (bt:with-lock-held (*integer-lock*)
      (reject-worker-read-write 'register-dynamic-object)
      ;; Double-check pattern: object might have been added by another thread
      (unless (gethash object *constant-integers*)
        (when (>= *last-object-index* 999)
          (error "Design Limit Error: Total number of planning objects exceeds 999"))
        (incf *last-object-index*)
        (setf (gethash object *constant-integers*) *last-object-index*)
        (setf (gethash *last-object-index* *integer-constants*) object))))
  ;; Create type proposition (type-name object) and convert to integer
  ;; This makes the object discoverable via type-based iteration and queries
  (let* ((type-prop (list type-name object))
         (type-prop-int (convert-to-integer-memoized type-prop)))
    ;; Add to static database if not already present
    (unless (gethash type-prop-int *static-idb*)
      (setf (gethash type-prop-int *static-idb*) t)))
  ;; Return the registered object for convenient chaining
  object)
  

(defun quoted-form-p (form)
  (and (consp form)
       (eql (first form) 'quote)
       (null (cddr form))))


(defun translated-prop-list-p (form)
  (and (consp form)
       (eql (first form) 'list)
       (quoted-form-p (second form))))


(defun translated-prop-relation (prop-form)
  (when (translated-prop-list-p prop-form)
    (second (second prop-form))))


(defun translated-not-literal-prop (literal-form)
  (when (and (consp literal-form)
             (eql (first literal-form) 'list)
             (equal (second literal-form) '(quote not))
             (translated-prop-list-p (third literal-form))
             (null (cdddr literal-form)))
    (third literal-form)))


(defun simple-int-write-relation-p (relation)
  "True when RELATION can bypass general update expansion in compiled int code."
  (and (gethash relation *relations*)
       (not (gethash relation *complements*))
       (not (gethash relation *bijective-relations*))
       (not (gethash relation *bijective-canonical*))
       (null (gethash relation *symmetrics*))))


(defun int-write-db-form-p (db-form)
  (equal db-form '(problem-state.idb state)))


(defun remove-prop-items-at-indexes (items indexes)
  (loop with remaining-indexes = indexes
        for item in items
        for i from 0
        unless (and remaining-indexes (= i (first remaining-indexes)))
          collect item
        else
          do (setf remaining-indexes (rest remaining-indexes))))


(defun select-prop-items-at-indexes (items indexes)
  (loop with remaining-indexes = indexes
        for item in items
        for i from 0
        when (and remaining-indexes (= i (first remaining-indexes)))
          collect item
          and do (setf remaining-indexes (rest remaining-indexes))))


(defun int-write-key-form (prop-form fluent-indexes)
  (let* ((items (cdr prop-form))
         (key-items (remove-prop-items-at-indexes items fluent-indexes)))
    (convert-prop-list (cons 'list key-items))))


(defun int-write-value-form (prop-form fluent-indexes)
  (if fluent-indexes
    `(list ,@(select-prop-items-at-indexes (cdr prop-form) fluent-indexes))
    t))


(defun convert-int-update-form (form)
  "Convert safe generated UPDATE forms into direct integer-key mutations."
  (when (and (= (length form) 3)
             (eql (first form) 'update)
             (int-write-db-form-p (second form)))
    (let* ((db-form (second form))
           (literal-form (third form))
           (negative-prop-form (translated-not-literal-prop literal-form))
           (prop-form (or negative-prop-form literal-form))
           (relation (translated-prop-relation prop-form)))
      (when (and relation
                 (simple-int-write-relation-p relation))
        (let* ((fluent-indexes (get-prop-fluent-indices (list relation)))
               (key-form (int-write-key-form prop-form fluent-indexes)))
          `(progn
             (when *print-updates*
               (ut::prt ,literal-form))
             ,(if negative-prop-form
                `(del-int-prop-key ,db-form ,key-form)
                `(add-int-prop-key
                   ,db-form
                   ,key-form
                   ,(int-write-value-form prop-form fluent-indexes)))))))))


(defun generated-static-read-table ()
  "Choose expressions at generation, without capturing a staged table object."
  (if (zerop *threads*)
      '*static-idb*
      '(or *worker-static-read-view* *static-idb*)))

(defun generated-object-code (object)
  (if (zerop *threads*)
      `(gethash ,object *constant-integers*)
      `(worker-object-code ,object)))

(defun subst-int-code (code-tree)
  (labels ((process-item (item)
             (cond ((atom item) item)
                   ((not (typep item 'alexandria:proper-list)) item)
                   ((and (consp item)
                         (eql (first item) 'update))
                    (or (convert-int-update-form item)
                        (mapcar #'process-item item)))
                   ((and (consp item)
                         (eql (first item) 'gethash)
                         (consp (second item)) (eql (first (second item)) 'list))
                      (list (first item)
                            (convert-prop-list (second item))
                            (cond ;((equal (third item) '(problem-state.db state))
                                  ;   '(problem-state.idb state))
                                  ((equal (third item) '(problem-state.idb state))
                                     '(problem-state.idb state))
                                  ((equal (third item) '(problem-state.idb state+))
                                     '(problem-state.idb state+))
                                  ((equal (third item) '(problem-state.idb state-or-state+))
                                     '(problem-state.idb state-or-state+))
                                  ((eql (third item) '*static-db*)
                                     (generated-static-read-table))
                                  ;((eql (third item) 'idb)
                                  ;   'idb)
                                  ((equal (third item) '(merge-idb-hidb state))
                                     '(merge-idb-hidb state))
                                  ;; ← Add this case for context-aware conditionals
                                  ;((and (consp (third item))
                                  ;      (eql (first (third item)) 'if)
                                  ;      (equal (second (third item)) '(hash-table-p state-or-idb))
                                  ;      (eql (third (third item)) 'state-or-idb)
                                  ;      (equal (fourth (third item)) '(problem-state.idb state-or-idb)))
                                  ;   (third item))  ; Pass through unchanged
                                  ((error "Error in subst-int-code: ~A" (third item))))))
                   (t (mapcar #'process-item item)))))
    (process-item code-tree)))


(defun convert-to-integer-memoized (prop-key)
  "Memoized version for straightforward lookup"
  (or (gethash prop-key *prop-key-cache*)
      (setf (gethash prop-key *prop-key-cache*)
            (convert-to-integer prop-key))))


(defun convert-to-integer (prop-key)
  "Thread-safe original version with narrower locking.
   Only the create-new-code path runs under the lock; summing happens outside."
  (iter (for item in prop-key)
        (for multiplier in '(1 1000 1000000 1000000000 1000000000000))
        ;; First try without any lock
        (for code = (or (gethash item *constant-integers*)
                        ;; Only lock if we didn't find a code
                        (bt:with-lock-held (*integer-lock*)
                          ;; Double-check pattern: item might have been added by another thread
                          (or (gethash item *constant-integers*)
                              (progn
                                (reject-worker-read-write (list 'convert-to-integer item))
                                (when (>= *last-object-index* 999)
                                  (error "Design Limit Error: Total # of actual + derived planning objects > 999"))
                                (incf *last-object-index*)
                                (setf (gethash item *constant-integers*) *last-object-index*)
                                (setf (gethash *last-object-index* *integer-constants*) item)
                                *last-object-index*)))))
        ;; Use the code outside the lock
        (summing (* code multiplier))))


(defun convert-prop-list (prop-list)
  "Converts a statement form in an action--eg, (list 'loc ?jammer ?area)
   with no $vars to an integer key form for efficient db access."
  (iter (for item in (cdr prop-list))
        (for multiplier in '(1 1000 1000000 1000000000 1000000000000))
        (for new-item = (cond ((and (consp item) (eql (car item) 'quote))
                                 (* (gethash (second item) *constant-integers*) multiplier))
                              ((and (symbolp item)
                                    (or (char= (char (symbol-name item) 0) #\$)
                                        (char= (char (symbol-name item) 0) #\?)))
                                 `(* ,(generated-object-code item) ,multiplier))
                              ((numberp item)
                                 (* (gethash item *constant-integers*) multiplier))
                              ((error "Error in convert-prop-list: ~A invalid in ~A"
                                       item prop-list))))
        (collect new-item into new-items)
        (finally (return (cons '+ new-items)))))
