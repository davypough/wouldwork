;;; Filename:  ww-searcher.lisp

;;; Nonstandard Depth First Branch & Bound. Optional duplicate checking for nodes
;;; previously visited (graph search) as specified in problem spec. Open nodes are
;;; kept in an indexed stack and (optionally for graph search) visited nodes in a
;;; CLOSED hash table. Search
;;; follows the scheme described on p.55 of Problem Solving Methods in Artificial
;;; Intelligence by Nillson.
;;; A complete path from a goal to the start state is then available in OPEN.
;;; In graph search a visited node is
;;; either in OPEN or CLOSED at any particular time. A user-defined heuristic can be
;;; used to expand the best states first at each level (beam search), but
;;; the entire search graph may ultimately be searched (completeness).


(in-package :ww)


(defmacro lprt (&rest vars)
  "Print some variable values in a thread for debugging."
  `(bt:with-lock-held (*lock*)  ;grab lock for uninterrupted printing
     (let ((*package* (find-package :ww))  ;suppress printing package prefixes
           (thread-index  (lparallel:kernel-worker-index)))  ;get current thread
       (terpri)
       (ut::prt thread-index)
       (ut::prt ,@vars)
       (finish-output))))  ;make sure printout is complete before continuing


(defun simple-break ()
  "Call to simplify debugger printout on a break."
  (declare (optimize (debug 1)))
  (break))


(defun probe (current-node name instantiations depth &optional (count 1))
  "Breaks when the current node matches action name, instantiations, depth, and count from start--eg, (put (a b) 1)."
  (declare (type node current-node))  ;(ut::prt name instantiations depth current-node) (break)
  (let ((state (node.state current-node)))
    (when (and (eql (problem-state.name state) name)
               (equal (problem-state.instantiations state) instantiations)
               (= (node.depth current-node) depth))
      (if (= count *counter*)
        (setq *debug* 6)  ;(setq *debug* 5)  ;means probe found
        (incf *counter*)))))


(defparameter *shutdown-requested* nil
  "Variable used to signal threads shutdown, if *threads* > 0")


(defvar *min-steps-fallback-mode* :eager)
(defvar *min-steps-fallback-nonpruning-streak* 0)
(defvar *min-steps-fallback-sample-countdown* 0)
;; INCREMENT-GLOBAL expands to SB-EXT:ATOMIC-INCF whenever *THREADS* is positive at
;; macroexpansion time, and that place must be a DEFGLOBAL declaimed FIXNUM.  The two
;; counters it touches are therefore globals; the rest stay ordinary specials because
;; only the serial adaptive path (see MIN-STEPS-FALLBACK-ADAPTIVE-P) ever writes them.
(sb-ext:defglobal *min-steps-fallback-evaluations* 0)
(declaim (type fixnum *min-steps-fallback-evaluations*))
(sb-ext:defglobal *min-steps-fallback-unique-prunes* 0)
(declaim (type fixnum *min-steps-fallback-unique-prunes*))
(defvar *min-steps-fallback-skipped* 0)
(defvar *min-steps-fallback-reactivations* 0)


(defun min-steps-fallback-adaptive-p ()
  (and *min-steps-remaining-contributors*
       (fboundp 'min-steps-remaining?)
       (zerop *threads*)
       (> *min-steps-fallback-sample-interval* 1)))


(defun min-steps-pruning-relevant-p ()
  "Whether a lower bound could reject a node under the current search limits."
  (and *min-steps-pruning-enabled*
       (or (> *depth-cutoff* 0)
           (and *solution-paths*
                (member *solution-type* '(min-length first))))))


(defun initialize-min-steps-fallback-adaptation ()
  (setf *min-steps-fallback-mode*
          (if (min-steps-fallback-adaptive-p) :active :eager)
        *min-steps-fallback-nonpruning-streak* 0
        *min-steps-fallback-sample-countdown* 0
        *min-steps-fallback-evaluations* 0
        *min-steps-fallback-skipped* 0
        *min-steps-fallback-unique-prunes* 0
        *min-steps-fallback-reactivations* 0))


(defun reactivate-min-steps-fallback ()
  "Resume full aggregate evaluation without clearing cumulative diagnostics."
  (when (min-steps-fallback-adaptive-p)
    (setf *min-steps-fallback-mode* :active
          *min-steps-fallback-nonpruning-streak* 0
          *min-steps-fallback-sample-countdown* 0)))


(defun min-steps-fallback-evaluation-due-p ()
  (case *min-steps-fallback-mode*
    ((:eager :active) t)
    (:sampling
      (if (zerop *min-steps-fallback-sample-countdown*)
        t
        (progn
          (decf *min-steps-fallback-sample-countdown*)
          (incf *min-steps-fallback-skipped*)
          nil)))))


(defun note-min-steps-fallback-result (prunes-p)
  (increment-global *min-steps-fallback-evaluations* 1)
  (when prunes-p
    (increment-global *min-steps-fallback-unique-prunes* 1))
  (cond
    ((and prunes-p (not (eq *min-steps-fallback-mode* :eager)))
      (when (eq *min-steps-fallback-mode* :sampling)
        (incf *min-steps-fallback-reactivations*))
      (reactivate-min-steps-fallback))
    ((eq *min-steps-fallback-mode* :active)
      (incf *min-steps-fallback-nonpruning-streak*)
      (when (>= *min-steps-fallback-nonpruning-streak*
                *min-steps-fallback-warmup*)
        (setf *min-steps-fallback-mode* :sampling
              *min-steps-fallback-sample-countdown*
                (1- *min-steps-fallback-sample-interval*))))
    ((eq *min-steps-fallback-mode* :sampling)
      (setf *min-steps-fallback-sample-countdown*
            (1- *min-steps-fallback-sample-interval*)))))


(defun valid-min-steps-remaining-bound (function-name state)
  "Evaluate FUNCTION-NAME and require a nonnegative real lower bound."
  (unless (fboundp function-name)
    (error "Registered min-steps-remaining contributor is undefined: ~S"
           function-name))
  (let ((bound (funcall (symbol-function function-name) state)))
    (unless (and (realp bound) (not (minusp bound)))
      (error "~S returned invalid min-steps-remaining bound: ~S"
             function-name bound))
    bound))


(defun min-steps-remaining-bound-prunes-p (depth bound)
  "Whether admissible BOUND independently rejects a node at DEPTH."
  (or (and (> *depth-cutoff* 0)
           (> (+ depth bound) *depth-cutoff*))
      (and *solution-paths*
           (member *solution-type* '(min-length first))
           (>= (+ depth bound)
               (solution.depth (first *solution-paths*))))))


(defun registered-min-steps-contributor-prunes-p (state depth)
  "Evaluate cheap contributors in cost order, stopping at the first proof."
  (loop for entry in *min-steps-remaining-contributors*
        for function-name = (second entry)
        for bound = (valid-min-steps-remaining-bound function-name state)
        do (increment-global *min-steps-contributor-evaluations* 1)
        when (min-steps-remaining-bound-prunes-p depth bound)
          do (increment-global *min-steps-contributor-prunes* 1)
             (return t)
        finally (return nil)))


(defun min-steps-remaining-bound (state)
  "Return the maximum registered and aggregate lower bound for diagnostics."
  (let ((bound 0))
    (dolist (entry *min-steps-remaining-contributors*)
      (setf bound
            (max bound
                 (valid-min-steps-remaining-bound (second entry) state))))
    (when (fboundp 'min-steps-remaining?)
      (setf bound
            (max bound
                 (valid-min-steps-remaining-bound
                   'min-steps-remaining? state))))
    bound))


(defun min-steps-remaining-prunes-node-p (state depth)
  "Run cheap bounds first and the aggregate query only when still necessary."
  (and (min-steps-pruning-relevant-p)
       (or (registered-min-steps-contributor-prunes-p state depth)
           (and (fboundp 'min-steps-remaining?)
                (when (min-steps-fallback-evaluation-due-p)
                  (let ((prunes-p
                          (min-steps-remaining-bound-prunes-p
                            depth
                            (valid-min-steps-remaining-bound
                              'min-steps-remaining? state))))
                    (note-min-steps-fallback-result prunes-p)
                    prunes-p))))))


(defparameter *open* (hs::make-hstack)  ;initialized in dfs
  "The hash-stack structure containing the stack of open nodes as a vector,
   and hash table of idb -> node.")
(declaim (hs::hstack *open*))


(defun initialize-search-progress-timing ()
  "Start serial and parallel progress windows at the beginning of this search."
  (let ((now (get-internal-real-time)))
    (setf *start-time* now
          *prior-time* now
          *prior-parallel-progress-time* now
          *prior-parallel-progress-states* 0
          *prior-parallel-progress-cycles* 0
          *progress-gap* (* *progress-first-report* internal-time-units-per-second)
          *next-progress-time* (+ now *progress-gap*))))


(defun progress-report-due-p (states-since-report)
  "With a fixed *progress-reporting-interval*, true once STATES-SINCE-REPORT reaches it;
   otherwise true once the adaptive schedule's next report time has passed."
  (if *progress-reporting-interval*
    (>= states-since-report *progress-reporting-interval*)
    (>= (get-internal-real-time) *next-progress-time*)))


(defun advance-progress-schedule ()
  "After a report, double the adaptive gap and set the next report time from now."
  (setf *progress-gap* (* 2 *progress-gap*)
        *next-progress-time* (+ (get-internal-real-time) *progress-gap*)))


(sb-ext:defglobal *closed* (make-hash-table :synchronized (> *threads* 0))  ;initialized in dfs
  "Contains the set of closed state idbs for graph search, idb -> (depth time value).")


(defun node.state.idb (node)
  "Gets the idb of a node."
  (problem-state.idb (node.state node)))


(defun node.state.idb-hash (node)
  "Gets the cached idb-hash of a node's state."
  (problem-state.idb-hash (node.state node)))


(defun ensure-idb-hash (state)
  "Ensure STATE carries its graph hash and canonical split components when active."
  (if (use-canonical-symmetry-p)
      (progn
        (unless (problem-state.symmetry-idb state)
          (let ((fixed-hash 0)
                (symmetry-idb (make-hash-table :test #'eql :synchronized nil)))
            (maphash
              (lambda (key value)
                (if (idb-entry-references-symmetry-p key value)
                    (setf (gethash key symmetry-idb) value)
                    (setf fixed-hash
                          (logxor fixed-hash
                                  (deep-sxhash (cons key value))))))
              (problem-state.idb state))
            (setf (problem-state.fixed-idb-hash state) fixed-hash
                  (problem-state.symmetry-idb state) symmetry-idb)))
        (when (eq (problem-state.canonical-symmetry-form state) :uncached)
          (setf (problem-state.canonical-symmetry-form state)
                (build-canonical-idb-form
                  (problem-state.symmetry-idb state))
                (problem-state.canonical-form-hash state) nil))
        (unless (problem-state.canonical-form-hash state)
          (setf (problem-state.canonical-form-hash state)
                (ww-with-timing :symm/canon-hash
                  (ldb (byte 62 0)
                       (deep-sxhash
                         (problem-state.canonical-symmetry-form state))))))
        (unless (problem-state.idb-hash state)
          (setf (problem-state.idb-hash state)
                (logxor
                  (problem-state.fixed-idb-hash state)
                  (problem-state.canonical-form-hash state)))))
      (unless (problem-state.idb-hash state)
        (setf (problem-state.idb-hash state)
              (compute-idb-hash (problem-state.idb state)))))
  (problem-state.idb-hash state))


(defun closed-key (state depth)
  "Generates the appropriate key for *closed* hash table lookup/storage.
   Standard mode: idb-hash (state identity only)
   Hybrid mode: (cons idb-hash depth) for (state, depth) pair identity."
  (declare (type problem-state state) (type fixnum depth))
  (ensure-idb-hash state)
  (let ((hash (problem-state.idb-hash state)))
    (if *hybrid-mode*
        (cons hash depth)
        hash)))


#|
  ;; LEGACY DEAD CODE -- commented out (not deleted) on 2026-05-07.
  ;;
  ;; The six forms below form a closed dependency island with no callers anywhere
  ;; in src/ or in any problem-*.lisp file:
  ;;   - choose-ht-value-test     called only once, to initialize *fixed-ht-values-fn*
  ;;   - *fixed-ht-values-fn*     read only inside fixed-keys-ht-equal
  ;;   - fixed-keys-ht-equal      referenced only in the define-hash-table-test below
  ;;   - fixed-keys-ht-hash       referenced only in the define-hash-table-test below
  ;;   - the define-hash-table-test registration was never used: dfs creates *closed*
  ;;     with :test 'eql (or 'equal in hybrid mode), never 'fixed-keys-ht-equal
  ;;   - fixedp                   has no callers at all
  ;;
  ;; If this cluster is ever revived, fixed-keys-ht-hash would have the same
  ;; sxhash-on-simple-vectors blind spot that compute-idb-hash had; route its
  ;; per-value hash through deep-sxhash to fix it.

(defun choose-ht-value-test (relations)
  "Chooses either #'equal or #'equalp as a test for *closed* ht (idb) keys."
  (let (lisp-$types)  ;eg, $list, $hash-table, $fixnum, $real
    (maphash (lambda (rel args)
               (declare (ignore rel))
               (when (listp args)
                 (iter (for arg in args)
                       (when ($varp arg)
                         (let ((lisp-$type (trim-1st-char arg)))
                           (unless (gethash lisp-$type *types*)  ;user defined type
                             (pushnew lisp-$type lisp-$types)))))))
             relations)
    (cond ((intersection '(hash-table vector array) lisp-$types) #'equalp)
          (t #'equal))))


(defparameter *fixed-ht-values-fn* (choose-ht-value-test *relations*)
  "Determines which equality test to use in fixed-keys-ht-equal.")


(defun fixed-keys-ht-equal (ht-key1 ht-key2)
  "Quick equality test with *closed* for two hash tables with the same fixed keys.
   The equality predicate tests the hash table values, skipping the keys."
  (declare (type hash-table ht-key1 ht-key2))
  (maphash (lambda (k v)
             (unless (funcall *fixed-ht-values-fn* v (gethash k ht-key2))
               (return-from fixed-keys-ht-equal nil)))
           ht-key1)
  t)


(defun fixed-keys-ht-hash (ht)
  (let ((hash 0))
    (maphash (lambda (key val)
               (declare (ignore key))
               (setf hash (logxor hash (sxhash val))))
             ht)
    hash))


(sb-ext:define-hash-table-test fixed-keys-ht-equal fixed-keys-ht-hash)


(defun fixedp (relations)
  "Determines if all relations have $var args, and thus have fixed keys idb."
  (maphash (lambda (rel args)
             (declare (ignore rel))
             (unless (and (listp args)
                          (member-if #'$varp args))
               (return-from fixedp nil)))
           relations)
  t)
|#


(defun solution-count-reached-p ()
  "Returns T if we should stop searching because the requested solution count is reached.
   Handles both *solution-type* = 'first and *solution-type* = <positive-fixnum>."
  (or (eql *solution-type* 'first)
      (and (typep *solution-type* 'fixnum)
           (>= (length *unique-solution-states*) *solution-type*))))


(defun initialize-hybrid-mode ()
  "Activates hybrid graph search mode for *solution-type* = ALL-PATHS.
   ALL-PATHS finds every distinct path to every goal state (combinatorially
   explosive; requires depth-first + graph + depth-cutoff > 0).
   Returns T when all constraints are met; NIL otherwise, in which case
   ALL-PATHS falls back to standard EVERY semantics (one path per unique
   goal state).  Parallel search always uses the EVERY fallback."
  (unless (eql *solution-type* 'all-paths)
    (return-from initialize-hybrid-mode nil))
  (when (> *threads* 0)
    (format t "~&Note: ALL-PATHS with parallel search falls back to EVERY semantics ~
               (one path per unique goal state).~%")
    (return-from initialize-hybrid-mode nil))
  (let ((constraints-met t))
    (unless (eql *algorithm* 'depth-first)
      (setf constraints-met nil))
    (unless (eql *tree-or-graph* 'graph)
      (setf constraints-met nil))
    (unless (> *depth-cutoff* 0)
      (setf constraints-met nil))
    (if constraints-met
        (format t "~&ALL-PATHS mode active: enumerating all paths to all goal states ~
                   at depth ~D.~%" *depth-cutoff*)
        (format t "~&Note: ALL-PATHS requires depth-first + graph + depth-cutoff > 0. ~
                   Falling back to EVERY semantics.~%"))
    constraints-met))


;;; Search Functions


(defun dfs ()
  "Main search program."
  (reject-worker-read-write 'dfs)
  (validate-worker-read-snapshot-mode)
  (reset-symmetry-statistics)
  (when *global-invariants*
    (unless (validate-global-invariants nil *start-state*)
      (format t "~%Invariant validation failed on initial state.~%")
      (return-from dfs :invalid-start)))
  (setf *hybrid-mode* (initialize-hybrid-mode))
  (reset-search-successor-pruners)
  (when *failed-state-memory*
    (validate-failed-state-memory-settings))
  (reset-failed-state-memory)
  (setf *open* 
      (hs::make-hstack :table (make-hash-table :test 'eql
                                               :synchronized nil)
                       :keyfn #'node.state.idb-hash))
  ;; Always reset closed-state storage so prior runs do not retain old graph tables.
  (setf *closed* (make-hash-table :test 'eql :synchronized nil))
  ;; Drop shard references unless graph mode with parallelism reinitializes them below.
  (when (boundp '*closed-shards*)
    (setf *closed-shards* nil))
  (when (boundp '*closed-shard-locks*)
    (setf *closed-shard-locks* nil))
  (when (eql *tree-or-graph* 'graph)
    (let ((hash-test (if *hybrid-mode* 'equal 'eql))) 
      (setf *closed* (make-hash-table :test hash-test
                                      :size 200003
                                      :rehash-size 2.7
                                      :rehash-threshold 0.8
                                      :synchronized nil))
      (when (> *threads* 0)
        (initialize-closed-infrastructure hash-test))))
  (when (> *threads* 0)  ;; Ensure start state has synchronized IDB tables for parallel mode
    (ensure-start-state-synchronized))
  (let ((start-node (make-node :state (copy-problem-state *start-state*))))
    (hs::push-hstack start-node *open* :new-only (eq *tree-or-graph* 'graph))
    ;; Reserve start state in *closed* for graph search (maintains consistency with process-successors)
    (when (eql *tree-or-graph* 'graph)
      (invalidate-problem-state-hash *start-state*)
      (ensure-idb-hash *start-state*)
      (let ((closed-table (if (> *threads* 0)
                              (closed-shard *start-state*)
                              *closed*)))
        (closed-bucket-insert (make-closed-entry *start-state* 0)        ; was raw setf gethash with inline 4-element list
                              *start-state* 0 closed-table)))
    (setf *program-cycles* 0)
    (setf *average-branching-factor* 0.0)
    (setf *total-states-processed* 1)  ;start state is first
    (setf *prior-total-states-processed* 0)
    (setf *prior-program-cycles* 0)
    (setf *last-improvement-states* 0)
    (setf *accumulated-backtrack-distance* 0)
    (setf *num-backtracks* 0)
    (setf *prev-expansion-depth* 0)
    (setf *rem-init-successors* nil)  ;branch nodes from start state
    (setf *num-init-successors* 0)
    (setf *max-depth-explored* 0)
    (setf *num-idle-threads* 0)
    (setf *dead-end-accumulated-depths* 0)
    (setf *dead-end-num-paths* 0)
    (setf *duplicate-accumulated-depths* 0)
    (setf *duplicate-num-paths* 0)
    (setf *depth-cutoff-hits* 0)
    (setf *depth-cutoff-truncated* nil)
    (setf *repeated-states* 0)
    (setf *solution-paths* nil)
    (setf *hybrid-goals* nil)
    (setf *unique-solution-states* nil)
    (setf *best-states* (list *start-state*))
    (setf *solution-count* 0)
    (setf *count-example* nil)
    (reset-candidate-solution-validation-statistics)
    (setf *upper-bound* 1000000)
    (setf *search-tree* nil)
    (initialize-search-progress-timing)
    (setf *inconsistent-states-dropped* 0)
    (setf *lower-bound-pruned* 0)
    (setf *bounding-pruned* 0)
    (setf *min-steps-contributor-evaluations* 0)
    (setf *min-steps-contributor-prunes* 0)
    (initialize-min-steps-fallback-adaptation)
    (setf *search-prefix-validations* 0)
    (reset-search-prefix-validator-statistics)
    (setf *search-prefix-pruned* 0)
    (setf *successor-policy-pruned* 0)
    (setf *shutdown-requested* nil)
    (clrhash *prop-key-cache*)
    (let* ((start-goal-p (goal (node.state start-node)))
           (accepted-start-goal-p
             (and start-goal-p
                  (candidate-solution-valid-p nil (node.state start-node))
                  (not (goal-chain-candidate-rejected-p
                         nil (node.state start-node))))))
      (when accepted-start-goal-p
        (register-solution start-node))
      (unless (and accepted-start-goal-p
                    (or (solution-count-reached-p)
                        (member *solution-type* '(min-length min-time))))
        (if (> *threads* 0)
          (progn
            (ecase *algorithm*
              (depth-first (process-partitioned-parallel))
              (backtracking (process-partitioned-parallel-bt)))
            (finalize-parallel-search-results)
            (display-parallel-timing)
            (display-worker-stats)
            (display-closed-shard-stats))
          (ecase *algorithm*
            (depth-first (search-serial))
            (backtracking (search-backtracking))))))
    (when *hybrid-mode*
      (finalize-hybrid-solutions))
    (let ((*package* (find-package :ww)))  ;avoid printing package prefixes
      (if *shutdown-requested*
        :shutdown
        (let ((condition
                (cond ((and *solution-paths* (solution-count-reached-p)) 'first)  ;CHANGED
                      (*time-limit-reached* 'time-limit)  ;CHANGED
                      (t 'exhausted))))  ;CHANGED
          (summarize-search-results condition)
          (ecase condition  ;CHANGED
            (first :solution-limit-reached)  ;CHANGED
            (time-limit :time-limit)  ;CHANGED
            (exhausted :exhausted)))))))  ;CHANGED


(defun auto-wait-debug-find-prop (props pred &rest prefix)
  "Return the first proposition in PROPS whose (car ...) is PRED and whose
   arguments begin with PREFIX. Used for compact debug signatures."
  (declare (type list props))
  (find-if (lambda (p)
             (and (consp p)
                  (eql (car p) pred)
                  (loop for x in prefix
                        for y in (cdr p)
                        always (eql x y))))
           props))


(defun auto-wait-debug-state-signature (state)
  "Compact signature to detect whether STATE drifted/mutated between re-push and backtrack-wait."
  (declare (type problem-state state))
  (let* ((idb (problem-state.idb state))
         (props (list-database idb)))
    (list :time (problem-state.time state)
          :idb-count (hash-table-count idb)
          :idb-hash (compute-idb-hash idb)
          :elev-agent1 (auto-wait-debug-find-prop props 'ELEVATION 'AGENT1)
          :loc-buzzer1 (auto-wait-debug-find-prop props 'LOC 'BUZZER1)
          :loc-box2    (auto-wait-debug-find-prop props 'LOC 'BOX2))))


(defun search-serial ()
  "Branch & Bound DFS serial search."
  (iter
    (when (hs::empty-hstack *open*)
      (leave))  ;terminate *open*
    (for current-node = (hs::peek-hstack *open*))
    (for succ-nodes = (df-bnb1 *open*))
    (when (equal succ-nodes '(first))
      (return-from search-serial 'first))
    (when succ-nodes  ;nongoal succ-nodes
      (if (fboundp 'heuristic?)
        (setf succ-nodes (sort (copy-list succ-nodes) #'>
                               :key (lambda (node)
                                      (problem-state.heuristic (node.state node)))))
        (when *randomize-search*
          (setf succ-nodes (alexandria:shuffle succ-nodes)))))
    (when (= *program-cycles* 0)  ;ie, expanding the start state
      (when (>= *branch* 1)  ;choose an initial branch to explore, drop others
        (format t "~&Exploring only branch ~D of ~D~%" *branch* (length succ-nodes))
        (setf succ-nodes (subseq succ-nodes (1- *branch*) *branch*)))
      (setf *num-init-successors* (length succ-nodes))
      (setf *rem-init-successors* (reverse succ-nodes)))
    ;; Backtrack-triggered wait setup
    ;; If we have successors and auto-wait is enabled, re-push current-node with wait-tried=T.
    ;; This ensures that after all successors are exhausted, we'll encounter current-node again
    ;; and df-bnb1 will attempt backtrack-triggered wait before truly backtracking.
    (when (and succ-nodes
               (auto-wait-enabled-p)
               (not (node.wait-tried current-node)))
      (setf (node.wait-tried current-node) t)
      (hs::push-hstack current-node *open* :new-only nil))  ; Push underneath successors
    (iter (for succ-node in succ-nodes)
          (hs::push-hstack succ-node *open*
                         :new-only (and (eq *tree-or-graph* 'graph)
                                        (not *hybrid-mode*))))         ; hybrid allows same-idb nodes at different depths
    (increment-global *program-cycles* 1)  ;finished with this cycle
    (setf *average-branching-factor* (compute-average-branching-factor))
    (print-search-progress)  ;#nodes expanded so far
    (after-each ;; Probe facility - always available regardless of debug compilation
                (when (= *debug* 6)
                  (setf *debug* 0)
                  (format t "~2%Probing current node: ~A~2%" current-node)
                  (format t "~%Successor nodes (~D):~%" (length succ-nodes))
                  (when succ-nodes
                    (dolist (succ-node succ-nodes)
                      (format t "~%  ~A~%" succ-node)))
                  (simple-break))  ; Reset for next probe
                ;; Full debug output - only when :ww-debug compiled in
                #+:ww-debug (when (= *debug* 5)
                              (format t "~%---~%Restating current node for easy reference: ~A~%---~%" current-node)
                              (simple-break)))))  ;allows continuing search for next *probe*


;;; ============================================================================
;;; AUTO-WAIT STUCK HANDLER
;;; ============================================================================


(defun handle-auto-wait-stuck (current-node)
  "Attempts auto-wait when node has no successors (agent is stuck).
   Called from df-bnb1 when succ-states is nil and auto-wait is enabled.
   
   Returns one of:
     (:goal goal-state)        - Goal reached during wait; goal-state for registration
     (:continue wait-state)    - Action became possible; wait-state as single successor
     (:fail)                   - Auto-wait failed or not applicable; use normal dead-end handling
   
   The wait-state returned for :continue has name WAIT and instantiations (duration)
   for proper solution path recording."
  (declare (type node current-node))
  (let ((state (node.state current-node)))
    ;; Attempt macro-wait simulation
    (multiple-value-bind (outcome wait-duration sim-state)
        (simulate-until-action-applicable state *auto-wait-max-time*)
      (case outcome
        ;; Goal was reached during waiting
        (:goal
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Auto-wait: Goal reached after waiting ~A time units~%" wait-duration))
         (let ((wait-state (create-auto-wait-state state sim-state wait-duration)))
           (if (state-is-inconsistent wait-state)
             (progn
               (increment-global *inconsistent-states-dropped* 1)
               (values :fail nil))
             (values :goal wait-state))))
        
        ;; An action became applicable after waiting
        (:action
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Auto-wait: Action became applicable after waiting ~A time units~%" wait-duration))
         (let ((wait-state (create-auto-wait-state state sim-state wait-duration)))
           (if (state-is-inconsistent wait-state)
             (progn
               (increment-global *inconsistent-states-dropped* 1)
               (values :fail nil))
             (values :continue wait-state))))
        
        ;; Timeout - waited too long without progress
        (:timeout
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Auto-wait: Timeout after ~A time units~%" *auto-wait-max-time*))
         (values :fail nil))
        
        ;; Agent was killed during wait
        (:killed
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Auto-wait: Agent killed during wait~%"))
         (values :fail nil))
        
        ;; No happenings to simulate
        (:no-happenings
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Auto-wait: No happenings available~%"))
         (values :fail nil))
        
        ;; Unknown outcome - treat as failure
        (otherwise
         (values :fail nil))))))


(defun handle-auto-wait-backtrack (current-node)
  "Attempts backtrack-triggered wait when all regular successors have been exhausted.
   Called from df-bnb1 when node.wait-tried is T (second visit after children exhausted).
   
   Returns one of:
     (list wait-node)          - Wait succeeded, continue exploring from wait-node
     '(first)                  - Goal reached during wait and *solution-type* is first
     nil                       - Wait failed, continue backtracking
   
   This enables finding solutions that require waiting when regular actions exist
   but all lead to dead ends."
  (declare (type node current-node))
  (let ((state (node.state current-node)))
    #+:ww-debug (when (>= *debug* 3)
                  (format t "~&Backtrack-triggered wait attempt at depth ~D~%" (node.depth current-node)))
    ;; Attempt macro-wait simulation
    (multiple-value-bind (outcome wait-duration sim-state)
        (simulate-until-action-applicable state *auto-wait-max-time*)
      (case outcome
        ;; Goal was reached during waiting
        (:goal
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Backtrack-wait: Goal reached after waiting ~A time units~%" wait-duration))
         (let* ((wait-state (create-auto-wait-state state sim-state wait-duration))
                (succ-depth (1+ (node.depth current-node))))
           (when (state-is-inconsistent wait-state)
             (increment-global *inconsistent-states-dropped* 1)
             (return-from handle-auto-wait-backtrack nil))
           ;; Check if we can improve on existing solutions
           (when (and *solution-paths* (member *solution-type* '(min-length min-time min-value max-value)))
             (unless (f-value-better wait-state succ-depth)
               ;; Can't improve, continue backtracking
               (return-from handle-auto-wait-backtrack nil)))
           ;; Register solution
           #+:ww-debug (when (>= *debug* 1)
                         (update-search-tree wait-state (1+ (node.depth current-node)) "backtrack-wait->goal"))
           (register-solution
             (make-node :state wait-state
                        :depth succ-depth
                        :parent current-node))
           (update-max-depth-explored succ-depth)
           (increment-global *total-states-processed* 1)
           (if (solution-count-reached-p)  ; was (eql *solution-type* 'first)
               '(first)
               nil)))  ; Continue searching for more solutions
        
        ;; An action became applicable after waiting
        (:action
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Backtrack-wait: Action became applicable after waiting ~A time units~%" wait-duration))
         (let ((wait-state (create-auto-wait-state state sim-state wait-duration)))
           (when (state-is-inconsistent wait-state)
             (increment-global *inconsistent-states-dropped* 1)
             (return-from handle-auto-wait-backtrack nil))
           #+:ww-debug (when (>= *debug* 1)
                         (update-search-tree wait-state (1+ (node.depth current-node)) "backtrack-wait->continue"))
           (update-max-depth-explored (1+ (node.depth current-node)))
           (increment-global *total-states-processed* 1)
           ;; Return wait-node as successor for further exploration
           (list (make-node :state wait-state
                            :depth (1+ (node.depth current-node))
                            :parent current-node
                            :wait-tried nil))))  ; New node starts fresh
        
        ;; Timeout, killed, no-happenings, or unknown - continue backtracking
        (otherwise
         #+:ww-debug (when (>= *debug* 3)
                       (format t "~&Backtrack-wait: Failed with outcome ~A~%" outcome))
         nil)))))


(defun df-bnb1 (open)
  "Performs expansion of one node from open. Returns
   new successor nodes, (first), or nil if no new nodes generated."
  (declare (type hs::hstack open))
  (let ((current-node (get-next-node-for-expansion open)))  ;pop next node
   (when current-node
     (let* ((current-depth (node.depth current-node))
            (backtrack-distance (- *prev-expansion-depth* current-depth)))
       (when (> backtrack-distance 0)
         (incf *accumulated-backtrack-distance* backtrack-distance)
         (incf *num-backtracks*))
       (setf *prev-expansion-depth* current-depth)
       (when *failed-state-memory*
         (close-failed-state-path current-depth))))
   (when *probe*
     (apply #'probe current-node *probe*))
   (iter
    #+:ww-debug (when (>= *debug* 3)
                  (format t "~&-----------------------------------------------------------~%")
                  (format t "~%Current node selected:~%~S~2%" current-node))
    (when (null current-node)  ;open is empty
      (return-from df-bnb1 nil))
    (when (and (> *depth-cutoff* 0) (= (node.depth current-node) *depth-cutoff*))
      (increment-global *depth-cutoff-hits* 1)
      ;; The cutoff leaves the space unexplored only where a cut node still had
      ;; successors.  One confirmed truncation settles the whole search, so the
      ;; probe stops as soon as the flag is set and never runs again.
      (unless *depth-cutoff-truncated*
        (when (expand current-node)
          (setf *depth-cutoff-truncated* t)))
      (narrate "State at max depth" (node.state current-node) (node.depth current-node))
      (return-from df-bnb1 nil))
    (when (and *solution-paths*
               (member *solution-type* '(min-length min-time min-value))
               (node-descendants-cannot-improve-p current-node))
      (narrate "Node pruned by incumbent bound"
               (node.state current-node)
               (node.depth current-node))
      (return-from df-bnb1 nil))
    (when (and (min-steps-remaining-available-p)
               (min-steps-remaining-prunes-node-p
                 (node.state current-node)
                 (node.depth current-node)))
      (increment-global *lower-bound-pruned* 1)
      (narrate "State pruned by lower bound"
               (node.state current-node)
               (node.depth current-node))
      (return-from df-bnb1 nil))
    (when (eql (bounding-function current-node) 'kill-node)
      (return-from df-bnb1 nil))
    (when *failed-state-memory*
      (when (failed-state-skip-p current-node)
        (narrate "State skipped by failed-state memory"
                 (node.state current-node)
                 (node.depth current-node))
        (return-from df-bnb1 nil))
      (push (cons current-node nil) *failed-state-path*))
    ;; Backtrack-triggered wait check
    ;; If this node was re-pushed with wait-tried=T, all regular successors were exhausted.
    ;; Now try waiting as a "second chance" before truly backtracking.
    (when (and (auto-wait-enabled-p) (node.wait-tried current-node))
      (return-from df-bnb1 (handle-auto-wait-backtrack current-node)))
    ;; States are now reserved in *closed* when added to open in process-successors
    (let ((succ-states (expand current-node)))  ;from generate-children
      (when *troubleshoot-current-node*
        (setf *debug* 5)
        (setf *troubleshoot-current-node* nil)
        (next-iteration))  ;redo current-node
      (when (null succ-states)  ;no successors
        ;; Auto-wait stuck handling
        (when (auto-wait-enabled-p)
          (multiple-value-bind (outcome wait-state) (handle-auto-wait-stuck current-node)
            (case outcome
              ;; Goal reached during auto-wait
              (:goal
               (let ((succ-depth (1+ (node.depth current-node))))
                 ;; Register the wait action in search tree for debugging
                 #+:ww-debug (when (>= *debug* 1)
                               (update-search-tree wait-state (node.depth current-node) "auto-wait->goal"))
                 ;; Check if we can improve on existing solutions
                 (when (and *solution-paths* (member *solution-type* '(min-length min-time min-value max-value)))
                   (unless (f-value-better wait-state succ-depth)
                     ;; Can't improve, treat as dead end
                     (update-max-depth-explored (node.depth current-node))
                     (finalize-dead-end-depth (node.depth current-node))
                     (return-from df-bnb1 nil)))
                 ;; The solution path will show: ... -> (current-node's action) -> (WAIT duration)
                 (register-solution
                   (make-node :state wait-state
                              :depth succ-depth
                              :parent current-node))
                 (update-max-depth-explored succ-depth)
                 (increment-global *total-states-processed* 1)
                 (if (solution-count-reached-p)  ; was (eql *solution-type* 'first)
                     (return-from df-bnb1 '(first))
                     (return-from df-bnb1 nil))))
              
              ;; Action became applicable after auto-wait
              (:continue
               #+:ww-debug (when (>= *debug* 1)
                             (update-search-tree wait-state (node.depth current-node) "auto-wait->continue"))
               ;; Return wait-state as the single successor for further expansion
               (update-max-depth-explored (1+ (node.depth current-node)))
               (increment-global *total-states-processed* 1)
               (return-from df-bnb1 
                 (list (make-node :state wait-state
                                  :depth (1+ (node.depth current-node))
                                  :parent current-node))))
              
              ;; Auto-wait failed - fall through to normal dead-end handling
              (:fail nil))))
        (update-max-depth-explored (node.depth current-node))
        (narrate "No successor states" (node.state current-node) (node.depth current-node))
        (finalize-dead-end-depth (node.depth current-node))
        (return-from df-bnb1 nil))
      #+:ww-debug (when (>= *debug* 1)
                    (update-search-tree (node.state current-node) (node.depth current-node) ""))
      (update-max-depth-explored (1+ (node.depth current-node)))
      (increment-global *total-states-processed* (length succ-states))
;      #+:ww-debug (when (= *debug* 6) (simple-break))  ;probe found
      (return-from df-bnb1 (process-successors succ-states current-node open))))))  ;returns live successor nodes


(defun search-prefix-pruned-p (state path-generator)
  "Whether the enabled prefix validators reject every candidate path ending at STATE.

PATH-GENERATOR receives the newest move and returns the candidate paths ending at STATE.
It is called only when validation is actually required, so a successor no validator is
interested in never pays for path reconstruction.  Both prefix statistics are counted
here, so every search driver reports validations and prunes on the same basis."
  (when (search-prefix-validation-enabled-p)
    (let ((move (record-move state)))
      (when (search-prefix-validation-required-p move state)
        (increment-global *search-prefix-validations* 1)
        (unless (some (lambda (path)
                        (candidate-search-prefix-valid-p path state))
                      (funcall path-generator move))
          (increment-global *search-prefix-pruned* 1)
          t)))))


(defun print-search-prefix-validator-breakdown ()
  "Print each prefix validator's own checks and rejections under the aggregate line.

The aggregate counts successors, while a validator counts the candidate paths it
examined, so the two agree only when one validator sees one path per successor.
Registered validators that never ran are listed too, so the final report shows which
validators were in force."
  (dolist (row (search-prefix-validator-statistics))
    (destructuring-bind (validator enabled-p checks rejections) row
      (cond
        ((> checks 0)
         (format t "~&  ~(~A~): ~:D check~:P, ~:D rejection~:P."
                 validator checks rejections))
        (enabled-p
         (format t "~&  ~(~A~): enabled, never triggered." validator))
        (t
         (format t "~&  ~(~A~): disabled." validator))))))


(defun successor-search-prefix-pruned-p (current-node succ-state)
  "Whether no path to SUCC-STATE survives the enabled prefix validators.

Standard search has one parent path.  Hybrid ALL-PATHS search keeps the successor
when at least one path through its parent DAG remains viable."
  (search-prefix-pruned-p
    succ-state
    (lambda (move)
      (mapcar (lambda (parent-path)
                (append parent-path (list move)))
              (if *hybrid-mode*
                (enumerate-paths-to-node current-node)
                (list (record-solution-path current-node)))))))


(defun goal-chain-candidate-rejected-p (path state)
  "Whether the active milestone search context rejects endpoint STATE.

This check deliberately runs before graph duplicate handling.  A rejected goal state
is still admitted as an ordinary search successor, because a later descendant may be a
different acceptable milestone state."
  (and *goal-chain-candidate-rejector*
       (funcall *goal-chain-candidate-rejector* path state)))


(defun process-successors (succ-states current-node open)
  "Processes successor states: checks goals, handles duplicates, generates nodes.
   In hybrid mode, accumulates parent pointers for multi-path enumeration."
  (iter (with succ-depth = (1+ (node.depth current-node)))
        (for succ-state in succ-states)
        (when (state-is-inconsistent succ-state)
          (increment-global *inconsistent-states-dropped* 1)
          (next-iteration))
        (when *global-invariants*
          (validate-global-invariants current-node succ-state))
        (when (successor-search-prefix-pruned-p current-node succ-state)
          (next-iteration))
        (when (search-successor-pruned-p current-node succ-state)
          (next-iteration))
        (when (and *solution-paths* (member *solution-type* '(min-length min-time min-value)))
          (unless (f-value-better succ-state succ-depth)
            (next-iteration)))  ;throw out state if can't better best solution so far
        (when (goal succ-state)
          (when (and *solution-paths*
                     (eql *solution-type* 'max-value)
                     (not (f-value-better succ-state succ-depth)))
            (next-iteration))  ;max-value prunes only goals that can't better best solution
          (let ((goal-node
                  (make-node :state succ-state
                             :depth succ-depth
                             :parent current-node)))
            (cond
              (*hybrid-mode*
               (defer-hybrid-goal current-node succ-state)
               ;; Hybrid paths are complete only after the parent DAG is closed.  With
               ;; validators active, retain nominal goal states as ordinary successors so
               ;; a rejected goal prefix can be repaired by later actions.
               (unless *solution-validators*
                 (next-iteration)))
              (t
               (let ((candidate-path (candidate-path-to-goal-node goal-node)))
                 (cond
                   ((not (candidate-solution-valid-p candidate-path succ-state))
                    (narrate "Candidate goal rejected by solution validator"
                             succ-state succ-depth))
                   ((goal-chain-candidate-rejected-p candidate-path succ-state)
                    (narrate "Candidate checkpoint rejected for this continuation"
                             succ-state succ-depth))
                   (t
                    (register-solution goal-node)
                    (if (solution-count-reached-p)
                      (return-from process-successors '(first))
                      (next-iteration))))))
              )))
        (unless (boundp 'goal-fn)
          (process-min-max-value succ-state))
        (when (and (eql *tree-or-graph* 'tree) (eql *problem-type* 'planning)
                   (not *failed-state-memory*))  ;failed-state memory handles repeats itself
          (when (on-current-path succ-state current-node)
            (increment-global *repeated-states*)
            (finalize-duplicate-depth succ-depth)
            (next-iteration)))
        (when (eql *tree-or-graph* 'graph)
          ;; Check if state already on open
          (let ((open-node (idb-in-open succ-state open succ-depth)))
            (when open-node
              (narrate "State already on open" succ-state succ-depth)
              (increment-global *repeated-states*)
              (cond (*hybrid-mode*
                     (add-parent-to-node open-node current-node (record-move succ-state))
                     (finalize-duplicate-depth succ-depth))
                    (t
                     (if (update-open-if-succ-better open-node succ-state)
                       (setf (node.parent open-node) current-node)
                       (finalize-duplicate-depth succ-depth))))
              (next-iteration)))
          ;; Check if state in closed
          (with-search-structures-lock
            (let ((closed-values (get-closed-values succ-state succ-depth)))
              (when closed-values
                (increment-global *repeated-states*)
                (cond (*hybrid-mode*
                       (let ((closed-node (get-closed-node succ-state succ-depth)))
                         (when closed-node
                           (add-parent-to-node closed-node current-node (record-move succ-state))))
                       (narrate "Accumulating parent for closed state" succ-state succ-depth)
                       (finalize-duplicate-depth succ-depth)
                       (next-iteration))
                      ((better-than-closed closed-values succ-state succ-depth)
                       (narrate "Returning this previously closed state to open" succ-state succ-depth)
                       (closed-bucket-remove succ-state succ-depth *closed*))      ; was (remhash (closed-key …) *closed*)
                      (t
                       (narrate "Dropping this previously closed state" succ-state succ-depth)
                       (finalize-duplicate-depth succ-depth)
                       (next-iteration)))))
            ;; State is new or reopened - reserve immediately
            (let ((succ-node (generate-new-node current-node succ-state)))
              (closed-bucket-insert (make-closed-entry succ-state succ-depth succ-node)   ; was (setf (gethash …) …)
                                    succ-state succ-depth *closed*)
              (collecting succ-node))))
        ;; Tree search path - generate node without closed tracking
        (when (eql *tree-or-graph* 'tree)
          (collecting (generate-new-node current-node succ-state)))))


(defun validate-global-invariants (current-node succ-state)
  "Validate all registered global invariants on the given succ-state.
   Returns T if all invariants pass, NIL if any fail.
   If current-node is nil, this is a start state validation."
  (loop for invariant-name in *global-invariants*
        for fn = (symbol-function invariant-name)
        unless (funcall fn succ-state)
        do (if (null current-node)
             (troubleshoot "~%Invariant ~A failed on start state:~2%~A"
                          invariant-name
                          succ-state)
             (troubleshoot "~%Invariant ~A failed during transition:~2%Current node:~%~A~2%Successor state:~%~A" 
                          invariant-name
                          current-node
                          succ-state))
           (return-from validate-global-invariants nil))
  t)


(defun idb-in-open (succ-state open &optional succ-depth)
  "Determines if a state's idb matches the contents of a key in open's table.
   Uses idb-hash for O(1) lookup with idb verification for collision safety.
   In hybrid mode, also requires depth match (succ-depth must be provided).
   Returns the node in open or nil."
  (declare (type problem-state succ-state))
  (ensure-idb-hash succ-state)  ; ensure hash is cached
  (let ((hash-key (problem-state.idb-hash succ-state))
        (ht (hs::hstack.table open)))
    (let ((nodes (gethash hash-key ht)))  ; lookup by hash
      (when nodes
        ;; verify idb matches to handle hash collisions
        ;; in hybrid mode, also verify depth matches
        (find-if (lambda (node)
                   (and (equalp (problem-state.idb succ-state)
                                (problem-state.idb (node.state node)))
                        (or (not *hybrid-mode*)
                            (= succ-depth (node.depth node)))))
                 nodes)))))


(defun deep-sxhash (obj)
  "Computes an sxhash that descends through conses, simple-vectors, hash tables,
   and general arrays (including strings). Other types delegate to sxhash. Used by
   compute-idb-hash so that fluent values containing vectors, hash tables, or other
   composite objects contribute their contents to the state hash."
  (cond ((consp obj)
         (sxhash (cons (deep-sxhash (car obj)) (deep-sxhash (cdr obj)))))
        ((simple-vector-p obj)
         (let ((h (sxhash 'simple-vector)))
           (loop for elt across obj
                 do (setf h (sxhash (cons h (deep-sxhash elt)))))
           h))
        ((hash-table-p obj)
         (let ((h (sxhash (cons 'hash-table
                                (cons (hash-table-test obj)
                                      (hash-table-count obj))))))
           (maphash (lambda (k v)
                      (setf h (logxor h
                                      (sxhash (cons (deep-sxhash k)
                                                    (deep-sxhash v))))))
                    obj)
           h))
        ((simple-bit-vector-p obj) (sxhash obj))
        ((arrayp obj)
         (let ((h (sxhash (cons 'array (array-dimensions obj)))))
           (loop for i from 0 below (array-total-size obj)
                 do (setf h (sxhash (cons h (deep-sxhash (row-major-aref obj i))))))
           h))
        (t (sxhash obj))))


(defun compute-idb-hash (idb-hash-table)
  "Computes a fixnum hash from an idb hash table.
   Uses XOR of sxhash values for deterministic hashing."
  (declare (type hash-table idb-hash-table))
  (let ((hash 0))
    (declare (type fixnum hash))
    (maphash (lambda (k v)
               (setf hash (logxor hash (deep-sxhash (cons k v)))))
             idb-hash-table)
    hash))


(defun validate-carried-hash (state)
  "Debug gate. When *validate-idb-hash* is set, signal an error if STATE's
   incrementally-carried idb-hash disagrees with a full compute-idb-hash rescan.
   Skips states whose carried hash is NIL (recomputed downstream) and canonical-
   symmetry mode (where the carried hash is intentionally left NIL)."
  (declare (type problem-state state))
  (when (and *validate-idb-hash*
             (problem-state.idb-hash state)
             (not (use-canonical-symmetry-p)))
    (let ((carried (problem-state.idb-hash state))
          (full (compute-idb-hash (problem-state.idb state))))
      (unless (= carried full)
        (error "Incremental idb-hash ~D disagrees with full rescan ~D for state:~%~A"
               carried full state)))))


(defun build-canonical-idb-form (idb)
  "Build the exact row-permutation canonical representation of IDB."
  (declare (type hash-table idb))
  (ww-with-timing :symm/canon-form
    (build-exact-canonical-idb-form idb)))


(defun canonical-prop-less-p (prop1 prop2)
  "Comparison function for sorting canonicalized propositions.

;; PH4C: fast path for integer keys."
  (let ((k1 (car prop1))
        (k2 (car prop2)))
    (cond ((and (integerp k1) (integerp k2)) (< k1 k2))
          ((integerp k1) t)
          ((integerp k2) nil)
          (t (string< (prin1-to-string k1)
                      (prin1-to-string k2))))))


(defun fixed-idb-equal-p (idb1 slice1 idb2 slice2)
  "Whether IDB1 and IDB2 contain exactly the same entries outside their cached
   symmetry slices SLICE1 and SLICE2. Membership in the slice stands in for
   re-deriving each entry's symmetry-family status, so this scans each idb once."
  (declare (type hash-table idb1 slice1 idb2 slice2))
  (unless (= (- (hash-table-count idb1) (hash-table-count slice1))
             (- (hash-table-count idb2) (hash-table-count slice2)))
    (return-from fixed-idb-equal-p nil))
  (maphash
    (lambda (key value)
      (unless (nth-value 1 (gethash key slice1))
        (multiple-value-bind (other-value present-p) (gethash key idb2)
          (unless (and present-p
                       (not (nth-value 1 (gethash key slice2)))
                       (equalp value other-value))
            (return-from fixed-idb-equal-p nil)))))
    idb1)
  t)


(defun canonical-state-equal-p (state1 state2)
  "Whether STATE1 and STATE2 are exactly equal under the active row permutations."
  (declare (type problem-state state1 state2))
  (ensure-idb-hash state1)
  (ensure-idb-hash state2)
  (or (equalp (problem-state.idb state1)
              (problem-state.idb state2))
      (ww-with-timing :symm/canon-equal
        (and
          (equal (problem-state.canonical-symmetry-form state1)
                 (problem-state.canonical-symmetry-form state2))
          (fixed-idb-equal-p (problem-state.idb state1)
                              (problem-state.symmetry-idb state1)
                              (problem-state.idb state2)
                              (problem-state.symmetry-idb state2))))))


(defun closed-bucket-find (state depth table)
  "Return the entry in TABLE for STATE at DEPTH, or NIL if absent.
   Verify concrete identity first, then cached canonical-slice equality, then
   exact fixed-part equality in canonical mode. Neither the canonical form nor
   the symmetry slice is rebuilt during bucket lookup.
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (let ((bucket (gethash (closed-key state depth) table)))
    (when bucket
      (let ((succ-idb (problem-state.idb state))
            (succ-canonical-form
              (problem-state.canonical-symmetry-form state))
            (succ-symmetry-idb (problem-state.symmetry-idb state))
            (canonical-mode (use-canonical-symmetry-p)))
        (find-if (lambda (entry)
                   (let ((closed-idb (first entry)))
                     (cond ((equalp closed-idb succ-idb) t)
                           ((not canonical-mode) nil)
                           (t
                            (ww-with-timing :symm/canon-equal
                              (when (and
                                      (equal (fifth entry) succ-canonical-form)
                                      (fixed-idb-equal-p closed-idb (sixth entry)
                                                          succ-idb succ-symmetry-idb))
                                (increment-global *symmetric-duplicates-pruned*)
                                t))))))
                 bucket)))))


(defun closed-bucket-insert (entry state depth table)
  "Push ENTRY into the bucket for STATE at DEPTH in TABLE.
   Caller is responsible for ensuring no equivalent entry already exists
   (typically via a prior closed-bucket-find under the same lock).
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (push entry (gethash (closed-key state depth) table))
  entry)


(defun closed-bucket-remove (state depth table)
  "Remove the entry for STATE at DEPTH from TABLE, if present.
   When removal empties the bucket, removes the hash key entirely.
   Returns the removed entry, or NIL if none matched.
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (let ((entry (closed-bucket-find state depth table)))
    (when entry
      (let* ((key (closed-key state depth))
             (new-bucket (delete entry (gethash key table) :test #'eq)))
        (if new-bucket
            (setf (gethash key table) new-bucket)
            (remhash key table))
        entry))))


(defun make-closed-entry (state depth &optional node)
  "Build a closed entry, including STATE's cached canonical form and symmetry
   slice when active, so later comparisons never re-derive them."
  (let ((canonical-form
          (when (use-canonical-symmetry-p)
            (problem-state.canonical-symmetry-form state)))
        (symmetry-idb
          (when (use-canonical-symmetry-p)
            (problem-state.symmetry-idb state))))
    (if *hybrid-mode*
        (list (problem-state.idb state)
              depth
              (problem-state.time state)
              (problem-state.value state)
              canonical-form
              symmetry-idb
              node)
        (list (problem-state.idb state)
              depth
              (problem-state.time state)
              (problem-state.value state)
              canonical-form
              symmetry-idb))))


(defun get-closed-values (state depth)
  "Retrieve the closed entry for STATE at DEPTH from *closed* (or its shard
   in parallel mode). Returns the entry list or NIL.
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (closed-bucket-find state depth
                      (if (> *threads* 0)
                          (closed-shard state)
                          *closed*)))


(defun get-closed-node (state depth)
  "Retrieve the node stored in *closed* for hybrid mode.
   Returns the node from STATE's closed entry, or NIL if absent.
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (let ((entry (closed-bucket-find state depth
                                   (if (> *threads* 0)
                                       (closed-shard state)
                                       *closed*))))
    (when entry
      (seventh entry))))


(defun goal (state)
  "Returns t or nil depending on if state is a goal state."
  (declare (type problem-state state))
  (when (boundp 'goal-fn)
    (funcall (symbol-function 'goal-fn) state)))


(defun process-min-max-value (succ-state &optional worker-id)
  "Update *best-states* on improvement, reporting the zero-based worker ID.
   Without a worker ID, report the coordinator in parallel search or serial search."
  (let ((current-value (problem-state.value succ-state))
        (best-value (problem-state.value (first *best-states*))))
    (ecase *solution-type*
      (max-value (when (> current-value best-value)
                   (bt:with-lock-held (*lock*)
                     (format t "~%Higher value state found: ~A in ~A~%"
                             (problem-state.value succ-state)
                             (if worker-id (format nil "worker ~D" worker-id)
                                 (if (> *threads* 0) "coordinator" "serial search")))
                     (finish-output))
                   (push-global succ-state *best-states*)))
      (min-value (when (< current-value best-value)
                   (bt:with-lock-held (*lock*)
                     (format t "~%Lower value state found: ~A in ~A~%"
                             (problem-state.value succ-state)
                             (if worker-id (format nil "worker ~D" worker-id)
                                 (if (> *threads* 0) "coordinator" "serial search")))
                     (finish-output))
                   (push-global succ-state *best-states*))))))

 
(defun f-value-better (succ-state succ-depth)
  "Computes f-value of current-node to see if it's better than best solution so far."
  (let ((best-solution (first *solution-paths*)))
    (case *solution-type*
      ((min-length first)
        (< succ-depth (solution.depth best-solution)))
      (min-time
        (< (problem-state.time succ-state) (solution.time best-solution)))
      (min-value
        (< (problem-state.value succ-state) (solution.value best-solution)))
      (max-value
        (> (problem-state.value succ-state) (solution.value best-solution))))))


(defun node-descendants-cannot-improve-p (current-node)
  "Whether no descendant of CURRENT-NODE can improve on the incumbent solution.
   Every descendant lies at least one action beyond CURRENT-NODE, so the depth- and
   time-based objectives charge that action before comparing.  MIN-VALUE tests the
   node's own value -- the same predicate PROCESS-SUCCESSORS already applied when
   this node was generated, re-evaluated against a bound that may have improved
   while it sat on open.  This assumes value never decreases along a path (costs
   accumulate, as in TSP).  MAX-VALUE is not pruned here: rewards normally grow
   along a path, so a node's own value says nothing about its descendants; its
   bounds come only from BOUNDING-FUNCTION?.
   Nodes on open are never themselves usable solutions: PROCESS-SUCCESSORS registers
   a goal before installing anything, so only descendants are at stake here."
  (declare (type node current-node))
  (let ((best-solution (first *solution-paths*))
        (state (node.state current-node)))
    (ecase *solution-type*
      (min-length
        (>= (1+ (node.depth current-node)) (solution.depth best-solution)))
      (min-time
        (>= (+ (problem-state.time state) *min-action-duration*)
            (solution.time best-solution)))
      (min-value
        (>= (problem-state.value state) (solution.value best-solution))))))


(defun update-open-if-succ-better (open-node succ-state)
  "Determines if f-value of successor is better than open state, and updates it."
  (let ((open-state (node.state open-node)))
    (ecase *solution-type*
      ((min-length first every count all-paths)
         nil)  ;in depth first search succ depth is never better than open
      (min-time
         (when (< (problem-state.time succ-state) (problem-state.time open-state))
           (setf (problem-state.time open-state) (problem-state.time succ-state))))
      (min-value
         (when (< (problem-state.value succ-state) (problem-state.value open-state))
           (setf (problem-state.value open-state) (problem-state.value succ-state))))
      (max-value
         (when (> (problem-state.value succ-state) (problem-state.value open-state))
           (setf (problem-state.value open-state) (problem-state.value succ-state)))))))


(defun better-than-closed (closed-values succ-state succ-depth)
  "Check if succ-state is better than the closed version.
   CALLER MUST HOLD THE APPROPRIATE SHARD LOCK in parallel mode."
  (declare (ignorable succ-depth))
  (let ((closed-depth (second closed-values))
        (closed-time (third closed-values))
        (closed-value (fourth closed-values)))
    (case *solution-type*
      ((first every count all-paths min-length)
       (< succ-depth closed-depth))
      (min-time
       (< (problem-state.time succ-state) closed-time))
      (min-value
       (< (problem-state.value succ-state) closed-value))
      (max-value
       (> (problem-state.value succ-state) closed-value))
      (otherwise nil))))


(defun bounding-function (current-node)
  "Applies the bounding function, if there is one."
  (bound-search-state (node.state current-node) (node.depth current-node)))


(defun bound-search-state (state depth)
  "Apply the shared user bound to a state before expanding its descendants."
  (when (fboundp 'bounding-function?)
    (ut::mvb (current-cost current-upper) (funcall (symbol-function 'bounding-function?) state)
       #+:ww-debug (when (>= *debug* 3)
                     (format t "~&Cost bound = ~A, Upper bound = ~A~%" current-cost current-upper))
       (cond ((> current-cost *upper-bound*)
                (narrate "State killed by bounding" state depth)
                #+:ww-debug (when (>= *debug* 3)
                              (format t "~&current-cost = ~F > *upper-bound* = ~F~%" current-cost *upper-bound*))
                (increment-global *bounding-pruned* 1)
                (return-from bound-search-state 'kill-node))
             ((< current-upper *upper-bound*)
                #+:ww-debug (when (>= *debug* 3)
                              (format t "~&Updating *upper-bound* from ~F to ~F~%" *upper-bound* current-upper))
                (minimize-global *upper-bound* current-upper))))))


(defun update-max-depth-explored (succ-depth)
  (when (> succ-depth *max-depth-explored*)
    (increment-global *max-depth-explored* (- succ-depth *max-depth-explored*))))


(defun get-next-node-for-expansion (open)
  "Returns the node at the top of open."
  (declare (type hs::hstack open))
  (unless (hs::empty-hstack open)
    (hs::pop-hstack open)))  ;return node at top of stack or nil


(defun compute-average-branching-factor ()
  "Average branching on each cycle."
  (coerce (/ (1- *total-states-processed*) *program-cycles*) 'single-float))


(defun compute-effective-branching-factor (n d)
  "Returns the effective branching factor b* > 1 such that a uniform tree of
   depth D with branching factor b* would contain N nodes total
   (1 + b* + b*^2 + ... + b*^D = N). Computed via Newton's method on
   f(b) = b^(d+1) - N*b + (N - 1), starting from b_0 = N^(1/d).
   Returns 1.0 when the search has not generated enough states for a
   meaningful estimate (N <= d+1)."
  (declare (type fixnum n d))
  (when (or (<= d 0) (<= n (1+ d)))
    (return-from compute-effective-branching-factor 1.0))
  (let* ((n-fp (coerce n 'double-float))
         (d+1 (1+ d))
         (b (expt n-fp (/ 1.0d0 d))))
    (iter (repeat 30)
          (for f = (- (expt b d+1) (* n-fp b) (- 1.0d0 n-fp)))
          (for f-prime = (- (* d+1 (expt b d)) n-fp))
          (when (or (zerop f-prime) (< (abs f) 1.0d-9))
            (leave))
          (setf b (- b (/ f f-prime)))
          (when (< b 1.001d0)
            (setf b 1.001d0)))
    (coerce b 'single-float)))


(defun on-current-path (succ-state current-node)
  "Determines if a successor is already on the current path from the start state.
   Uses cached idb-hash for O(1) comparison with equalp verification on hash collision.
   With happenings, equal idbs can have different futures, so a match also needs the
   same failed-state key (each happening's phase and whether reached by a wait)."  ;CHANGED
  (ensure-idb-hash succ-state)  ; ensure hash is cached
  (let ((succ-key (when *happening-names*  ;CHANGED
                    (failed-state-key succ-state))))  ;CHANGED
    (when (iter (for node initially current-node then (node.parent node))  ;CHANGED: indented
                (while node)
                (for node-state = (node.state node))  ; bind node-state for clarity
                (ensure-idb-hash node-state)  ; ensure hash is cached
                (thereis (and (= (problem-state.idb-hash succ-state)  ; hash comparison first
                                 (problem-state.idb-hash node-state))
                              (or (null succ-key)  ;CHANGED
                                  (equal succ-key (failed-state-key node-state)))  ;CHANGED
                              (equalp (problem-state.idb succ-state)  ; equalp only on collision
                                      (problem-state.idb node-state)))))
      (narrate "State already on current path" succ-state (1+ (node.depth current-node)))
      t)))  ;CHANGED


(defun update-search-tree (state depth message)
  (declare (type problem-state state) (type fixnum depth) (type string message))
  (when (and (not (> *threads* 0)) (>= *debug* 1))
    (push `((,(problem-state.name state) 
             ,@(problem-state.instantiations state))
           ,depth
           ,message
           ,@(case *debug*
               (1 nil)
               (2 (list (list-database (problem-state.idb state))))))
          *search-tree*)))


(defun narrate (string state depth)
  (declare (ignorable string state depth))
  #+:ww-debug (when (>= *debug* 3)
                (format t "~%~A:~%~A~%" string state))
  #+:ww-debug (when (>= *debug* 1)
                (update-search-tree state depth string))
  nil)


(defun generate-new-node (current-node succ-state)
  "Produces a new node for a given successor.
   In hybrid mode, stores parent as (parent-node . move) pair."
  (declare (type node current-node) (type problem-state succ-state))
  (let* ((depth (1+ (node.depth current-node)))
         (move (record-move succ-state))
         (parent-entry (if *hybrid-mode*
                           (list (cons current-node move))
                           current-node))
         (succ-node (make-node :state succ-state
                               :depth depth
                               :parent parent-entry)))
    #+:ww-debug (when (>= *debug* 3)
                  (format t "~%Installing new or updated successor:~%~S~%" succ-node))
    succ-node))


(defun best-states-last (state1 state2)
  "Used to sort a list of expanded states according to the user-defined heuristic."
  (declare (type problem-state state1 state2))
  (> (estimate-to-goal state1) (estimate-to-goal state2)))


(defun finalize-dead-end-depth (depth)
  "Records the depth of a path that terminated in a dead end (no successor states)."
  (increment-global *dead-end-accumulated-depths* depth)
  (increment-global *dead-end-num-paths* 1))


(defun finalize-duplicate-depth (depth)
  "Records the depth of a path that terminated by colliding with an
   already-open or already-closed state."
  (increment-global *duplicate-accumulated-depths* depth)
  (increment-global *duplicate-num-paths* 1))


;;; Solution Processing Functions


(defun record-solution-path (goal-node)
  "Recovers a path from a goal node back to the start node following parent links."
  (declare (type node goal-node))
  (let ((path nil))
    (do ((n goal-node (node.parent n)))
        ((null (node.parent n)) path)
      (push (record-move ;(node.state (node.parent n))
                         (node.state n))
            path))))


(defun candidate-path-to-goal-node (goal-node)
  "Return the complete candidate path represented by GOAL-NODE."
  (declare (type node goal-node))
  (let* ((goal-state (node.state goal-node))
         (nominal-path (record-solution-path goal-node)))
    (if (or (zerop (node.depth goal-node))
            (= (hash-table-count *state-codes*) 0))
      nominal-path
      (append nominal-path
              (continue-backward-path
                (gethash
                  (funcall (symbol-function 'encode-state)
                           (list-database (problem-state.idb goal-state)))
                  *state-codes*)
                (problem-state.time goal-state))))))


(defun continue-backward-path (backward-path goal-time)
  "Reverses BACKWARD-PATH, the (time move) entries of a backward search, so it
   continues a forward path ending at GOAL-TIME.  Each reversed move ends at
   GOAL-TIME plus the backward final time minus the time of the backward move
   preceding it, which preserves move durations."
  (let ((final-time (first (first (last backward-path))))
        (prior-times (cons 0.0 (mapcar #'first (butlast backward-path)))))
    (loop for (nil move) in (reverse backward-path)
          for prior-time in (reverse prior-times)
          collect (list (+ goal-time (- final-time prior-time)) move))))


(defun enumerate-paths-to-node (node)
  "Enumerates all paths from the start node to NODE.
   Returns a list of paths, where each path is a list of (action instantiations) moves.
   Paths are in forward order (start to node).
   In hybrid mode, uses moves stored in (parent-node . move) pairs.
   In standard mode with single parents, returns a single-element list."
  (declare (type node node))
  (let ((parent-entries (node.parent node)))
    (if (null parent-entries)
        ;; At start node - return one path with no moves
        (list nil)
        ;; Branch based on mode
        (if *hybrid-mode*
            ;; Hybrid mode: parent-entries is list of (parent-node . move) pairs
            (mapcan (lambda (entry)
                      (let ((parent (car entry))
                            (move (cdr entry)))
                        (mapcar (lambda (path-to-parent)
                                  (append path-to-parent (list move)))
                                (enumerate-paths-to-node parent))))
                    parent-entries)
            ;; Standard mode: parent-entries is single node or list of nodes
            (let ((parents (if (listp parent-entries)
                               parent-entries
                               (list parent-entries)))
                  (current-move (record-move (node.state node))))
              (mapcan (lambda (parent)
                        (mapcar (lambda (path-to-parent)
                                  (append path-to-parent (list current-move)))
                                (enumerate-paths-to-node parent)))
                      parents))))))


(defun summarize-search-results (condition)
  (declare (type symbol condition))
  (format t "~2%In problem ~A, performed ~A~A search for ~A solution, ~A."
            *problem-name*
            (if *hybrid-mode* "hybrid " "")
            *tree-or-graph*
            (if (and (eql *solution-type* 'all-paths) (not *hybrid-mode*))
                'every
                *solution-type*)
            (if (> *threads* 0)
                (format nil "with ~D thread~:P" *threads*)
                "serially"))
  (ecase condition
    (first
      (when *solution-paths*
        (if (typep *solution-type* 'fixnum)
            (format t "~2%Search ended after finding ~D solution~:P (as requested)." 
                    (length *solution-paths*))
            (format t "~2%Search ended with first solution found."))))
    (time-limit  ;CHANGED
      (format t "~2%Search stopped at the time limit of ~A sec; it is not exhaustive." *time-limit*))  ;CHANGED
    (exhausted
      (format t "~2%~A search process completed normally." *algorithm*)
      (when (eql *solution-type* 'count)
        (format t "~2%Counting finished within the search limits and pruning rules; at most one example retained."))
      (when (eql *solution-type* 'every)
        (cond (*hybrid-mode*
               (format t "~2%Hybrid mode enumerated all paths to goal states at depth ~D."
                       *depth-cutoff*))
              ((and (eql *tree-or-graph* 'tree) (eql *symmetry-pruning* nil))
               (format t "~2%Exhaustive search for every solution finished (up to the depth cutoff, if any)."))
              (t
               (format t "~2%Exhaustive search for every solution finished (except solutions in pruned branches)."))))
      (when (eql *solution-type* 'all-paths)
        (if *hybrid-mode*
            (format t "~2%ALL-PATHS enumerated all paths to all goal states at depth ~D."
                    *depth-cutoff*)
            (format t "~2%ALL-PATHS fell back to EVERY semantics: one representative path per unique goal state.")))))
  (format t "~2%Depth cutoff = ~:D" *depth-cutoff*)
  (format t "~2%Maximum depth explored = ~:D" *max-depth-explored*)
  (format t "~2%Program cycles = ~:D" *program-cycles*)
  (let* ((elapsed (/ (- (get-internal-real-time) *start-time*)
                     internal-time-units-per-second))
         (total-secs (round elapsed)))
    (format t "~2%Elapsed time = ~Dh ~Dm ~Ds (~,1F sec)"
            (floor total-secs 3600) (floor (mod total-secs 3600) 60) (mod total-secs 60)
            elapsed))
  (format t "~2%Total states processed = ~:D" *total-states-processed*)
  (when (eql *tree-or-graph* 'graph)
    (format t "~2%Repeated states pruned = ~:D, ie, ~,1F percent"
              *repeated-states* (* (/ *repeated-states* *total-states-processed*) 100)))
  (when (> *dead-end-num-paths* 0)
    (format t "~2%Average dead-end depth = ~A"
            (round (/ *dead-end-accumulated-depths* *dead-end-num-paths*))))
  (when (> *duplicate-num-paths* 0)
    (format t "~2%Average duplicate depth = ~A"
            (round (/ *duplicate-accumulated-depths* *duplicate-num-paths*))))
  (when (> *depth-cutoff-hits* 0)
    (format t "~2%Depth-cutoff hits = ~:D, ie, ~,1F percent"
            *depth-cutoff-hits*
            (* 100.0 (/ *depth-cutoff-hits* *total-states-processed*))))
  (when (> *num-backtracks* 0)
    (format t "~2%Average backtrack distance = ~,1F levels (~:D backtracks)"
            (coerce (/ *accumulated-backtrack-distance* *num-backtracks*) 'single-float)
            *num-backtracks*))
  (when (> *inconsistent-states-dropped* 0)
    (format t "~%~%Abandoned ~D inconsistent state~:P."
            *inconsistent-states-dropped*))
  (when *failed-state-memory*
    (format t "~2%Failed-state memory recorded ~:D state~:P and skipped ~:D node~:P."
            *failed-states-recorded* *failed-states-skipped*))
  (when (> *bounding-pruned* 0)
    (format t "~2%Bounding function pruned ~:D node~:P, ~,1F% of total states."
            *bounding-pruned*
            (* 100.0 (/ *bounding-pruned* *total-states-processed*))))
  (when (or (> *lower-bound-pruned* 0) (> *min-steps-contributor-evaluations* 0))
    (format t "~2%Min-steps-remaining pruned ~:D node~:P, ~,1F% of total states~@[, in ~:D bound evaluations~]."
            *lower-bound-pruned*
            (* 100.0 (/ *lower-bound-pruned* *total-states-processed*))
            (when (> *min-steps-contributor-evaluations* 0)
              *min-steps-contributor-evaluations*)))
  (when (> *min-steps-fallback-evaluations* 0)
    (format t
            "~2%Aggregate lower-bound fallback: evaluated ~:D, skipped ~:D, uniquely pruned ~:D, reactivated ~:D time~:P."
            *min-steps-fallback-evaluations*
            *min-steps-fallback-skipped*
            *min-steps-fallback-unique-prunes*
            *min-steps-fallback-reactivations*))
  (when (> *search-prefix-validations* 0)
    (format t "~2%Search-prefix validation pruned ~:D state~:P, ~,1F% of ~:D prefix validation~:P."
            *search-prefix-pruned*
            (* 100.0 (/ *search-prefix-pruned* *search-prefix-validations*))
            *search-prefix-validations*)
    (print-search-prefix-validator-breakdown))
  (when (> *successor-policy-pruned* 0)
    (format t "~2%Successor policies pruned ~:D state~:P, ~,1F% of total states."
            *successor-policy-pruned*
            (* 100.0 (/ *successor-policy-pruned* *total-states-processed*))))
  (when (and (not (eql *problem-type* 'csp)) (> *program-cycles* 0))
    ;; Computed from the final totals, since parallel workers never update *average-branching-factor*.
    (format t "~2%Average branching factor = ~,1F~%" (compute-average-branching-factor)))
  (print-candidate-solution-validation-statistics)
  (let ((sym-stats (format-symmetry-statistics)))
    (when sym-stats
      (format t "~%~A~%" sym-stats)))
  (format t "~%Start state:~%~A" (list-database (problem-state.idb *start-state*)))
  (format t "~2%Goal:~%~A~2%" (when (boundp 'goal-fn)
                                (get 'goal-fn :form)))  ;(symbol-value 'goal-fn)
  (when (eql *solution-type* 'count)
    (format t "~%Total accepted goals counted = ~:D ~2%" *solution-count*)
    (when *count-example*
      (format t "~%One accepted solution (not necessarily shortest or best):~%")
      (print-count-example *count-example*)))
  (when *solution-paths*  ;ie, recorded solution paths
    (let* ((shallowest-depth (reduce #'min *solution-paths* :key #'solution.depth))
           (shallowest-depth-solution (find shallowest-depth *solution-paths* :key #'solution.depth))
           (minimum-time (reduce #'min *solution-paths* :key #'solution.time))
           (minimum-time-solution (find minimum-time *solution-paths* :key #'solution.time))
           (min-max-value-solution (first *solution-paths*))
           (min-max-value (solution.value min-max-value-solution)))
      (format t "~2%Total solution paths recorded = ~:D, of which ~:D is/are unique solution paths" 
                (length *solution-paths*) (length *unique-solution-states*))
      (format t "~%Check *solution-paths* and *unique-solution-states* for solution records.")
      (case *solution-type*
        (first
          (format t "~2%Number of steps in first solution found: = ~:D" shallowest-depth)
          (format t "~2%Duration of first solution found = ~:D" minimum-time)
          (format t "~2%Solution path of first solution found from start state to goal state:~%")
          (printout-solution shallowest-depth-solution))
        (min-length
          (format t "~2%Number of steps in a minimum path length solution = ~:D" shallowest-depth)
          (format t "~2%A minimum length solution path from start state to goal state:~%")
          (printout-solution shallowest-depth-solution))
        (min-time
          (format t "~2%Duration of a minimum time solution = ~:D" minimum-time)
          (format t "~2%A minimum time solution path from start state to goal state:~%")
          (printout-solution minimum-time-solution))
        (min-value
          (format t "~2%Value of a minimum value solution = ~:D" min-max-value)
          (format t "~2%A minimum value solution path from start state to goal state:~%")
          (printout-solution min-max-value-solution))
        (max-value
          (format t "~2%Value of a maximum value solution = ~:D" min-max-value)
          (format t "~2%A maximum value solution path from start state to goal state:~%")
          (printout-solution min-max-value-solution))
        (every
          (format t "~2%Number of steps in a minimum path length solution = ~:D" shallowest-depth)
          (format t "~2%A minimum length solution path from start state to goal state:~%")
          (printout-solution shallowest-depth-solution)
          (cond ((and (not (eq *problem-type* 'csp))
                      (equalp shallowest-depth-solution minimum-time-solution))
                   (format t "~%A shortest path solution is also a minimum duration solution.~2%"))
                (t (unless (eq *problem-type* 'csp)
                     (format t "~2%Duration of a minimum time solution = ~:D" minimum-time)
                     (format t "~2%A minimum time solution path from start state to goal state:~%")
                     (printout-solution minimum-time-solution)))))
        (all-paths
          (format t "~2%Total paths enumerated = ~:D across ~:D unique goal state~:P."
                  (length *solution-paths*) (length *unique-solution-states*))
          (format t "~2%Number of steps in a minimum path length solution = ~:D" shallowest-depth)
          (format t "~2%A minimum length solution path from start state to goal state:~%")
          (printout-solution shallowest-depth-solution)))))
  (if (boundp 'goal-fn)
    (when (or (and (eql *solution-type* 'count) (= *solution-count* 0))
              (and (not (eql *solution-type* 'count)) (null *solution-paths*)))
      (format t "~&No solutions found.~%"))
    (format t "~&No goal specified, but best results follow:"))
  (unless (boundp 'goal-fn)
    (format t "~2%Total number of results recorded = ~:D." (length *best-states*))
    (format t "~%Check *best-states* for all result records.")
    (case *solution-type*
        (min-value
          (let ((best-state (reduce #'(lambda (a b)
                                        (if (<= (problem-state.value a) (problem-state.value b))
                                          a
                                          b))
                                    *best-states*)))
            (format t "~2%The minimum objective value found = ~:D" (problem-state.value best-state))
            (format t "~2%A minimum value state:~%")
            (print-problem-state best-state)
            (format t "~2%")))
        (max-value
          (let ((best-state (reduce #'(lambda (a b)
                                        (if (>= (problem-state.value a) (problem-state.value b))
                                          a
                                          b))
                                    *best-states*)))
            (format t "~2%The maximum objective value found = ~:D" (problem-state.value best-state))
            (format t "~2%A maximum value state:~%")
            (print-problem-state best-state)
            (format t "~2%")))))
  (print-search-tree))


(defun print-search-tree ()
  (when (and (not (> *threads* 0)) (or (= *debug* 1) (= *debug* 2)))
    (when (y-or-n-p "~%Display search tree?")
      (format t "~2%Search tree:~%")
      (loop for act in (reverse *search-tree*)
            do (if (alexandria:length= 2 act)
                 (format t "~vT~d:~a~%" (* 3 (second act)) (second act) (first act))
                 (case *debug*
                   (1 (format t "~vT~d:~a ~a~%"
                                (* 3 (second act)) (second act) (first act) (third act)))
                   (2 (format t "~vT~d:~a ~a~%" 
                                (* 3 (second act)) (second act) (first act) (third act))
                      (format t "~vT  ~a~%"
                                (* 3 (second act)) (fourth act))
                      (when (fifth act)
                        (format t "~vT  ~a~%"
                                  (* 3 (second act)) (fifth act))))))
            finally (terpri)))))

 
(defun print-count-example (solution)
  "Print the retained path and final state directly, without replaying the actions."
  (format t "~&Number of steps = ~D~%" (solution.depth solution))
  (dolist (step (solution.path solution))
    (format t "~S~%" step))
  (format t "~&Goal state:~%")
  (print-problem-state (solution.goal solution)))


(defun count-accepted-goal ()
  "Count a validated goal; return true only to the caller claiming the first example.
   The lock makes this claim exclusive across workers; integer addition permits bignums."
  (= 1 (if (> *threads* 0)
           (bt:with-lock-held (*lock*)
             (incf *solution-count*))
           (incf *solution-count*))))


(defun register-solution (goal-node)
  "Records the path ending at GOAL-NODE as a solution."
  (declare (type node goal-node))
  (when *failed-state-memory*
    (mark-goal-ancestors goal-node))
  (when (eql *solution-type* 'count)
    (when (count-accepted-goal)
      (setf *count-example*
            (make-search-solution (candidate-path-to-goal-node goal-node)
                                  (node.state goal-node))))
    (return-from register-solution nil))
  (let* ((goal-state (node.state goal-node))
         (state-depth (node.depth goal-node))
         (solution (make-search-solution (candidate-path-to-goal-node goal-node) goal-state)))
    (when (report-solution-found-p)
      (let ((ctrl-str (if (zerop state-depth)
                          "Start state satisfies goal; recorded zero-action solution at depth = ~:D"
                          "New path to goal found at depth = ~:D")))
        (cond ((> *threads* 0)
               #+:ww-debug (when (>= *debug* 1)
                             (lprt))
               (bt:with-lock-held (*lock*)
                 (if (or (eql *solution-type* 'min-value) (eql *solution-type* 'max-value))
                   (format t (concatenate 'string "~&" ctrl-str
                                          "~%Objective value = ~:A~2%")
                            state-depth (solution.value solution))
                   (format t (concatenate 'string "~&" ctrl-str "~%") state-depth))
                 (finish-output)))
              (t (format t (concatenate 'string "~%" ctrl-str) state-depth)
               (when (or (eql *solution-type* 'min-value) (eql *solution-type* 'max-value))
                 (format t " Objective value = ~:A~%" (solution.value solution)))
               (when (eql *solution-type* 'min-time)
                 (format t "Time = ~:A~%" (solution.time solution)))
               (finish-output)))))
    (when (eql *algorithm* 'depth-first)
      (narrate "Solution found ***" goal-state state-depth))
    (push-global solution *solution-paths*)
    (reactivate-min-steps-fallback)
    (setf *last-improvement-states* *total-states-processed*)
    ;; Replace existing unique solution if new one is better
    (with-search-structures-lock
      (let* ((new-idb (problem-state.idb (solution.goal solution)))
             (existing (find new-idb *unique-solution-states*
                             :key (lambda (soln)
                                    (problem-state.idb (solution.goal soln)))
                             :test #'equalp)))
        (cond (existing
               ;; Replace if new solution is better
               (when (solution-better-p solution existing)
                 (setf *unique-solution-states*
                       (substitute solution existing *unique-solution-states*))))
              (t
               (push-global solution *unique-solution-states*)))))))


(defun make-search-solution (path goal-state)
  "Makes the solution record for PATH ending at GOAL-STATE.  Depth and time are
   taken from PATH itself, so the backward tail of a bidirectional path counts."
  (declare (type list path) (type problem-state goal-state))
  (make-solution
    :depth (length path)
    :time (if path
            (first (car (last path)))
            (problem-state.time goal-state))
    :value (problem-state.value goal-state)
    :path path
    :goal goal-state))


(defun report-solution-found-p ()
  "True when a newly found solution should be announced: the first one, each
   new best of an optimizing search, or every one when *debug* >= 1.  Call
   before the new solution is pushed onto *solution-paths*."
  (or (null *solution-paths*)
      (member *solution-type* '(min-length min-time min-value max-value))
      (>= *debug* 1)))


(defun printout-solution (soln)
  (declare (type solution soln))
  (if *enum-csp-search-active*
      (format t "~%(Enumerator assignment path, not replayable; display skipped.)~%")
      (progn
        (printout-solution-with-states soln)
        (dolist (printer *solution-report-printers*)
          (funcall (symbol-function printer) soln)))))


(defun printout-solution-with-states (soln)
  "Print solution path with database state after each action.
   Used when *debug* >= 2 to show state progression.
   On replay failure, prints a diagnostic and returns immediately;
   subsequent steps cannot be displayed once state reconstruction
   has lost synchronization with the recorded plan."
  (declare (type solution soln))
  (let ((path (solution.path soln))
        (current-state (copy-problem-state *start-state*))
        (step 0))
    (write (list (problem-state.time *start-state*) '(START-STATE)) :pretty t)
    (terpri)
    (format t "~A~%" (list-database (problem-state.idb current-state)))
    (terpri)
    (dolist (item path)
      (incf step)
      (let* ((action-form (second item))
             (new-state (apply-action-to-state action-form current-state nil nil)))
        (write-string (format-action-entry-for-display item))
        (terpri)
        (cond (new-state
               (setf current-state new-state)
               (format t "~A~%" (list-database (problem-state.idb current-state)))
               (terpri))
              (t
               (report-replay-failure step action-form current-state)
               (return-from printout-solution-with-states)))))
    (terpri)))


(defun report-replay-failure (step action-form last-good-state)
  "Print a diagnostic for replay failure in printout-solution-with-states.
   Replay failure is a system invariant violation: the recorded action
   did not reproduce when re-applied to its predecessor state. Likely
   cause is a bug in the action's precondition or effect form."
  (format t "~%============================================================~%")
  (format t "REPLAY FAILURE at step ~D~%" step)
  (format t "Action: ~A~%" (format-action-for-display action-form))
  (format t "Last consistent state (time ~A):~%" (problem-state.time last-good-state))
  (format t "  ~A~%" (list-database (problem-state.idb last-good-state)))
  (format t "The recorded action did not reproduce when re-applied to~%")
  (format t "this state. This indicates a system invariant violation,~%")
  (format t "likely a bug in the action's precondition or effect form.~%")
  (format t "Display halted; subsequent steps cannot be reconstructed.~%")
  (format t "============================================================~%"))


(defun print-search-progress ()
  "Print search progress using appropriate global variables"
  (bt:with-lock-held (*lock*)
    (printout-search-progress)))


(defun printout-search-progress ()
  "Printout of search progress modulo reporting interval. Metrics are grouped
   into diagnostic categories - Execution, Search Space, Search Dynamics,
   Progress, Optimization, Parallel - each gated by relevant search context
   (*problem-type*, *tree-or-graph*, *threads*, *solution-type*, etc.).
   Empty sections produce no output."
  (when (progress-report-due-p (- *total-states-processed* *prior-total-states-processed*))
    ;; ===== Execution =====
    (format t "~2%total states processed so far = ~:D" *total-states-processed*)
    (format t "~%current recent processing speed = ~:D states/sec"
            (round (/ (the fixnum (- *total-states-processed* *prior-total-states-processed*))
                      (/ (max 1 (- (get-internal-real-time) *prior-time*))  ;a report within one clock tick
                         internal-time-units-per-second))))
    ;; ===== Search Space =====
    (unless (eql *problem-type* 'csp)
      (format t "~%net average branching factor = ~,1F (recent: ~,1F)"
              *average-branching-factor*
              (coerce (/ (- *total-states-processed* *prior-total-states-processed*)
                         (- *program-cycles* *prior-program-cycles*))
                      'single-float))
      (when (> *max-depth-explored* 0)
        (format t "~%effective branching factor (b*) = ~,2F"
                (compute-effective-branching-factor *total-states-processed*
                                                    *max-depth-explored*))))
    (when (> *dead-end-num-paths* 0)
      (format t "~%average dead-end depth = ~A"
              (round (/ *dead-end-accumulated-depths* *dead-end-num-paths*))))
    (when (> *duplicate-num-paths* 0)
      (format t "~%average duplicate depth = ~A"
              (round (/ *duplicate-accumulated-depths* *duplicate-num-paths*))))
    (when (> *depth-cutoff-hits* 0)
      (format t "~%depth-cutoff hits = ~:D (~,1F% of total states)"
              *depth-cutoff-hits*
              (* 100.0 (/ *depth-cutoff-hits* *total-states-processed*))))
    ;; ===== Search Dynamics =====
    (unless (eql *problem-type* 'csp)
      (format t "~%frontier nodes: ~:D"
              (if (> *threads* 0)
                  (total-parallel-frontier)
                  (ecase *algorithm*
                    (depth-first (hs::length-hstack *open*))
                    (backtracking (length *choice-stack*))))))
    (when (eql *tree-or-graph* 'graph)
      (if (> *threads* 0)
          ;; Parallel mode: sum counts across all shards
          (format t "~%ht count: ~:D    ht size: ~:D (across ~D shards)"
                  (closed-shards-total-count)
                  (loop for shard across *closed-shards* sum (hash-table-size shard))
                  *num-closed-shards*)
          ;; Serial mode: single hash table
          (format t "~%ht count: ~:D    ht size: ~:D"
                  (loop for bucket being the hash-values of *closed* sum (length bucket))
                  (hash-table-size *closed*)))
      (format t "~%repeated states pruned = ~:D (~,1F% of total states)"
                *repeated-states* (* 100.0 (/ *repeated-states* *total-states-processed*))))
    (when (and *symmetry-pruning* *symmetry-families*)
      (if (use-canonical-symmetry-p)
        (when (> *symmetric-duplicates-pruned* 0)
          (format t "~%symmetry pruned = ~:D (~,1F% of total states)"
                  *symmetric-duplicates-pruned*
                  (* 100.0 (/ *symmetric-duplicates-pruned* *total-states-processed*))))
        (when (> *symmetry-pruning-count* 0)
          (format t "~%symmetry pruned = ~:D (~,1F% of ~:D instantiations checked)"
                  *symmetry-pruning-count*
                  (symmetry-pruning-percentage)
                  *symmetry-check-count*))))
    (when (> *bounding-pruned* 0)
      (format t "~%bounding function pruned = ~:D (~,1F% of total states)"
              *bounding-pruned*
              (* 100.0 (/ *bounding-pruned* *total-states-processed*))))
    (when (or (> *lower-bound-pruned* 0) (> *min-steps-contributor-evaluations* 0))
      (format t "~%min-steps-remaining pruned = ~:D (~,1F% of total states)~@[ in ~:D bound evaluations~]"
              *lower-bound-pruned*
              (* 100.0 (/ *lower-bound-pruned* *total-states-processed*))
              (when (> *min-steps-contributor-evaluations* 0)
                *min-steps-contributor-evaluations*)))
    (when (> *min-steps-fallback-evaluations* 0)
      (format t "~%aggregate lower-bound fallback: evaluated = ~:D, skipped = ~:D, uniquely pruned = ~:D"
              *min-steps-fallback-evaluations*
              *min-steps-fallback-skipped*
              *min-steps-fallback-unique-prunes*))
    (when (> *search-prefix-validations* 0)
      (format t "~%search-prefix validation pruned = ~:D (~,1F% of ~:D prefix validations)"
              *search-prefix-pruned*
              (* 100.0 (/ *search-prefix-pruned* *search-prefix-validations*))
              *search-prefix-validations*))
    (when (> *num-backtracks* 0)
      (format t "~%average backtrack distance = ~,1F levels (~:D backtracks)"
              (coerce (/ *accumulated-backtrack-distance* *num-backtracks*) 'single-float)
              *num-backtracks*))
    ;; ===== Progress / Coverage =====
    (when (and (zerop *threads*) (not (eql *problem-type* 'csp)))
      (iter (while (and *rem-init-successors*
                        (not (idb-in-open (node.state (first *rem-init-successors*))
                                          *open*
                                          (node.depth (first *rem-init-successors*))))))
            (pop-global *rem-init-successors*))
      (format t "~%current progress: in #~:D of ~:D initial branches"
              (the fixnum (- *num-init-successors*
                             (length *rem-init-successors*)))
              *num-init-successors*))
    ;; ===== Optimization =====
    (when (eql *solution-type* 'count)
      (format t "~%accepted goals counted = ~:D" *solution-count*))
    (when (or *hybrid-goals* *solution-paths*)
      (format-best-solution-line (- *total-states-processed* *last-improvement-states*))
      (when (and (member *solution-type* '(min-value max-value))
                 *solution-paths*
                 (< *upper-bound* 1000000))
        (let* ((best-val (solution.value (first *solution-paths*)))
               (gap (abs (- *upper-bound* best-val))))
          (unless (zerop gap)
            (format t "~%anytime gap = ~A (best = ~A, upper bound = ~A)"
                    gap best-val *upper-bound*)))))
    ;; ===== Parallel =====
    (when (> *threads* 0)
      (format t "~%threads currently idle: ~D of ~D"
              *num-idle-threads* *threads*)
      (when (and (eql *tree-or-graph* 'graph) *closed-shards*)
        (let* ((shard-counts (loop for shard across *closed-shards*
                                   collect (hash-table-count shard)))
               (max-count (reduce #'max shard-counts))
               (min-count (reduce #'min shard-counts))
               (skew (if (zerop min-count)
                         'infinite
                         (coerce (/ max-count min-count) 'single-float))))
          (format t "~%closed-shard load: max=~:D  min=~:D  skew=~A"
                  max-count min-count
                  (if (numberp skew) (format nil "~,1Fx" skew) skew)))))
    ;; ===== Closing =====
    (let* ((total-secs (round (/ (- (get-internal-real-time) *start-time*)
                                 internal-time-units-per-second)))
           (hrs (floor total-secs 3600))
           (mins (floor (mod total-secs 3600) 60))
           (secs (mod total-secs 60)))
      (format t "~%elapsed time = ~Dh ~Dm ~Ds" hrs mins secs))
    (format t "~2%")
    (finish-output)
    (setf *prior-time* (get-internal-real-time))
    (setf *prior-total-states-processed* *total-states-processed*)
    (setf *prior-program-cycles* *program-cycles*)
    (advance-progress-schedule)))


(defun format-best-solution-line (states-since)
  "Print the headline best-solution line for the Optimization section,
   dispatching on *hybrid-mode* and *solution-type*. Caller is responsible
   for verifying that *solution-paths* or *hybrid-goals* is non-nil."
  (declare (type fixnum states-since))
  (cond
    (*hybrid-mode*
     (format t "~%hybrid goals deferred = ~:D (~:D states since last)"
             (length *hybrid-goals*) states-since))
    ((member *solution-type* '(first min-length))
     (let ((best (first *solution-paths*)))
       (format t "~%best solution depth = ~:D (~:D states since last improvement)"
               (solution.depth best) states-since)))
    ((eql *solution-type* 'min-time)
     (let ((best (first *solution-paths*)))
       (format t "~%best solution time = ~A (depth ~:D, ~:D states since last improvement)"
               (solution.time best) (solution.depth best) states-since)))
    ((member *solution-type* '(min-value max-value))
     (let ((best (first *solution-paths*)))
       (format t "~%best solution value = ~A (depth ~:D, ~:D states since last improvement)"
               (solution.value best) (solution.depth best) states-since)))
    ((member *solution-type* '(every all-paths))
     (format t "~%solutions found = ~:D unique (~:D states since last new)"
             (length *unique-solution-states*) states-since))
    ((typep *solution-type* 'fixnum)
     (format t "~%solutions found = ~:D of ~D (~:D states since last new)"
             (length *unique-solution-states*) *solution-type* states-since))))


(defun ww-solve ()
  "Runs a branch & bound search on the problem specification."
  (reject-worker-read-write 'ww-solve)
  (validate-bt-path-mode)
  (validate-worker-read-snapshot-mode)
  ;; A prior result stops being a continuation candidate as soon as another search starts.
  ;; Clear here rather than relying on DFS, whose initial-invariant failure exits before
  ;; DFS's own search-statistics reset.
  (setf *solution-paths* nil
        *solutions-valid* nil
        *last-search-outcome*
          (make-search-outcome :status :unknown :reason :running))
  (let ((completed nil)
        (dfs-result nil))
    (unwind-protect
        (handler-bind
            ((storage-condition
               (lambda (condition)
                 (declare (ignore condition))
                 (setf *last-search-outcome*
                       (make-search-outcome
                         :status :unknown :reason :out-of-memory))))
             (serious-condition
               (lambda (condition)
                 (declare (ignore condition))
                 (when (eq (search-outcome-reason *last-search-outcome*) :running)
                   (setf *last-search-outcome*
                         (make-search-outcome
                           :status :unknown :reason :interrupted))))))
          (if (> *threads* 0)
            (format t "~%working with ~D thread(s)...~2%" *threads*)
            (format t "~%working...~2%"))
          (setf *time-limit-reached* nil  ;CHANGED
                *search-deadline* (when (plusp *time-limit*)  ;CHANGED
                                    (+ (get-internal-real-time)  ;CHANGED
                                       (round (* *time-limit* internal-time-units-per-second)))))  ;CHANGED
          (setf dfs-result (time (dfs))
                completed t))
      (setf *search-deadline* nil)  ;CHANGED
      (setf *solutions-valid*
            (and completed
                 (member dfs-result '(:solution-limit-reached :exhausted :time-limit))  ;CHANGED
                 (not (null *solution-paths*))))
      (when completed
        (setf *last-search-outcome*
              (cond
                ((and *solutions-valid* (eq dfs-result :exhausted))
                 (make-search-outcome
                   :status :exhausted-with-solutions :reason :complete))
                (*solutions-valid*
                 (make-search-outcome :status :solution :reason dfs-result))
                ((eq dfs-result :exhausted)
                 (make-search-outcome
                   :status :exhausted-no-solution
                   :reason (if *depth-cutoff-truncated*
                             :depth-cutoff-truncated
                             :complete)))
                (t
                 (make-search-outcome :status :unknown :reason dfs-result)))))))
  (in-package :ww))


(defun defer-hybrid-goal (current-node goal-state)
  "Stores a goal-reaching pair for deferred enumeration after search completes.
   Called in hybrid mode when a goal is reached.
   When canonical symmetry is active, skips canonically-equivalent goals."
  (declare (type node current-node) (type problem-state goal-state))
  (let ((goal-depth (1+ (node.depth current-node))))
    ;; For canonical symmetry, check if equivalent goal already deferred
    (when (use-canonical-symmetry-p)
      (ensure-idb-hash goal-state)
      (let ((goal-hash (problem-state.idb-hash goal-state)))
        (when (find-if (lambda (pair)
                         (let ((existing-goal (cdr pair)))
                           (ensure-idb-hash existing-goal)
                           (and (= (problem-state.idb-hash existing-goal)
                                   goal-hash)
                                (canonical-state-equal-p
                                  goal-state existing-goal))))
                       *hybrid-goals*)
          (narrate "Duplicate solution found (via symmetry) ***" goal-state goal-depth)
          (increment-global *repeated-states*)
          (return-from defer-hybrid-goal))))
    (narrate "Solution found (hybrid mode) ***" goal-state goal-depth)
    (push-global (cons current-node goal-state) *hybrid-goals*)
    (setf *last-improvement-states* *total-states-processed*)))


(defun finalize-hybrid-solutions ()
  "Enumerates all solutions from stored goal-reaching pairs after search completes.
   Called once when all parent DAGs are fully constructed."
  (dolist (pair *hybrid-goals*)
    (let* ((current-node (car pair))
           (goal-state (cdr pair))
           (state-depth (1+ (node.depth current-node)))
           (goal-move (record-move goal-state))
           (paths-to-current (enumerate-paths-to-node current-node))
           (num-paths (length paths-to-current))
           (goal-idb (problem-state.idb goal-state)))
      (declare (ignore num-paths))
      (dolist (path paths-to-current)
        (let* ((full-path (append path (list goal-move)))
               (solution (make-solution
                           :depth state-depth
                           :time (problem-state.time goal-state)
                           :value (problem-state.value goal-state)
                           :path full-path
                           :goal goal-state)))
          (when (candidate-solution-valid-p full-path goal-state)
            (push-global solution *solution-paths*)
            (with-search-structures-lock
              (let ((existing
                      (find goal-idb *unique-solution-states*
                            :key (lambda (soln)
                                   (problem-state.idb (solution.goal soln)))
                            :test #'equalp)))
                (cond (existing
                       ;; Replace if new solution is better
                        (when (solution-better-p solution existing)
                          (setf *unique-solution-states*
                                (substitute solution existing *unique-solution-states*))))
                      (t
                       (push-global solution *unique-solution-states*)))))))))))
