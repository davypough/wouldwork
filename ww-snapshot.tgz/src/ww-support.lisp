;;; Filename: ww-support.lisp

;;; Support functions for planning.


(in-package :ww)


(defmacro mvsetq (var-list form)
  `(multiple-value-setq ,var-list ,form))


(defmacro when-debug>= (n &rest expressions)
  "Inserts debugging expressions when *debug* >= n, otherwise NIL"
  `(when (>= *debug* ,n)
     ,@expressions))


(defmacro equivalent (&rest forms)
  "Returns true if all forms evaluate to nil, or if all forms evaluate to non-nil."
  `(or (and ,@forms)
       (and ,@(mapcar (lambda (form) `(null ,form)) forms))))


(defun troubleshoot (error-msg &rest args)
  (apply #'cerror "Troubleshoot the current node" error-msg args)
  (setf *troubleshoot-current-node* t)
  nil)


(defun profile ()
  "Deterministically profiles Wouldwork. Press Ctrl-C during the solve
   to abort early and still see a report of data gathered so far. Profiling
   instrumentation is always removed before this function returns."
  (sb-profile:reset)
  (sb-profile:profile "WOULDWORK")
  (unwind-protect
      (progn
        (handler-case (ww-solve)
          (sb-sys:interactive-interrupt ()
            (format t "~2%Profiling interrupted by user -- reporting data gathered so far.~%")))
        (sb-profile:report))
    (sb-profile:unprofile)))


;;;;;;;;;;;;; User Functions ;;;;;;;;;;;;;;;;;;;;;;;;;;


(defun eql* (&rest arguments)
  (every #'eql arguments (rest arguments)))


(defun different (sym1 sym2)
  "Determines whether two symbols are different."
  (if (and (symbolp sym1) (symbolp sym2))
    (not (eql sym1 sym2))
    (error "Arguments must be symbols: ~A ~A" sym1 sym2)))


(defun delete-actions (&rest names)
  "Deletes named actions from *actions* at run-time."
  (setf *actions* (delete-if (lambda (name)
                               (member name names))
                             *actions*
                             :key #'action.name)))


(defun get-state-codes ()
  "User calls this after finding backwards *solution-paths*."
  (format t "~%Working ...~%")
  (clrhash *state-codes*)
  (iter (for soln in *solution-paths*)
        (for path = (solution.path soln))
        (for db-props = (list-database (problem-state.idb (solution.goal soln))))
        (setf (gethash (funcall (symbol-function 'encode-state) db-props) *state-codes*) path))
  *state-codes*)


(defun backward-path-exists (state)
  "Use in forward search goal to check existence of backward path."
  (declare (type problem-state state))
  (gethash (funcall (symbol-function 'encode-state) (list-database (problem-state.idb state))) *state-codes*))


(defun make-ht-set (&rest args &key (initial-contents nil initial-contents-p) &allow-other-keys)
  "Makes a wouldwork hash-table that works as a set container for the user."
  (let* ((ht-args (if initial-contents-p
                    (alexandria:remove-from-plist args :initial-contents)
                    args))
         (ht (apply #'make-hash-table ht-args)))
    (when initial-contents-p
      (dolist (key initial-contents)
        (setf (gethash key ht) t)))
    ht))
    
    
(defun union-ht-set (&rest set-hts)
  "Unions two hash tables keys. Assumes values are all t and have the same :test function."
  (let ((test-fn (hash-table-test (first set-hts))))
    (assert (and (every (lambda (ht) (typep ht 'hash-table)) set-hts)
                 (every (lambda (ht) (eql (hash-table-test ht) test-fn)) (rest set-hts)))
            () "All arguments must be hash tables, and have the same :test function in union-ht.")
    (let ((result-ht (make-hash-table :test test-fn)))
      (dolist (ht set-hts)
        (maphash (lambda (key value)
                   (setf (gethash key result-ht) value))
                 ht))
      result-ht)))
      
      
(defun set-difference-ht-set (ht1 ht2)
  "Returns a new hash table that represents the set difference of HT1 and HT2."
  (assert (and (typep ht1 'hash-table)
               (typep ht2 'hash-table)
               (eql (hash-table-test ht1) (hash-table-test ht2)))
          () "The two arguments must be hash tables and have the same :test function in set-difference-ht.")
  (let ((result-ht (make-hash-table :test (hash-table-test ht1))))
    (maphash (lambda (key value)
               (unless (gethash key ht2)
                 (setf (gethash key result-ht) value)))
             ht1)
    result-ht))


(defun copy-ht-set (set-ht)
  "Copy a set hash table (with t values)."
  (loop with new-ht = (make-hash-table
                        :test (hash-table-test set-ht)
                        :size (hash-table-size set-ht)
                        :rehash-size (hash-table-rehash-size set-ht)
                        :rehash-threshold (hash-table-rehash-threshold set-ht))
      for key being the hash-keys in set-ht ;using (hash-value value)
      do (setf (gethash key new-ht) t)
      finally (return new-ht)))


(defun vectorize (lists)
  "Turns a list of lists into vector vectors."
  (iter (for list in lists)
        (collect (apply #'vector list) result-type 'simple-vector)))


#|
(defun make-bv-set (dotted-pairs)
  "Makes a bit vector that works as a set container corresponding to board coordinates."
  (let ((bv (make-array (* *row-dimension* *col-dimension*) :element-type 'bit :adjustable nil)))
    (dolist (pair dotted-pairs)
      (let* ((row (car pair))
             (col (cdr pair))
             (index (+ (* row *col-dimension*) col)))
        (setf (sbit bv index) 1)))
    bv))
|#

;;;;;;;;;;;;;;;;; Program Support Functions ;;;;;;;;;;;;;;;;


;(declaim (inline add-prop del-prop))


(defun add-int-prop-key (db key value)
  "Store VALUE at integer KEY in DB, preserving propagated-change detection
   and any active incremental idb-hash fold."
  (declare (type hash-table db)
           (type integer key))
  (if *detect-propagated-changes*
    (when (note-add-change db key value)
      (fold-store key value db t))
    (fold-store key value db t))
  t)


(defun del-int-prop-key (db key)
  "Remove integer KEY from DB, preserving propagated-change detection
   and any active incremental idb-hash fold."
  (declare (type hash-table db)
           (type integer key))
  (if *detect-propagated-changes*
    (when (note-del-change db key)
      (fold-remove key db t))
    (fold-remove key db t))
  t)


(defun add-prop (proposition db int-db
                 &optional indices precomputed-key precomputed-values)
  "Add one proposition, without expanding bijective or symmetric relations.
   INT-DB says whether DB uses integer proposition keys."
  (declare (type hash-table db))
  (let* ((fluent-indices (or indices (get-prop-fluent-indices proposition)))
         (value (if fluent-indices
                    (or precomputed-values
                        (get-prop-fluents proposition fluent-indices))
                    t))
         (key (if int-db
                  (or precomputed-key
                      (convert-fluentless-prop-to-integer proposition fluent-indices))
                   (if fluent-indices
                       (get-fluentless-prop proposition fluent-indices)
                       proposition))))
    (if int-db
      (add-int-prop-key db key value)
      (fold-store key value db nil))
    (when (gethash (car proposition) *complements*)
      (let* ((complement (get-complement-prop proposition))
             (complement-indices (get-prop-fluent-indices complement))
             (complement-key
               (if int-db
                   (convert-fluentless-prop-to-integer complement complement-indices)
                   (if complement-indices
                       (get-fluentless-prop complement complement-indices)
                       complement))))
        (if int-db
          (del-int-prop-key db complement-key)
          (fold-remove complement-key db nil))))))


(defun del-prop (proposition db int-db)
  "Delete one proposition, without expanding bijective or symmetric relations.
   INT-DB says whether DB uses integer proposition keys."
  (declare (type hash-table db))
  (let* ((fluent-indices (get-prop-fluent-indices proposition))
         (key (if int-db
                   (convert-fluentless-prop-to-integer proposition fluent-indices)
                   (if fluent-indices
                       (get-fluentless-prop proposition fluent-indices)
                       proposition))))
    (if int-db
      (del-int-prop-key db key)
      (fold-remove key db nil))
    (when (gethash (car proposition) *complements*)
      (let* ((complement (get-complement-prop proposition))
             (complement-indices (get-prop-fluent-indices complement)))
        ;; A deleted fluent supplies the values needed to restore either kind of
        ;; complement. A deleted non-fluent cannot restore a fluent complement.
        (when (or fluent-indices (null complement-indices))
          (let ((complement-key
                  (if int-db
                      (convert-fluentless-prop-to-integer complement complement-indices)
                      (if complement-indices
                          (get-fluentless-prop complement complement-indices)
                          complement)))
                (complement-value
                  (if complement-indices
                      (get-prop-fluents complement complement-indices)
                      t)))
            (if int-db
              (add-int-prop-key db complement-key complement-value)
              (fold-store complement-key complement-value db nil))))))))


(defun note-add-change (db key new-value)
  "Return true and set *PROPAGATED-STATE-CHANGED* when storing NEW-VALUE at KEY
   would change DB -- KEY is absent, or its current value differs."
  (multiple-value-bind (old-value present) (gethash key db)
    (let ((changed (or (not present)
                       (not (equal old-value new-value)))))
      (when changed
        (setf *propagated-state-changed* t))
      changed)))


(defun note-del-change (db key)
  "Return true and set *PROPAGATED-STATE-CHANGED* when KEY is present in DB."
  (let ((changed (nth-value 1 (gethash key db))))
    (when changed
      (setf *propagated-state-changed* t))
    changed))


(defun symmetry-object-in-tree-p (tree)
  "Whether a cons tree contains an object registered in a symmetry family."
  (cond ((consp tree)
         (or (symmetry-object-in-tree-p (car tree))
             (symmetry-object-in-tree-p (cdr tree))))
        (t
         (nth-value 1 (gethash tree *object-to-symmetry-membership*)))))


(defun encoded-idb-key-references-symmetry-p (key)
  "Whether integer IDB KEY encodes an object registered in a symmetry family."
  (loop with remaining = key
        do (multiple-value-bind (next code) (truncate remaining 1000)
             (when (nth-value 1
                     (gethash (gethash code (or *worker-name-read-view* *integer-constants*))   ; CHANGED
                              *object-to-symmetry-membership*))
               (return t))
             (when (zerop next)
               (return nil))
             (setf remaining next))))


(defun idb-entry-references-symmetry-p (key value)
  "Whether encoded IDB entry KEY/VALUE mentions any symmetry-family object."
  (or (encoded-idb-key-references-symmetry-p key)
      (symmetry-object-in-tree-p value)))


(defun begin-bt-undo (db)
  (make-bt-undo-frame :db db
                      :propagated-changed *propagated-state-changed*
                      :symmetry-touched *symmetry-idb-touched-p*))

(defun record-bt-undo (db key old present)
  "Capture the actual entry before mutation, after relation expansion."
  (when (and *bt-undo-frame*
             (or (eq db (bt-undo-frame.db *bt-undo-frame*)) (eq db *static-db*)))
    (setf (bt-undo-frame.head *bt-undo-frame*)
            (make-bt-undo-entry :key key :old-value old :present-p present
                               :previous (bt-undo-frame.head *bt-undo-frame*)
                               :secondary-db (unless (eq db (bt-undo-frame.db *bt-undo-frame*)) db)))))

(defun restore-bt-undo (frame)
  "Consume one application trail without recording rollback into a parent scope."
  (let ((*bt-undo-frame* nil))
    (loop for entry = (bt-undo-frame.head frame) while entry
          for db = (or (bt-undo-entry.secondary-db entry) (bt-undo-frame.db frame))
          for integer-p = (eq (hash-table-test db) 'eql) do
      (if (bt-undo-entry.present-p entry)
          (fold-store (bt-undo-entry.key entry) (bt-undo-entry.old-value entry) db integer-p)
          (fold-remove (bt-undo-entry.key entry) db integer-p))
      (setf (bt-undo-frame.head frame) (bt-undo-entry.previous entry)))
    (setf *propagated-state-changed* (bt-undo-frame.propagated-changed frame)
          *symmetry-idb-touched-p* (bt-undo-frame.symmetry-touched frame))))

(defun reject-bt-path-static-write (db key)
  (when (and *bt-path-search-active* (or (eq db *static-db*) (eq db *static-idb*)))
    (error "BT PATH cycle checking does not support static database writes (key ~S)." key)))

(defun fold-store (key value db int-db)
  "Store VALUE at KEY while maintaining the active standard or split hash accumulator.
   Standard mode folds every changed entry into *IDB-HASH-ACC*. Split mode folds fixed
   entries into *FIXED-IDB-HASH-ACC* and stores symmetry-bearing entries in
   *SYMMETRY-IDB-ACC*, setting *SYMMETRY-IDB-TOUCHED-P* so callers know the slice
   changed. An idempotent re-store leaves every accumulator unchanged."
  (declare (type hash-table db))
  (reject-worker-static-write db)
  (reject-bt-path-static-write db key)
  (multiple-value-bind (old present) (gethash key db)
    (when *bt-undo-frame* (record-bt-undo db key old present))
    (when int-db
      (unless (and present (equal old value))
        (cond
          ((and *fixed-idb-hash-acc* *symmetry-idb-acc*)
           (when present
             (if (idb-entry-references-symmetry-p key old)
                 (progn (remhash key *symmetry-idb-acc*)
                        (setf *symmetry-idb-touched-p* t))
                 (setf *fixed-idb-hash-acc*
                       (logxor *fixed-idb-hash-acc*
                               (deep-sxhash (cons key old))))))
           (if (idb-entry-references-symmetry-p key value)
               (progn (setf (gethash key *symmetry-idb-acc*) value)
                      (setf *symmetry-idb-touched-p* t))
               (setf *fixed-idb-hash-acc*
                     (logxor *fixed-idb-hash-acc*
                             (deep-sxhash (cons key value))))))
          (*idb-hash-acc*
           (when present
             (setf *idb-hash-acc*
                   (logxor *idb-hash-acc* (deep-sxhash (cons key old)))))
           (setf *idb-hash-acc*
                 (logxor *idb-hash-acc* (deep-sxhash (cons key value)))))))))
  (setf (gethash key db) value))


(defun fold-remove (key db int-db)
  "Remove KEY while maintaining the active standard or split hash accumulator.
   Standard mode folds the removed entry out of *IDB-HASH-ACC*. Split mode removes
   symmetry-bearing entries from *SYMMETRY-IDB-ACC*, setting *SYMMETRY-IDB-TOUCHED-P*,
   and folds fixed entries out of *FIXED-IDB-HASH-ACC*. A missing key leaves every
   accumulator unchanged."
  (declare (type hash-table db))
  (reject-worker-static-write db)
  (reject-bt-path-static-write db key)
  (multiple-value-bind (old present) (gethash key db)
    (when (and *bt-undo-frame* present) (record-bt-undo db key old present))
    (when int-db
      (when present
        (cond
          ((and *fixed-idb-hash-acc* *symmetry-idb-acc*)
           (if (idb-entry-references-symmetry-p key old)
               (progn (remhash key *symmetry-idb-acc*)
                      (setf *symmetry-idb-touched-p* t))
               (setf *fixed-idb-hash-acc*
                     (logxor *fixed-idb-hash-acc*
                             (deep-sxhash (cons key old))))))
          (*idb-hash-acc*
           (setf *idb-hash-acc*
                 (logxor *idb-hash-acc* (deep-sxhash (cons key old)))))))))
  (remhash key db))


(defun bijective-index-propositions (proposition)
  "For a bijective relation, returns list of internal index propositions.
   For (on A B) where ON is bijective, returns ((ON1 A B) (ON2 A B)).
   Returns NIL if the relation is not bijective."
  (let* ((relation-name (car proposition))
         (args (cdr proposition))
         (index-names (gethash relation-name *bijective-relations*)))
    (when index-names
      (loop for index-name in index-names
            collect (cons index-name args)))))


(defun bijective-index-value (index-name args db int-db)
  "Return the value currently stored under INDEX-NAME for ARGS' key position, or NIL
   if no fact currently occupies that key.  Reusing the full current ARGS to compute
   the key is safe regardless of which position INDEX-NAME treats as fluent: the
   fluent position is skipped by GET-PROP-FLUENT-INDICES/CONVERT-FLUENTLESS-PROP-TO-INTEGER
   either way, so its value here is never consulted."
  (let* ((proposition (cons index-name args))
         (fluent-indices (get-prop-fluent-indices proposition))
         (key (if int-db
                (convert-fluentless-prop-to-integer proposition fluent-indices)
                (get-fluentless-prop proposition fluent-indices))))
    (multiple-value-bind (vals present-p) (gethash key db)
      (when present-p (first vals)))))


(defun add-bijective-proposition (index-names args db int-db)
  "Write ARGS under both of a bijective relation's indices, first retracting any
   stale reverse mapping left by a different previous pairing on either side.
   Without this, reassigning one side would leave the old partner's own index entry
   still pointing back at it, and the two indices could permanently disagree about
   who is paired with whom."
  (destructuring-bind (index1-name index2-name) index-names
    (destructuring-bind (arg1 arg2) args
      (let ((old-arg2 (bijective-index-value index1-name args db int-db))
            (old-arg1 (bijective-index-value index2-name args db int-db)))
        (when (and old-arg2 (not (equal old-arg2 arg2)))
          (del-prop (list index2-name arg1 old-arg2) db int-db))
        (when (and old-arg1 (not (equal old-arg1 arg1)))
          (del-prop (list index1-name old-arg1 arg2) db int-db))))
    (dolist (index-name index-names)
      (add-prop (cons index-name args) db int-db))))


(defun add-proposition (proposition db &optional indices precomputed-key precomputed-values)
  "Adds an atomic proposition and all its symmetries to the database.
   For bijective relations, adds both internal index propositions, first retracting
   any stale reverse mapping -- see ADD-BIJECTIVE-PROPOSITION."
  (declare (type hash-table db))
  (let* ((int-db (eql (hash-table-test db) 'eql))
         (relation-name (car proposition))
         (args (cdr proposition))
         (index-names (gethash relation-name *bijective-relations*)))
    (if index-names
        (add-bijective-proposition index-names args db int-db)
        ;; Handle normal relation (existing logic)
        (let ((symmetric-indexes (gethash relation-name *symmetrics*)))
          (if (null symmetric-indexes)
            (add-prop proposition db int-db indices precomputed-key precomputed-values)
            (let ((symmetric-variables
                     (loop for indexes in symmetric-indexes
                           collect (loop for index in indexes
                                         collect (nth index args))))
                  (props (list (copy-list proposition))))
              (loop for vars in symmetric-variables
                    for idxs in symmetric-indexes do
                    (setf props (generate-new-propositions vars props idxs)))
              (loop for prop in props do
                    (add-prop prop db int-db))))))))

              
(defun delete-proposition (proposition db)
  "Deletes an atomic proposition and all its symmetries from the database.
   For bijective relations, deletes both internal index propositions."
  (declare (type hash-table db))
  (let* ((int-db (eql (hash-table-test db) 'eql))
         (relation-name (car proposition))
         (args (cdr proposition))
         (index-names (gethash relation-name *bijective-relations*)))
    (if index-names
        ;; Handle bijective relation directly (avoids building an intermediate list)
        (dolist (index-name index-names)
          (del-prop (cons index-name args) db int-db))
        ;; Handle normal relation (existing logic)
        (let ((symmetric-indexes (gethash relation-name *symmetrics*)))
          (if (null symmetric-indexes)
            (del-prop proposition db int-db)
            (let ((symmetric-variables
                     (loop for indexes in symmetric-indexes
                           collect (loop for index in indexes
                                         collect (nth index args))))
                  (props (list (copy-list proposition))))
              (loop for vars in symmetric-variables
                    for idxs in symmetric-indexes do
                    (setf props (generate-new-propositions vars props idxs)))
              (loop for prop in props do
                    (del-prop prop db int-db))))))))


(defun generate-new-propositions (vars propositions idxs)
  "Collects new propositions for each prop in propositions."
  (loop for prop in propositions
        append (generate-proposition-permutations vars prop idxs)))


(defun generate-proposition-permutations (vars proposition idxs)
  "Returns list of propositions generated from given proposition replacing
   items at indices with vars, respectively."
  (let (propositions)
    (alexandria:map-permutations
      (lambda (perm)
        (push (ut::subst-items-at-ascending-indexes perm (mapcar #'1+ idxs) proposition)
              propositions))
      vars)
    propositions))


(defun revise (db literals)
  "Updates a database given a simple list of atomic propositions."
  (declare (type hash-table db))
  (loop for literal in literals
      do (update db literal)
      finally (return db)))


(defun update (db literal)
  "For depth-first, single add or delete from db. Returns the literal for change tracking."
  (declare (type hash-table db))
  (when *print-updates*
    (ut::prt literal))
  (if (eql (car literal) 'not)
    (delete-proposition (second literal) db)
    (add-proposition literal db))
  literal)


(defun update-bt (db literal)
  "For backtracking, single add or delete from db.
   Returns the update proposition as first value.
   Returns an inverse literal as second value, except in a trailed CSP or PATH
   update. Physical undo records restore those writes; IMMEDIATE planning still
   needs inverse literals for its cycle check. Standalone calls retain inverses."
  (declare (type hash-table db))
  ;; Neither CSP nor PATH uses inverse-literal cycle checking.
  (when (and *bt-undo-frame*
             (or (eql *problem-type* 'csp) *bt-cycle-check*))
    (return-from update-bt (values (update db literal) nil)))
  (when *print-updates*
    (ut::prt literal))
  (if (eql (car literal) 'not)
      ;; Negative literal: deletion case
      (progn
        (delete-proposition (second literal) db)
        (values literal (second literal)))   ;should return inverse = not literal
      ;; Positive literal: addition/update case
      (let ((fluent-indices (get-prop-fluent-indices literal)))
        (if fluent-indices
          ;; Fluent case: capture current value before overwriting
          (let* ((key (convert-fluentless-prop-to-integer literal fluent-indices)))
            (multiple-value-bind (vals present-p)
                (gethash key db)
              (add-proposition literal db
                               fluent-indices
                               key
                               (get-prop-fluents literal fluent-indices))
              (if present-p
                  ;; Reconstruct previous literal
                  (values literal
                          (reconstruct-literal-with-fluent-values literal fluent-indices vals))
                  ;; No previous value exists
                  (values literal (list 'not literal)))))
          ;; Non-fluent case: standard behavior
          (progn
            (add-proposition literal db)
            (values literal (list 'not literal)))))))


(defun expand-into-plist (parameters)
  "Return alternating plist of variable/type from input parameter list."
  (loop for (vars type) on parameters by #'cddr
      if (listp vars)
      append (ut::intersperse type vars) into plist
      else append (list vars type) into plist
        finally (return plist)))


(defun get-fluentless-prop (proposition &optional indices)
  "Derives the fluentless proposition counterpart from a full proposition."
  (let ((fluent-indices (or indices (get-prop-fluent-indices proposition))))
    (if (null fluent-indices)
        (copy-list proposition)
        (loop with remaining-indices = fluent-indices
              for i from 0
              for item in proposition
              unless (and remaining-indices (= i (first remaining-indices)))
                collect item
              else
                do (setf remaining-indices (rest remaining-indices))))))


(defun convert-fluentless-prop-to-integer (proposition &optional indices)
  "Convert PROPOSITION with fluent slots removed directly to integer key.
   Avoids constructing an intermediate fluentless list in int-db update paths."
  (let ((fluent-indices (or indices (get-prop-fluent-indices proposition))))
    (if (null fluent-indices)
        (convert-to-integer proposition)
        (loop with remaining-indices = fluent-indices
              with key of-type integer = 0
              with multiplier of-type integer = 1
              for i from 0
              for item in proposition
              unless (and remaining-indices (= i (first remaining-indices)))
                do (let ((code (or (gethash item *constant-integers*)
                                   ;; Fallback preserves object-indexing semantics while avoiding list allocation.
                                   (bt:with-lock-held (*integer-lock*)
                                     (or (gethash item *constant-integers*)
                                         (progn
                                           (reject-worker-read-write
                                             (list 'convert-fluentless-prop-to-integer item))
                                           (when (>= *last-object-index* 999)
                                             (error "Design Limit Error: Total # of actual + derived planning objects > 999"))
                                           (incf *last-object-index*)
                                           (setf (gethash item *constant-integers*) *last-object-index*)
                                           (setf (gethash *last-object-index* *integer-constants*) item)
                                           *last-object-index*))))))
                     (incf key (* code multiplier))
                     (setf multiplier (* multiplier 1000)))
              else
                do (setf remaining-indices (rest remaining-indices))
              finally (return key)))))


(defun reconstruct-literal-with-fluent-values (literal indices values)
  "Return LITERAL with fluent positions replaced by VALUES."
  (loop with remaining-indices = indices
        with remaining-values = values
        for i from 0
        for item in literal
        collect (if (and remaining-indices (= i (first remaining-indices)))
                    (prog1 (first remaining-values)
                      (setf remaining-indices (rest remaining-indices))
                      (setf remaining-values (rest remaining-values)))
                    item)))


(defun get-complement-prop (proposition)
  "Derives the complement proposition counterpart from a given proposition."
  (let* ((predicate (car proposition))
         (joint-patterns (gethash predicate *complements*))
         (prop-pattern (first joint-patterns))
         (comp-pattern (copy-tree (second (second joint-patterns)))))
    (loop for const in (cdr proposition)
          for pat in (cdr prop-pattern)
          when (member pat comp-pattern :test #'equal)
            do (nsubst const pat comp-pattern :test #'equal)
          finally (return comp-pattern))))


(defun dissect-pre-params (pre-param-list)
  (iter (for item in pre-param-list)
        (for prior-item previous item)
        (cond ((member item *parameter-headers*) (collecting item into types))  ;header
              ((?varp item) (collecting item into ?vars))  ;?variable
              ((and (listp item) (?varp (first item)))  ;list of ?variables
                 (appending item into ?vars))
              ((nth-value 1 (gethash item *types*))  ;type
                 (if (symbolp prior-item)  ;single prior ?variable
                   (collecting item into types)
                   (appending (make-list (length prior-item) :initial-element item) into types)))  ;multiple prior ?variables
              ((and (listp item)
                    (member (first item) *query-names*))  ;call to a query
                 (if (symbolp prior-item)  ;single prior ?variable
                   (collecting item into types)
                   (appending (make-list (length prior-item) :initial-element item) into types)))
              (($varp item)  ;$variable holding a runtime list of instances
                 (if (symbolp prior-item)  ;single prior ?variable
                   (collecting item into types)
                   (appending (make-list (length prior-item) :initial-element item) into types)))
              ((eql (first item) 'either)  ;combo type
                 (let* ((new-type (intern (ut::interleave+ (ut::sort-symbols (cdr item)))))
                        (type-instances (mapcar (lambda (type) (gethash type *types*)) (cdr item)))
                        (combined-instances (if (every #'null type-instances)
                                              '(nil)
                                              (remove-duplicates (apply #'append type-instances)))))
                   (setf (gethash new-type *types*) combined-instances)
                   (setf (gethash new-type *type-components*) (cdr item))  ;← added: schema, exactly as INSTALL-TYPES retains it for a named (either ...) type, so TYPE-SPEC-LEAF-TYPES can expand this synthesized name instead of treating it as an opaque leaf
                   (if (symbolp prior-item)  ;single prior ?variable
                     (collecting new-type into types)
                     (appending (make-list (length prior-item) :initial-element new-type) into types))))
              ((member (first item) *parameter-headers*)  ;subparameter list
                 (multiple-value-bind (additional-?vars additional-types)
                   (dissect-pre-params item)
                   (collecting additional-?vars into ?vars)
                   (collecting additional-types into types)))
              (t (error "Problem detected in dissect-pre-params: ~A" pre-param-list)))
        (finally (return (values ?vars types)))))


(defun flatten-param-types (types)
  "Flattens a pre-param-types list (as returned by DISSECT-PRE-PARAMS) so the result
   aligns positionally, one-for-one, with (alexandria:flatten pre-param-?vars). Discards
   header symbols (from *parameter-headers*), which have no corresponding ?var slot.
   A nested list whose first element is itself a header is a recursively-dissected
   subparameter list and is flattened in turn. Any other list is a single type-spec for
   one ?var -- a query-call form, the only kind of list that reaches this function
   intact, since an inline either-combo is already normalized to a synthesized type
   symbol by DISSECT-PRE-PARAMS -- and is kept as one unit rather than descended into.
   A $variable domain is likewise kept as one unit; its type resolves to :unknown."
  (mapcan (lambda (item)
            (cond ((member item *parameter-headers*) nil)
                  ((and (consp item) (member (car item) *parameter-headers*))
                   (flatten-param-types item))
                  (t (list item))))
          types))


(defun query/update-parameter-type-p (item)
  "Whether ITEM is a Wouldwork object type allowed in a query/update signature."
  (or (nth-value 1 (gethash item *types*))
      (and (consp item)
           (eq (first item) 'either)
           (consp (rest item))
           (every (lambda (type)
                    (nth-value 1 (gethash type *types*)))
                  (rest item)))))


(defun dissect-query-params-tail (remaining variables types)
  "Parse REMAINING query/update signature items into aligned VARIABLES and TYPES."
  (when (null remaining)
    (return-from dissect-query-params-tail
      (values (nreverse variables) (nreverse types))))
  (let ((parameter (first remaining)))
    (unless (?varp parameter)
      (error "Expecting a ?variable in a query/update parameter list, found ~A in ~A"
             parameter remaining))
    (let ((next (second remaining)))
      (cond ((null (rest remaining))
             (dissect-query-params-tail nil
                                        (cons parameter variables)
                                        (cons nil types)))
            ((query/update-parameter-type-p next)
             (dissect-query-params-tail (cddr remaining)
                                        (cons parameter variables)
                                        (cons next types)))
            ((?varp next)
             (dissect-query-params-tail (rest remaining)
                                        (cons parameter variables)
                                        (cons nil types)))
            (t
             (error "Expecting a ?variable or Wouldwork object type after ~A, found ~A in ~A"
                    parameter next remaining))))))


(defun dissect-query-params (args)
  "Parse a DEFINE-QUERY/DEFINE-UPDATE signature.
   Every formal parameter is a ?variable optionally followed by a Wouldwork object
   type or an inline (EITHER ...) object type. Returns the formal variables and a
   positionally aligned type list containing NIL for each untyped parameter."
  (check-type args list)
  (dissect-query-params-tail args nil nil))


(defun dissect-eff-params (eff-parameter-list)
  "Returns a list of primitive eff-parameter variables and types."
  (iter (for (var-form type-form) on eff-parameter-list by #'cddr)
        (cond ((atom var-form)
                 (collecting var-form into vars)
                 (collecting type-form into types))
              ((listp var-form)
                 (appending var-form into vars)
                 (appending (make-list (length var-form) :initial-element type-form) into types)))
        (finally (return (values vars types)))))

     
(defun instantiate-type-spec (pre-type-spec)
  "Given the pre-type-spec from dissect-pre-params,
   eg (product gate (get-remaining? ladder) (product fan fan)),
   instantiate all of the included types,
   eg (product (gate1 gate2) (get-remaining? ladder) (product (fan1 fan2) (fan1 fan2)))."
  (iter (for item in pre-type-spec)
        (cond ((member item *parameter-headers*) ;collect header
                 (collecting item))
              ((nth-value 1 (gethash item *types*))  ;collect type instances
                 (collecting (gethash item *types*)))
              ((and (listp item)  ;collect dynamic query
                    (member (first item) *query-names*))
                 (collecting item))
              (($varp item)  ;collect $variable domain, evaluated at runtime
                 (collecting item))
              ((and (listp item)
                    (member (first item) *parameter-headers*))
                 (collecting (instantiate-type-spec item))))))


(defun eval-instantiated-spec (instantiated-pre-type-spec &optional state)
  "Receives possibly nested static or dynamic input from instantiate-type-spec,
   and evaluates it. Works with state, idb parameter."
  (iter (for item in instantiated-pre-type-spec)
        (cond ((member item *parameter-headers*)
                 (collecting item into instantiated-spec))
              ((and (listp item)
                    (member (first item) *query-names*))
                 (collecting (apply (first item) state (cdr item)) into instantiated-spec))
              ((and (listp item)
                    (member (first item) *parameter-headers*))
                 (collecting (eval-instantiated-spec item state) into instantiated-spec))
              ((listp item)
                 (collecting item into instantiated-spec))
              (t (error "Unexpected item ~A in dynamic-spec ~A" item instantiated-pre-type-spec)))
        (finally (return (get-pre-lambda-arg-lists instantiated-spec)))))


(defun get-pre-lambda-arg-lists (instantiated-spec)
  "Returns list of instantiations as arg list for a rule precondition."
  (when (or (equal instantiated-spec '(standard))  ;no precondition parameters
            (equal instantiated-spec '(standard nil)))
    (return-from get-pre-lambda-arg-lists '((nil))))
  (let ((header (first instantiated-spec))
        (value-lists (cdr instantiated-spec)))
    ;; Fast path for single-parameter case (no filtering needed)
    (when (null (cdr value-lists))
      (return-from get-pre-lambda-arg-lists (mapcar #'list (first value-lists))))
    (if (eql header 'dot-product)
      (apply #'mapcar #'list value-lists)
      ;; Pre-check if all elements are atoms (symbols, numbers, characters)
      ;; to enable faster eql comparisons vs equalp for list instances
      (let* ((all-atoms-p (every (lambda (lst) (every #'atom lst)) value-lists))
             (element-test (if all-atoms-p #'eql #'equalp))
             (product-values (apply #'alexandria:map-product #'list value-lists)))
        (if (eql header 'product)
          product-values
          (let ((set-values (remove-if-not (lambda (x) 
                                             (alexandria:setp x :test element-test))
                                           product-values)))
            (if (eql header 'combination)
              (or (delete-duplicates set-values 
                                     :test (if all-atoms-p
                                             #'alexandria:set-equal
                                             (lambda (a b) 
                                               (alexandria:set-equal a b :test #'equalp))))
                  (make-list (length value-lists) :initial-element nil))
              (if (eql header 'standard)
                (or set-values
                    (make-list (length value-lists) :initial-element nil))
                (error "Unknown header label ~A in an instantiated-spec: ~A"
                       header instantiated-spec)))))))))


;;; =========================
;;; WW TIMING (coarse counters)
;;; =========================


(defvar *ww-timing-enabled* nil
  "When true, ww-with-timing records inclusive CPU time per label.")


(defvar *ww-timing-table* (make-hash-table :test #'eq)
  "Maps label -> #(ticks calls). ticks are GET-INTERNAL-RUN-TIME deltas.")


(defun ww-reset-timing ()
  (clrhash *ww-timing-table*)
  t)


(defun ww--timing-cell (label)
  (or (gethash label *ww-timing-table*)
      (setf (gethash label *ww-timing-table*)
            (vector 0 0))))

(defun ww--timing-add (label ticks)
  (let ((cell (ww--timing-cell label)))
    (incf (aref cell 0) ticks)
    (incf (aref cell 1) 1))
  nil)


#+ignore (defmacro ww-with-timing (label &body body)  ;disables timing instrumentation
  (declare (ignore label))
  `(progn ,@body))


(defmacro ww-with-timing (label &body body)  ;enables timing instrumentation
  "Inclusive CPU-time timing for BODY under LABEL."
  (let ((start (gensym "START")))
    `(if *ww-timing-enabled*
         (let ((,start (get-internal-run-time)))
           (multiple-value-prog1 (progn ,@body)
             (ww--timing-add ,label (- (get-internal-run-time) ,start))))
         (progn ,@body))))


(defun ww-report-timing (&key (stream *standard-output*) (top 30))
  "Print timings sorted by total seconds."
  (let* ((units internal-time-units-per-second)
         (rows nil)
         (total-ticks 0))
    (maphash (lambda (label cell)
               (let ((ticks (aref cell 0))
                     (calls (aref cell 1)))
                 (incf total-ticks ticks)
                 (push (list label ticks calls) rows)))
             *ww-timing-table*)
    (setf rows (sort rows #'> :key #'second))
    (format stream "~%~%=== WW TIMING (inclusive CPU) ===~%")
    (format stream "Total timed: ~,3F s~%~%"
            (/ (float total-ticks) units))
    (format stream "~16A ~12A ~12A ~12A ~10A~%"
            "label" "seconds" "calls" "sec/call" "%")
    (format stream "~A~%" (make-string 68 :initial-element #\-))
    (loop for (label ticks calls) in rows
          for i from 1
          while (<= i top)
          for sec = (/ (float ticks) units)
          for spc = (if (plusp calls) (/ sec calls) 0.0)
          for pct = (if (plusp total-ticks) (* 100.0 (/ ticks total-ticks)) 0.0)
          do (format stream "~16S ~12,3F ~12D ~12,6F ~9,1F~%"
                     label sec calls spc pct))
    (terpri stream)
    t))


;;;; heuristic calculations ;;;;


(defun combine-heuristics (state specs &key (combiner :weighted-sum) admissible)
  "Combines weighted heuristic components into single cost estimate.
   SPECS: list of (weight . function-symbol) pairs
   COMBINER: :weighted-sum | :max | :sum
   Returns: non-negative numeric estimate"
  (declare (ignore admissible))
  (let ((result
          (ecase combiner
            (:weighted-sum 
             (loop for (weight . fn) in specs
                   for raw-value = (funcall fn state)
                   for weighted-value = (* weight raw-value)
                   sum weighted-value))
            (:max 
             (loop for (weight . fn) in specs
                   maximize (funcall fn state)))
            (:sum 
             (loop for (weight . fn) in specs
                   sum (funcall fn state))))))
    result))
